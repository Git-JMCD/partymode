# SPDX-License-Identifier: GPL-3.0-or-later
"""
remesh_asset: a clean quad mesh for a generated or scanned model, with its detail baked into
textures instead of polygons.

The recipe, proven on generated props (TripoSG): weld the parts a generated mesh is split into
along its UV seams, remesh the welded copy to quads (Smart Remesh when installed, else Blender's
own QuadriFlow), measure how far the new surface strays from the original and whether it folded,
bake colour, roughness and normal from the original onto the new mesh, then swap names: the new
mesh takes the original's name and parent, the original is kept, excluded, in HighPoly_Source.
"""

import json
import math
import os
import shutil
import subprocess
import tempfile
import time

import bmesh
import bpy
import numpy as np
from mathutils.bvhtree import BVHTree

from . import cancel, childwatch, mainthread
from .registry import ToolError, get_object, r, tool, world_bounds
from .tools_inspect import _mesh_health, _summarise

HP_COLLECTION = "HighPoly_Source"
_TARGETS = {"simple": 4000, "detailed": 12000}
_SIZES = {"simple": 1024, "detailed": 2048}
_SAMPLES = 3000


# ---------------------------------------------------------------------------
# Measuring.

def _parts(me) -> int:
    """Connected pieces of a mesh (vertices joined by edges)."""
    n = len(me.vertices)
    if not n:
        return 0
    edges = np.empty(len(me.edges) * 2, np.int64)
    me.edges.foreach_get("vertices", edges)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for a, b in edges.reshape(-1, 2).tolist():
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    return len({find(i) for i in range(n)})


def _quad_share(me) -> float:
    if not len(me.polygons):
        return 0.0
    sizes = np.empty(len(me.polygons), np.int32)
    me.polygons.foreach_get("loop_total", sizes)
    return float((sizes == 4).mean())


def _world_bm(me, mw):
    """A bmesh copy in world space with consistent outward normals (generated meshes mix them)."""
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.transform(mw)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.normal_update()
    return bm


def _every(seq, limit):
    step = max(1, len(seq) // limit)
    return seq[::step]


def _measure(hp_bm, low_ob):
    """How the remeshed surface compares with the original: distance (mm) and folded faces."""
    tree = BVHTree.FromBMesh(hp_bm)
    low = _world_bm(low_ob.data, low_ob.matrix_world)
    try:
        dists = []
        for v in _every(low.verts[:], _SAMPLES):
            hit = tree.find_nearest(v.co)
            if hit[0] is not None:
                dists.append(hit[3])
        folded = total = 0
        for f in _every(low.faces[:], _SAMPLES):
            hit = tree.find_nearest(f.calc_center_median())
            if hit[0] is not None:
                total += 1
                folded += f.normal.dot(hit[1]) < 0
        area = sum(f.calc_area() for f in low.faces)
        edge = math.sqrt(area / max(1, len(low.faces)))
    finally:
        low.free()
    d = np.array(dists) if dists else np.zeros(1)
    return {"mean_mm": r(d.mean() * 1000, 2), "p95_mm": r(np.percentile(d, 95) * 1000, 2),
            "max_mm": r(d.max() * 1000, 2)}, (folded / total if total else 0.0), edge, d


def _thin_walls(hp_bm, edge):
    """Wall thickness, measured inward from the original's surface. Walls thinner than the new
    quads fold the inside onto the outside when remeshed."""
    tree = BVHTree.FromBMesh(hp_bm)
    thick = []
    for f in _every(hp_bm.faces[:], _SAMPLES):
        n = f.normal
        if n.length < 0.5:
            continue
        start = f.calc_center_median() - n * 1e-5
        hit = tree.ray_cast(start, -n, edge * 20)
        # No hit within 20 quads: thicker than that (or open on that side), so not thin.
        thick.append(hit[3] if hit[0] is not None else math.inf)
    if not thick:
        return None
    t = np.array(thick)
    share = float((t < edge * 1.5).mean())
    finite = t[np.isfinite(t)]
    return {"median_mm": r(np.median(finite) * 1000, 2) if len(finite) > len(t) / 2 else None,
            "thinner_than_quads_share": r(share, 3), "quad_edge_mm": r(edge * 1000, 2), "thin": share > 0.15}


# ---------------------------------------------------------------------------
# Remeshing.

def smart_remesh_available() -> bool:
    prefs = bpy.context.preferences.addons
    return (any(k.endswith("smart_remesh") for k in prefs.keys())
            and hasattr(bpy.types.Scene, "quadremesh") and hasattr(bpy.ops.mesh, "quadremesh_run"))


def _only(ob):
    return {"object": ob, "active_object": ob, "selected_objects": [ob], "selected_editable_objects": [ob]}


def _smart_remesh(work, target, stalls):
    """Smart Remesh (Superhive) on the welded copy: a new '<name>_S-Remesh' object, all quads.
    Its Instant Meshes runs can freeze without a word; a watch stops one that sits idle (see
    childwatch), and Smart Remesh carries on with its other attempts."""
    st = bpy.context.scene.quadremesh
    want = {"backend": "AUTO", "solid_rebuild": "AUTO", "mode": "FACES", "target_faces": target, "replace": False}
    old = {k: getattr(st, k) for k in want if hasattr(st, k)}
    before = set(bpy.data.objects)
    try:
        for k, v in want.items():
            if hasattr(st, k):
                setattr(st, k, v)
        with childwatch.watch("instant meshes") as w, bpy.context.temp_override(**_only(work)):
            try:
                res = bpy.ops.mesh.quadremesh_run('EXEC_DEFAULT')
            except RuntimeError as ex:
                res = {'CANCELLED', str(ex).strip()[:200]}
        stalls.extend(w.stopped)
    finally:
        for k, v in old.items():
            try:
                setattr(st, k, v)
            except (TypeError, ValueError):
                pass
    made = [o for o in bpy.data.objects if o not in before and o.type == 'MESH']
    if 'FINISHED' not in res or not made:
        raise ToolError("Smart Remesh did not finish ({}). Try remesher='quadriflow'.".format(", ".join(res)))
    low = max(made, key=lambda o: len(o.data.polygons))
    for o in made:
        if o is not low:
            bpy.data.objects.remove(o)
    _remove(work)
    return low, "smart_remesh"


_WORKER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "remesh_worker.py")
_MARKER = "AGENT_BRIDGE_REMESH "
QUADRIFLOW_TIMEOUT_S = 300


def _run_child(src, dst, opts, timeout_s, label, on_main):
    """Run remesh_worker.py in a child Blender on the mesh saved in `src`; returns its report, or
    None when it ran out of time. A stop, Escape or the time limit kills the child, so a QuadriFlow
    that never returns costs only that process. `on_main`: this is Blender's main thread, where a
    stop arrives as AgentStopped; off it (the usual way), `stop` kills the child directly."""
    cmd = [bpy.app.binary_path, "-b", "--factory-startup", "-noaudio", "--python-exit-code", "3",
           "--python", _WORKER, "--", src, dst, json.dumps(opts)]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    reason, timed_out, out = None, False, b""
    with cancel.child(label, proc) as kid:
        try:
            if on_main:
                # Waits in short slices: a stop lands between them (it can't inside the C wait).
                with cancel.running(label, timeout_s):
                    while proc.poll() is None:
                        try:
                            proc.wait(0.2)
                        except subprocess.TimeoutExpired:
                            pass
            else:
                try:
                    out = proc.communicate(timeout=timeout_s)[0] or b""
                except subprocess.TimeoutExpired:
                    timed_out = True
        except cancel.AgentStopped:
            reason = cancel.last_reason() or "stopped"
        finally:
            if proc.poll() is None:
                proc.kill()
            out = out or proc.communicate()[0] or b""
        reason = reason or kid.killed
    if timed_out or reason == "time limit reached":
        return None
    if reason:
        raise ToolError("Stopped: {}. The original is unchanged.".format(reason))
    text = out.decode("utf-8", "replace")
    report = None
    for line in text.splitlines():
        if line.startswith(_MARKER):
            report = json.loads(line[len(_MARKER):])
    if report is None:
        raise ToolError("The remesh Blender exited ({}) without a result: {}".format(proc.returncode, text[-1500:]))
    if "error" in report:
        said = [ln.split(":", 1)[1].strip() for ln in text.splitlines() if ln.startswith(("Warning:", "Error:"))]
        raise ToolError("; ".join(said + [report["error"]]).rstrip(".") + ".")
    return report


def _quadriflow_files(src, mesh, target, diag, timeout_s, on_main):
    """Blender's own QuadriFlow on the mesh saved in `src`, in a child Blender (see remesh_worker).
    It needs a closed mesh with no edge under 0.1 mm, so the copy runs scaled up to 10 m; when it
    still refuses, a voxel remesh closes the shape first. If the first run never finishes
    (QuadriFlow can loop forever on a mesh it accepts), a second goes straight to the voxel remesh
    with the time left. Returns the report, with the result's file in `dst` and mesh in `out_name`."""
    k = max(1.0, 10.0 / max(diag, 1e-6))
    folder = os.path.dirname(src)
    opts = {"target_faces": target, "scale": k, "voxel_size": diag / 150.0, "mesh": mesh, "out_name": mesh + "_quads"}
    t0 = time.monotonic()
    dst = os.path.join(folder, "out1.blend")
    report = _run_child(src, dst, opts, timeout_s * 0.5, "remeshing with QuadriFlow", on_main)
    if report is None:
        left = timeout_s - (time.monotonic() - t0)
        dst = os.path.join(folder, "out2.blend")
        report = _run_child(src, dst, dict(opts, voxel_first=True), max(left, 10.0),
                            "remeshing with QuadriFlow (after a voxel remesh)", on_main)
        if report is None:
            raise ToolError("QuadriFlow didn't finish within {:.0f}s, even after a voxel remesh, so its separate "
                            "Blender was stopped. The original is unchanged. Try fewer target_faces, a longer "
                            "timeout_s, or Smart Remesh (Superhive) if you have it.".format(timeout_s))
        report["used"] += ", after the first run hung"
    return dict(report, dst=dst, out_name=opts["out_name"])


def _load_result(work, report):
    """Main thread: the child's mesh replaces the welded copy's."""
    with bpy.data.libraries.load(report["dst"]) as (_, data_to):
        data_to.meshes = [report["out_name"]]
    old = work.data
    work.data = data_to.meshes[0]
    if old.users == 0:
        bpy.data.meshes.remove(old)
    return work, report["used"]


def _quadriflow(work, target, diag, timeout_s=QUADRIFLOW_TIMEOUT_S):
    """QuadriFlow on the welded copy, waiting on the main thread: only when Smart Remesh failed
    mid-call. Normally _prepare ran it before the edit, off the main thread."""
    folder = tempfile.mkdtemp(prefix="agent_bridge_remesh_")
    try:
        src = os.path.join(folder, "in.blend")
        bpy.data.libraries.write(src, {work.data})
        return _load_result(work, _quadriflow_files(src, work.data.name, target, diag, timeout_s, True))
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def _weld(src, dist):
    """A welded copy of `src`'s mesh after modifiers (not linked anywhere), and the face count
    before welding: a generated mesh comes in split along its UV seams."""
    dg = bpy.context.evaluated_depsgraph_get()
    bm = bmesh.new()
    bm.from_object(src, dg)
    faces = len(bm.faces)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=dist)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    me = bpy.data.meshes.new(src.name + "_weld")
    bm.to_mesh(me)
    bm.free()
    return me, faces


def _signature(src):
    return [src.name, src.data.name, len(src.data.vertices), len(src.data.polygons), [m.name for m in src.modifiers]]


def _checked(args):
    """The object and settings, checked the same way in _prepare and in the edit."""
    src = get_object(args["object"])
    if src.type != 'MESH':
        raise ToolError("{!r} is a {}, not a mesh.".format(src.name, src.type))
    if src.mode != 'OBJECT' or bpy.context.mode != 'OBJECT':
        raise ToolError("Leave edit or sculpt mode first (remesh_asset works in Object Mode).")
    choice = args.get("remesher", "auto")
    if choice == "smart_remesh" and not smart_remesh_available():
        raise ToolError("Smart Remesh is not installed or not enabled; use remesher='quadriflow' "
                        "(built into Blender) or enable it in Preferences > Add-ons.")
    use_smart = choice == "smart_remesh" or (choice == "auto" and smart_remesh_available())
    target = int(args.get("target_faces") or _TARGETS[args.get("detail", "simple")])
    lo, hi = world_bounds(src)
    return src, choice, use_smart, target, (hi - lo).length


def _prepare(args):
    """Server thread, before the edit: weld and save a copy on the main thread (quick), then run
    QuadriFlow in a child Blender while Blender's main thread stays free for the user. The edit
    then loads the result as one undo step. Smart Remesh runs inside the edit as before."""
    def export():
        src, _, use_smart, target, diag = _checked(args)
        if use_smart:
            return None
        me, _ = _weld(src, float(args.get("weld_distance", 0.0002)))
        name = me.name
        folder = tempfile.mkdtemp(prefix="agent_bridge_remesh_")
        path = os.path.join(folder, "in.blend")
        try:
            bpy.data.libraries.write(path, {me})
        finally:
            bpy.data.meshes.remove(me)
        return {"dir": folder, "src": path, "mesh": name, "target": target, "diag": diag, "sig": _signature(src)}

    try:
        info = mainthread.run_on_main(export, 60)
    except ToolError:
        return args  # the edit reports it, in the usual way
    if info is None:
        return args
    try:
        report = _quadriflow_files(info["src"], info["mesh"], info["target"], info["diag"],
                                   float(args.get("timeout_s", QUADRIFLOW_TIMEOUT_S)), False)
    except BaseException:
        shutil.rmtree(info["dir"], ignore_errors=True)
        raise
    return dict(args, _remesh=dict(info, report=report))


def _remove(ob):
    me = ob.data if ob.type == 'MESH' else None
    bpy.data.objects.remove(ob)
    if me is not None and me.users == 0:
        bpy.data.meshes.remove(me)


# ---------------------------------------------------------------------------
# Baking.

def _uv_unwrap(low, pad):
    """Smart UV Project cuts the islands, then _pack_uvs lays them out (Smart UV Project's own
    packing can leave a generated shape's islands in a tenth of the texture). Edit Mode acts on
    the scene's own active object, so that is set for the duration. Returns the share of the
    texture the islands cover."""
    me = low.data
    for layer in list(me.uv_layers):
        me.uv_layers.remove(layer)
    me.uv_layers.new(name="UVMap")
    vl = bpy.context.view_layer
    active = vl.objects.active
    # Edit Mode takes in every selected object, and Smart UV Project would unwrap them all:
    # only the new mesh is selected while it runs.
    selected = [o for o in vl.objects if o.select_get()]
    for o in selected:
        o.select_set(False)
    low.select_set(True)
    vl.objects.active = low
    try:
        with bpy.context.temp_override(**_only(low)):
            bpy.ops.object.mode_set(mode='EDIT')
            try:
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.uv.smart_project(angle_limit=1.15, island_margin=0.0)
            finally:
                bpy.ops.object.mode_set(mode='OBJECT')
    finally:
        low.select_set(False)
        for o in selected:
            o.select_set(True)
        vl.objects.active = active
    return _pack_uvs(me, pad)


def _islands(bm, uv):
    """UV islands: faces joined across edges whose two sides share UV coordinates."""
    def key(loop):
        c = loop[uv].uv
        return round(c.x, 6), round(c.y, 6)
    parent = list(range(len(bm.faces)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for e in bm.edges:
        if len(e.link_loops) == 2:
            a, b = e.link_loops
            if {key(a), key(a.link_loop_next)} == {key(b), key(b.link_loop_next)}:
                parent[find(a.face.index)] = find(b.face.index)
    groups = {}
    for f in bm.faces:
        groups.setdefault(find(f.index), []).append(f)
    return list(groups.values())


def _shelves(boxes, width, pad):
    """Rows left to right, tallest first: (x, y) per box and the layout's size."""
    x = y = row = used = 0.0
    spots = [None] * len(boxes)
    for i in sorted(range(len(boxes)), key=lambda i: -boxes[i][1]):
        w, h = boxes[i]
        if x > 0 and x + w > width:
            x, y = 0.0, y + row + pad
            row = 0.0
        spots[i] = (x, y)
        x += w + pad
        used = max(used, x - pad)
        row = max(row, h)
    return spots, max(used, 1e-9), y + row


def _pack_uvs(me, pad):
    """Lay the islands out in shelves (each turned so it lies flat), scaled to fill the square,
    `pad` apart in the final texture. Returns the share of the texture they cover."""
    bm = bmesh.new()
    bm.from_mesh(me)
    try:
        bm.faces.ensure_lookup_table()
        uv = bm.loops.layers.uv.active
        islands = []
        for faces in _islands(bm, uv):
            pts = np.array([tuple(l[uv].uv) for f in faces for l in f.loops])
            lo, hi = pts.min(axis=0), pts.max(axis=0)
            w, h = hi - lo
            islands.append((faces, lo, h > w, (max(w, h), min(w, h))))
        area = sum(b[0] * b[1] for *_, b in islands)
        boxes = [b for *_, b in islands]

        def layout(gap):
            """The widest-scaled shelf layout over a few row widths, `gap` between islands."""
            best = None
            for k in (0.8, 0.9, 1.0, 1.1, 1.25, 1.5):
                spots, w, h = _shelves(boxes, math.sqrt(area) * k, gap)
                scale = (1.0 - 2 * pad) / max(w, h)
                if best is None or scale > best[0]:
                    best = (scale, spots)
            return best
        # The gap is wanted in final texture units, which depend on the scale: find it, then use it.
        scale, spots = layout(pad / layout(pad)[0])
        for (faces, lo, turn, (bw, bh)), (x, y) in zip(islands, spots):
            for f in faces:
                for l in f.loops:
                    u, v = l[uv].uv.x - lo[0], l[uv].uv.y - lo[1]
                    if turn:  # a quarter turn (not a mirror), so it lies along the shelf
                        u, v = v, bh - u
                    l[uv].uv = (pad + (x + u) * scale, pad + (y + v) * scale)
        bm.to_mesh(me)
        total = 0.0
        for f in bm.faces:
            c = [l[uv].uv for l in f.loops]
            total += abs(sum(c[i].x * c[i - 1].y - c[i - 1].x * c[i].y for i in range(len(c)))) / 2
        return total
    finally:
        bm.free()


def _baked_material(name, size):
    mat = bpy.data.materials.new(name + "_Baked")
    if mat.node_tree is None:  # new materials have a node tree from Blender 5
        mat.use_nodes = True
    nt = mat.node_tree
    bsdf = next(n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED')
    images, nodes = {}, {}
    for i, (key, data) in enumerate((("BaseColor", False), ("Roughness", True), ("Normal", True))):
        img = bpy.data.images.new("{}_{}".format(name, key), size, size, alpha=False)
        if data:
            img.colorspace_settings.name = 'Non-Color'
        node = nt.nodes.new("ShaderNodeTexImage")
        node.image = img
        node.location = (bsdf.location.x - 600, bsdf.location.y - 300 * i)
        images[key], nodes[key] = img, node
    nt.links.new(nodes["BaseColor"].outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(nodes["Roughness"].outputs["Color"], bsdf.inputs["Roughness"])
    nmap = nt.nodes.new("ShaderNodeNormalMap")
    nmap.location = (bsdf.location.x - 250, bsdf.location.y - 600)
    nt.links.new(nodes["Normal"].outputs["Color"], nmap.inputs["Color"])
    nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    return mat, images, nodes


def _bake(hp, low, name, size, extrusion, ray):
    """Cycles, selected to active: the original's colour, roughness and normal onto the new mesh."""
    scene = bpy.context.scene
    vl = bpy.context.view_layer
    mat, images, nodes = _baked_material(name, size)
    low.data.materials.clear()
    low.data.materials.append(mat)
    bake = scene.render.bake
    saved = {"engine": scene.render.engine, "samples": scene.cycles.samples,
             "bake": {k: getattr(bake, k) for k in ("use_selected_to_active", "cage_extrusion", "max_ray_distance",
                                                     "margin", "use_clear", "target", "use_cage")}}
    selected = [o for o in vl.objects if o.select_get()]
    active = vl.objects.active
    try:
        scene.render.engine = 'CYCLES'
        scene.cycles.samples = 8
        for o in selected:
            o.select_set(False)
        hp.select_set(True)
        low.select_set(True)
        vl.objects.active = low
        override = {"object": low, "active_object": low, "selected_objects": [hp, low],
                    "selected_editable_objects": [hp, low]}
        for key, kind, extra in (("BaseColor", 'DIFFUSE', {"pass_filter": {'COLOR'}}),
                                 ("Roughness", 'ROUGHNESS', {}),
                                 ("Normal", 'NORMAL', {"normal_space": 'TANGENT'})):
            for n in mat.node_tree.nodes:
                n.select = False
            nodes[key].select = True
            mat.node_tree.nodes.active = nodes[key]
            with bpy.context.temp_override(**override):
                bpy.ops.object.bake(type=kind, use_selected_to_active=True, use_cage=False, cage_extrusion=extrusion,
                                    max_ray_distance=ray, margin=8, use_clear=True, target='IMAGE_TEXTURES', **extra)
        for img in images.values():
            img.pack()
    finally:
        scene.render.engine = saved["engine"]
        scene.cycles.samples = saved["samples"]
        for k, v in saved["bake"].items():
            setattr(bake, k, v)
        hp.select_set(False)
        low.select_set(False)
        for o in selected:
            if o.name in vl.objects:
                o.select_set(True)
        vl.objects.active = active if active and active.name in vl.objects else low
    return mat, images


def _missed(low, img):
    """Share of the new mesh's faces whose spot in the baked colour stayed pure black: the bake
    rays found nothing there (cage too tight or rays too short)."""
    me = low.data
    uv = me.uv_layers.active
    if uv is None or not len(me.polygons):
        return None
    n = len(me.polygons)
    starts = np.empty(n, np.int64)
    totals = np.empty(n, np.int64)
    me.polygons.foreach_get("loop_start", starts)
    me.polygons.foreach_get("loop_total", totals)
    coords = np.empty(len(me.loops) * 2, np.float32)
    uv.data.foreach_get("uv", coords)
    coords = coords.reshape(-1, 2)
    pick = np.arange(0, n, max(1, n // _SAMPLES))
    centres = np.array([coords[starts[i]:starts[i] + totals[i]].mean(axis=0) for i in pick])
    w, h = img.size
    px = np.empty(w * h * 4, np.float32)
    img.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    x = np.clip((centres[:, 0] % 1.0) * w, 0, w - 1).astype(int)
    y = np.clip((centres[:, 1] % 1.0) * h, 0, h - 1).astype(int)
    return float((px[y, x, :3].sum(axis=1) < 1e-6).mean())


def _image_stats(img):
    px = np.empty(len(img.pixels), np.float32)
    img.pixels.foreach_get(px)
    rgb = px.reshape(-1, 4)[:, :3]
    return {"mean": [r(x, 3) for x in rgb.mean(axis=0)], "spread": r(float(rgb.std()), 3)}


# ---------------------------------------------------------------------------
# Finishing.

def _high_poly_collection(scene, vl):
    coll = bpy.data.collections.get(HP_COLLECTION)
    if coll is None:
        coll = bpy.data.collections.new(HP_COLLECTION)
    if coll.name not in scene.collection.children:
        scene.collection.children.link(coll)

    def find(lc):
        if lc.collection is coll:
            return lc
        for child in lc.children:
            got = find(child)
            if got:
                return got
        return None
    lc = find(vl.layer_collection)
    if lc is not None:
        lc.exclude = True
    return coll


@tool("remesh_asset",
      "Turn a generated or scanned mesh (many pieces, messy triangles) into a clean quad mesh, "
      "with its detail baked into textures instead of polygons. Welds the pieces a generated "
      "mesh is split into, remeshes to quads (Smart Remesh when installed, else Blender's "
      "QuadriFlow), measures how far the new surface strays from the original (mm) and whether "
      "faces folded, bakes colour, roughness and normal from the original onto the new mesh, then "
      "gives the new mesh the original's name and parent; the original is kept, excluded, in "
      "the HighPoly_Source collection. detail: simple (4000 faces, 1K textures) or detailed "
      "(12000, 2K); target_faces and texture_size override. Thin walls (a bucket's) fold when "
      "remeshed: the reply's thin_walls says so. Fix colours on the original before baking. "
      "Can take a minute or more; if the call times out it keeps running (call_status). QuadriFlow runs in "
      "a separate Blender: timeout_s (default 300) or a stop ends it, and the original stays as it was.",
      {"object": {"type": "string", "description": "The mesh to remesh."},
       "detail": {"type": "string", "enum": ["simple", "detailed"], "default": "simple"},
       "target_faces": {"type": "integer", "minimum": 100, "maximum": 200000},
       "remesher": {"type": "string", "enum": ["auto", "smart_remesh", "quadriflow"], "default": "auto",
                    "description": "auto: Smart Remesh when installed, else QuadriFlow."},
       "bake": {"type": "boolean", "default": True,
                "description": "Bake colour, roughness and normal from the original (else keep its materials)."},
       "texture_size": {"type": "integer", "enum": [512, 1024, 2048, 4096]},
       "weld_distance": {"type": "number", "minimum": 0, "maximum": 0.01, "default": 0.0002,
                         "description": "Vertices closer than this (m) are welded before remeshing."},
       "cage_extrusion": {"type": "number", "minimum": 0,
                          "description": "Bake cage push-out (m). Default: from the measured distance."},
       "max_ray_distance": {"type": "number", "minimum": 0, "description": "Bake ray length (m)."},
       "timeout_s": {"type": "number", "minimum": 10, "maximum": 1800, "default": QUADRIFLOW_TIMEOUT_S,
                     "description": "Time limit for QuadriFlow, which can loop forever on some meshes."},
       "keep_high_poly": {"type": "boolean", "default": True,
                          "description": "Keep the original in HighPoly_Source (else delete it)."}},
      required=("object",), mutating=True, prepare=_prepare)
def remesh_asset(args):
    pre = args.get("_remesh")
    try:
        return _remesh_asset(args, pre)
    finally:
        if pre:
            shutil.rmtree(pre["dir"], ignore_errors=True)


def _remesh_asset(args, pre):
    t0 = time.time()
    src, choice, use_smart, target, diag = _checked(args)
    if pre and _signature(src) != pre["sig"]:
        raise ToolError("{!r} changed while it was being remeshed; nothing was replaced. Run it again.".format(src.name))
    detail = args.get("detail", "simple")
    size = int(args.get("texture_size") or _SIZES[detail])
    name = src.name
    scene, vl = bpy.context.scene, bpy.context.view_layer
    warnings = []

    # 1. Weld a copy (after modifiers): a generated mesh comes in split along its UV seams.
    work_me, before_faces = _weld(src, float(args.get("weld_distance", 0.0002)))
    work = bpy.data.objects.new(name + "_weld", work_me)
    for c in src.users_collection:
        c.objects.link(work)
    work.matrix_world = src.matrix_world.copy()
    parts = {"before": _parts(src.data), "welded": _parts(work_me)}
    if parts["welded"] > 1:
        warnings.append("{} separate pieces after welding: each is remeshed on its own (weld_distance "
                        "higher, or join them)".format(parts["welded"]))
    hp_bm = _world_bm(work_me, work.matrix_world)

    low = None
    try:
        # 2. Remesh.
        stalls = []
        used = None
        if use_smart:
            try:
                low, used = _smart_remesh(work, target, stalls)
            except ToolError as ex:
                if choice != "auto":
                    raise
                warnings.append("Smart Remesh failed ({}); used QuadriFlow instead".format(ex))
        if used is None and pre:
            low, used = _load_result(work, pre["report"])  # remeshed before the edit, off the main thread
        elif used is None:
            low, used = _quadriflow(work, target, diag, float(args.get("timeout_s", QUADRIFLOW_TIMEOUT_S)))
        if stalls:
            warnings.append("stopped {} Instant Meshes run(s) that froze (no CPU use for 30 s); Smart Remesh "
                            "used its other attempts".format(len(stalls)))
        work = None  # remeshed in place, or removed by Smart Remesh's path
        me = low.data
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
        for c in list(low.users_collection):
            c.objects.unlink(low)
        for c in src.users_collection:
            c.objects.link(low)

        # 3. Measure against the original.
        shape, folded, edge, dists = _measure(hp_bm, low)
        walls = _thin_walls(hp_bm, edge)
        if folded > 0.03:
            warnings.append("{:.0%} of the new faces face the wrong way (folded through a thin wall?)".format(folded))
        if walls and walls["thin"]:
            warnings.append("thin walls: {:.0%} of the surface is thinner than the new quads ({} mm); they fold "
                            "inside onto outside. Remesh one side and add Solidify, or model it.".format(
                                walls["thinner_than_quads_share"], walls["quad_edge_mm"]))
        hp_bm.free()
        hp_bm = None

        # 4. Bake the original's detail onto the new mesh.
        baked = None
        has_material = any(s.material and s.material.node_tree for s in src.material_slots)
        if args.get("bake", True) and has_material:
            p95, worst = float(np.percentile(dists, 95)), float(dists.max())
            extrusion = float(args.get("cage_extrusion") or max(p95 * 2, diag * 0.006))
            ray = float(args.get("max_ray_distance") or max(extrusion * 4, worst * 2))
            # Islands two bake margins apart (8 px each side), so the margins don't bleed into each other.
            coverage = _uv_unwrap(low, 18.0 / size)
            tries = 0
            while True:
                tries += 1
                mat, images = _bake(src, low, name, size, extrusion, ray)
                missed = _missed(low, images["BaseColor"])
                given = args.get("cage_extrusion") or args.get("max_ray_distance")
                if missed is None or missed <= 0.02 or tries > 1 or given:
                    break
                # Rays found nothing on part of the mesh: once more, reaching further.
                for img in images.values():
                    bpy.data.images.remove(img)
                bpy.data.materials.remove(mat)
                extrusion, ray = extrusion * 2, ray * 2
            baked = {"material": mat.name, "size": size, "images": {k: v.name for k, v in images.items()},
                     "base_color": _image_stats(images["BaseColor"]), "packed": True,
                     "uv_coverage": r(coverage, 3),
                     "missed_share": r(missed, 4) if missed is not None else None, "tries": tries,
                     "cage_extrusion_m": r(extrusion, 5), "max_ray_distance_m": r(ray, 5)}
            if missed is not None and missed > 0.02:
                warnings.append("the bake missed {:.0%} of the surface (black there): raise cage_extrusion and "
                                "max_ray_distance, or check the original sits where the new mesh is".format(missed))
            if coverage < 0.25:
                warnings.append("the UV islands cover only {:.0%} of the texture: the bake is low resolution and "
                                "darkens when seen small".format(coverage))
            if baked["base_color"]["spread"] < 0.005:
                warnings.append("the baked colour is flat: check it with render_view look=lit")
        else:
            low.data.materials.clear()
            for s in src.material_slots:
                low.data.materials.append(s.material)
            if args.get("bake", True):
                baked = {"skipped": "the original has no material to bake from; its materials were kept"}
    except Exception:
        for ob in (work, low):
            try:
                if ob is not None and ob is not src:
                    _remove(ob)
            except ReferenceError:
                pass
        raise
    finally:
        if hp_bm is not None:
            hp_bm.free()

    # 5. Swap names: the new mesh takes the original's place.
    parent, mw = src.parent, low.matrix_world.copy()
    src.name = name + "_HP"
    if src.data.users == 1:
        src.data.name = name + "_HP"
    low.name, low.data.name = name, name
    low.parent = parent
    if parent is not None:
        low.matrix_parent_inverse = src.matrix_parent_inverse.copy()
    low.matrix_world = mw
    high = None
    if args.get("keep_high_poly", True):
        coll = _high_poly_collection(scene, vl)
        for c in list(src.users_collection):
            c.objects.unlink(src)
        coll.objects.link(src)
        high = {"name": src.name, "collection": coll.name, "excluded": True}
    else:
        _remove(src)

    stats, findings = _mesh_health(low, bpy.context.evaluated_depsgraph_get(), False)
    issues, ok = _summarise(findings)
    return {"data": {
        "object": low.name, "remesher": used,
        "before": {"faces": before_faces, "parts": parts["before"], "parts_after_weld": parts["welded"]},
        "after": {"faces": len(low.data.polygons), "quads_share": r(_quad_share(low.data), 3),
                  "parts": _parts(low.data), "closed": stats.get("closed")},
        "shape_vs_original": shape, "folded_share": r(folded, 4), "thin_walls": walls,
        "baked": baked, "high_poly": high, "mesh_check": {"ok": ok, "issues": issues},
        "warnings": warnings, "seconds": r(time.time() - t0, 1),
        "next": "render_view focus_objects=[{!r}] look=lit to compare; the original is in {}".format(
            low.name, HP_COLLECTION if high else "nowhere (deleted)"),
    }}
