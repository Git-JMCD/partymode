# SPDX-License-Identifier: GPL-3.0-or-later
"""
Team: the agents the user has (Claude, Codex, OpenCode with a local or hosted model) working in
one scene on one goal.

The agent picked in the chat leads. With helpers ticked in the agent menu, a message becomes a
team goal: the lead plans it and hands each helper a task with team_assign (the task's objects
are claimed for that helper, so the others keep off them). Helpers run at the same time, each
its own agent process connected to this Blender under its own name (Blender still runs their
tool calls one at a time). When every helper has reported back, the lead gets a review turn with
their reports: it checks the scene and either hands out follow-ups or answers the user. A run
ends after MAX_ROUNDS reviews, when the lead assigns nothing more, or with Stop.

A helper's work lands in the chat as one block when it finishes (its steps, renders and report,
under its own name and colour); while it runs, the chat shows what each one is doing.
"""

import json
import os
import subprocess
import threading
import time

from . import chat, intercom, runners
from .registry import ToolError, tool

MAX_ROUNDS = 3
_lock = threading.Lock()
T = {"run": None}  # the team run: {"local_id", "goal", "lead", "round", "members", "review_due", "started"}

MEMBER_PROMPT = """You are {me}, one of a team of AI agents working in the user's Blender at the same time,
on one goal. {lead} leads the team and gave you this task; the user sees your work in the chat.

The team's goal: {goal}

Your task: {title}
{task}
{objects}
The others: {others}

Stick to your task. Objects another teammate is working on are claimed for them: leave them be
(an edit naming one is stopped). Need something from a teammate? post_note to them. Check your
own work before you finish (render_view, inspect_geometry, inspect_mesh). End with a short
report for {lead}: what you did, the objects you made or changed (exact names), and anything
left undone or wrong."""

# A later task for a helper that already worked in this run: it resumes its own session, so it
# keeps what it learned and only needs the new task.
FOLLOW_PROMPT = """{lead} has another task for you (same team, same goal).

Your task: {title}
{task}
{objects}
Same as before: stick to it, leave objects claimed for teammates alone, check your work, and end
with a short report for {lead}: what you did, the objects you made or changed, anything left."""

FAILED_PROMPT = """{who} could not finish its task ({title}): {report}

The other helpers are still at work. Retry it now if it is worth it (team_assign {key} again with
what to change, or give it to another helper), or leave it for your review when the others report.
Keep this turn short."""

LEAD_PROMPT = """You lead a team of AI agents working in this Blender at the same time: {team}.
Plan the user's goal and hand each helper a focused task with team_assign (title, task, and the
objects it owns, existing or still to be made: they are claimed for that helper). Give each helper
work that does not overlap the others'; a helper still busy queues the next task you give it and
starts it when it finishes. Play to their
strengths ({notes}). You may do a part yourself in this turn. Then end your turn with the plan in
a few lines: the helpers report back when they finish, and you get a review turn with their
reports. Small jobs that need no team: just do them."""

REVIEW_PROMPT = """Your team reported back (round {round} of {max}):

{reports}

Check the scene (render_view, inspect_geometry, inspect_mesh, scene_overview). If something is
missing or wrong, hand out follow-ups with team_assign (say exactly what to fix){last}. If it is
done, answer the user: what the team made, who did what, anything left."""

STRENGTHS = {"claude": "careful planning, checking and fixing", "codex": "precise scripted edits and code",
             "opencode": "its model's own strengths; local models are best given small, clear tasks"}


def label(key):
    return runners.get(key).label


def helpers():
    """The helpers ticked in the agent menu that are installed, other than the lead."""
    picked = [k for k in getattr(chat.S, "team_helpers", ()) if k in runners.RUNNERS]
    return [k for k in picked if k != chat.S.runner and chat.executable(k)]


def run():
    with _lock:
        return T["run"]


def busy():
    r = run()
    return bool(r) and any(m["status"] == "working" for m in r["members"].values())


def rows():
    """For the chat: each helper of the run with what it is doing."""
    r = run()
    if not r:
        return []
    now = time.time()
    out = []
    for key, m in r["members"].items():
        if m["status"] == "idle":
            continue
        secs = round((m.get("ended") or now) - m["started"]) if m.get("started") else 0
        out.append({"key": key, "label": label(key), "title": m.get("title", ""), "status": m["status"],
                    "activity": m.get("activity", ""), "secs": secs})
    return out


# ---------------------------------------------------------------------------
# The lead's side: a goal, a review.

def lead_brief(local_id, goal):
    """The lead's instructions for a new team goal (and the run it starts), or "" with no helpers."""
    team = helpers()
    if not team:
        return ""
    lead = chat.S.runner
    with _lock:
        old = T["run"]
        if old and old["local_id"] == local_id and any(m["status"] == "working" for m in old["members"].values()):
            members = old["members"]  # a message while helpers work: they keep going
        else:
            members = {k: {"status": "idle"} for k in team}
        T["run"] = {"local_id": local_id, "goal": goal, "lead": lead, "round": 0, "members": members,
                    "review_due": False, "started": time.time()}
    names = ", ".join("{} (helper, {})".format(label(k), _model(k) or "its default model") for k in team)
    return LEAD_PROMPT.format(team="you ({}, lead) and {}".format(label(lead), names),
                              notes="; ".join("{}: {}".format(label(k), STRENGTHS[k]) for k in team))


def _model(key):
    if key == chat.S.runner:
        return chat.S.model
    return (getattr(chat.S, "team_models", {}) or {}).get(key, "")


def on_lead_done(local_id):
    """The lead's turn ended: tell it about a helper that failed meanwhile (while others work), or
    with no helper still at work, start the review (or end the run)."""
    r = run()
    if r and r.get("failed_due") and any(m["status"] == "working" for m in r["members"].values()):
        with _lock:
            key = r["failed_due"].pop(0)
        _failed_turn(r, key)
        return
    if r:
        r.pop("failed_due", None)  # everyone has finished: the review covers it
    _maybe_review()


def _maybe_review():
    with _lock:
        r = T["run"]
        if not r or not r["review_due"] or any(m["status"] == "working" for m in r["members"].values()):
            return
        if chat.S.live:
            return  # the lead is answering; its turn's end tries again
        r["review_due"] = False
        r["round"] += 1
        reports = [(k, m) for k, m in r["members"].items() if m.get("fresh")]
        done = []  # every task a helper finished since the last review, a queued one too
        for k, m in reports:
            m["fresh"] = False
            done += [(k, title, report) for title, report in m.pop("reports", [])]
        last = r["round"] >= MAX_ROUNDS
        local_id, round_n = r["local_id"], r["round"]
    text = "\n\n".join("{} ({}): {}".format(label(k), title, report or "(no report)")
                       for k, title, report in done) or "(no reports)"
    prompt = REVIEW_PROMPT.format(round=round_n, max=MAX_ROUNDS, reports=text,
                                  last=". This is the last round: after it, answer the user" if last else "")
    shown = "Team: {} reported back".format(", ".join(label(k) for k, _m in reports) or "the helpers")
    try:
        chat.send(prompt, local_id, extra="", team_review=shown, runner=r["lead"])  # the lead, whoever is picked now
    except Exception as ex:  # the lead could not start: say so in the chat
        chat._append(local_id, {"role": "system", "text": "The team's review could not start: {}".format(ex)})
    if last:
        with _lock:
            if T["run"] is r:
                r["final"] = True


def stop_all():
    """Stop every helper (the chat's Stop)."""
    r = run()
    if not r:
        return False
    stopped = False
    for m in r["members"].values():
        m["queue"] = []
        proc = m.get("proc")
        if m["status"] == "working":
            m["status"] = "stopped"  # a helper not started yet stops as soon as its process does
            if proc is not None:
                _kill(proc)
            stopped = True
    with _lock:
        r["review_due"] = False
    return stopped


def _kill(proc):
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True,
                           creationflags=subprocess.CREATE_NO_WINDOW, timeout=15)
        else:
            proc.terminate()
    except (OSError, subprocess.SubprocessError):
        try:
            proc.terminate()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# A helper at work.

def _start(r, key, title, task, objects):
    m = r["members"][key]
    others = ["{} (lead)".format(label(r["lead"]))]
    for k, o in r["members"].items():
        if k != key:  # a teammate may get its task after this one: scene_overview shows the claims
            others.append("{} ({})".format(label(k), o["title"] if o.get("status") == "working" else "helper"))
    claimed = ("Objects claimed for you: " + ", ".join(objects) + "\n") if objects else ""
    brief = MEMBER_PROMPT.format(me=label(key), lead=label(r["lead"]), goal=r["goal"], title=title, task=task,
                                 objects=claimed, others="; ".join(others))
    follow = FOLLOW_PROMPT.format(lead=label(r["lead"]), title=title, task=task, objects=claimed)
    m.update(status="working", title=title, task=task, objects=list(objects), activity="starting",
             started=time.time(), ended=None, report="", proc=None, fresh=False, brief=brief)
    prompt = follow if m.get("session") else brief
    threading.Thread(target=_work, args=(r, key, prompt), name="agent-team-" + key, daemon=True).start()


def _work(r, key, prompt):
    m = r["members"][key]
    resume = m.get("session")  # a later task resumes the helper's own session from this run
    local_id = r["local_id"]
    rn = runners.get(key)
    exe = chat.executable(key)
    work = os.path.join(chat.S.root, "work", "team-" + key)
    os.makedirs(work, exist_ok=True)
    mcp_url = "http://127.0.0.1:{}/mcp?client=chat-{}".format(chat.S.port, key)
    model = _model(key)
    state = {"_model": model or rn.defaults().get("model", "")}
    block, texts, err_tail = [], [], []
    error, done = None, False
    try:
        kwargs = {"tool_names": chat.S.tool_names} if key in ("codex", "opencode") else {}
        if key == "opencode":
            kwargs["env_for"] = chat._child_env
            m["activity"] = "connecting OpenCode to Blender"
        effort = (getattr(chat.S, "team_efforts", {}) or {}).get(key, "")  # its own reasoning setting
        cmd, stdin_text, cwd = rn.command(exe, work, prompt, resume, model, effort, chat.SYSTEM_PROMPT, mcp_url,
                                          **kwargs)
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        attempt = 0
        while True:
            proc = subprocess.Popen(cmd, cwd=cwd, env=chat._child_env(cwd), stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags)
            m["proc"] = proc
            if m["status"] == "stopped":
                _kill(proc)
            threading.Thread(target=lambda p=proc: err_tail.extend(p.stderr.read().decode("utf-8", "replace")
                                                                   .splitlines()[-20:]), daemon=True).start()
            try:
                proc.stdin.write(stdin_text.encode("utf-8"))
                proc.stdin.close()
            except OSError:
                pass
            for raw in proc.stdout:
                try:
                    msg = json.loads(raw)
                except ValueError:
                    continue
                if not isinstance(msg, dict):
                    continue
                for ev in rn.parse(msg, state):
                    kind = ev[0]
                    if kind == "model" and ev[1]:
                        state["_model"] = ev[1]
                    elif kind == "session" and ev[1]:
                        m["session"] = ev[1]
                    elif kind == "delta":
                        m["activity"] = "writing"
                    elif kind == "text":
                        texts.append(ev[1])
                    elif kind == "tool":
                        _, cid, name, tool_input = ev
                        short, detail = chat._tool_summary(name, tool_input)
                        state[cid] = short
                        if short in chat._HIDDEN_TOOLS:
                            continue
                        block.append({"role": "tool", "tool": short, "detail": detail, "t": time.time()})
                        m["activity"] = "using " + short + ("" if not detail else ": " + detail[:40])
                    elif kind == "result":
                        _, cid, name, ok, text, images = ev
                        short = state.get(cid) or chat._tool_summary(name, None)[0]
                        if short in chat._HIDDEN_TOOLS:
                            continue
                        entry = {"role": "tool_result", "tool": short, "ok": bool(ok),
                                 "text": text[:chat._MAX_TOOL_TEXT], "t": time.time()}
                        names = [chat._save_png(local_id, png) for png in images]
                        if names:
                            entry["images"] = names
                        card = chat._card(short, text) if ok else None
                        if card:
                            entry["card"] = card
                        block.append(entry)
                        m["activity"] = "thinking"
                    elif kind == "done":
                        done, error = True, ev[1]
            proc.wait(timeout=60)
            if error and not texts and not block and resume:
                # Its session could not be resumed: start fresh, with the full brief.
                resume = m["session"] = None
                cmd, stdin_text, cwd = rn.command(exe, work, m["brief"], None, model, effort, chat.SYSTEM_PROMPT,
                                                  mcp_url, **kwargs)
                done, error = False, None
                continue
            if error and not texts and not block:
                retry = rn.recover(cmd, cwd, error, attempt)
                if retry:
                    cmd, cwd = retry
                    attempt += 1
                    done, error = False, None
                    continue
            break
        if not done and texts and proc.returncode == 0:
            done = True  # OpenCode ends with the process
        if m["status"] == "stopped":
            report = "(stopped)"
        elif error or not done:
            report = "(did not finish: {})".format(error or " ".join(err_tail[-3:]) or "ended without an answer")
        else:
            # The last message is the report; the ones before it narrate the work as it went.
            report = chat.hide_next(texts[-1]).strip() if texts else ""
    except Exception as ex:
        report = "(could not run {}: {})".format(rn.label, ex)
    ended = time.time()
    for e in block:
        e["member"] = key
        chat._append(local_id, e)
    chat._append(local_id, {"role": "assistant", "text": report, "member": key, "t": ended})
    chat._append(local_id, {"role": "member_meta", "member": key, "title": m.get("title", ""),
                            "duration_s": round(ended - m["started"], 1), "model": state.get("_model", ""),
                            "runner": key, "t": ended})
    _finish(r, key, report, done and not error, ended)


def _finish(r, key, report, ok, ended):
    """A helper's task ended: start its next queued task, or (all done) the lead's review."""
    m = r["members"][key]
    with _lock:
        nxt = m["queue"].pop(0) if m.get("queue") and m["status"] == "working" else None
        if m["status"] == "working" and not nxt:  # with a next task it stays working: no early review
            m["status"] = "done" if ok else "failed"
        m.update(ended=ended, report=report, proc=None, fresh=True, activity="")
        m.setdefault("reports", []).append((m.get("title", ""), report))
        stopped = m["status"] == "stopped"
        others_busy = any(o["status"] == "working" for k, o in r["members"].items() if k != key)
    # Its claims end with the task; a queued task keeps the ones claimed for it.
    intercom.release("chat-" + key, set(m.get("objects") or ()) if nxt else None)
    chat.S.revision += 1
    if nxt:
        _start(r, key, *nxt)  # the next task the lead queued for it: the review waits for that too
    elif not ok and not stopped and others_busy:
        _failed_turn(r, key)  # the lead hears now, not after the slowest helper
    elif not stopped:
        _maybe_review()


def _failed_turn(r, key):
    """A helper failed while others still work: a short turn for the lead to retry or reassign it.
    It uses a review round, but never the last one."""
    with _lock:
        if T["run"] is not r or r.get("final"):
            return
        if chat.S.live:
            r.setdefault("failed_due", []).append(key)  # the lead is answering: on_lead_done sends it
            return
        if r["round"] + 1 < MAX_ROUNDS:
            r["round"] += 1
        m = r["members"][key]
        title, report, local_id = m.get("title", ""), m.get("report", ""), r["local_id"]
    prompt = FAILED_PROMPT.format(who=label(key), key=key, title=title, report=report or "(no report)")
    try:
        chat.send(prompt, local_id, extra="", team_review="Team: {} could not finish".format(label(key)),
                  runner=r["lead"])
    except Exception as ex:
        chat._append(local_id, {"role": "system", "text": "The team's lead could not be told: {}".format(ex)})


# ---------------------------------------------------------------------------
# The lead's tools.

def _lead_run(args):
    r = run()
    me = args.get("_client", "")
    if not r or me != "chat-" + r["lead"]:
        raise ToolError("Only the team's lead can do this, during a team goal (tick helpers in the agent menu).")
    return r


@tool("team_assign",
      "Team lead only: give a helper a task. Helpers work in parallel with each other; one helper does "
      "one task at a time, so a task for a busy helper is queued and starts when its current one "
      "ends. member: one of the helpers named in your instructions (claude, codex, opencode). title: "
      "a few words the user sees; task: what to do and how to check it; objects: what it owns, "
      "existing or still to be made (claimed for it so others keep off). Its reports come back in "
      "your review turn.",
      {"member": {"type": "string", "enum": list(runners.RUNNERS)},
       "title": {"type": "string", "minLength": 1, "maxLength": 80},
       "task": {"type": "string", "minLength": 1, "maxLength": 4000},
       "objects": {"type": "array", "items": {"type": "string"}, "maxItems": 32}},
      required=("member", "title", "task"))
def team_assign(args):
    r = _lead_run(args)
    key = args["member"]
    if key not in r["members"]:
        raise ToolError("{} is not on this team. Helpers: {}.".format(label(key) if key in runners.RUNNERS else key,
                                                                     ", ".join(label(k) for k in r["members"])))
    if r.get("final"):
        raise ToolError("This was the last round: answer the user with what the team made.")
    m = r["members"][key]
    names, planned = intercom.targets(args.get("objects") or [])
    claimed, refused = intercom.claim("chat-" + key, names, args["title"], 60)
    if refused:
        intercom.release("chat-" + key, set(claimed))
        raise ToolError("Already claimed: " + "; ".join("{} by {}".format(x["object"], x["claimed_by"])
                                                      for x in refused))
    reserved = [n for n in planned if n in claimed]
    data = {"title": args["title"], "claimed_for_it": claimed}
    if reserved:
        data["reserved"] = reserved  # not made yet: claimed by name
    with _lock:
        r["review_due"] = True
        queued = m["status"] == "working"
        if queued:
            m.setdefault("queue", []).append((args["title"], args["task"], claimed))
            ahead = len(m["queue"])
    if queued:
        data.update(queued_for=label(key), behind=[m["title"]] + [q[0] for q in m["queue"][:-1]],
                    note="{} is busy with {!r}: this starts when it finishes ({} queued). You get a review "
                         "turn when every helper has finished all its tasks.".format(label(key), m["title"], ahead))
    else:
        _start(r, key, args["title"], args["task"], claimed)
        data.update(started=label(key), note="It works in parallel and reports back; you get a review turn "
                                             "when every helper has finished. Assign the others, then end your "
                                             "turn with the plan.")
    chat.S.revision += 1
    return {"data": data}


@tool("team_status",
      "Team lead only: each helper's task, whether it is working or done, and its report.", {})
def team_status(args):
    r = _lead_run(args)
    out = []
    for k, m in r["members"].items():
        row = {"member": label(k), "status": m["status"], "title": m.get("title", ""),
               "doing": m.get("activity", ""), "report": m.get("report", "")}
        if m.get("queue"):
            row["queued"] = [q[0] for q in m["queue"]]
        out.append(row)
    return {"data": {"goal": r["goal"], "round": r["round"], "max_rounds": MAX_ROUNDS, "helpers": out}}
