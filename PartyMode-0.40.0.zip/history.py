# SPDX-License-Identifier: GPL-3.0-or-later
"""
One timeline of what happened to the file: agent calls and manual edits.

Agent calls are recorded by the tool layer. Manual edits are read from the undo
stack (``WindowManager.undo_stack``, Blender 5.3+), which names every undoable
edit; agent edits are told apart by their "Agent: " step names. Where there is
no undo stack (background mode) the recently-run operator list is used instead.
"""

import time
from collections import deque

import bpy

AGENT_PREFIX = "Agent: "


def step_name(label, client="agent"):
    """An agent edit's undo step: 'Agent (Codex): add wetness' (plain 'Agent: ' if unknown)."""
    from . import intercom
    who = intercom.label_for(client) if client and client not in ("agent", "ui") else ""
    return "Agent ({}): {}".format(who, label) if who else AGENT_PREFIX + label


def is_agent_step(name):
    """Undo steps the agents made ('Agent: …', 'Agent (Codex): …', 'Agent checkpoint: …')."""
    return name.startswith("Agent")
_MAX_EVENTS = 500

_events: deque = deque(maxlen=_MAX_EVENTS)
_seen: set = set()
_primed = False
# While > 0, edits are being made by the agent and are not logged as manual.
agent_depth = 0


def record_agent(call_id: str, tool: str, label: str, status: str, changes: dict | None,
                 client: str = "agent") -> None:
    summary = None
    touched = []
    if changes:
        summary = {
            "created": len(changes.get("created_objects", ())),
            "modified": len(changes.get("modified_objects", {})),
            "deleted": len(changes.get("deleted_objects", ())),
        }
        # Data changed without an object changing (a mesh's normals, a material's nodes, a world).
        made = sum(len(v) for v in (changes.get("created_data") or {}).values())
        gone = sum(len(v) for v in (changes.get("deleted_data") or {}).values())
        edited = changes.get("updated_data") or []
        if made or gone or edited:
            summary["data"] = {"created": made, "deleted": gone, "edited": len(edited),
                               "names": (["{}:{}".format(k, n)
                                          for k, v in (changes.get("created_data") or {}).items() for n in v]
                                         + list(edited))[:8]}
        if status == "failed" and changes.get("changed"):
            summary["partly_applied"] = True  # it failed after changing things: they were kept
        touched = (list(changes.get("created_objects", ())) + list(changes.get("modified_objects", {})))[:100]
    _events.append({
        "t": time.time(), "by": "agent", "client": client, "tool": tool, "label": label,
        "call_id": call_id, "status": status, "changes": summary, "objects": touched,
    })
    revision[0] += 1


# Bumped on every new event so the UI knows when to redraw.
revision = [0]


def undo_stack():
    wm = bpy.context.window_manager
    return getattr(wm, "undo_stack", None) if wm is not None else None


def _items():
    """(key, name, is_agent) for each user-visible edit Blender currently remembers."""
    # Keys pair the address with the name: a freed step's address can be reused.
    stack = undo_stack()
    if stack is not None:
        for step in stack.steps:
            if not step.is_substep:
                yield (step.as_pointer(), step.name), step.name, is_agent_step(step.name)
        return
    wm = bpy.context.window_manager
    for op in (wm.operators if wm is not None else ()):
        yield (op.as_pointer(), op.bl_idname), op.name, False


def poll() -> None:
    """Pick up manual edits. Call on the main thread."""
    global _primed
    try:
        current = set()
        for key, name, is_agent in _items():
            current.add(key)
            if key in _seen:
                continue
            _seen.add(key)
            if _primed and not is_agent and agent_depth == 0:
                _events.append({"t": time.time(), "by": "user", "edit": name})
                from . import undo
                undo.forget_marks()
                revision[0] += 1
        _seen.intersection_update(current)
        _primed = True
    except Exception:
        pass


def mark_seen() -> None:
    """Treat everything up to now as already logged (used after agent calls)."""
    try:
        _seen.update(key for key, _name, _agent in _items())
    except Exception:
        pass


def events(limit: int = 50, by: str | None = None) -> list:
    items = [e for e in _events if by is None or e["by"] == by]
    from . import intercom
    out = []
    for e in items[-limit:][::-1]:
        if e["by"] == "agent" and "who" not in e:
            e = dict(e, who=intercom.label_for(e.get("client")))
            if e.get("client") == "ui":
                e["receipt"] = "none: a chat button the user pressed, not an agent's call (call_status has no record)"
        out.append(e)
    return out


def source() -> str:
    return "undo stack" if undo_stack() is not None else "operator log"
