# SPDX-License-Identifier: GPL-3.0-or-later
"""
Fewer API guesses: "did you mean ..." for a failed script, and `api_lookup`.

When an agent's script fails on the bpy API (an attribute that does not exist, a key not in a
collection, an operator argument or name, an enum value), `hint` reads the real names from the
running Blender, so they are right for this version: close names first, a direct fix for the
classic confusions (Scene.view_layer, Object.select, BMFace.loop_indices), and for node
sockets their types and whether they are live (a Mix node has three sockets called "A").

`api_lookup` answers "what does X have" from the same live introspection: RNA types
(bpy.types), operators (bpy.ops), and Python types (bmesh, mathutils).
"""

import difflib
import re
import traceback

import bmesh
import bpy
import mathutils

from .registry import ToolError, tool

# (type name, attribute) -> what to use instead.
_KNOWN = {
    ("Scene", "view_layer"): "the active view layer is bpy.context.view_layer; all of them: scene.view_layers",
    ("Scene", "active_object"): "bpy.context.active_object, or set it with bpy.context.view_layer.objects.active = ob",
    ("Scene", "objects.link"): "link through a collection: scene.collection.objects.link(ob)",
    ("Object", "select"): "ob.select_set(True) / ob.select_get()",
    ("Object", "hide"): "ob.hide_set(True) (this view layer), ob.hide_viewport or ob.hide_render",
    ("Object", "matrix"): "ob.matrix_world (or matrix_local / matrix_basis)",
    ("Object", "mesh"): "ob.data (the Mesh)",
    ("Mesh", "faces"): "mesh.polygons (or bmesh: bm.faces)",
    ("Mesh", "update_normals"): "mesh.update(); normals are computed on demand",
    ("BMFace", "loop_indices"): "[l.index for l in face.loops] (or [v.index for v in face.verts])",
    ("BMFace", "vertices"): "face.verts",
    ("BMEdge", "vertices"): "edge.verts",
    ("BMesh", "parts"): "a BMesh has no list of loose parts: walk v.link_edges from a vertex to collect "
                        "each island (or bpy.ops.mesh.separate(type='LOOSE') on an object)",
    ("BMesh", "vertices"): "bm.verts",
    ("BMesh", "polygons"): "bm.faces",
    ("Vector", "len"): "v.length (or len(v) for the number of components)",
    ("Vector", "norm"): "v.normalized() (a copy) or v.normalize() (in place)",
    ("Material", "base_color"): "the Principled BSDF node: next(n for n in mat.node_tree.nodes if n.type == "
                                "'BSDF_PRINCIPLED').inputs['Base Color'].default_value (or shade_* / "
                                "describe_material); mat.diffuse_color is the viewport colour",
    ("Context", "active_object"): "bpy.context.active_object is read-only: set "
                                  "bpy.context.view_layer.objects.active = ob",
}


def _members(obj):
    """Names an object really has: RNA properties and functions, plus Python attributes."""
    names = set()
    rna = getattr(obj, "bl_rna", None)
    if rna is not None:
        names |= {p.identifier for p in rna.properties if p.identifier != "rna_type"}
        names |= {f.identifier for f in rna.functions}
    try:
        names |= {n for n in dir(obj) if not n.startswith("_")}
    except Exception:  # noqa: BLE001
        pass
    return names


def _close(name, names, n=4):
    names = list(names)
    out = difflib.get_close_matches(name, names, n=n, cutoff=0.6)
    low = name.lower()
    parts = [p for p in re.split(r"_+", low) if len(p) >= 3]
    for cand in sorted(names):
        if len(out) >= n + 2:
            break
        c = cand.lower()
        if cand not in out and (low in c or c in low or any(p in c for p in parts)):
            out.append(cand)
    return out[: n + 2]


def _type_name(obj):
    rna = getattr(obj, "bl_rna", None)
    return rna.identifier if rna is not None else type(obj).__name__


def _attribute(ex):
    obj, name = getattr(ex, "obj", None), getattr(ex, "name", None)
    if obj is None or not name:
        m = re.search(r"Calling operator \"bpy\.ops\.(\w+)\.(\w+)\" error, could not be found", str(ex))
        if m:
            module = getattr(bpy.ops, m.group(1), None)
            close = _close(m.group(2), dir(module)) if module else []
            return ("There is no operator bpy.ops.{}.{}.".format(m.group(1), m.group(2)) +
                    (" Close: {}.".format(", ".join("bpy.ops.{}.{}".format(m.group(1), c) for c in close))
                     if close else ""))
        return None
    tname = _type_name(obj)
    known = _KNOWN.get((tname, name))
    if known is None and getattr(obj, "bl_rna", None) is not None:  # a base type's entry (Object for Mesh...)
        for base in type(obj).__mro__:
            known = _KNOWN.get((base.__name__, name))
            if known:
                break
    close = _close(name, _members(obj))
    out = "'{}' has no '{}'.".format(tname, name)
    if known:
        out += " Use " + known + "."
    if close:
        out += " Close names on {}: {}.".format(tname, ", ".join(close))
    out += " All of it: api_lookup('{}').".format(tname)
    return out


def _source_line(tb, filename, source):
    line = None
    for frame, lineno in traceback.walk_tb(tb):
        if frame.f_code.co_filename == filename:
            line = (frame, lineno)
    if line is None:
        return None, None
    frame, lineno = line
    lines = source.splitlines()
    return frame, (lines[lineno - 1] if 0 < lineno <= len(lines) else "")


def _resolve(expr, frame):
    """A dotted name like `node.outputs` from the failing frame (no calls, no indexing)."""
    head, *rest = expr.split(".")
    if head in frame.f_locals:
        obj = frame.f_locals[head]
    elif head in frame.f_globals:
        obj = frame.f_globals[head]
    else:
        return None
    for part in rest:
        obj = getattr(obj, part, None)
        if obj is None:
            return None
    return obj


def _socket_list(coll):
    socks = [s for s in coll]
    if not socks or not isinstance(socks[0], bpy.types.NodeSocket):
        return None
    live = ["{} ({}{})".format(s.name, s.type, "" if s.enabled else ", unused") for s in socks]
    dup = sorted({s.name for s in socks if sum(1 for t in socks if t.name == s.name) > 1})
    out = "Sockets: " + ", ".join(live) + "."
    if dup:
        side = "outputs" if socks[0].is_output else "inputs"
        example = next(s for s in socks if s.name == dup[0])
        out += (" Several are called {}: pick by name, type and enabled, e.g. next(s for s in "
                "node.{} if s.name == '{}' and s.type == '{}' and s.enabled).").format(
                    ", ".join(dup), side, dup[0], next((s.type for s in socks if s.name == dup[0] and s.enabled),
                                                       example.type))
    return out


def _key(ex, frame, line):
    m = re.search(r'key "([^"]*)" not found', str(ex))
    if not m:
        return None
    key = m.group(1)
    coll = None
    if frame is not None and line:
        for expr in re.findall(r"([A-Za-z_][\w.]*)\s*\[\s*['\"]" + re.escape(key) + r"['\"]\s*\]", line):
            coll = _resolve(expr, frame)
            if coll is not None:
                break
    if coll is None or not hasattr(coll, "keys"):
        names = [n for attr in ("objects", "meshes", "materials", "collections", "images", "node_groups",
                                "cameras", "lights", "worlds", "scenes")
                 for n in getattr(bpy.data, attr).keys()]
        close = difflib.get_close_matches(key, names, n=5, cutoff=0.6)
        return "No '{}' there.{}".format(key, " Close names in bpy.data: {}.".format(", ".join(close)) if close else "")
    keys = list(coll.keys())
    out = "No '{}' in that collection.".format(key)
    sockets = _socket_list(coll)
    if sockets:
        return out + " " + sockets
    close = difflib.get_close_matches(key, keys, n=5, cutoff=0.5)
    if close:
        out += " Close: {}.".format(", ".join(close))
    elif keys:
        out += " It has: {}{}.".format(", ".join(keys[:15]), " …" if len(keys) > 15 else "")
    else:
        out += " It is empty."
    return out


def _operator_args(ex, line):
    m = re.search(r'keyword "(\w+)" unrecognized', str(ex))
    op = re.search(r"bpy\.ops\.(\w+)\.(\w+)\s*\(", line or "")
    if not m or not op:
        return None
    try:
        props = getattr(getattr(bpy.ops, op.group(1)), op.group(2)).get_rna_type().properties
    except Exception:  # noqa: BLE001
        return None
    names = [p.identifier for p in props if p.identifier != "rna_type"]
    close = _close(m.group(1), names, n=3)
    out = "bpy.ops.{}.{} has no argument '{}'.".format(op.group(1), op.group(2), m.group(1))
    if close:
        out += " Close: {}.".format(", ".join(close))
    return out + " It takes: {}.".format(", ".join(names[:30]))


def _enum(ex):
    m = re.search(r'enum "([^"]*)" not found in \(([^)]*)\)', str(ex))
    if not m:
        return None
    value = m.group(1)
    items = [i.strip().strip("'\"") for i in m.group(2).split(",") if i.strip()]
    close = [i for i in items if value.lower() in i.lower()] or difflib.get_close_matches(value, items, n=3, cutoff=0.5)
    return "'{}' is not one of the choices.{}".format(value, " Did you mean {}?".format(" or ".join(close)) if close else "")


def _keyword_only(ex):
    """Blender functions whose arguments must be named (do_create=True, not True)."""
    text = str(ex)
    m = re.search(r"(\w+)\(\) takes (\d+) positional arguments? but (\d+) (?:was|were) given", text) or \
        re.search(r"(\w+)\(\): (?:required|takes) .*keyword", text)
    if not m:
        return None
    return ("{}() takes its arguments by name: write name=value (e.g. do_create=True), not a bare value; "
            "api_lookup shows the names.").format(m.group(1))


def hint(ex, tb, filename, source):
    """A short "did you mean" for an API mistake, or None."""
    try:
        frame, line = _source_line(tb, filename, source)
        if isinstance(ex, AttributeError):
            return _attribute(ex)
        if isinstance(ex, KeyError):
            return _key(ex, frame, line)
        if isinstance(ex, TypeError):
            return _operator_args(ex, line) or _enum(ex) or _keyword_only(ex)
    except Exception:  # noqa: BLE001 - a hint must never hide the real error
        return None
    return None


# ---------------------------------------------------------------------------
# api_lookup.

def _prop_text(p):
    t = p.type
    if t in ('POINTER', 'COLLECTION'):
        t = "{}({})".format(t.lower(), p.fixed_type.identifier if p.fixed_type else "?")
    elif t == 'ENUM':
        items = [e.identifier for e in p.enum_items][:12]
        t = "enum[{}{}]".format(", ".join(items), ", …" if len(p.enum_items) > 12 else "") if items else "enum"
    else:
        t = t.lower()
        if getattr(p, "array_length", 0):
            t += "[{}]".format(p.array_length)
    return "{}: {}{}".format(p.identifier, t, " (read-only)" if p.is_readonly else "")


def _func_text(f):
    args = []
    for p in f.parameters:
        if p.is_output:
            continue
        args.append(p.identifier + ("" if p.is_required else "=…"))
    outs = [p.identifier for p in f.parameters if p.is_output]
    return "{}({}){}".format(f.identifier, ", ".join(args), " -> " + ", ".join(outs) if outs else "")


_TREES = (("ShaderNode", "ShaderNodeTree"), ("CompositorNode", "CompositorNodeTree"),
          ("GeometryNode", "GeometryNodeTree"), ("FunctionNode", "GeometryNodeTree"),
          ("TextureNode", "TextureNodeTree"))


def _menu_choices(sock):
    """A menu socket's choices: Blender lists them when given one that is not."""
    try:
        sock.default_value = "__not_a_choice__"
    except (TypeError, ValueError) as ex:
        m = re.search(r"not found in \(([^)]*)\)", str(ex))
        if m:
            return [i.strip().strip("'\"") for i in m.group(1).split(",") if i.strip()]
    return None


_sockets_seen = {}  # node type -> its sockets (a throwaway tree marks the file changed: once per type)


def _node_sockets(type_name):
    """A node type's inputs and outputs as a real node has them: name, type, default, a menu's
    choices, and whether it is in use (made in a throwaway node tree)."""
    if type_name not in _sockets_seen:
        _sockets_seen[type_name] = _make_sockets(type_name)
    return _sockets_seen[type_name]


def _make_sockets(type_name):
    tree_type = next((t for prefix, t in _TREES if type_name.startswith(prefix)), None)
    if tree_type is None:
        return None
    tree = bpy.data.node_groups.new(".api_lookup", tree_type)
    try:
        node = tree.nodes.new(type_name)

        def row(sock):
            out = {"name": sock.name, "type": sock.type}
            if not sock.enabled:
                out["unused"] = True
            if sock.type == "MENU":
                out["default"] = sock.default_value
                choices = _menu_choices(sock)
                if choices:
                    out["choices"] = choices
            elif hasattr(sock, "default_value"):
                v = sock.default_value
                try:
                    out["default"] = [round(x, 4) for x in v] if hasattr(v, "__len__") and not isinstance(v, str) \
                        else (round(v, 4) if isinstance(v, float) else v)
                except TypeError:
                    pass
            return out
        return {"inputs": [row(x) for x in node.inputs], "outputs": [row(x) for x in node.outputs],
                "set_inputs": "node.inputs['Name'].default_value = ... (a menu input takes one of its choices)"}
    except RuntimeError:
        return None
    finally:
        bpy.data.node_groups.remove(tree)


def _find(name):
    """bpy.types / bmesh.types / mathutils / bpy.ops / bmesh.ops object for a name or path."""
    n = name.strip()
    for prefix in ("bpy.types.", "bmesh.types.", "mathutils."):
        if n.startswith(prefix):
            n = n[len(prefix):]
    m = re.match(r"(?:bpy\.ops\.)?(\w+)\.(\w+)$", n) if n.startswith("bpy.ops.") else None
    if m:
        return "operator", getattr(getattr(bpy.ops, m.group(1)), m.group(2)), None
    if n.startswith("bmesh.ops."):
        return "bmesh_op", getattr(bmesh.ops, n.split(".")[-1], None), None
    member = None
    if "." in n:
        n, member = n.split(".", 1)
    for space in (bpy.types, bmesh.types, mathutils):
        obj = getattr(space, n, None)
        if obj is not None:
            return "type", obj, member
    return None, None, member


@tool("api_lookup",
      "What a Blender Python type, operator or bmesh op really has, read from this running Blender "
      "(always the right version). name: a type ('Scene', 'BMFace', 'Vector', 'ShaderNodeMix'), a "
      "member ('Scene.view_layers'), an operator ('bpy.ops.mesh.primitive_cube_add') or a bmesh op "
      "('bmesh.ops.subdivide_edges'). filter keeps names containing that text.",
      {"name": {"type": "string", "minLength": 1}, "filter": {"type": "string"}},
      required=("name",))
def api_lookup(args):
    kind, obj, member = _find(args["name"])
    flt = (args.get("filter") or "").lower()
    if obj is None:
        pool = [n for n in dir(bpy.types) if not n.startswith("_")] + list(dir(bmesh.types)) + list(dir(mathutils))
        close = difflib.get_close_matches(args["name"].split(".")[-1], pool, n=6, cutoff=0.6)
        raise ToolError("No type or operator {!r}.{}".format(args["name"], " Close: {}.".format(", ".join(close))
                                                                    if close else ""))
    if kind == "operator":
        rna = obj.get_rna_type()
        props = [_prop_text(p) for p in rna.properties if p.identifier != "rna_type"]
        return {"data": {"operator": args["name"], "description": rna.description,
                         "arguments": [p for p in props if flt in p.lower()],
                         "poll_ok": bool(obj.poll()) if hasattr(obj, "poll") else None}}
    if kind == "bmesh_op":
        doc = (obj.__doc__ or "").strip().splitlines()
        return {"data": {"bmesh_op": args["name"], "doc": "\n".join(doc[:40])}}
    rna = getattr(obj, "bl_rna", None)
    data = {"type": args["name"].split(".")[0] if member else args["name"]}
    if rna is not None:
        if rna.base:
            data["base"] = rna.base.identifier
        if rna.description:
            data["description"] = rna.description
        props = [p for p in rna.properties if p.identifier != "rna_type"]
        funcs = list(rna.functions)
        if member:
            p = next((p for p in props if p.identifier == member), None)
            f = next((f for f in funcs if f.identifier == member), None)
            if p is None and f is None:
                close = _close(member, [p.identifier for p in props] + [f.identifier for f in funcs])
                raise ToolError("{} has no {!r}.{}".format(rna.identifier, member,
                                                         " Close: {}.".format(", ".join(close)) if close else ""))
            if p is not None:
                data["property"] = _prop_text(p)
                data["description"] = p.description
            else:
                data["function"] = _func_text(f)
                data["description"] = f.description
            return {"data": data}
        data["properties"] = [_prop_text(p) for p in props if flt in p.identifier.lower()][:150]
        data["functions"] = [_func_text(f) for f in funcs if flt in f.identifier.lower()][:80]
        sockets = _node_sockets(rna.identifier) if issubclass(obj, bpy.types.Node) else None
        if sockets:
            data["sockets"] = sockets  # many settings are inputs now, not properties
        return {"data": data}
    # A Python type (bmesh, mathutils).
    names = [n for n in dir(obj) if not n.startswith("_") and flt in n.lower()]
    if member:
        if member not in dir(obj):
            raise ToolError("{} has no {!r}. Close: {}.".format(data["type"], member, ", ".join(_close(member, dir(obj)))))
        names = [member]
    rows = []
    for n in names[:150]:
        attr = getattr(obj, n, None)
        doc = (getattr(attr, "__doc__", "") or "").strip().splitlines()
        kind_ = "method" if callable(attr) else "attribute"
        rows.append("{} ({}){}".format(n, kind_, ": " + doc[0][:120] if doc else ""))
    data["members"] = rows
    return {"data": data}
