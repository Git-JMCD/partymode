# SPDX-License-Identifier: GPL-3.0-or-later
"""
Safety tools: save points, try-before-you-commit edits, and stopping work.

- checkpoint / restore_checkpoint: a named undo step plus a .blend copy on disk.
  Restoring jumps back through undo when the step is still there (fast, keeps
  redo) and otherwise reloads the copy and points the file back at the user's path.
- try_edit / apply_trial: render before, edit, render after, then undo the edit.
  The scene ends as it started; apply_trial makes the edit for real.
- stop: ends the agent's running script or render (also: Escape, time limits).
"""

import json
import os
import re
import time
import uuid

import bpy

from . import cancel, changes, imagediff, undo
from .registry import TOOLS, ToolError, tool
from .tools_edit import DEFAULT_TIMEOUT_S, run_scripts

_CHECKPOINT_PREFIX = "Agent checkpoint: "
_TRIAL_PREFIX = "Agent trial: "

_checkpoints: "dict[str, dict]" = {}
_trials: "dict[str, dict]" = {}
_loaded = {"dir": None}
_INDEX = "index.json"
_FILE_RE = re.compile(r"^(?P<name>.+)_(?P<t>\d{9,})\.blend$")


def _checkpoint_dir() -> str:
    path = bpy.utils.user_resource('CONFIG', path=os.path.join("agent_bridge", "checkpoints"), create=True)
    return path


def _load():
    """The save points on disk, kept in index.json beside them so they outlive a restart.
    Copies made before the index existed are picked up from their file names."""
    folder = _checkpoint_dir()
    if _loaded["dir"] == folder:
        return
    _checkpoints.clear()
    try:
        with open(os.path.join(folder, _INDEX), encoding="utf-8") as fh:
            for cp in json.load(fh):
                if os.path.isfile(cp.get("file", "")):
                    cp["undo_key"] = None  # undo history does not survive a restart
                    _checkpoints[cp["name"]] = cp
    except (OSError, ValueError, TypeError, KeyError):
        pass
    known = {os.path.normcase(cp["file"]) for cp in _checkpoints.values()}
    for entry in os.scandir(folder):
        m = _FILE_RE.match(entry.name)
        if not entry.is_file() or not m or os.path.normcase(entry.path) in known:
            continue
        name, t = m.group("name"), float(m.group("t"))
        old = _checkpoints.get(name)
        if old is None or old["t"] < t:
            _checkpoints[name] = {"name": name, "note": "", "t": t, "file": entry.path, "undo_key": None,
                                  "objects": None, "user_file": None}
    _loaded["dir"] = folder
    _save_index()


def _save_index():
    folder = _checkpoint_dir()
    keep = ("name", "note", "t", "file", "objects", "user_file")
    rows = [{k: cp.get(k) for k in keep} for cp in sorted(_checkpoints.values(), key=lambda c: c["t"])]
    tmp = os.path.join(folder, _INDEX + ".tmp")
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, indent=1)
        os.replace(tmp, os.path.join(folder, _INDEX))
    except OSError:
        pass


def _same_file(a, b):
    return bool(a) and bool(b) and os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))


def _working_file():
    """The user's file. After a restore, stock Blender has the save point's copy open (it can't
    point the file back), so a copy counts as the file it was made from."""
    path = bpy.data.filepath
    for cp in _checkpoints.values():
        if _same_file(cp.get("file"), path):
            return cp.get("user_file") or ""
    return path


def _origin(cp):
    """'this file', 'another file' or 'unknown' (copies made before the index)."""
    if not cp.get("user_file"):
        return "unknown"
    return "this file" if _same_file(cp["user_file"], _working_file()) else "another file"


def forget_checkpoint(name: str, delete_file: bool = True) -> bool:
    """Drop a save point (tests clean up with this). Not an agent tool."""
    _load()
    cp = _checkpoints.pop(name, None)
    if cp is None:
        return False
    if delete_file:
        try:
            os.remove(cp["file"])
        except OSError:
            pass
    _save_index()
    return True


def _safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name).strip("_")[:60] or "checkpoint"


@tool("checkpoint",
      "Make a named save point of the whole file before risky work. Stored as an undo step "
      "and as a .blend copy on disk, so it survives even after the undo history moves on. "
      "Go back with restore_checkpoint.",
      {"name": {"type": "string", "minLength": 1, "maxLength": 60},
       "note": {"type": "string", "maxLength": 200}},
      required=("name",), mutating=True, push_undo=False)
def checkpoint(args):
    _load()
    name = args["name"].strip()
    undo.push_marked(_CHECKPOINT_PREFIX + name, noop=True)
    _index, key = undo.active()
    path = os.path.join(_checkpoint_dir(), "{}_{}.blend".format(_safe_name(name), int(time.time())))
    bpy.ops.wm.save_as_mainfile(filepath=path, copy=True, compress=False, check_existing=False)
    old = _checkpoints.get(name)
    if old and old["file"] != path:
        try:
            os.remove(old["file"])
        except OSError:
            pass
    _checkpoints[name] = {
        "name": name, "note": args.get("note", ""), "t": time.time(), "file": path,
        "undo_key": key, "objects": len(bpy.data.objects),
        "user_file": _working_file(),
    }
    _save_index()
    return {"data": {"checkpoint": name, "objects": len(bpy.data.objects),
                     "saved_copy": os.path.basename(path), "in_undo_history": key is not None}}


@tool("list_checkpoints",
      "Save points on disk, newest first (they survive restarts), with the file each was made from "
      "and how it can be restored. Shows this file's save points (and old ones of unknown origin); "
      "all=true lists every file's.",
      {"all": {"type": "boolean", "default": False}})
def list_checkpoints(args):
    _load()
    out = []
    for cp in sorted(_checkpoints.values(), key=lambda c: c["t"], reverse=True):
        origin = _origin(cp)
        if origin == "another file" and not args.get("all"):
            continue
        out.append({
            "name": cp["name"], "note": cp["note"], "objects": cp["objects"],
            "age_s": round(time.time() - cp["t"]),
            "made_from": origin if origin != "another file" else os.path.basename(cp["user_file"]),
            "size_mb": round(os.path.getsize(cp["file"]) / 1e6, 1) if os.path.isfile(cp["file"]) else None,
            "restore_by": "undo" if undo.find(cp["undo_key"]) is not None else "reload saved copy",
        })
    hidden = sum(1 for cp in _checkpoints.values() if _origin(cp) == "another file") if not args.get("all") else 0
    data = {"checkpoints": out}
    if hidden:
        data["other_files"] = "{} save point(s) from other files; all=true to list them".format(hidden)
    return {"data": data}


@tool("restore_checkpoint",
      "Return the whole file to a save point made with checkpoint. Uses the undo history when "
      "it still holds the step (redo stays possible); otherwise reloads the saved copy and keeps "
      "the file pointed at the user's own path. Everything after the save point is undone, "
      "including the user's manual edits: check history first. A save point made from another "
      "file would replace this scene with that one, so it needs other_file=true.",
      {"name": {"type": "string"}, "other_file": {"type": "boolean", "default": False}},
      required=("name",), mutating=True, push_undo=False)
def restore_checkpoint(args):
    _load()
    cp = _checkpoints.get(args["name"])
    if cp is None:
        mine = sorted(n for n, c in _checkpoints.items() if _origin(c) != "another file")
        raise ToolError("No checkpoint {!r}. Known for this file: {}.".format(
            args["name"], ", ".join(mine) or "none yet"))
    if not os.path.isfile(cp["file"]):
        forget_checkpoint(cp["name"], delete_file=False)
        raise ToolError("The saved copy of {!r} is gone from disk.".format(cp["name"]))
    if _origin(cp) == "another file" and not args.get("other_file"):
        raise ToolError("{!r} was made from {}, not this file; restoring it would replace this scene "
                        "with that one. Ask the user, then pass other_file=true.".format(
                            cp["name"], os.path.basename(cp["user_file"])))
    index = undo.find(cp["undo_key"])
    if index is not None:
        undo.goto(index)
        return {"data": {"restored": cp["name"], "method": "undo history"}}

    user_file = _working_file()
    bpy.ops.wm.open_mainfile(filepath=cp["file"], load_ui=False)
    undo.forget_marks()  # a loaded file starts a new undo history
    agent = getattr(bpy.app, "agent", None)
    note = None
    if agent is not None and hasattr(agent, "set_blendfile_path"):
        agent.set_blendfile_path(user_file)
    else:
        note = "This Blender cannot re-point the file; it now shows the checkpoint copy. Use Save As."
    _, cp["undo_key"] = undo.active()
    data = {"restored": cp["name"], "method": "reloaded saved copy"}
    if note:
        data["note"] = note
    return {"data": data}


def _render(view, focus, look):
    res = TOOLS["render_view"].fn({"view": view, "focus_objects": focus, "look": look,
                                   "width": 768, "height": 576})
    return res["images"][0]


@tool("try_edit",
      "Try an edit without keeping it: renders the chosen views before, runs the code, reports "
      "what it would change, renders the views after, then undoes it so the scene is exactly as "
      "it was. `measured` gives each view's difference in numbers: changed_share of the frame, "
      "strength, box (x0, y0, x1, y1 as fractions, top-left origin), where, a coarse map "
      "('.' none, '+' some, '#' mostly), and whether the changed area got lighter or darker; "
      "'no visible change' means the edit did not show from that view. diff_images=true adds a "
      "picture per view with the changes highlighted. Show the before/after to the user; "
      "apply_trial(trial_id) makes the edit for real. Same code/steps/timeout_s as run_python.",
      {"code": {"type": "string"},
       "steps": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 50},
       "views": {"type": "array", "maxItems": 4, "default": ["hero"],
                 "items": {"type": "string", "enum": ["camera", "hero", "top", "front", "back", "left", "right"]}},
       "focus_objects": {"type": "array", "items": {"type": "string"}, "maxItems": 64},
       "look": {"type": "string", "enum": ["solid", "lit"], "default": "solid"},
       "diff_images": {"type": "boolean", "default": False},
       "timeout_s": {"type": "number", "minimum": 1, "maximum": 3600, "default": DEFAULT_TIMEOUT_S}},
      mutating=True, push_undo=False)
def try_edit(args):
    from .registry import ui_override
    if not ui_override():
        undo.require_stack()  # says it needs a window
    stamped = undo.stack() is None  # Blender without a readable undo history (5.2): stamped steps
    views = args.get("views") or ["hero"]
    look = args.get("look", "solid")
    focus = args.get("focus_objects") or []
    focus_before = [n for n in focus if n in bpy.data.objects]

    images, labels = [], []
    for v in views:
        images.append(_render(v, focus_before, look))
        labels.append("before: " + v)

    if stamped:
        start_sid = undo.push_marked(_TRIAL_PREFIX + "start", noop=True)
        if start_sid is None:
            raise ToolError("Couldn't save an undo step to try this from.")
        start_key = None
    else:
        undo.push(_TRIAL_PREFIX + "start")
        _, start_key = undo.active()
    before = changes.snapshot()
    data, ok = run_scripts(args)
    report = changes.diff(before, changes.snapshot())
    if ok:
        for v in views:
            images.append(_render(v, [n for n in focus if n in bpy.data.objects], look))
            labels.append("after: " + v)
    label = args.get("_label", "trial")
    undo.push(_TRIAL_PREFIX + label)
    if stamped:
        # Back to the stamped start, however many steps the code pushed on the way.
        trial_key = None
        if not undo.back_to(start_sid):
            raise ToolError("Couldn't get back to the trial's start; undo by hand to discard it.")
        undo.clear_mark()
    else:
        _, trial_key = undo.active()
        # By key, not position: with a full undo history this push dropped the oldest step,
        # so every index moved down one.
        start_index = undo.find(start_key)
        if start_index is None:
            raise ToolError("The undo history lost the trial's start; undo by hand to discard it.")
        undo.goto(start_index)

    if ok:
        data["measured"] = _measure(views, images, labels, look, args.get("diff_images"))

    trial_id = "trial-" + uuid.uuid4().hex[:8]
    _trials[trial_id] = {
        "label": label, "trial_key": trial_key, "ok": ok,
        "script": {k: args[k] for k in ("code", "steps", "timeout_s") if k in args},
    }
    data.update(trial_id=trial_id, would_change=report, images=labels, kept=False,
                next="apply_trial(trial_id) to keep it" if ok else "fix the error and try again")
    return {"data": data, "images": images, "isError": not ok}


def _measure(views, images, labels, look, want_images):
    """Before/after numbers per view (images: the befores, then the afters)."""
    n = len(views)
    out = {}
    for i, v in enumerate(views):
        try:
            m = imagediff.compare(images[i], images[n + i])
        except Exception as ex:  # noqa: BLE001 - numbers are extra; the renders still stand
            m = {"error": "could not measure: {}".format(ex)}
        out[v] = m
    if all(m.get("verdict") == "no visible change" for m in out.values()):
        out["hint"] = "Nothing changed in these views: the edit may be off-screen, hidden or a no-op."
        if look == "solid":
            out["hint"] += " Material and colour edits only show with look='lit'."
    if want_images:
        for i, v in enumerate(views):
            try:
                png = imagediff.diff_image(images[i], images[n + i])
            except Exception:  # noqa: BLE001
                png = None
            if png:
                images.append(png)
                labels.append("diff: " + v)
    return out


@tool("apply_trial",
      "Make a tried edit real. Re-applies the exact result from try_edit when nothing happened "
      "since (a redo); otherwise runs the same code again.",
      {"trial_id": {"type": "string"}}, required=("trial_id",), mutating=True, push_undo=False)
def apply_trial(args):
    trial = _trials.get(args["trial_id"])
    if trial is None:
        raise ToolError("No trial {!r} (this session).".format(args["trial_id"]))
    if not trial["ok"]:
        raise ToolError("That trial failed; there is nothing to apply.")
    if trial["trial_key"] is not None and undo.next_key() == trial["trial_key"]:
        from .registry import ui_override
        with bpy.context.temp_override(**ui_override()):
            bpy.ops.ed.redo()
        _trials.pop(args["trial_id"], None)
        return {"data": {"applied": trial["label"], "method": "redo of the trial"}}
    data, ok = run_scripts(dict(trial["script"], _label=trial["label"]))
    if ok:
        undo.push_marked("Agent: " + trial["label"])
        _trials.pop(args["trial_id"], None)
    data.update(applied=trial["label"] if ok else None, method="ran the code again")
    return {"data": data, "isError": not ok}


@tool("stop",
      "Stop the agent work running in Blender right now (a long script, render or remesh). The "
      "user can also press Escape in Blender. Answers even while Blender is busy. A script inside "
      "a bpy.ops operator only stops once the operator returns.",
      on_main=False)
def stop(args):
    running = cancel.busy()
    result = cancel.stop("stop requested")
    if running:
        result["was_running_s"] = running["running_s"]
        if running["stop_sent_s_ago"] is not None and running["stop_sent_s_ago"] > 2:
            result["note"] = ("An earlier stop hasn't landed after {:.0f}s: the script is inside one of "
                              "Blender's own operations, which a stop can't interrupt. See "
                              "call_status.blender_busy.").format(running["stop_sent_s_ago"])
    return {"data": result}
