# SPDX-License-Identifier: GPL-3.0-or-later
"""
Hand work from the HTTP worker thread to Blender's main thread.

bpy is only safe on the main thread. The HTTP server submits a callable and
waits for the main-thread pump to run it. In the UI the pump is a persistent
`bpy.app.timers` timer; in background mode (`blender -b`) the caller drives
`pump` from its own loop (see `serve_blocking` in the package).
"""

import queue
import threading
import time
import traceback

import bpy

_PUMP_INTERVAL = 0.02


class Job:
    __slots__ = ("fn", "done", "result", "error", "on_done", "submitted")

    def __init__(self, fn, on_done=None):
        self.fn = fn
        self.submitted = time.monotonic()
        self.done = threading.Event()
        self.result = None
        self.error = None
        # Called on the main thread with the finished job, even if no one waits any more.
        self.on_done = on_done


_queue: "queue.Queue[Job]" = queue.Queue()
_running = {"since": None}   # monotonic time the job now on the main thread started, else None
_waiting = {}                # id(job) -> submitted, for jobs still in the queue


class MainThreadTimeout(Exception):
    pass


def submit(fn, on_done=None) -> Job:
    job = Job(fn, on_done)
    if threading.current_thread() is threading.main_thread():
        _run(job)
    else:
        _waiting[id(job)] = job.submitted
        _queue.put(job)
    return job


def busy() -> dict | None:
    """How long the main thread has been on one of our jobs, and how long the oldest queued
    job has waited. Readable from any thread; None when nothing is running or waiting."""
    now = time.monotonic()
    since = _running["since"]
    oldest = min(_waiting.values(), default=None)
    if since is None and oldest is None:
        return None
    return {"running_s": round(now - since, 1) if since is not None else None,
            "oldest_waiting_s": round(now - oldest, 1) if oldest is not None else None}


def run_on_main(fn, timeout: float = 120.0):
    """Run ``fn()`` on Blender's main thread and return its result (or raise its error)."""
    job = submit(fn)
    if not job.done.wait(timeout):
        raise MainThreadTimeout("Blender did not answer within {:.0f}s.".format(timeout))
    if job.error is not None:
        raise job.error
    return job.result


def _run(job: Job) -> None:
    _waiting.pop(id(job), None)
    outer = _running["since"]  # a job can run another one inline (submit from the main thread)
    if outer is None:
        _running["since"] = time.monotonic()
    try:
        job.result = job.fn()
    except BaseException as ex:  # Hand every failure back to the caller.
        job.error = ex
        try:
            ex.agent_traceback = traceback.format_exc()
        except Exception:
            pass
    finally:
        if outer is None:
            _running["since"] = None
        if job.on_done is not None:
            try:
                job.on_done(job)
            except Exception:
                traceback.print_exc()
        job.done.set()


def pump(max_jobs: int = 8) -> None:
    """Run queued jobs. Must be called on the main thread."""
    for _ in range(max_jobs):
        try:
            job = _queue.get_nowait()
        except queue.Empty:
            return
        _run(job)


def _timer():
    pump()
    return _PUMP_INTERVAL


def start() -> None:
    if not bpy.app.timers.is_registered(_timer):
        bpy.app.timers.register(_timer, first_interval=_PUMP_INTERVAL, persistent=True)


def stop() -> None:
    if bpy.app.timers.is_registered(_timer):
        bpy.app.timers.unregister(_timer)
