# SPDX-License-Identifier: GPL-3.0-or-later
"""
House rules the agent follows: "always metres", "name meshes SM_<Name>".

Project rules live in the .blend as a text block called "Agent Rules" (editable in
Blender's Text Editor, saved with the file); global rules live in the agent
config folder and apply to every file. One rule per line starting with "- ";
"- [off] " keeps a rule but turns it off.
"""

import os

import bpy

from .registry import ToolError, tool

TEXT_NAME = "Agent Rules"
_HEADER = ("# Agent Rules for this file. One rule per line starting with '- '.\n"
           "# '- [off] ' turns a rule off. The agent reads these before working.\n")
_OFF = "[off] "


def _global_path() -> str:
    folder = bpy.utils.user_resource('CONFIG', path="agent_bridge", create=True)
    return os.path.join(folder, "global_rules.md")


def _parse(text: str) -> list:
    rules = []
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("- "):
            continue
        body = s[2:].strip()
        enabled = not body.startswith(_OFF)
        rules.append({"text": body[len(_OFF):].strip() if not enabled else body, "enabled": enabled})
    return rules


def _render(rules: list) -> str:
    return _HEADER + "".join("- {}{}\n".format("" if r["enabled"] else _OFF, r["text"]) for r in rules)


def _read(scope: str) -> list:
    if scope == "project":
        txt = bpy.data.texts.get(TEXT_NAME)
        return _parse(txt.as_string()) if txt else []
    path = _global_path()
    if not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8") as fh:
        return _parse(fh.read())


def _write(scope: str, rules: list) -> None:
    if scope == "project":
        txt = bpy.data.texts.get(TEXT_NAME) or bpy.data.texts.new(TEXT_NAME)
        txt.from_string(_render(rules))
    else:
        with open(_global_path(), "w", encoding="utf-8") as fh:
            fh.write(_render(rules))


def active_rules() -> list:
    """Enabled rules for the open file, global first: [{id, scope, text}]."""
    out = []
    for scope in ("global", "project"):
        for i, rule in enumerate(_read(scope)):
            if rule["enabled"]:
                out.append({"id": "{}-{}".format(scope[0], i + 1), "scope": scope, "text": rule["text"]})
    return out


def _locate(rule_id: str):
    try:
        prefix, num = rule_id.split("-", 1)
        scope = {"g": "global", "p": "project"}[prefix]
        index = int(num) - 1
    except (ValueError, KeyError):
        raise ToolError("Rule ids look like g-1 (global) or p-2 (project); got {!r}.".format(rule_id)) from None
    rules = _read(scope)
    if not 0 <= index < len(rules):
        raise ToolError("No rule {!r}.".format(rule_id))
    return scope, index, rules


@tool("list_rules",
      "Read the house rules: global ones (every file) and this file's own (the 'Agent Rules' text "
      "in the .blend, which the user can edit). Includes turned-off rules. Follow enabled rules.")
def list_rules(args):
    out = {}
    for scope in ("global", "project"):
        out[scope] = [{"id": "{}-{}".format(scope[0], i + 1), **rule} for i, rule in enumerate(_read(scope))]
    return {"data": out}


@tool("add_rule",
      "Save a standing preference the user asked for, e.g. 'model in metres at real scale' or "
      "'name static meshes SM_<Name>'. scope project: saved in this .blend; global: every file. "
      "Only add rules the user asked for.",
      {"text": {"type": "string", "minLength": 3, "maxLength": 400},
       "scope": {"type": "string", "enum": ["project", "global"], "default": "project"}},
      required=("text",), mutating=True)
def add_rule(args):
    scope = args.get("scope", "project")
    rules = _read(scope)
    text = " ".join(args["text"].split())
    if any(r["text"].lower() == text.lower() for r in rules):
        raise ToolError("That rule is already saved.")
    rules.append({"text": text, "enabled": True})
    _write(scope, rules)
    return {"data": {"id": "{}-{}".format(scope[0], len(rules)), "scope": scope, "text": text}}


@tool("update_rule",
      "Change a rule's text or turn it on/off, by id from list_rules.",
      {"id": {"type": "string"}, "text": {"type": "string", "minLength": 3, "maxLength": 400},
       "enabled": {"type": "boolean"}},
      required=("id",), mutating=True)
def update_rule(args):
    scope, index, rules = _locate(args["id"])
    if "text" in args:
        rules[index]["text"] = " ".join(args["text"].split())
    if "enabled" in args:
        rules[index]["enabled"] = bool(args["enabled"])
    _write(scope, rules)
    return {"data": {"id": args["id"], **rules[index]}}


@tool("remove_rule",
      "Delete a rule by id, only when the user asks.",
      {"id": {"type": "string"}}, required=("id",), mutating=True)
def remove_rule(args):
    scope, index, rules = _locate(args["id"])
    removed = rules.pop(index)
    _write(scope, rules)
    return {"data": {"removed": removed["text"], "scope": scope,
                     "note": "Ids of later rules in this scope shift down by one."}}
