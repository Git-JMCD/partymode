# SPDX-License-Identifier: GPL-3.0-or-later
"""Editing tools: run Python, undo agent edits, and read receipts/history."""

import contextlib
import io
import math
import re
import sys
import time
import tokenize
import traceback

import bmesh
import bpy
import mathutils

from . import apihints, cancel, history, receipts
from .registry import ToolError, tool, ui_override

DEFAULT_TIMEOUT_S = 120

_MAX_OUTPUT = 20000


def namespace():
    import numpy
    return {
        "__name__": "__agent__", "bpy": bpy, "bmesh": bmesh, "mathutils": mathutils,
        "Vector": mathutils.Vector, "Matrix": mathutils.Matrix, "Euler": mathutils.Euler,
        "Quaternion": mathutils.Quaternion, "math": math, "np": numpy, "C": bpy.context, "D": bpy.data,
    }


def _short_traceback(filename: str) -> str:
    """The traceback from the agent's own code down, without bridge internals."""
    etype, value, tb = sys.exc_info()
    frames = traceback.extract_tb(tb)
    start = next((i for i, f in enumerate(frames) if f.filename == filename), 0)
    lines = traceback.format_list(frames[start:])
    lines += traceback.format_exception_only(etype, value)
    return "".join(lines).strip()


def run_source(source: str, filename: str, namespace: dict, label: str = "script",
               timeout_s: float | None = None):
    """Exec ``source``; return (ok, output, error_text, error_line, hint). Stoppable (see `cancel`).
    `hint` is a "did you mean" for a bpy API mistake (see `apihints`), or None."""
    buf = io.StringIO()
    try:
        code = compile(source, filename, "exec")
    except SyntaxError as ex:
        return False, "", "SyntaxError: {} (line {})".format(ex.msg, ex.lineno), ex.lineno, None
    try:
        with cancel.running(label, timeout_s):
            with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                exec(code, namespace)
    except cancel.AgentStopped:
        line = None
        for frame, lineno in traceback.walk_tb(sys.exc_info()[2]):
            if frame.f_code.co_filename == filename:
                line = lineno
        reason = cancel.last_reason() or "stopped"
        return False, buf.getvalue(), "Stopped: {} (at line {})".format(reason, line), line, None
    except Exception as ex:
        tb = sys.exc_info()[2]
        line = None
        for frame, lineno in traceback.walk_tb(tb):
            if frame.f_code.co_filename == filename:
                line = lineno
        text = _short_traceback(filename)
        return False, buf.getvalue(), text, line, apihints.hint(ex, tb, filename, source)
    return True, buf.getvalue(), None, None, None


# Operators that can run forever inside Blender's C code, where no stop reaches them, so a
# script calling one can freeze Blender until it is force-quit. run_python refuses them and
# names the safe way instead.
BLOCKING_OPS = {
    "quadriflow_remesh": "remesh_asset(object), which runs QuadriFlow in a separate Blender with a "
                         "time limit (a stop ends it too) and cleans the mesh first",
}
_BLOCKING_RE = re.compile(r"\b({})\b".format("|".join(BLOCKING_OPS)))


def blocking_op(source: str) -> str | None:
    """The name of a BLOCKING_OPS operator `source` uses in code (names and strings, so
    getattr(bpy.ops.object, "quadriflow_remesh") counts too; comments don't), or None."""
    try:
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type in (tokenize.NAME, tokenize.STRING):
                m = _BLOCKING_RE.search(tok.string)
                if m:
                    return m.group(1)
        return None
    except (tokenize.TokenError, SyntaxError, IndentationError):
        m = _BLOCKING_RE.search(source)  # compile() will report the syntax error
        return m.group(1) if m else None


def _clip(text: str) -> str:
    if len(text) <= _MAX_OUTPUT:
        return text
    return text[:_MAX_OUTPUT] + "\n... [{} more characters]".format(len(text) - _MAX_OUTPUT)


@tool("run_python",
      "Run bpy Python in the open Blender on the main thread. Pass `code` for one script, or "
      "`steps` (a list of scripts sharing one namespace) for larger edits: steps run in order "
      "and stop at the first error, keeping earlier steps. Full Python, no sandbox. "
      "print() what you want to check. The reply reports what changed (objects created, "
      "modified with which fields, deleted; data blocks created or edited), and the whole "
      "call is one undo step. Preloaded: bpy, bmesh, mathutils, Vector, Matrix, Euler, "
      "Quaternion, math, np (numpy), C (context), D (bpy.data). The user can stop a "
      "running script with Escape; `timeout_s` (default 120) stops it automatically. Neither "
      "can stop a bpy.ops operator while it runs, only between Python lines: for a quad remesh "
      "use remesh_asset.",
      {"code": {"type": "string"},
       "steps": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 50},
       "timeout_s": {"type": "number", "minimum": 1, "maximum": 3600, "default": DEFAULT_TIMEOUT_S}},
      mutating=True)
def run_python(args):
    data, ok = run_scripts(args)
    return {"data": data, "isError": not ok}


def run_scripts(args) -> "tuple[dict, bool]":
    """Run `code` or `steps` from tool args; shared by run_python, try_edit and apply_trial."""
    code, steps = args.get("code"), args.get("steps")
    if bool(code) == bool(steps):
        raise ToolError("Pass exactly one of `code` or `steps`.")
    scripts = [code] if code else list(steps)
    for src in scripts:
        op = blocking_op(src)
        if op:
            raise ToolError(
                "Not run: bpy.ops...{} can hang inside Blender's own code, where timeout_s, stop and "
                "Escape can't reach it, and then Blender has to be force-quit. Use {}.".format(op, BLOCKING_OPS[op]))
    timeout_s = float(args.get("timeout_s", DEFAULT_TIMEOUT_S))
    label = args.get("_label", "script")
    ns = namespace()
    deadline = time.monotonic() + timeout_s
    outputs, ran = [], 0
    for i, src in enumerate(scripts, 1):
        filename = "<agent>" if code else "<agent step {}>".format(i)
        ok, out, err, line, hint = run_source(src, filename, ns, label, max(0.1, deadline - time.monotonic()))
        if out:
            outputs.append(out if code else "[step {}]\n{}".format(i, out))
        if not ok:
            data = {"output": _clip("".join(outputs)), "error": err, "error_line": line}
            if hint:
                data["hint"] = hint
            if err.startswith("Stopped:"):
                data["stopped"] = True
            if steps:
                data.update(failed_step=i, steps_completed=ran,
                            note="Steps before the failed one were kept.")
            return data, False
        ran += 1
    data = {"output": _clip("".join(outputs))}
    if steps:
        data["steps_completed"] = ran
    if bpy.context.mode != 'OBJECT':
        data["note"] = "Left in {} mode.".format(bpy.context.mode)
    return data, True


@tool("undo",
      "Undo the most recent undo step(s) in Blender, the same as Ctrl+Z. Every agent edit "
      "is one step, so steps=1 reverts the last agent call if nothing was done since. "
      "Reports which steps were undone when this build exposes the undo stack.",
      {"steps": {"type": "integer", "minimum": 1, "maximum": 20, "default": 1}},
      mutating=True, push_undo=False)
def undo(args):
    n = int(args.get("steps", 1))
    override = ui_override()
    if not override:
        raise ToolError("Undo needs a Blender window (not available in background mode).")
    if history.undo_stack() is None:
        # No readable undo history (Blender 5.2): only the agent's own stamped steps, never
        # the user's (see undo.undo_marked).
        from . import undo as undo_steps
        history.poll()
        names = undo_steps.undo_marked(n)
        return {"data": {"undone": len(names), "undone_steps": names, "now_at": None,
                         "note": "This Blender can't show its undo history, so only the agent's own latest "
                                 "edits can be undone here; Ctrl+Z undoes anything."}}
    undone = []
    with bpy.context.temp_override(**override):
        for _ in range(n):
            stack = history.undo_stack()
            name = stack.active.name if stack is not None and stack.active else None
            if not bpy.ops.ed.undo.poll():
                break
            bpy.ops.ed.undo()
            undone.append(name)
    stack = history.undo_stack()
    return {"data": {"undone": len(undone), "undone_steps": undone,
                     "now_at": stack.active.name if stack is not None and stack.active else None}}


@tool("call_status",
      "Look up the receipt of an earlier edit by its call_id: running, succeeded or failed, "
      "with its stored result. Use after a timeout instead of re-sending a new edit. "
      "Without call_id, lists recent receipts. Answers even while Blender is busy; while an edit "
      "runs, `blender_busy` says for how long, and `stuck` means it can no longer be stopped: "
      "stop polling and tell the user (read its `advice`).",
      {"call_id": {"type": "string"}}, on_main=False)
def call_status(args):
    # Off the main thread so it answers while an edit holds it; receipts are thread-safe.
    call_id = args.get("call_id")
    blocked = cancel.busy_report()
    if not call_id:
        data = {"recent": receipts.recent()}
        if blocked:
            data["blender_busy"] = blocked
        return {"data": data}
    receipt = receipts.get(call_id)
    if receipt is None:
        raise ToolError("No receipt for call_id {!r} (this Blender session).".format(call_id))
    if receipt["status"] == "running":
        receipt["running_s"] = round(time.time() - receipt["started"], 1)
        if blocked:
            receipt["blender_busy"] = blocked
            if blocked.get("stuck"):
                receipt["advice"] = blocked["advice"]
    return {"data": receipt}


@tool("history",
      "One timeline of what happened in this Blender session, newest first: agent edits "
      "(tool, label, call_id, change counts) and your manual edits (by name). "
      "Use it to catch up on what the user did by hand.",
      {"limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
       "by": {"type": "string", "enum": ["agent", "user"]}})
def history_tool(args):
    history.poll()
    return {"data": {"events": history.events(int(args.get("limit", 50)), args.get("by")),
                     "manual_source": history.source()}}
