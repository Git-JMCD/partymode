# SPDX-License-Identifier: GPL-3.0-or-later
"""
Talk to an AI agent from inside Blender, with sessions you can come back to.

Each message runs an agent headless (Claude Code, Codex or OpenCode; see `runners`)
connected only to this Blender's MCP server. The agent keeps the real session (resumed
by id next turn); this module keeps a readable transcript of each session (messages,
tool calls, rendered images) for the Blender editor and the browser chat page.
Switching agents mid-conversation hands the new one a short recap. Each session records
how full the agent's context is; "continue in a new chat" has the agent write a handoff
summary, which the new chat's first message carries.
Nothing here touches bpy: it runs on worker threads, and the agent reaches Blender
through the MCP server like any other client.
"""

import json
import os
import re
import shutil
import subprocess
import threading
import time
import uuid

from . import runners

_MAX_TOOL_TEXT = 600
# Runner plumbing, not worth showing the user.
_HIDDEN_TOOLS = {"ToolSearch"}

# Claude model aliases (`--model`); Codex and OpenCode take a model name.
# Claude Code's model aliases: each always runs the latest model of that family.
_FAMILIES = (
    ("fable", "Fable", "The most capable model"),
    ("opus", "Opus", "Strong all-round model"),
    ("sonnet", "Sonnet", "Faster, lighter on usage"),
    ("haiku", "Haiku", "Fastest, lightest on usage"),
)
# The version each alias runs today; a run that reports a newer one updates it (see learn_model).
_VERSIONS = {"fable": "5.1", "opus": "5.5", "sonnet": "5.5", "haiku": "5.5"}


def _versions_path():
    return os.path.join(S.root, "claude_models.json") if S.root else ""


def _load_versions():
    try:
        with open(_versions_path(), encoding="utf-8") as fh:
            seen = json.load(fh)
    except (OSError, ValueError, TypeError):
        return
    for family, version in (seen or {}).items():
        if family in _VERSIONS and _newer_version(version, _VERSIONS[family]):
            _VERSIONS[family] = version


def _newer_version(a, b):
    try:
        return tuple(int(x) for x in str(a).split(".")) > tuple(int(x) for x in str(b).split("."))
    except ValueError:
        return False


def learn_model(model):
    """A run reported the model it used ('claude-opus-5-6'): remember that version for its alias."""
    m = re.match(r"claude-([a-z]+)-(\d+)(?:-(\d+))?", model or "")
    if not m or m.group(1) not in _VERSIONS:
        return
    version = m.group(2) + ("." + m.group(3) if m.group(3) and len(m.group(3)) < 3 else "")
    if _newer_version(version, _VERSIONS[m.group(1)]):
        _VERSIONS[m.group(1)] = version
        try:
            with open(_versions_path(), "w", encoding="utf-8") as fh:
                json.dump(_VERSIONS, fh)
        except OSError:
            pass


def models():
    """[(alias, "Opus 5.5", description)] for the Claude model choices."""
    return [(key, "{} {}".format(label, _VERSIONS[key]), desc) for key, label, desc in _FAMILIES]


MODELS = tuple(models())  # as of loading (the preferences' list is fixed at registration)
EFFORTS = ("low", "medium", "high", "xhigh", "max")

SYSTEM_PROMPT = """You are the assistant built into the user's Blender (agent-blender). The user is
chatting with you from a panel inside Blender or the chat page it serves.
- Work in their open Blender through the agent-blender tools. Start with
  scene_overview when you need to know the scene; follow its house rules.
- Every edit is undoable and reported; checkpoint before risky work, check your
  work (render_view, inspect_geometry, inspect_mesh) before saying it is done.
- Images you render are shown to the user in the chat automatically.
- To wait for a generation job, call wait_for_job (timeout_s up to 240) instead of polling
  generation_status. A failed check is a claim: read its evidence (and render the close-up it
  names) before fixing; mark_intent records deliberate traits (an open water film, tiling UVs).
- Keep replies short and plain: the Blender panel is narrow. Use short
  paragraphs and simple lists; avoid tables.
- You may read files the user points you to; you cannot run commands or write files
  except through the Blender tools.
- End every reply with one last line: NEXT: followed by a short message the user would likely
  send next, in their words (under 12 words), e.g. "NEXT: make the sand a little darker". The
  chat hides that line and offers it in the message box. Leave it out if nothing fits.
"""

# The reply's last line "NEXT: ..." (see SYSTEM_PROMPT), with or without markdown around it.
_NEXT = re.compile(r"\n?[ \t]*[*_`>]*\s*next\s*:\s*[*_`]*\s*(.+?)\s*[*_`]*\s*$", re.IGNORECASE)
_NEXT_START = re.compile(r"\n[ \t]*[*_`>]*\s*n(e(x(t\s*:?)?)?)?\s*[*_`]*\s*$", re.IGNORECASE)


def split_next(text):
    """(reply without its NEXT line, the suggested next message or None)."""
    lines = (text or "").rstrip().split("\n")
    if lines and _NEXT.fullmatch("\n" + lines[-1]):
        suggestion = _NEXT.fullmatch("\n" + lines[-1]).group(1).strip().strip('"').strip()
        return "\n".join(lines[:-1]).rstrip(), (suggestion[:160] or None)
    return text, None


def hide_next(text):
    """A reply as it streams in: without its NEXT line, even half written."""
    shown, _s = split_next(text)
    return _NEXT_START.sub("", shown) if shown == text else shown


def add_reply(local_id, text):
    """Keep a reply: its NEXT line comes off and becomes the chat's suggested next message."""
    shown, suggestion = split_next(text)
    if shown.strip():
        _append(local_id, {"role": "assistant", "text": shown})
    if suggestion:
        with S.lock:
            if local_id in S.sessions:
                S.sessions[local_id]["next"] = suggestion
                _save_index()


def next_suggestion(local_id):
    """What the agent suggested the user might send next in this chat, or None."""
    with S.lock:
        meta = S.sessions.get(local_id) if local_id else None
        return meta.get("next") if meta else None


class _State:
    def __init__(self):
        self.lock = threading.Lock()
        self.root = None            # Folder for sessions (set by configure()).
        self.port = 9900
        self.paths = {}             # runner key -> custom executable path ("" = find it)
        self.tool_names = []        # this Blender's MCP tools (OpenCode's allow list)
        self.runner = "claude"      # agent for new turns
        self.model = ""             # model for new turns ("" = the runner's default)
        self.effort = ""            # reasoning level for new turns ("" = the runner's default)
        self.research = False       # the next message may use the web (scene read-only); one message
        self.research_mode = "MESSAGE"  # OFF: no web; MESSAGE: the switch, per message; AUTO: when it helps
        self.sessions = {}          # id -> meta dict
        self.windows = {}           # "runner/model" -> context window, learned from turns
        self.measured = set()       # sessions measured since start (older chats)
        self.live = None            # The running turn, or None.
        self.team_helpers = []      # agents ticked as helpers in the agent menu (team.py)
        self.team_models = {}       # agent -> model it uses as a helper ("" = its default)
        self.revision = 0           # Bumped on every change (UI redraws on change).


S = _State()


# ---------------------------------------------------------------------------
# Setup and choices.

def configure(root: str, port: int, paths: dict | None = None, runner: str = "claude", model: str = "",
              effort: str = "", tool_names=()) -> None:
    S.root = root
    _load_versions()
    S.port = port
    S.paths = dict(paths or {})
    S.tool_names = list(tool_names)
    set_choice(runner, model, effort)
    os.makedirs(os.path.join(root, "work"), exist_ok=True)
    _load_index()
    try:
        with open(os.path.join(root, "windows.json"), encoding="utf-8") as fh:
            S.windows = dict(json.load(fh))
    except (OSError, ValueError, TypeError):
        S.windows = {}


def set_choice(runner: str = "claude", model: str = "", effort: str = "") -> None:
    """Agent, model and reasoning level for the next turns ("" keeps the agent's default)."""
    S.runner = runner if runner in runners.RUNNERS else "claude"
    S.model = model or ""
    S.effort = effort if effort in EFFORTS else ""
    S.revision += 1


def executable(runner: str) -> str | None:
    return runners.get(runner).find(S.paths.get(runner, ""))


def defaults(runner: str | None = None) -> dict:
    """What the agent uses when the chat sets nothing, and where that comes from."""
    return runners.get(runner or S.runner).defaults()


def claude_defaults() -> dict:
    return runners.Claude.defaults()


def model_label(model: str) -> str:
    """'claude-opus-5-5' -> 'Opus 5.5', 'opus' -> 'Opus', 'ollama/qwen3.8:27b' -> 'qwen3.8:27b'."""
    if not model:
        return ""
    m = re.match(r"claude-([a-z]+)-(\d+)(?:-(\d+))?", model)
    if m:
        version = m.group(2) + ("." + m.group(3) if m.group(3) and len(m.group(3)) < 3 else "")
        return "{} {}".format(m.group(1).capitalize(), version)
    alias = model.split("[")[0]
    known = next((label for key, label, _d in models() if key == alias), None)
    if known:
        return known
    return model.split("/")[-1] if "/" in model else model


# ---------------------------------------------------------------------------
# Storage.

def _index_path():
    return os.path.join(S.root, "sessions.json")


def _load_index():
    try:
        with open(_index_path(), encoding="utf-8") as fh:
            S.sessions = {m["id"]: m for m in json.load(fh)}
    except (OSError, ValueError):
        S.sessions = {}


def _save_index():
    tmp = _index_path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(sorted(S.sessions.values(), key=lambda m: -m["updated"]), fh, indent=1)
    os.replace(tmp, _index_path())


def _session_dir(local_id):
    path = os.path.join(S.root, "sessions", local_id)
    os.makedirs(path, exist_ok=True)
    return path


_write_lock = threading.Lock()  # a team writes from several threads at once


def _append(local_id, entry):
    entry.setdefault("t", time.time())
    line = json.dumps(entry, ensure_ascii=False) + "\n"
    with _write_lock:
        with open(os.path.join(_session_dir(local_id), "transcript.jsonl"), "a", encoding="utf-8") as fh:
            fh.write(line)
    S.revision += 1


def transcript(local_id) -> list:
    path = os.path.join(S.root, "sessions", local_id, "transcript.jsonl")
    out = []
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    except OSError:
        pass
    return out


def list_sessions() -> list:
    with S.lock:
        return sorted((dict(m) for m in S.sessions.values()), key=lambda m: -m["updated"])


def image_path(local_id, name):
    path = os.path.join(S.root, "sessions", local_id, os.path.basename(name))
    return path if os.path.isfile(path) else None


def rename(local_id, title):
    with S.lock:
        if local_id in S.sessions:
            S.sessions[local_id]["title"] = title.strip()[:80] or S.sessions[local_id]["title"]
            _save_index()
            S.revision += 1


def delete(local_id):
    with S.lock:
        if S.live and S.live["local_id"] == local_id:
            raise RuntimeError("That session is answering right now; stop it first.")
        S.sessions.pop(local_id, None)
        _save_index()
        S.revision += 1
    shutil.rmtree(os.path.join(S.root, "sessions", local_id), ignore_errors=True)


# ---------------------------------------------------------------------------
# Running a turn.

def live() -> dict | None:
    with S.lock:
        if not S.live:
            return None
        out = dict(S.live)
    out["text"] = hide_next(out.get("text", ""))
    return out


def _missing(runner):
    r = runners.get(runner)
    return ("{} was not found. Install it, or set its path in the PartyMode preferences "
            "(Edit > Preferences > Add-ons > PartyMode).".format(r.description.split(" (")[0]))


RESEARCH_PROMPT = """This message is a research turn: you may search and read the web. The scene is
read-only this turn (edits are refused): gather, do not build. Put what you find in the Sandbox so
the user can see it beside the chat: pictures with sandbox_add url=... (always with credit,
license and source, the page it came from), notes with sandbox_add note=... (key facts, sizes,
links). For pictures, prefer search_images: openly licensed, with the licence attached. Group
what belongs together on the board (sandbox_arrange), and end with a short summary of what you
pinned. The user is asked before each search and each picture you pull in."""


AUTO_RESEARCH_PROMPT = """You may use the web this turn when it helps (references, sizes, facts).
Put pictures you find in the Sandbox with search_images, then sandbox_add url=... (with credit,
license and source); notes with links with sandbox_add note=.... The user is asked before each
search and picture, and once before you change the scene after reading the web."""


WEB_TOOLS = {"WebSearch", "WebFetch", "web_search", "webfetch", "websearch"}  # the agents' own web tools


def turn_research():
    """How the next message may use the web: None, "message" (scene read-only) or "auto"."""
    if S.research_mode == "OFF":
        return None
    if S.research_mode == "AUTO":
        return "auto"
    return "message" if S.research else None


def set_research(on: bool) -> None:
    """Research for the next message: the web on, the scene read-only (approvals.py asks first)."""
    S.research = bool(on)
    S.revision += 1


def send(text: str, local_id: str | None, blend_file: str = "", extra: str = "", team_review: str = "",
         runner: str = "") -> str:
    """Start a turn with the chosen agent; returns the local session id. One turn runs at a time.
    team_review: the lead's review turn of a team goal (team.py), shown in the chat as that line.
    runner: this agent instead of the one picked (a team's review goes to its lead)."""
    text = text.strip()
    if not text:
        raise ValueError("Empty message.")
    if runner and runner != S.runner:  # with that agent's own model; its default reasoning
        model, effort = S.team_models.get(runner, ""), ""
    else:
        runner, model, effort = S.runner, S.model, S.effort
    exe = executable(runner)
    if not exe:
        raise RuntimeError(_missing(runner))
    with S.lock:
        if S.live:
            raise RuntimeError("Still answering the last message. Wait, or press Stop.")
        if local_id is None or local_id not in S.sessions:
            local_id = uuid.uuid4().hex[:12]
            S.sessions[local_id] = {"id": local_id, "runner": runner, "runner_session": None, "title": text[:60],
                                    "created": time.time(), "updated": time.time(),
                                    "blend_file": blend_file, "turns": 0, "cost_usd": 0.0}
        meta = S.sessions[local_id]
        meta.pop("next", None)  # the suggestion was for this message
        if "runner" not in meta:  # sessions from before there was a choice of agent
            meta["runner"], meta["runner_session"] = "claude", meta.get("claude_session")
        resume = meta.get("runner_session") if meta.get("runner") == runner else None
        recap = _recap(local_id) if meta["turns"] and meta.get("runner") != runner else ""
        if meta.get("carry") and not meta["turns"]:
            recap = _carry_preamble(meta)
        heard = _from_other_agents(runner, meta)
        if heard:
            recap = (recap + "\n\n" + heard) if recap else heard
        notes = meta.pop("notes", [])
        if notes:
            told = "Since your last reply, the user did this from the chat panel:\n" + "\n".join(
                "- " + n for n in notes)
            recap = (recap + "\n\n" + told) if recap else told
        meta["updated"] = time.time()
        _save_index()
        research = turn_research()
        S.research = False  # one message at a time
        from . import team
        brief = "" if team_review else team.lead_brief(local_id, text)
        if brief or team_review:
            research = None  # a team builds; research is its own message
        S.live = {"local_id": local_id, "started": time.time(), "text": "", "activity": "thinking",
                  "proc": None, "runner": runner, "research": research}
    if team_review:
        _append(local_id, {"role": "user", "text": team_review, "team": True})
        prompt = (recap + "\n\n" + text) if recap else text
    else:
        _append(local_id, dict({"role": "user", "text": text}, **({"research": research} if research else {})))
        prompt = (recap + "\n\nNew message from the user:\n" + text) if recap else text
    if brief:
        prompt += "\n\n" + brief
    if extra:  # facts the chat adds about the message (e.g. objects it @mentions); not shown
        prompt += "\n\n" + extra
    if research == "message":
        prompt += "\n\n" + RESEARCH_PROMPT
    elif research == "auto":
        prompt += "\n\n" + AUTO_RESEARCH_PROMPT
    threading.Thread(target=_run_turn, args=(local_id, prompt, runner, exe, resume, model, effort, research),
                     name="agent-chat-turn", daemon=True).start()
    return local_id


def _recap(local_id, limit=12, chars=700):
    """A short transcript for an agent joining a conversation another agent started."""
    lines = []
    for e in transcript(local_id):
        if e.get("role") == "user":
            lines.append("User: " + e.get("text", "")[:chars])
        elif e.get("role") == "assistant":
            lines.append("Assistant: " + e.get("text", "")[:chars])
    if not lines:
        return ""
    return ("You are taking over a conversation that another assistant started in this Blender. "
            "The scene already contains its work; check it with scene_overview before changing "
            "anything. The conversation so far (most recent last):\n\n" + "\n\n".join(lines[-limit:]))


def _from_other_agents(runner, meta):
    """Notes other agents left for the chat's agent, and what they changed since its last turn."""
    from . import intercom
    me = "chat-" + runner
    notes = intercom.unread(me)
    since = meta.get("updated", 0)
    edits = [e for e in intercom.recent_by_others(me, within_s=max(60, time.time() - since), limit=8)]
    parts = []
    held = [c for c in intercom.claims_overview(me) if c["by"] != "you"]
    if held:
        parts.append("Objects other agents are working on (leave them alone unless the user says so):\n" +
                     "\n".join("- {} ({}{})".format(c["object"], c["by"], ": " + c["why"] if c["why"] else "")
                               for c in held))
    if notes:
        parts.append("Notes from other agents working in this Blender:\n" + "\n".join(
            "- {}: {}".format(n["from_label"], n["text"]) for n in notes))
    if edits:
        parts.append("Other agents changed the scene since your last reply:\n" + "\n".join(
            "- {} {} s ago: {}{}".format(e["client"], e["ago_s"], e["label"] or e["tool"],
                                         " ({})".format(", ".join(e["objects"][:5])) if e["objects"] else "")
            for e in edits))
    if parts:
        parts.append("(post_note and read_notes reach them; chat_log is what they can read of this chat.)")
    return "\n\n".join(parts)


def agent_note(from_label, text, fam=""):
    """Show a note another agent left in the most recent chat (the agent gets it next turn)."""
    with S.lock:
        target = S.live["local_id"] if S.live else None
        if target is None and S.sessions:
            target = max(S.sessions.values(), key=lambda m: m["updated"])["id"]
    if target:
        _append(target, {"role": "note", "from": from_label, "family": fam, "text": text})


def user_action(local_id, text, image_png=None, card=None, **extra):
    """Something the user did from the chat itself (kept a trial, undid, rendered): shown in the
    conversation, and told to the agent with the next message."""
    entry = dict(extra, role="action", text=text)
    with S.lock:
        meta = S.sessions.get(local_id)
        if meta is None:
            return
        meta.setdefault("notes", []).append(text)
        _save_index()
    if image_png is not None:
        n = len([f for f in os.listdir(_session_dir(local_id)) if f.endswith(".png")]) + 1
        name = "img_{:03d}.png".format(n)
        while os.path.exists(os.path.join(_session_dir(local_id), name)):
            n += 1
            name = "img_{:03d}.png".format(n)
        with open(os.path.join(_session_dir(local_id), name), "wb") as fh:
            fh.write(image_png)
        entry["images"] = [name]
        if card:
            entry["card"] = card
    _append(local_id, entry)


def _save_png(local_id, png):
    folder = _session_dir(local_id)
    n = len([f for f in os.listdir(folder) if f.endswith(".png")]) + 1
    name = "img_{:03d}.png".format(n)
    while os.path.exists(os.path.join(folder, name)):
        n += 1
        name = "img_{:03d}.png".format(n)
    with open(os.path.join(folder, name), "wb") as fh:
        fh.write(png)
    return name


def add_marks(local_id, marks):
    """The areas the user marked for a message, shown under it (the agent sees them with view_marks)."""
    for m in marks:
        names = [_save_png(local_id, png) for png in m["images"][:1]]
        _append(local_id, {"role": "mark", "text": "Mark {}: {}".format(m["n"], m["facts"].get("short", "")),
                           "images": names, "card": {"kind": "mark", "n": m["n"], "editor": m["editor_label"]}})


def add_scraps(local_id, items):
    """Sandbox items attached to a message, shown under it (the agent sees them with view_sandbox)."""
    from . import sandbox
    names = []
    for it in items[:4]:
        png = sandbox.png(it)
        if png is not None:
            names.append(_save_png(local_id, png))
    titles = [it.get("title") or it["id"] for it in items]
    entry = {"role": "mark", "text": "Attached from the Sandbox: " + ", ".join(titles)}
    if names:
        entry.update(images=names, card={"kind": "scrap", "titles": titles})
    _append(local_id, entry)


def _record_context(local_id, runner_key, tokens, window):
    with S.lock:
        meta = S.sessions.get(local_id)
        if meta is None or not tokens:
            return
        old = meta.get("context") or {}
        wkey = "{}/{}".format(runner_key, meta.get("model", ""))
        if window:
            if S.windows.get(wkey) != window:
                S.windows[wkey] = int(window)
                try:
                    with open(os.path.join(S.root, "windows.json"), "w", encoding="utf-8") as fh:
                        json.dump(S.windows, fh, indent=1)
                except OSError:
                    pass
        elif old.get("runner") == runner_key and old.get("window"):
            window = old["window"]
        else:
            window = S.windows.get(wkey, 0)
        meta["context"] = {"tokens": int(tokens), "window": int(window or 0), "runner": runner_key,
                           "t": time.time()}
        _save_index()
        S.revision += 1


def measure(local_id) -> None:
    """Fill in the meter for a chat from before it existed (once, in the background)."""
    with S.lock:
        meta = S.sessions.get(local_id)
        if (meta is None or local_id in S.measured or meta.get("context") or not meta.get("turns")
                or not meta.get("runner_session") or (S.live and S.live["local_id"] == local_id)):
            return
        S.measured.add(local_id)
        runner_key, session, model = meta.get("runner") or "claude", meta["runner_session"], meta.get("model", "")

    def work():
        exe = executable(runner_key)
        try:
            got = runners.get(runner_key).context_after(exe, session, model, _child_env) if exe else None
        except Exception:  # noqa: BLE001 - a missing meter is not worth an error
            got = None
        if got:
            _record_context(local_id, runner_key, *got)

    threading.Thread(target=work, name="agent-chat-measure", daemon=True).start()


def context(local_id) -> dict | None:
    """{"tokens", "window", "fraction" (None if the window is unknown), "runner"} or None."""
    with S.lock:
        c = dict((S.sessions.get(local_id) or {}).get("context") or {})
    if not c.get("tokens"):
        return None
    c["fraction"] = (c["tokens"] / c["window"]) if c.get("window") else None
    return c


# How full a chat is before the editor suggests moving on.
LONG_FRACTION = 0.6
LONG_TOKENS = 200_000   # when the window is unknown

SUMMARY_PROMPT = """The user is moving this conversation to a new chat because this one is getting
long. Write a handoff summary for the assistant that will continue the work in a fresh chat
(it will see only your summary and the Blender scene). Do not use any tools.

Include, briefly: the goal; what is in the scene now (object names, sizes, materials, files
made); decisions and the user's preferences; what was checked and passed; checkpoints made;
open problems and the next steps. Plain text with short headings, under 450 words."""


def is_long(local_id) -> bool:
    c = context(local_id)
    if not c:
        return False
    return c["fraction"] >= LONG_FRACTION if c["fraction"] is not None else c["tokens"] >= LONG_TOKENS


def _carry_preamble(meta):
    return ("This chat continues an earlier conversation in this Blender (\"{}\"). The assistant "
            "there wrote this handoff summary. The scene already contains that work; check it with "
            "scene_overview before changing anything.\n\n{}".format(meta.get("carry_title", ""),
                                                                    meta["carry"]))


def continue_in_new(local_id: str) -> str:
    """Start a new chat that carries a summary of `local_id` over. The summary is written by
    the agent that holds the old session (full memory), or built from the transcript if that
    is not possible. Returns the new session id; the summary arrives in the background."""
    with S.lock:
        if S.live:
            raise RuntimeError("Still answering the last message. Wait, or press Stop.")
        old = S.sessions.get(local_id)
        if old is None or not old.get("turns"):
            raise RuntimeError("That chat has nothing to carry over yet.")
        new_id = uuid.uuid4().hex[:12]
        title = old.get("title") or "Untitled"
        new_title = title if title.endswith("(continued)") else title[:48] + " (continued)"
        S.sessions[new_id] = {"id": new_id, "runner": S.runner, "runner_session": None, "title": new_title,
                              "created": time.time(), "updated": time.time(),
                              "blend_file": old.get("blend_file", ""), "turns": 0, "cost_usd": 0.0,
                              "carry_from": local_id, "carry_title": title, "carry": ""}
        _save_index()
        S.live = {"local_id": new_id, "started": time.time(), "text": "", "proc": None,
                  "runner": old.get("runner"), "activity": "summarizing the last chat"}
        S.revision += 1
    threading.Thread(target=_write_carry, args=(local_id, new_id), name="agent-chat-summary",
                     daemon=True).start()
    return new_id


def _write_carry(old_id, new_id):
    summary, how = "", "agent"
    try:
        summary = _agent_summary(old_id)
    except Exception:  # noqa: BLE001 - fall back to the transcript below
        summary = ""
    if not summary.strip():
        how = "transcript"
        summary = _recap(old_id, limit=16, chars=900).split("(most recent last):\n\n", 1)[-1]
    summary = summary.strip()
    with S.lock:
        meta = S.sessions.get(new_id)
        if meta is not None:
            meta["carry"] = summary
            meta["updated"] = time.time()
            _save_index()
        old_title = (S.sessions.get(old_id) or {}).get("title", "")
    _append(new_id, {"role": "carry", "from": old_id, "from_title": old_title, "how": how, "text": summary})
    with S.lock:
        S.live = None
        S.revision += 1


def _agent_summary(old_id):
    """Ask the agent that holds the old session for a handoff summary (resumes it, no tools)."""
    with S.lock:
        meta = dict(S.sessions.get(old_id) or {})
    runner_key, session = meta.get("runner") or "claude", meta.get("runner_session")
    exe = executable(runner_key)
    if not session or not exe:
        return ""
    r = runners.get(runner_key)
    work = os.path.join(S.root, "work", runner_key)
    os.makedirs(work, exist_ok=True)
    model = meta.get("model", "") if runner_key != "claude" else (S.model if S.runner == "claude" else "")
    kwargs = {"tool_names": S.tool_names} if runner_key in ("codex", "opencode") else {}
    if runner_key == "opencode":
        kwargs["env_for"] = _child_env
    cmd, stdin_text, cwd = r.command(exe, work, SUMMARY_PROMPT, session, model or "", "", SYSTEM_PROMPT,
                                     "http://127.0.0.1:{}/mcp".format(S.port), **kwargs)
    proc = subprocess.Popen(cmd, cwd=cwd, env=_child_env(cwd), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.DEVNULL,
                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
    _set_live(proc=proc)
    try:
        proc.stdin.write(stdin_text.encode("utf-8"))
        proc.stdin.close()
    except OSError:
        pass
    texts, state = [], {"_model": model or ""}
    for raw in proc.stdout:
        try:
            msg = json.loads(raw)
        except ValueError:
            continue
        if isinstance(msg, dict):
            for ev in r.parse(msg, state):
                if ev[0] == "text":
                    texts.append(ev[1])
    proc.wait(timeout=60)
    return "\n\n".join(texts) if proc.returncode == 0 else ""


def stop() -> bool:
    from . import approvals, team
    approvals.deny_all()  # nothing waits for an answer once the turn is stopped
    helpers = team.stop_all()
    with S.lock:
        turn = S.live
        proc = turn.get("proc") if turn else None
    if proc is None:
        return helpers
    try:
        if os.name == "nt":
            # The agents start helper processes (servers, sandboxes): end the whole tree.
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)], capture_output=True,
                           creationflags=subprocess.CREATE_NO_WINDOW, timeout=15)
        else:
            proc.terminate()
    except (OSError, subprocess.SubprocessError):
        try:
            proc.terminate()
        except OSError:
            pass
    return True


def _card(tool, text):
    """What a render card needs from a tool's reply: the view and look of a render; a
    trial's id, image labels and measured change."""
    if tool not in ("render_view", "try_edit", "apply_trial"):
        return None
    try:
        # The reply is JSON first; anything an agent's tooling appends after it is ignored.
        data, _ = json.JSONDecoder().raw_decode(text.lstrip())
    except ValueError:
        return None
    if not isinstance(data, dict):
        return None
    if tool == "render_view":
        return {"kind": "render", "view": data.get("view"), "look": data.get("look")}
    if tool == "apply_trial":
        return {"kind": "applied", "label": data.get("applied")}
    measured = {}
    for view, m in (data.get("measured") or {}).items():
        if isinstance(m, dict):
            measured[view] = {k: m.get(k) for k in ("verdict", "changed_share", "where")}
            measured[view]["brightness"] = (m.get("in_changed_area") or {}).get("brightness")
    return {"kind": "trial", "trial_id": data.get("trial_id"), "labels": data.get("images") or [],
            "measured": measured, "hint": (data.get("measured") or {}).get("hint")}


def _tool_summary(name, tool_input):
    short = name.replace("mcp__agent-blender__", "")
    detail = ""
    if isinstance(tool_input, dict):
        if "label" in tool_input:
            detail = tool_input["label"]
        elif "code" in tool_input:
            detail = tool_input["code"].strip().splitlines()[0][:80] if tool_input["code"].strip() else ""
        elif "query" in tool_input:
            detail = tool_input["query"]
        elif "prompt" in tool_input:
            detail = tool_input["prompt"][:80]
        elif "view" in tool_input:
            detail = tool_input["view"]
        elif any(k in tool_input for k in ("file_path", "filePath", "path")):
            path = tool_input.get("file_path") or tool_input.get("filePath") or tool_input.get("path")
            detail = os.path.basename(str(path))
        elif "pattern" in tool_input:
            detail = str(tool_input["pattern"])[:80]
    return short, str(detail)


# Blender sets these for its own libraries; agents (Node/Bun programs) should not inherit them.
_BLENDER_ENV = ("SSL_CERT_FILE", "OCIO", "MATERIALX_SEARCH_PATH", "OIIO_LOAD_DLLS_FROM_PATH",
                "PXR_MTLX_STDLIB_SEARCH_PATHS", "PXR_USD_WINDOWS_DLL_PATH", "SYCL_UR_USE_LEVEL_ZERO_V2")


def _child_env(cwd):
    """The agent's environment. PWD must match the folder: OpenCode takes its project folder
    from PWD, and Blender's own PWD (from wherever it was launched) is stale."""
    env = {k: v for k, v in os.environ.items() if k not in _BLENDER_ENV}
    env["PWD"] = cwd
    env.setdefault("MCP_TOOL_TIMEOUT", str(runners.TOOL_TIMEOUT_S * 1000))  # Claude Code, in ms
    return env


def _set_live(**kw):
    with S.lock:
        if S.live:
            S.live.update(kw)
        S.revision += 1


def _run_turn(local_id, prompt, runner_key, exe, resume, model, effort, research=False):
    r = runners.get(runner_key)
    work = os.path.join(S.root, "work", runner_key)
    os.makedirs(work, exist_ok=True)
    # The chat's agent names itself, so the others (and history) know who it is.
    mcp_url = "http://127.0.0.1:{}/mcp?client=chat-{}".format(S.port, runner_key)
    effort = effort if effort in r.efforts else ""
    shown_effort = effort or r.defaults().get("effort", "")
    ran_model = model or r.defaults().get("model", "")
    state = {"_model": ran_model}
    err_tail = []
    done, error, got_text, acted = False, None, False, False
    started = time.time()
    try:
        kwargs = {"tool_names": S.tool_names} if runner_key in ("codex", "opencode") else {}
        if research:
            from . import approvals
            kwargs.update(research=True, ask=approvals.asking())  # the agent's own web tools on
        if runner_key == "opencode":
            kwargs["env_for"] = _child_env
            _set_live(activity="connecting OpenCode to Blender")
        cmd, stdin_text, cwd = r.command(exe, work, prompt, resume, model, effort, SYSTEM_PROMPT, mcp_url,
                                         **kwargs)
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        attempt = 0
        while True:
            proc = subprocess.Popen(cmd, cwd=cwd, env=_child_env(cwd), stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags)
            _set_live(proc=proc)
            threading.Thread(target=lambda p=proc: err_tail.extend(p.stderr.read().decode("utf-8", "replace")
                                                                   .splitlines()[-20:]), daemon=True).start()
            try:
                proc.stdin.write(stdin_text.encode("utf-8"))
                proc.stdin.close()
            except OSError:
                pass
            for raw in proc.stdout:
                try:
                    msg = json.loads(raw)
                except ValueError:
                    continue
                if not isinstance(msg, dict):
                    continue
                for ev in r.parse(msg, state):
                    kind = ev[0]
                    if kind == "session" and ev[1]:
                        with S.lock:
                            S.sessions[local_id]["runner"] = runner_key
                            S.sessions[local_id]["runner_session"] = ev[1]
                            _save_index()
                    elif kind == "model" and ev[1]:
                        ran_model = ev[1]
                        if runner_key == "claude":
                            learn_model(ran_model)
                        with S.lock:
                            S.sessions[local_id]["model"] = ran_model
                            if S.live:
                                S.live["model"] = ran_model
                    elif kind == "delta":
                        with S.lock:
                            if S.live:
                                S.live["text"] += ev[1]
                                S.live["activity"] = "writing"
                            S.revision += 1
                    elif kind == "text":
                        got_text = True
                        add_reply(local_id, ev[1])
                        _set_live(text="")
                    elif kind == "tool":
                        _, cid, name, tool_input = ev
                        short, detail = _tool_summary(name, tool_input)
                        state[cid] = short
                        if name in WEB_TOOLS or short in WEB_TOOLS:
                            _set_live(web_used=True)  # edits after this ask first (auto research)
                        if short in _HIDDEN_TOOLS:
                            continue
                        _append(local_id, {"role": "tool", "tool": short, "detail": detail})
                        _set_live(activity="using " + short + ("" if not detail else ": " + detail[:40]))
                    elif kind == "result":
                        _, cid, name, ok, text, images = ev
                        short = state.get(cid) or _tool_summary(name, None)[0]
                        if short in _HIDDEN_TOOLS:
                            continue
                        names = [_save_png(local_id, png) for png in images]  # unique: a team saves too
                        entry = {"role": "tool_result", "tool": short, "ok": bool(ok), "text": text[:_MAX_TOOL_TEXT]}
                        if names:
                            entry["images"] = names
                        card = _card(short, text) if ok else None
                        if card:
                            entry["card"] = card
                        _append(local_id, entry)
                        _set_live(activity="thinking")
                    elif kind == "context":
                        _record_context(local_id, runner_key, ev[1], ev[2])
                    elif kind == "done":
                        done, error = True, ev[1]
            proc.wait(timeout=60)
            # A runner that failed before doing anything may know how to recover (OpenCode's
            # config reload); nothing ran yet, so retrying cannot repeat work.
            if error and not got_text and not acted:
                retry = r.recover(cmd, cwd, error, attempt)
                if retry:
                    cmd, cwd = retry
                    attempt += 1
                    done, error = False, None
                    state = {"_model": ran_model}
                    _set_live(activity="starting " + r.label)
                    continue
            break
        stopped = proc.returncode not in (0, None) and not done
        if not done and got_text and proc.returncode == 0:
            done = True  # OpenCode ends with the process, not an event
        if error:
            _append(local_id, {"role": "system", "text": error})
        if not done:
            reason = "was stopped" if stopped else "ended without an answer"
            detail = " ".join(err_tail[-3:])
            _append(local_id, {"role": "system", "text": "{} {}{}".format(r.label, reason,
                                                                         (": " + detail) if detail else "")})
        else:
            with S.lock:
                meta = S.sessions[local_id]
                meta["turns"] += 1
                meta["updated"] = time.time()
                session = meta.get("runner_session")
                _save_index()
            if runner_key != "claude" and session:
                _set_live(activity="measuring the context")
                got = r.context_after(exe, session, ran_model, _child_env)
                if got:
                    _record_context(local_id, runner_key, *got)
            _append(local_id, {"role": "meta", "duration_s": round(time.time() - started, 1),
                               "runner": runner_key, "model": ran_model, "effort": shown_effort})
    except Exception as ex:
        _append(local_id, {"role": "system", "text": "Could not run {}: {}".format(r.label, ex)})
    finally:
        with S.lock:
            S.live = None
            S.revision += 1
        try:
            from . import team
            team.on_lead_done(local_id)
        except Exception as ex:  # never let the team break the chat
            _append(local_id, {"role": "system", "text": "Team: {}".format(ex)})
