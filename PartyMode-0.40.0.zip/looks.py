# SPDX-License-Identifier: GPL-3.0-or-later
"""
The chat's looks, picked in the add-on preferences: Halo (A), Signal (B) and Classic.

Same layout and behaviour in each; a look changes type, shape, light and the agent's texture
behind the chat (see the "UI directions" Figma board). On a dark Blender theme Halo and Signal use
their own palettes; on a light theme every look keeps the theme-derived one, so light themes work.

Fonts ship in fonts/ under the SIL Open Font License (the OFL-*.txt files beside them).
"""

import os

import bpy

FONTS = os.path.join(os.path.dirname(__file__), "fonts")


def _hex(h, a=1.0):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (a,)


LOOKS = {
    "HALO": {
        "label": "Halo",
        "fonts": {"ui": ("Geist-Regular.ttf", "Geist-SemiBold.ttf"),
                  "mono": ("GeistMono-Regular.ttf", "GeistMono-SemiBold.ttf"),
                  "head": ("Geist-Regular.ttf", "Geist-SemiBold.ttf")},
        "dark": {"bg": "#0F1013", "drawer": "#131519", "surface": "#17191E", "surface2": "#1F2229",
                 "border": "#2B2F37", "border2": "#3E434E", "text": "#EDEEF0", "muted": "#9298A3",
                 "faint": "#5F646E", "code_bg": "#1C1F25"},
        "radius": {"bubble": 14, "card": 16, "chip": 999, "composer": 18, "button": 999, "steps": 999},
        "steps": "pill",       # one rounded pill: a check, the count, tool names in mono
        "head": "orb",         # a glowing dot, the agent's name, the time
        "upper": False,        # labels as written
        "brackets": False,     # "[ YOU ]" labels
        "glow": True,          # coloured soft shadows: the focus ring, send key, orbs
        "wash": 0.10,          # the agent's colour washed down from the top of the chat
        "ticks": False,        # corner ticks on the focused panel
        "bullet": "dot",
        "prompt": "",          # drawn before the message in the box
        "texture": {"claude": ("dots", 18, 0.15), "codex": ("cross", 28, 0.13), "opencode": ("dash", 22, 0.12)},
    },
    "SIGNAL": {
        "label": "Signal",
        "fonts": {"ui": ("InstrumentSans-Regular.ttf", "InstrumentSans-SemiBold.ttf"),
                  "mono": ("JetBrainsMono-Regular.ttf", "JetBrainsMono-SemiBold.ttf"),
                  "head": ("MartianMono-Regular.ttf", "MartianMono-SemiBold.ttf")},
        "dark": {"bg": "#0A0B0C", "drawer": "#0E1012", "surface": "#111315", "surface2": "#171A1D",
                 "border": "#2C3237", "border2": "#3C444A", "text": "#E4E7E9", "muted": "#8A9298",
                 "faint": "#5A6168", "code_bg": "#15181B"},
        "radius": {"bubble": 3, "card": 3, "chip": 2, "composer": 3, "button": 2, "steps": 2},
        "steps": "log",        # a timestamped log on a rail, every step on its own row
        "head": "led",         # a square LED and "[ CODEX ]" in the agent's colour
        "upper": True,
        "brackets": True,
        "glow": False,
        "wash": 0.0,
        "ticks": True,
        "bullet": "chevron",
        "prompt": "›",
        "texture": {"claude": ("dots", 18, 0.21), "codex": ("cross", 28, 0.20), "opencode": ("dash", 22, 0.18)},
    },
    "CLASSIC": {
        "label": "Classic",
        "fonts": {"ui": None, "mono": None, "head": None},  # Blender's own
        "dark": None,
        "radius": {"bubble": 18, "card": 14, "chip": 999, "composer": 20, "button": 999, "steps": 8},
        "steps": "classic",
        "head": "classic",
        "upper": False,
        "brackets": False,
        "glow": False,
        "wash": 0.0,
        "ticks": False,
        "bullet": "dot",
        "prompt": "",
        "texture": {},
    },
}
DEFAULT = "HALO"
ITEMS = (("HALO", "Halo", "Polished and luminous: graphite surfaces, the agent's colour as light (Geist)"),
         ("SIGNAL", "Signal", "Instrument panel: ink-black, hairlines, a timestamped step log (Instrument Sans, "
                              "JetBrains Mono)"),
         ("CLASSIC", "Classic", "The original look, in Blender's own fonts"))

_state = {"name": None}


def name():
    """The look picked in the preferences (Halo before the add-on's preferences exist)."""
    if _state["name"]:
        return _state["name"]
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        n = getattr(prefs, "ui_look", DEFAULT)
    except (KeyError, AttributeError):
        return DEFAULT  # not stored: the preferences may come later
    _state["name"] = n if n in LOOKS else DEFAULT
    return _state["name"]


def get():
    return LOOKS[name()]


SEMIBOLD = 600  # weights from here up draw from the semibold file


def font_path(role, weight=400):
    """The font file for a role (ui: prose, mono: names, numbers and code, head: headings) at a
    weight, or None for Blender's own. Each role ships a regular and a semibold file: Blender's
    blf has no weights, so a weight is a file."""
    files = get()["fonts"].get(role)
    if not files:
        return None
    path = os.path.join(FONTS, files[1 if weight >= SEMIBOLD else 0])
    return path if os.path.isfile(path) else None


def amend_palette(pal, light):
    """The look's colours over the theme-derived palette (dark themes only)."""
    look = get()
    dark = look.get("dark")
    if dark and not light:
        for k, v in dark.items():
            pal[k] = _hex(v)
    return pal


def label(text):
    """A label as the look writes it: Signal in capitals."""
    return text.upper() if get()["upper"] else text


def tag(text):
    """A name tag: Signal writes [ CODEX ], the others Codex."""
    look = get()
    t = text.upper() if look["upper"] else text
    return "[ {} ]".format(t) if look["brackets"] else t


def radius(part, s, h=None):
    """Corner radius for a part in region pixels; 999 means a pill (half the height)."""
    r = get()["radius"].get(part, 10)
    if r >= 999:
        return (h / 2) if h else 999 * s
    return r * s


def use(look):
    """Switch to a look: the preference when the add-on has one, else for this session."""
    if look not in LOOKS:
        raise ValueError("No look {!r} (looks: {})".format(look, ", ".join(LOOKS)))
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
    except KeyError:
        prefs = None
    if prefs is not None and hasattr(prefs, "ui_look"):
        prefs.ui_look = look  # its update calls switched()
    else:
        switched()
        _state["name"] = look


def switched():
    """After a change of look: fonts, measures and layouts are built again."""
    _state["name"] = None
    from . import ui_draw, ui_space
    ui_draw.reset_fonts()
    ui_space._layout_cache.clear()
    ui_space._redraw_all()
