# SPDX-License-Identifier: GPL-3.0-or-later
"""
Receipts make edits safe to retry.

Every mutating call carries a ``call_id``. The first call with an id runs on
the main thread; any later call with the same id (a retry after a timeout, a
duplicate send) waits for or returns the stored result instead of running
again. A call that outlives the caller's timeout keeps running and its
receipt is completed when Blender finishes, so ``call_status`` stays truthful.
"""

import threading
import time
import uuid
from collections import OrderedDict

from . import mainthread

_MAX_RECEIPTS = 1000

_lock = threading.Lock()
_receipts: "OrderedDict[str, dict]" = OrderedDict()
_in_flight: "dict[str, threading.Event]" = {}


def new_id() -> str:
    return str(uuid.uuid4())


def get(call_id: str):
    with _lock:
        receipt = _receipts.get(call_id)
        return dict(receipt) if receipt else None


def recent(limit: int = 20) -> list:
    with _lock:
        items = list(_receipts.values())[-limit:]
    return [{k: v for k, v in r.items() if k != "result"} for r in reversed(items)]


def _store(call_id: str, receipt: dict) -> None:
    with _lock:
        _receipts[call_id] = receipt
        _receipts.move_to_end(call_id)
        while len(_receipts) > _MAX_RECEIPTS:
            _receipts.popitem(last=False)


def run_once(call_id: str, tool: str, main_fn, timeout: float = 120.0, before=None) -> dict:
    """
    Run ``main_fn()`` on the main thread at most once per ``call_id``.

    ``before``, if given, runs first on a background thread (an edit's slow preparation: a
    download, a remesh in a child Blender) and returns the function to run on the main thread
    instead of ``main_fn``. The ``timeout`` wait covers both, so a long preparation answers
    "running" like a long edit, and call_status follows it.

    ``main_fn`` returns a JSON-friendly dict (``isError`` marks a failure).
    Returns the receipt: ``{call_id, tool, status, result?, replayed}`` where
    status is ``succeeded``, ``failed`` or ``running``.
    """
    with _lock:
        existing = _receipts.get(call_id)
        event = _in_flight.get(call_id)
        owner = existing is None
        if owner:
            event = threading.Event()
            _in_flight[call_id] = event
            _receipts[call_id] = {
                "call_id": call_id, "tool": tool, "status": "running", "started": time.time(),
            }

    if not owner:
        if event is not None:
            event.wait(timeout)
        receipt = get(call_id)
        receipt["replayed"] = True
        return receipt

    def on_done(job):
        if job.error is not None:
            result = {
                "isError": True,
                "error": "{}: {}".format(type(job.error).__name__, job.error),
            }
        else:
            result = job.result
        receipt = {
            "call_id": call_id, "tool": tool,
            "status": "failed" if result.get("isError") else "succeeded",
            "result": result, "finished": time.time(),
        }
        _store(call_id, receipt)
        with _lock:
            done_event = _in_flight.pop(call_id, None)
        if done_event is not None:
            done_event.set()

    with _lock:
        finished = _in_flight.get(call_id)
    if before is None:
        mainthread.submit(main_fn, on_done=on_done)
    else:
        def prepare():
            try:
                fn = before()
            except BaseException as ex:  # reported like a failure of the edit itself
                def fn(ex=ex):
                    raise ex
            mainthread.submit(fn, on_done=on_done)
        threading.Thread(target=prepare, name="agent-prepare", daemon=True).start()
    finished.wait(timeout)
    receipt = get(call_id)
    receipt["replayed"] = False
    return receipt
