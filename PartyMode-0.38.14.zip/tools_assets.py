# SPDX-License-Identifier: GPL-3.0-or-later
"""
Ready-made assets before modelling from scratch: Poly Haven (free CC0 models,
PBR textures, HDRI skies, with real-world sizes) and the user's own Blender
asset libraries. Downloads run on the server thread so Blender stays responsive.
"""

import json
import math
import os
import threading
import time
import urllib.parse
import urllib.request

import bpy

from . import assetwords, placement
from .registry import ToolError, get_object, r, tool

_API = "https://api.polyhaven.com"
_UA = {"User-Agent": "agent-blender/0.1 (Blender agent bridge)"}
_KINDS = {"model": "models", "texture": "textures", "hdri": "hdris"}
_catalog: "dict[str, dict]" = {}
_catalog_t: "dict[str, float]" = {}
_lock = threading.Lock()


def _cache_dir(*parts) -> str:
    return bpy.utils.user_resource('CONFIG', path=os.path.join("agent_bridge", "assets", *parts), create=True)


def _get_json(url):
    req = urllib.request.Request(url, headers=_UA)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except Exception as ex:
        raise ToolError("Poly Haven is not reachable ({}).".format(ex)) from None


def _download(url, path):
    if os.path.isfile(path) and os.path.getsize(path) > 0:
        return path
    os.makedirs(os.path.dirname(path), exist_ok=True)
    req = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(req, timeout=300) as resp, open(path + ".part", "wb") as fh:
        while chunk := resp.read(1 << 20):
            fh.write(chunk)
    os.replace(path + ".part", path)
    return path


def _polyhaven(kind_plural):
    with _lock:
        if kind_plural in _catalog and time.time() - _catalog_t[kind_plural] < 3600:
            return _catalog[kind_plural]
    data = _get_json("{}/assets?t={}".format(_API, kind_plural))
    with _lock:
        _catalog[kind_plural], _catalog_t[kind_plural] = data, time.time()
    return data


_indexes = {}  # kinds -> (catalogue ids, assetwords.Index)


def _polyhaven_index(kinds):
    cats = {k: _polyhaven(_KINDS[k]) for k in kinds}
    key = tuple(kinds)
    ids = tuple(id(c) for c in cats.values())
    with _lock:
        hit = _indexes.get(key)
        if hit and hit[0] == ids:
            return hit[1], cats
    index = assetwords.Index(((k, aid), aid + " " + meta.get("name", ""),
                              meta.get("tags", []) + meta.get("categories", []), meta.get("description", ""))
                             for k, cat in cats.items() for aid, meta in cat.items())
    with _lock:
        _indexes[key] = (ids, index)
    return index, cats


def _local_assets():
    """Every asset in the user's asset libraries (no file is changed)."""
    out = []
    for lib in bpy.context.preferences.filepaths.asset_libraries:
        root = bpy.path.abspath(lib.path)
        if not os.path.isdir(root):
            continue
        for folder, _dirs, files in os.walk(root):
            for f in files:
                if not f.endswith(".blend"):
                    continue
                path = os.path.join(folder, f)
                try:
                    with bpy.data.libraries.load(path, assets_only=True) as (src, _dst):
                        groups = {"objects": list(src.objects), "collections": list(src.collections),
                                  "materials": list(src.materials), "node_groups": list(src.node_groups),
                                  "worlds": list(src.worlds)}
                except Exception:
                    continue
                for dtype, names in groups.items():
                    for n in names:
                        out.append({"source": "local", "library": lib.name, "file": path,
                                    "type": dtype, "id": n, "name": n})
    return out


def _explain(index, missing, loose, kind, source, found=()):
    """What to tell the user about query words the libraries do not know."""
    where = {"polyhaven": "Poly Haven", "local": "your asset libraries"}.get(source, "Poly Haven or your libraries")
    out = {}
    for w in missing:
        out[w] = {"found": "none", "nearest": index.nearest(w),
                  "note": "No asset in {} is called or tagged '{}'.".format(where, w)}
    for w in loose:
        out[w] = {"found": "loose", "nearest": index.nearest(w, found=found),
                  "note": "Nothing is called or tagged '{}'; these results only share part of the word "
                          "or a similar spelling, so check them.".format(w)}
    if kind in {"model", "any"}:
        for v in out.values():
            v["or"] = "generate_3d can make one on the user's GPU"
    return out


def _entry_extras(entry, q, covered, why):
    if len(q) > 1:
        entry["covers"] = "{}/{}: {}".format(len(covered), len(q), " ".join(covered))
    if why:
        entry["matched"] = why
    return entry


@tool("search_assets",
      "Find ready-made assets before modelling or texturing from scratch. source polyhaven: free "
      "CC0 models (with real-world size), PBR textures and HDRI skies; local: the user's Blender "
      "asset libraries. kind: model, texture, hdri or any. Words match names and tags, also as "
      "synonyms (pail -> bucket), word parts (seashell -> shell) and near spellings; results rank "
      "by how many query words they cover and say why they matched. `words` lists query words "
      "found nowhere or only loosely, with the nearest words the library has: tell the user, then "
      "search again with those or generate one. show_thumbnails returns previews of the top "
      "results. Add one with add_asset.",
      {"query": {"type": "string", "minLength": 1},
       "kind": {"type": "string", "enum": ["model", "texture", "hdri", "any"], "default": "any"},
       "source": {"type": "string", "enum": ["polyhaven", "local", "all"], "default": "all"},
       "limit": {"type": "integer", "minimum": 1, "maximum": 40, "default": 12},
       "show_thumbnails": {"type": "boolean", "default": False}},
      required=("query",), on_main=False)
def search_assets(args):
    kind, source = args.get("kind", "any"), args.get("source", "all")
    limit = int(args.get("limit", 12))
    ranked = []        # (covered count, score, entry)
    searched = []      # (index, query words, missing, loose) per library
    if source in {"polyhaven", "all"}:
        index, cats = _polyhaven_index([kind] if kind != "any" else list(_KINDS))
        found, q, missing, loose = index.search(args["query"])
        searched.append((index, q, missing, loose))
        for (k, aid), score, covered, why in found[: limit * 3]:
            meta = cats[k][aid]
            entry = {"source": "polyhaven", "kind": k, "id": aid, "name": meta.get("name"),
                     "categories": meta.get("categories", [])[:4], "tags": meta.get("tags", [])[:6]}
            if k == "model" and meta.get("dimensions"):
                entry["size_m"] = [r(d / 1000.0, 3) for d in meta["dimensions"]]
                entry["polycount"] = meta.get("polycount")
            if k == "texture" and meta.get("dimensions"):
                entry["covers_m"] = [r(d / 1000.0, 2) for d in meta["dimensions"]]
            ranked.append((len(covered), score, _entry_extras(entry, q, covered, why)))
    if source in {"local", "all"} and kind in {"model", "any", "texture"}:
        from .mainthread import run_on_main
        local = run_on_main(_local_assets)
        if local:
            lindex = assetwords.Index((i, e["name"], [e["type"], e["library"]], "") for i, e in enumerate(local))
            found, q, missing, loose = lindex.search(args["query"])
            searched.append((lindex, q, missing, loose))
            for i, score, covered, why in found[: limit * 3]:
                # The user's own assets first on a tie.
                ranked.append((len(covered), score * 1.05, _entry_extras(dict(local[i]), q, covered, why)))
    ranked.sort(key=lambda t: (-t[0], -t[1]))
    results = [e for _c, _s, e in ranked][:limit]
    # A word is missing only if no library has it, loose if none has it properly.
    words_info = {}
    if searched:
        q = searched[0][1]
        missing = [w for w in q if all(w in s[2] for s in searched)]
        strong = {w for s in searched for w in s[1] if w not in s[2] and w not in s[3]}
        loose = [w for w in q if w not in missing and w not in strong]
        first = searched[0][0]
        top_keys = [k for k, *_ in first.search(args["query"])[0][:8]] if loose else ()
        words_info = _explain(first, missing, loose, kind, source, top_keys)
    images = []
    if args.get("show_thumbnails"):
        for e in [e for e in results if e["source"] == "polyhaven"][:4]:
            url = "https://cdn.polyhaven.com/asset_img/thumbs/{}.png?width=256&height=256".format(e["id"])
            try:
                req = urllib.request.Request(url, headers=_UA)
                with urllib.request.urlopen(req, timeout=20) as resp:
                    images.append(resp.read())
            except Exception:
                pass
    data = {"query": args["query"], "results": results}
    if words_info:
        data["words"] = words_info
    data["thumbnails"] = [e["id"] for e in results if e["source"] == "polyhaven"][:len(images)]
    data["license"] = "Poly Haven assets are CC0 (free for any use, no credit needed)."
    return {"data": data, "images": images}


# ---------------------------------------------------------------------------
# Adding assets: downloads in `prepare` (server thread), scene work in the tool (main thread).

def _pick_res(files_by_res: dict, want: str) -> str:
    order = ["1k", "2k", "4k", "8k", "16k"]
    if want in files_by_res:
        return want
    for res in order:
        if res in files_by_res:
            return res
    raise ToolError("No downloadable resolution found.")


def _prepare_add(args):
    if args.get("source", "polyhaven") != "polyhaven":
        return args
    aid, kind, res = args["id"], args.get("kind", "model"), args.get("resolution", "1k")
    files = _get_json("{}/files/{}".format(_API, urllib.parse.quote(aid)))
    folder = _cache_dir("polyhaven", aid)
    if kind == "model":
        gltf = files.get("gltf") or {}
        res = _pick_res(gltf, res)
        entry = gltf[res]["gltf"]
        main = _download(entry["url"], os.path.join(folder, res, os.path.basename(entry["url"])))
        for rel, inc in entry.get("include", {}).items():
            _download(inc["url"], os.path.join(folder, res, rel.replace("/", os.sep)))
        args["_file"] = main
    elif kind == "texture":
        maps = {}
        for key, ph in (("color", "Diffuse"), ("normal", "nor_gl"), ("rough", "Rough"),
                        ("arm", "arm"), ("disp", "Displacement"), ("metal", "Metal")):
            if ph in files:
                res_k = _pick_res(files[ph], res)
                fmt = files[ph][res_k].get("jpg") or files[ph][res_k].get("png") or next(iter(files[ph][res_k].values()))
                maps[key] = _download(fmt["url"], os.path.join(folder, res_k, os.path.basename(fmt["url"])))
        if "color" not in maps:
            raise ToolError("{!r} has no colour map.".format(aid))
        args["_maps"] = maps
        args["_covers_m"] = None
        try:
            meta = _polyhaven("textures").get(aid, {})
            if meta.get("dimensions"):
                args["_covers_m"] = [d / 1000.0 for d in meta["dimensions"]]
        except ToolError:
            pass
    elif kind == "hdri":
        hd = files.get("hdri") or {}
        res = _pick_res(hd, args.get("resolution", "2k"))
        fmt = hd[res].get("hdr") or hd[res].get("exr")
        args["_file"] = _download(fmt["url"], os.path.join(folder, res, os.path.basename(fmt["url"])))
    else:
        raise ToolError("kind must be model, texture or hdri.")
    return args


def _texture_material(name, maps, covers_m, tile_m):
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    out.location = (600, 0)
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (300, 0)
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    coord = nt.nodes.new("ShaderNodeTexCoord")
    coord.location = (-900, 0)
    mapping = nt.nodes.new("ShaderNodeMapping")
    mapping.location = (-700, 0)
    # Object coordinates in metres: the texture repeats every `tile_m` metres, at true scale.
    size = tile_m or (covers_m[0] if covers_m else 1.0)
    mapping.inputs["Scale"].default_value = (1.0 / size,) * 3
    nt.links.new(coord.outputs["Object"], mapping.inputs["Vector"])

    def image_node(path, y, colour):
        node = nt.nodes.new("ShaderNodeTexImage")
        node.location = (-400, y)
        node.image = bpy.data.images.load(path, check_existing=True)
        node.image.colorspace_settings.name = "sRGB" if colour else "Non-Color"
        node.projection = 'BOX'
        node.projection_blend = 0.2
        nt.links.new(mapping.outputs["Vector"], node.inputs["Vector"])
        return node

    col = image_node(maps["color"], 300, True)
    nt.links.new(col.outputs["Color"], bsdf.inputs["Base Color"])
    if "arm" in maps:
        arm = image_node(maps["arm"], 0, False)
        sep = nt.nodes.new("ShaderNodeSeparateColor")
        sep.location = (-100, 0)
        nt.links.new(arm.outputs["Color"], sep.inputs["Color"])
        nt.links.new(sep.outputs["Green"], bsdf.inputs["Roughness"])
        nt.links.new(sep.outputs["Blue"], bsdf.inputs["Metallic"])
    elif "rough" in maps:
        rough = image_node(maps["rough"], 0, False)
        nt.links.new(rough.outputs["Color"], bsdf.inputs["Roughness"])
    if "normal" in maps:
        nor = image_node(maps["normal"], -300, False)
        nmap = nt.nodes.new("ShaderNodeNormalMap")
        nmap.location = (-100, -300)
        nt.links.new(nor.outputs["Color"], nmap.inputs["Color"])
        nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])
    if "disp" in maps:
        disp = image_node(maps["disp"], -600, False)
        dnode = nt.nodes.new("ShaderNodeDisplacement")
        dnode.location = (300, -500)
        dnode.inputs["Scale"].default_value = 0.02 * size
        nt.links.new(disp.outputs["Color"], dnode.inputs["Height"])
        nt.links.new(dnode.outputs["Displacement"], out.inputs["Displacement"])
    return mat


@tool("add_asset",
      "Add an asset found with search_assets. model: imported at its real size (or size_m), stood "
      "on the ground at location, parts grouped under one empty. texture: becomes a PBR material "
      "(colour, roughness/metal, normal, displacement) at true real-world scale (or tile_m metres "
      "per repeat), applied to `objects` if given. hdri: becomes the world lighting and sky "
      "(strength, rotation_deg). local assets are appended from their .blend. Downloads are cached.",
      {"id": {"type": "string"},
       "kind": {"type": "string", "enum": ["model", "texture", "hdri"], "default": "model"},
       "source": {"type": "string", "enum": ["polyhaven", "local"], "default": "polyhaven"},
       "resolution": {"type": "string", "enum": ["1k", "2k", "4k", "8k"], "default": "1k"},
       "name": {"type": "string"},
       "location": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
       "size_m": {"type": "number", "minimum": 0.001},
       "objects": {"type": "array", "items": {"type": "string"}, "maxItems": 64},
       "tile_m": {"type": "number", "minimum": 0.01},
       "strength": {"type": "number", "minimum": 0, "default": 1.0},
       "rotation_deg": {"type": "number", "default": 0},
       "file": {"type": "string", "description": "local only: the .blend file (from search_assets)."},
       "type": {"type": "string", "description": "local only: objects, collections, materials, ..."}},
      required=("id",), mutating=True, prepare=_prepare_add)
def add_asset(args):
    kind, source = args.get("kind", "model"), args.get("source", "polyhaven")
    if source == "local":
        return _append_local(args)
    if kind == "model":
        new = placement.import_file(args["_file"])
        result = placement.place(new, args.get("name") or args["id"], args.get("location") or (0, 0, 0),
                                 args.get("size_m"), "height", join=False)
        result["license"] = "CC0 (Poly Haven)"
        return {"data": result}
    if kind == "texture":
        mat = _texture_material(args.get("name") or args["id"], args["_maps"], args.get("_covers_m"), args.get("tile_m"))
        applied = []
        for n in args.get("objects") or []:
            ob = get_object(n)
            if ob.type not in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'}:
                continue
            ob.data.materials.clear()
            ob.data.materials.append(mat)
            applied.append(ob.name)
        return {"data": {"material": mat.name, "applied_to": applied, "maps": sorted(args["_maps"]),
                         "tile_m": r(args.get("tile_m") or ((args.get("_covers_m") or [1])[0]), 3),
                         "mapping": "box projection in object space (no UVs needed)"}}
    # HDRI world.
    world = bpy.data.worlds.get("Agent HDRI") or bpy.data.worlds.new("Agent HDRI")
    world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputWorld")
    bg = nt.nodes.new("ShaderNodeBackground")
    env = nt.nodes.new("ShaderNodeTexEnvironment")
    mapping = nt.nodes.new("ShaderNodeMapping")
    coord = nt.nodes.new("ShaderNodeTexCoord")
    for node, x in ((coord, -900), (mapping, -700), (env, -400), (bg, -100), (out, 150)):
        node.location = (x, 0)
    env.image = bpy.data.images.load(args["_file"], check_existing=True)
    mapping.inputs["Rotation"].default_value[2] = math.radians(args.get("rotation_deg", 0))
    bg.inputs["Strength"].default_value = float(args.get("strength", 1.0))
    nt.links.new(coord.outputs["Generated"], mapping.inputs["Vector"])
    nt.links.new(mapping.outputs["Vector"], env.inputs["Vector"])
    nt.links.new(env.outputs["Color"], bg.inputs["Color"])
    nt.links.new(bg.outputs["Background"], out.inputs["Surface"])
    bpy.context.scene.world = world
    return {"data": {"world": world.name, "hdri": args["id"], "strength": bg.inputs["Strength"].default_value,
                     "note": "Lighting shows in render_view look=lit."}}


def _append_local(args):
    path, dtype, name = args.get("file"), args.get("type", "objects"), args["id"]
    if not path or not os.path.isfile(path):
        raise ToolError("local assets need `file` and `type` from search_assets.")
    with bpy.data.libraries.load(path, link=False, assets_only=True) as (src, dst):
        if name not in getattr(src, dtype):
            raise ToolError("{!r} is not a {} asset in that file.".format(name, dtype))
        setattr(dst, dtype, [name])
    block = getattr(dst, dtype)[0]
    if dtype == "objects":
        bpy.context.scene.collection.objects.link(block)
        result = placement.place([block], args.get("name") or block.name, args.get("location") or block.location,
                                 args.get("size_m"), "height", join=False)
        return {"data": result}
    if dtype == "collections":
        bpy.context.scene.collection.children.link(block)
        return {"data": {"collection": block.name, "objects": len(block.all_objects)}}
    if dtype == "materials" and args.get("objects"):
        for n in args["objects"]:
            ob = get_object(n)
            ob.data.materials.clear()
            ob.data.materials.append(block)
    return {"data": {"appended": block.name, "type": dtype}}
