# SPDX-License-Identifier: GPL-3.0-or-later
"""
A small client for a local ComfyUI: read the user's saved workflows, turn them
into runnable prompts, fill in inputs, queue them and collect the results.

Saved workflows are in ComfyUI's UI format (nodes + links + widget values);
the /prompt API wants API format (inputs by name). `ui_to_api` converts using
ComfyUI's own node definitions (/object_info), following reroutes, primitive
nodes and bypassed nodes, so any workflow the user builds can be used.
Nothing here touches bpy: it runs on worker threads.
"""

import json
import mimetypes
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

_CONTROL_VALUES = {"fixed", "increment", "decrement", "randomize"}
_SKIP_TYPES = {"Note", "MarkdownNote", "Reroute", "PrimitiveNode", "PrimitiveString",
               "PrimitiveInt", "PrimitiveFloat", "PrimitiveBoolean"}
_PRIMITIVE_TYPES = {"PrimitiveNode", "PrimitiveString", "PrimitiveInt", "PrimitiveFloat", "PrimitiveBoolean"}
MODE_MUTED, MODE_BYPASS = 2, 4


class ComfyError(Exception):
    pass


class Client:
    def __init__(self, url: str = "http://127.0.0.1:8188"):
        self.url = url.rstrip("/")
        self.client_id = "agent-bridge-" + uuid.uuid4().hex[:8]
        self._object_info = None

    # -- HTTP --------------------------------------------------------------
    def _req(self, path, data=None, headers=None, timeout=30, raw=False):
        req = urllib.request.Request(self.url + path, data=data, headers=headers or {})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read()
        except urllib.error.HTTPError as ex:
            detail = ex.read().decode("utf-8", "replace")[:2000]
            raise ComfyError("ComfyUI {} on {}: {}".format(ex.code, path, detail)) from None
        except (urllib.error.URLError, ConnectionError, TimeoutError) as ex:
            raise ComfyError("ComfyUI is not reachable at {} ({}). Start ComfyUI and try again."
                             .format(self.url, getattr(ex, "reason", ex))) from None
        return body if raw else json.loads(body or b"null")

    def alive(self) -> dict:
        return self._req("/system_stats", timeout=3)

    def object_info(self) -> dict:
        if self._object_info is None:
            self._object_info = self._req("/object_info", timeout=60)
        return self._object_info

    def list_workflows(self) -> list:
        items = self._req("/api/userdata?dir=workflows&recurse=true")
        return sorted(i[:-5] for i in items if isinstance(i, str) and i.endswith(".json"))

    def load_workflow(self, name: str) -> dict:
        path = urllib.parse.quote("workflows/{}.json".format(name), safe="")
        return self._req("/api/userdata/" + path)

    def upload_image(self, filepath: str) -> str:
        """Upload a local image for LoadImage nodes; returns the name ComfyUI stored it under."""
        boundary = "----agentbridge" + uuid.uuid4().hex
        filename = os.path.basename(filepath)
        with open(filepath, "rb") as fh:
            payload = fh.read()
        ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        body = b"".join([
            "--{}\r\nContent-Disposition: form-data; name=\"image\"; filename=\"{}\"\r\nContent-Type: {}\r\n\r\n"
            .format(boundary, filename, ctype).encode(), payload,
            "\r\n--{}\r\nContent-Disposition: form-data; name=\"overwrite\"\r\n\r\ntrue\r\n--{}--\r\n"
            .format(boundary, boundary).encode(),
        ])
        res = self._req("/upload/image", body, {"Content-Type": "multipart/form-data; boundary=" + boundary})
        sub = res.get("subfolder")
        return "{}/{}".format(sub, res["name"]) if sub else res["name"]

    def queue(self, prompt: dict) -> str:
        body = json.dumps({"prompt": prompt, "client_id": self.client_id}).encode()
        res = self._req("/prompt", body, {"Content-Type": "application/json"})
        if res.get("node_errors"):
            raise ComfyError("ComfyUI rejected the workflow: {}".format(json.dumps(res["node_errors"])[:2000]))
        return res["prompt_id"]

    def history(self, prompt_id: str):
        return self._req("/history/" + prompt_id).get(prompt_id)

    def queue_position(self, prompt_id: str):
        q = self._req("/queue")
        running = [item[1] for item in q.get("queue_running", [])]
        pending = [item[1] for item in q.get("queue_pending", [])]
        if prompt_id in running:
            return 0
        if prompt_id in pending:
            return pending.index(prompt_id) + 1
        return None

    def download(self, file_ref: dict, folder: str) -> str:
        query = urllib.parse.urlencode({"filename": file_ref["filename"], "subfolder": file_ref.get("subfolder", ""),
                                        "type": file_ref.get("type", "output")})
        data = self._req("/view?" + query, raw=True, timeout=300)
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, os.path.basename(file_ref["filename"]))
        with open(path, "wb") as fh:
            fh.write(data)
        return path

    def interrupt(self) -> None:
        self._req("/interrupt", b"{}", {"Content-Type": "application/json"})

    def wait(self, prompt_id: str, timeout_s: float, on_progress=None) -> dict:
        """Poll until the prompt finishes; return its history entry (raises on error)."""
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            entry = self.history(prompt_id)
            if entry:
                status = entry.get("status") or {}
                if status.get("status_str") == "error":
                    msgs = [m for m in status.get("messages", []) if m and m[0] == "execution_error"]
                    detail = msgs[0][1] if msgs else status
                    if isinstance(detail, dict):
                        detail = "{} in node {} ({}): {}".format(
                            detail.get("exception_type"), detail.get("node_id"),
                            detail.get("node_type"), detail.get("exception_message", "").strip())
                    raise ComfyError("Generation failed: {}".format(detail))
                if status.get("completed") or entry.get("outputs"):
                    return entry
            if on_progress:
                on_progress(self.queue_position(prompt_id))
            time.sleep(1.0)
        raise ComfyError("Generation took longer than {:.0f}s; it may still finish in ComfyUI.".format(timeout_s))


def output_files(entry: dict) -> list:
    """Every file a finished prompt produced: [{filename, subfolder, type, node, kind}]."""
    files = []
    for node_id, out in (entry.get("outputs") or {}).items():
        for kind, items in out.items():
            if not isinstance(items, list):
                continue
            for item in items:
                if isinstance(item, dict) and "filename" in item and item.get("type", "output") != "temp":
                    files.append(dict(item, node=node_id, kind=kind))
                elif isinstance(item, str) and os.path.splitext(item)[1].lower() in {".glb", ".gltf", ".obj", ".fbx", ".ply"}:
                    sub, name = os.path.split(item.replace("\\", "/"))
                    files.append({"filename": name, "subfolder": sub, "type": "output", "node": node_id, "kind": kind})
    return files


# ---------------------------------------------------------------------------
# UI format -> API format.

def _ordered_inputs(info: dict) -> list:
    spec = info.get("input", {})
    order = info.get("input_order") or {}
    out = []
    for group in ("required", "optional"):
        names = order.get(group) or list((spec.get(group) or {}).keys())
        for name in names:
            s = (spec.get(group) or {}).get(name)
            if s is not None:
                out.append((name, s))
    return out


def _is_widget(name, spec, node_inputs) -> bool:
    """
    The UI format lists every socket in the node's ``inputs`` (connected or not); widgets
    are absent there or carry a ``widget`` key (a widget converted to a socket). Custom
    widget types such as COLOR are therefore handled without knowing them.
    """
    if name in node_inputs:
        return "widget" in node_inputs[name]
    opts = spec[1] if isinstance(spec, (list, tuple)) and len(spec) > 1 and isinstance(spec[1], dict) else {}
    return not opts.get("forceInput")


def ui_to_api(workflow: dict, object_info: dict) -> dict:
    if (workflow.get("definitions") or {}).get("subgraphs"):
        raise ComfyError("This workflow uses subgraphs, which the bridge cannot convert yet. "
                         "Unpack the subgraph in ComfyUI (right-click > Unpack) and save it again.")
    nodes = {n["id"]: n for n in workflow.get("nodes", [])}
    links = {}
    for link in workflow.get("links", []):
        if isinstance(link, dict):
            links[link["id"]] = (link["origin_id"], link["origin_slot"], link.get("type"))
        else:
            links[link[0]] = (link[1], link[2], link[5] if len(link) > 5 else None)

    def resolve(link_id, depth=0):
        """Where a link really comes from: [node_id, slot] or ('value', v)."""
        if depth > 50 or link_id not in links:
            return None
        origin, slot, ltype = links[link_id]
        node = nodes.get(origin)
        if node is None:
            return None
        ntype, mode = node.get("type"), node.get("mode", 0)
        if ntype == "Reroute":
            inp = (node.get("inputs") or [{}])[0]
            return resolve(inp.get("link"), depth + 1)
        if ntype in _PRIMITIVE_TYPES:
            wv = node.get("widgets_values") or [None]
            return ("value", wv[0] if isinstance(wv, list) else next(iter(wv.values())))
        if mode == MODE_BYPASS:
            out_type = ((node.get("outputs") or [])[slot] or {}).get("type") if slot < len(node.get("outputs") or []) else ltype
            for inp in node.get("inputs") or []:
                if inp.get("link") is not None and inp.get("type") == out_type:
                    return resolve(inp["link"], depth + 1)
            return None
        if mode == MODE_MUTED:
            return None
        return [str(origin), slot]

    prompt, missing = {}, set()
    for nid, node in nodes.items():
        ntype, mode = node.get("type"), node.get("mode", 0)
        if ntype in _SKIP_TYPES or mode in (MODE_MUTED, MODE_BYPASS):
            continue
        info = object_info.get(ntype)
        if info is None:
            missing.add(ntype)
            continue
        node_inputs = {i["name"]: i for i in node.get("inputs") or []}
        wv = node.get("widgets_values")
        by_name = wv if isinstance(wv, dict) else None
        values = list(wv) if isinstance(wv, list) else []
        i = 0
        inputs = {}
        for name, spec in _ordered_inputs(info):
            linked = node_inputs.get(name, {}).get("link")
            if _is_widget(name, spec, node_inputs):
                if by_name is not None:
                    value = by_name.get(name)
                else:
                    value = values[i] if i < len(values) else None
                    i += 1
                    # Extra UI-only values that follow some widgets.
                    if i < len(values) and isinstance(values[i], str) and values[i] in _CONTROL_VALUES:
                        opts = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
                        if opts.get("control_after_generate") or name in {"seed", "noise_seed"} or spec[0] == "INT":
                            i += 1
                    if i < len(values) and values[i] == "image":
                        opts = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
                        if opts.get("image_upload"):
                            i += 1
                if linked is not None:
                    src = resolve(linked)
                    if src is not None:
                        value = src[1] if isinstance(src, tuple) else src
                if value is not None:
                    inputs[name] = value
            elif linked is not None:
                src = resolve(linked)
                if isinstance(src, tuple):
                    inputs[name] = src[1]
                elif src is not None:
                    inputs[name] = src
        prompt[str(nid)] = {"class_type": ntype, "inputs": inputs,
                            "_meta": {"title": node.get("title") or info.get("display_name") or ntype}}
    if missing:
        raise ComfyError("ComfyUI does not have these node types installed: {}".format(", ".join(sorted(missing))))
    # Drop links that point at nodes which did not make it into the prompt (muted, etc).
    for node in prompt.values():
        for k, v in list(node["inputs"].items()):
            if isinstance(v, list) and len(v) == 2 and isinstance(v[0], str) and v[0] not in prompt:
                del node["inputs"][k]
    return prompt


# ---------------------------------------------------------------------------
# Filling in inputs by role.

def settable_inputs(prompt: dict) -> list:
    """Literal inputs an agent can set: [{node, title, class, input, value}]."""
    out = []
    for nid, node in sorted(prompt.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 0):
        for name, value in node["inputs"].items():
            if isinstance(value, list):
                continue
            shown = value if not isinstance(value, str) or len(value) < 120 else value[:117] + "..."
            out.append({"node": nid, "title": node["_meta"]["title"], "class": node["class_type"],
                        "input": name, "value": shown})
    return out


def _consumers(prompt: dict, nid: str):
    for other_id, node in prompt.items():
        for name, value in node["inputs"].items():
            if isinstance(value, list) and len(value) == 2 and value[0] == nid:
                yield other_id, name


def _text_nodes(prompt: dict):
    return [nid for nid, n in prompt.items()
            if isinstance(n["inputs"].get("text"), str) or isinstance(n["inputs"].get("prompt"), str)]


def apply_inputs(prompt: dict, *, text=None, negative=None, image=None, seed=None, overrides=None) -> list:
    """Set inputs by role; returns a list of what was set (for the report)."""
    done = []

    def set_(nid, name, value):
        prompt[nid]["inputs"][name] = value
        done.append("{} [{}].{} = {!r}".format(prompt[nid]["_meta"]["title"], nid, name,
                                               value if not isinstance(value, str) or len(value) < 60 else value[:57] + "..."))

    texts = _text_nodes(prompt)
    if text is not None or negative is not None:
        positive = [n for n in texts if any(inp == "positive" for _, inp in _consumers(prompt, n))]
        neg = [n for n in texts if any(inp == "negative" for _, inp in _consumers(prompt, n))]
        if text is not None:
            target = positive or [n for n in texts if n not in neg] or texts
            if not target:
                raise ComfyError("This workflow has no text prompt input.")
            key = "text" if "text" in prompt[target[0]]["inputs"] else "prompt"
            set_(target[0], key, text)
        if negative is not None and neg:
            key = "text" if "text" in prompt[neg[0]]["inputs"] else "prompt"
            set_(neg[0], key, negative)
    if image is not None:
        loaders = [nid for nid, n in prompt.items() if n["class_type"] in {"LoadImage", "LoadImageMask"}]
        if not loaders:
            raise ComfyError("This workflow has no Load Image node to feed.")
        set_(sorted(loaders, key=int)[0], "image", image)
    if seed is not None:
        for nid, n in prompt.items():
            for name in ("seed", "noise_seed"):
                if isinstance(n["inputs"].get(name), int):
                    set_(nid, name, int(seed))
    for key, value in (overrides or {}).items():
        target, _, name = key.rpartition(".")
        nids = [target] if target in prompt else [nid for nid, n in prompt.items() if n["_meta"]["title"] == target]
        if not nids or not name:
            raise ComfyError("Unknown input {!r}: use '<node id or title>.<input name>' "
                             "(see describe_workflow).".format(key))
        for nid in nids:
            if name not in prompt[nid]["inputs"]:
                raise ComfyError("Node {!r} has no input {!r}.".format(prompt[nid]["_meta"]["title"], name))
            set_(nid, name, value)
    return done
