# SPDX-License-Identifier: GPL-3.0-or-later
"""
Local AI generation through the user's ComfyUI: images, 3D models, anything a
saved workflow makes. Free, private, and uses the user's own workflows.

Jobs run on a background thread (Blender stays responsive). Importing a result
into the scene is a normal agent edit: receipt, change report, undo step.
"""

import os
import threading
import time
import uuid

import bpy

from . import comfy, placement
from .registry import ToolError, tool

DEFAULTS = {
    "comfy_url": "http://127.0.0.1:8188",
    "image_workflow": "IMAGE - Flux Schnell txt2img",
    "mesh_workflow": "3D - TripoSG image to mesh",
    "pbr_workflow": "3D - TripoSG image to PBR mesh",
}
# Added to text-to-3D prompts so the reference image is easy to turn into a mesh.
_OBJECT_SHOT = ("{}, a single object, whole object in frame, centered, three-quarter view, "
                "plain white background, soft even studio lighting, no shadows, product photo")
_MESH_EXT = {".glb", ".gltf", ".obj", ".fbx", ".ply", ".stl"}
_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".exr"}

_jobs: "dict[str, dict]" = {}
_lock = threading.Lock()
_changed = threading.Event()   # set when any job finishes (wakes wait_for_job)
_FINISHED = ("done", "failed", "cancelled")


def settings() -> dict:
    out = dict(DEFAULTS)
    addon = bpy.context.preferences.addons.get(__package__)
    prefs = addon.preferences if addon else None
    for key in DEFAULTS:
        value = getattr(prefs, key, "") if prefs else ""
        if value:
            out[key] = value
    return out


def _out_dir(job_id: str) -> str:
    return bpy.utils.user_resource('CONFIG', path=os.path.join("agent_bridge", "generated", job_id), create=True)


def _update(job, **kw):
    with _lock:
        job.update(kw)


def _run_stage(client, job, workflow, *, text=None, negative=None, image_path=None, seed=None,
               overrides=None, timeout_s=1800):
    _update(job, stage=workflow, state="preparing")
    prompt = comfy.ui_to_api(client.load_workflow(workflow), client.object_info())
    image = client.upload_image(image_path) if image_path else None
    applied = comfy.apply_inputs(prompt, text=text, negative=negative, image=image, seed=seed, overrides=overrides)
    pid = client.queue(prompt)
    _update(job, state="queued", prompt_id=pid, applied=job.get("applied", []) + applied)
    entry = client.wait(pid, timeout_s, on_progress=lambda pos: _update(
        job, state="running" if pos == 0 else "queued", queue_position=pos))
    files = []
    for ref in comfy.output_files(entry):
        ext = os.path.splitext(ref["filename"])[1].lower()
        if ext in _MESH_EXT | _IMAGE_EXT:
            files.append(client.download(ref, job["folder"]))
    return files


def _worker(job, stages):
    client = comfy.Client(job["comfy_url"])
    try:
        image_path = job.get("input_image")
        all_files = []
        for stage in stages:
            files = _run_stage(client, job, stage["workflow"], image_path=image_path if stage.get("needs_image") else None,
                               text=stage.get("text"), negative=stage.get("negative"), seed=job.get("seed"),
                               overrides=stage.get("overrides"), timeout_s=job["timeout_s"])
            all_files += files
            images = [f for f in files if os.path.splitext(f)[1].lower() in _IMAGE_EXT]
            with _lock:
                job["images"] = job.get("images", []) + images  # visible before the job is done
                job["stages_done"] = job.get("stages_done", 0) + 1
            if stage.get("feeds_next"):
                if not images:
                    raise comfy.ComfyError("Stage {!r} made no image to pass on.".format(stage["workflow"]))
                image_path = images[-1]
        meshes = [f for f in all_files if os.path.splitext(f)[1].lower() in _MESH_EXT]
        imgs = [f for f in all_files if os.path.splitext(f)[1].lower() in _IMAGE_EXT]
        _update(job, state="done", finished=time.time(), meshes=meshes, images=imgs)
        _changed.set()
    except Exception as ex:
        _update(job, state="failed", finished=time.time(), error=str(ex))
        _changed.set()


def _start(stages, *, input_image=None, seed=None, timeout_s=1800, kind="generic", request=None):
    cfg = settings()
    job_id = "gen-" + uuid.uuid4().hex[:8]
    job = {"job_id": job_id, "kind": kind, "state": "starting", "started": time.time(),
           "comfy_url": cfg["comfy_url"], "folder": _out_dir(job_id), "input_image": input_image,
           "seed": seed, "timeout_s": timeout_s, "request": request or {}, "imported": [],
           "stages": len(stages)}
    with _lock:
        _jobs[job_id] = job
    threading.Thread(target=_worker, args=(job, stages), name="agent-gen-" + job_id, daemon=True).start()
    return job_id


def _image_source(spec: str) -> str:
    """A local image file for an `image` argument: a file path or a Blender image name."""
    if not spec:
        return None
    if os.path.isfile(spec):
        return spec
    img = bpy.data.images.get(spec)
    if img is None:
        raise ToolError("image must be a file path or the name of an image in Blender; got {!r}.".format(spec))
    on_disk = bpy.path.abspath(img.filepath) if img.filepath else ""
    if on_disk and os.path.isfile(on_disk) and not img.is_dirty:
        return on_disk
    path = os.path.join(bpy.app.tempdir or os.path.expanduser("~"), "agent_src_{}.png".format(uuid.uuid4().hex[:6]))
    img.save_render(path)  # Packed, generated or edited images: write what Blender shows.
    return path


def _job_view(job, include_paths=False):
    out = {k: job[k] for k in ("job_id", "kind", "state") if k in job}
    out["elapsed_s"] = round((job.get("finished") or time.time()) - job["started"])
    for k in ("stage", "queue_position", "error", "applied", "title", "progress", "sandbox_item"):
        if job.get(k) is not None:
            out[k] = job[k]
    if job.get("stages"):
        out["stages"] = "{}/{} finished".format(job.get("stages_done", 0), job["stages"])
    if job.get("images"):
        out["images"] = [os.path.basename(p) for p in job["images"]]
    if job["state"] == "done":
        out["meshes"] = [os.path.basename(p) for p in job.get("meshes", [])]
        out["imported"] = job.get("imported", [])
        if job.get("meshes"):
            out["next"] = "import_generation(job_id) to bring the model into the scene"
        elif job.get("sandbox_item"):
            out["next"] = "in the Sandbox as {} (view_sandbox to see it)".format(job["sandbox_item"])
    if include_paths:
        out["folder"] = job["folder"]
    return out


# ---------------------------------------------------------------------------
# Tools.

@tool("generation_workflows",
      "List the user's saved ComfyUI workflows (names like 'IMAGE - ...', '3D - ...') and which "
      "ones this build uses by default for images, meshes and PBR models. Checks ComfyUI is running.")
def generation_workflows(args):
    cfg = settings()
    client = comfy.Client(cfg["comfy_url"])
    try:
        stats = client.alive()
        names = client.list_workflows()
    except comfy.ComfyError as ex:
        raise ToolError(str(ex))
    devices = [d.get("name") for d in (stats or {}).get("devices", [])]
    return {"data": {"comfy_url": cfg["comfy_url"], "devices": devices, "workflows": names,
                     "defaults": {k: v for k, v in cfg.items() if k.endswith("_workflow")}}}


@tool("describe_workflow",
      "Show the settable inputs of a saved ComfyUI workflow (node id, title, input name, current "
      "value), to pick values for generate's `inputs`.",
      {"workflow": {"type": "string"}}, required=("workflow",))
def describe_workflow(args):
    client = comfy.Client(settings()["comfy_url"])
    try:
        prompt = comfy.ui_to_api(client.load_workflow(args["workflow"]), client.object_info())
    except comfy.ComfyError as ex:
        raise ToolError(str(ex))
    has_image = any(n["class_type"] == "LoadImage" for n in prompt.values())
    has_text = bool(comfy._text_nodes(prompt))
    return {"data": {"workflow": args["workflow"], "takes_image": has_image, "takes_text": has_text,
                     "nodes": len(prompt), "inputs": comfy.settable_inputs(prompt)}}


@tool("generate",
      "Run any saved ComfyUI workflow in the background and return a job_id at once (Blender stays "
      "responsive). Fill inputs by role: `prompt` (positive text), `negative`, `image` (file path or "
      "Blender image name, fed to the first Load Image node), `seed`, and `inputs` for anything else "
      "as {'<node id or title>.<input>': value}. Check with generation_status; import with "
      "import_generation. Free: it runs on the user's own GPU.",
      {"workflow": {"type": "string"}, "prompt": {"type": "string"}, "negative": {"type": "string"},
       "image": {"type": "string"}, "seed": {"type": "integer"},
       "inputs": {"type": "object", "additionalProperties": True},
       "timeout_s": {"type": "number", "minimum": 10, "maximum": 7200, "default": 1800}},
      required=("workflow",))
def generate(args):
    stage = {"workflow": args["workflow"], "text": args.get("prompt"), "negative": args.get("negative"),
             "needs_image": bool(args.get("image")), "overrides": args.get("inputs")}
    job_id = _start([stage], input_image=_image_source(args.get("image")), seed=args.get("seed"),
                    timeout_s=float(args.get("timeout_s", 1800)), request={"workflow": args["workflow"]})
    return {"data": {"job_id": job_id, "state": "started",
                     "next": "generation_status(job_id) in a little while"}}


@tool("generate_3d",
      "Make a 3D model on the user's GPU, in the background. From a text description: makes a clean "
      "product-shot image first (image workflow), then turns it into a mesh. Or from an image (file "
      "path or Blender image name). quality: mesh (shape only, fastest), pbr (full PBR textures, "
      "slowest). Returns a job_id; import the result with import_generation.",
      {"prompt": {"type": "string", "description": "What to make, e.g. 'a weathered wooden crate'."},
       "image": {"type": "string"},
       "quality": {"type": "string", "enum": ["mesh", "pbr"], "default": "pbr"},
       "seed": {"type": "integer"},
       "timeout_s": {"type": "number", "minimum": 60, "maximum": 7200, "default": 2400}})
def generate_3d(args):
    if bool(args.get("prompt")) == bool(args.get("image")):
        raise ToolError("Pass exactly one of `prompt` or `image`.")
    cfg = settings()
    mesh_wf = cfg["pbr_workflow"] if args.get("quality", "pbr") == "pbr" else cfg["mesh_workflow"]
    stages = []
    if args.get("prompt"):
        stages.append({"workflow": cfg["image_workflow"], "text": _OBJECT_SHOT.format(args["prompt"]),
                       "feeds_next": True})
    stages.append({"workflow": mesh_wf, "needs_image": True})
    job_id = _start(stages, input_image=_image_source(args.get("image")), seed=args.get("seed"),
                    timeout_s=float(args.get("timeout_s", 2400)), kind="3d",
                    request={"prompt": args.get("prompt"), "quality": args.get("quality", "pbr")})
    return {"data": {"job_id": job_id, "state": "started", "stages": [s["workflow"] for s in stages],
                     "next": "generation_status(job_id); PBR models take a few minutes"}}


@tool("generation_status",
      "State of generation jobs: starting, queued (with position), running, done (with the files "
      "made) or failed (with ComfyUI's error). Without job_id, lists all jobs this session. "
      "show_images=true returns the images made so far (e.g. the reference shot, before the 3D "
      "stage ends). To wait for a job, use wait_for_job instead of calling this repeatedly.",
      {"job_id": {"type": "string"}, "show_images": {"type": "boolean", "default": False}})
def generation_status(args):
    job_id = args.get("job_id")
    if not job_id:
        with _lock:
            return {"data": {"jobs": [_job_view(j) for j in sorted(_jobs.values(), key=lambda j: -j["started"])]}}
    with _lock:
        job = _jobs.get(job_id)
        view = _job_view(job) if job else None
    if job is None:
        raise ToolError("No generation job {!r}.".format(job_id))
    images = []
    if args.get("show_images"):
        for path in job.get("images", [])[-3:]:
            if path.lower().endswith(".png"):
                with open(path, "rb") as fh:
                    images.append(fh.read())
    return {"data": view, "images": images}


def _png_images(job, limit=3):
    out = []
    for path in job.get("images", [])[-limit:]:
        if path.lower().endswith(".png") and os.path.isfile(path):
            with open(path, "rb") as fh:
                out.append(fh.read())
    return out


@tool("wait_for_job",
      "Wait for generation jobs to finish, in one call, instead of polling generation_status. "
      "Returns as soon as the job is done or failed (with mode=all: every job; any: the first), "
      "or after timeout_s with its progress, so call again if it is still running. Keep timeout_s "
      "within your client's tool-call limit (the default 50 s is safe; the in-Blender chat allows 240). "
      "show_images=true returns the job's images (made so far, or final).",
      {"job_id": {"type": "string", "description": "One job id (or use job_ids)."},
       "job_ids": {"type": "array", "items": {"type": "string"}, "maxItems": 8},
       "mode": {"type": "string", "enum": ["all", "any"], "default": "all"},
       "timeout_s": {"type": "number", "minimum": 1, "maximum": 600, "default": 50},
       "show_images": {"type": "boolean", "default": True}},
      on_main=False)
def wait_for_job(args):
    # Runs on the server thread (on_main=False): it only reads job state, so Blender stays free.
    ids = list(args.get("job_ids") or []) + ([args["job_id"]] if args.get("job_id") else [])
    if not ids:
        raise ToolError("Give job_id or job_ids (generation_status lists the jobs).")
    with _lock:
        missing = [i for i in ids if i not in _jobs]
    if missing:
        raise ToolError("No generation job {}.".format(", ".join(repr(i) for i in missing)))
    want_all = args.get("mode", "all") == "all"
    deadline = time.time() + float(args.get("timeout_s", 50))
    t0 = time.time()
    while True:
        with _lock:
            states = [_jobs[i]["state"] for i in ids]
        finished = [st in _FINISHED for st in states]
        if (all(finished) if want_all else any(finished)) or time.time() >= deadline:
            break
        _changed.wait(timeout=min(2.0, max(0.05, deadline - time.time())))
        _changed.clear()
    with _lock:
        jobs = [_jobs[i] for i in ids]
        views = [_job_view(j) for j in jobs]
    done = all(v["state"] in _FINISHED for v in views) if want_all else any(v["state"] in _FINISHED for v in views)
    images = []
    if args.get("show_images", True):
        for job in jobs:
            images += _png_images(job)
    data = {"finished": done, "waited_s": round(time.time() - t0, 1), "jobs": views}
    if not done:
        data["next"] = "still running: call wait_for_job again (progress above)"
    return {"data": data, "images": images[:4]}


@tool("cancel_generation",
      "Stop a generation job: interrupts it in ComfyUI if it is running there now.",
      {"job_id": {"type": "string"}}, required=("job_id",))
def cancel_generation(args):
    with _lock:
        job = _jobs.get(args["job_id"])
    if job is None:
        raise ToolError("No generation job {!r}.".format(args["job_id"]))
    if job["state"] in {"done", "failed", "cancelled"}:
        return {"data": {"job_id": job["job_id"], "state": job["state"], "note": "already finished"}}
    if job.get("kind") == "render":
        from . import renderjob
        renderjob.cancel(job["job_id"])
        return {"data": {"job_id": job["job_id"], "state": "cancelled"}}
    client = comfy.Client(job["comfy_url"])
    try:
        if job.get("prompt_id") and client.queue_position(job["prompt_id"]) == 0:
            client.interrupt()
        elif job.get("prompt_id"):
            client._req("/queue", b'{"delete": ["%s"]}' % job["prompt_id"].encode(), {"Content-Type": "application/json"})
    except comfy.ComfyError as ex:
        raise ToolError(str(ex))
    _update(job, state="failed", error="cancelled", finished=time.time())
    _changed.set()
    return {"data": {"job_id": job["job_id"], "state": "cancelled"}}


@tool("import_generation",
      "Bring a finished 3D generation into the scene as one object: named, scaled so its size "
      "matches size_m along size_axis (height = world Z), and stood on the ground at location "
      "(its lowest point at location.z). A normal edit: change report and undo step.",
      {"job_id": {"type": "string"}, "name": {"type": "string"},
       "location": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3,
                    "default": [0, 0, 0]},
       "size_m": {"type": "number", "minimum": 0.001},
       "size_axis": {"type": "string", "enum": ["height", "longest"], "default": "height"},
       "file": {"type": "string", "description": "Which mesh file of the job (default: the last one)."}},
      required=("job_id",), mutating=True)
def import_generation(args):
    with _lock:
        job = _jobs.get(args["job_id"])
    if job is None:
        raise ToolError("No generation job {!r}.".format(args["job_id"]))
    if job["state"] != "done":
        raise ToolError("Job is {}, not done yet.".format(job["state"]))
    meshes = job.get("meshes") or []
    if not meshes:
        raise ToolError("That job made no 3D file (images only: {}).".format(
            [os.path.basename(p) for p in job.get("images", [])]))
    path = next((p for p in meshes if os.path.basename(p) == args.get("file")), meshes[-1])
    name = args.get("name") or (job["request"].get("prompt") or "Generated")[:40].title().replace(" ", "")
    new = placement.import_file(path)
    result = placement.place(new, name, args.get("location") or (0, 0, 0), args.get("size_m"),
                             args.get("size_axis", "height"), join=True)
    job["imported"].append(result["object"])
    result["from"] = os.path.basename(path)
    return {"data": result}
