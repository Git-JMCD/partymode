# SPDX-License-Identifier: GPL-3.0-or-later
"""
Matching search words to asset names and tags without demanding the exact word.

Each query word is tried as itself (and its singular/plural), then as a synonym from a
small curated table of prop, material and sky words, then split into words the library
knows ("seashell" -> sea + shell, the last part carrying the meaning), then as a near
spelling. Results rank by how many query words they cover, then by how well; each says
why it matched. A word matched only by a part or a near spelling is "loose" (starfish ->
fish finds a fish knife): the caller should say so. Words that match nothing get the
nearest words the library does have, so the caller can say "no asset for that; nearest:
..." and try again.

Pure Python (no bpy), so it can be tested on its own.
"""

import difflib
import re

# Groups of words that mean the same thing for finding assets. Lower case, singular.
_SYNONYMS = [
    "bucket pail", "spade shovel trowel", "seashell shell conch", "starfish seastar",
    "stone rock pebble boulder cobble", "log branch trunk stump driftwood timber",
    "boat ship vessel dinghy canoe", "crate box chest", "barrel cask keg", "rope cord",
    "cup mug", "sofa couch", "table desk", "lamp lantern light", "bottle flask jar",
    "chair seat stool armchair", "bench seat", "knife blade dagger", "sword blade",
    "plant potted houseplant", "tree", "grass lawn turf", "road street path asphalt",
    "brick masonry", "wall facade", "metal steel iron", "wood wooden timber plank",
    "fabric cloth textile", "ground soil dirt earth mud", "water sea ocean lake",
    "beach coast shore seaside", "sand dune", "mountain hill", "night dark",
    "sunset dusk evening", "sunrise dawn morning", "city urban", "forest woods woodland",
    "snow ice winter", "interior indoor room", "studio", "rust rusty rusted",
    "rocky rock", "sandy sand", "muddy mud", "grassy grass", "wooden wood", "metallic metal",
    "skull bone", "food fruit vegetable", "pot pan cookware", "tile tiles ceramic",
    "concrete cement", "gravel pebble", "leaf leaves foliage", "flower flowers blossom",
    "car vehicle", "gun rifle pistol", "book books", "coin coins money", "treasure chest",
    "flag banner", "candle", "clock watch", "cannon", "anchor", "shield", "helmet",
    "statue sculpture bust", "fence railing", "door gate", "window", "stair stairs steps",
    "column pillar", "pipe tube", "cable wire", "trash garbage rubbish litter",
    "toy toys", "ball football soccer", "sky hdri", "cloudy overcast", "clear sunny",
]
_STOP = {"a", "an", "the", "of", "for", "with", "and", "or", "in", "on", "to", "some", "my"}

WEIGHTS = {"exact": 1.0, "synonym": 0.8, "part": 0.7, "modifier_part": 0.3, "spelling": 0.55}
STRONG = {"exact", "synonym"}
FIELD_WEIGHTS = {"name": 5.0, "tag": 3.0, "desc": 1.0}


def stem(w):
    """Plural to singular, cheaply: shells -> shell, boxes -> box, berries -> berry."""
    if len(w) > 4 and w.endswith("ies"):
        return w[:-3] + "y"
    if len(w) > 4 and w.endswith(("ches", "shes", "xes", "sses")):
        return w[:-2]
    if len(w) > 3 and w.endswith("s") and not w.endswith(("ss", "us", "is")):
        return w[:-1]
    return w


def words(text):
    """'Wooden_Bucket01 (old)' -> ['wooden', 'bucket', 'old'] (camelCase and digits split)."""
    text = re.sub(r"([a-z])([A-Z])", r"\1 \2", str(text))
    return [stem(t) for t in re.split(r"[^a-z]+", text.lower()) if len(t) > 1 and t not in _STOP]


_SYN = {}
for _group in _SYNONYMS:
    _members = [stem(w) for w in _group.split()]
    for _w in _members:
        _SYN.setdefault(_w, set()).update(m for m in _members if m != _w)


class Index:
    """Tokens of each item, by field, plus the library's vocabulary."""

    def __init__(self, items):
        """items: iterable of (key, name_text, tag_texts, desc_text)."""
        self.items = []
        self.vocab = set()
        for key, name, tags, desc in items:
            fields = {"name": set(words(name)), "tag": set(w for t in tags for w in words(t)),
                      "desc": set(words(desc))}
            self.items.append((key, fields))
            self.vocab |= fields["name"] | fields["tag"]

    def _split(self, w):
        """A compound as (modifier, head), the head carrying the meaning: seashell -> (sea, shell).
        Both parts known is best; otherwise a known head of 4+ letters (starfish -> fish)."""
        both, head_only = None, None
        for i in range(3, len(w) - 2):
            a, b = w[:i], stem(w[i:])
            if b not in self.vocab:
                continue
            if a in self.vocab and (both is None or len(b) > len(both[1])):
                both = (a, b)
            elif len(b) >= 4 and (head_only is None or len(b) > len(head_only[1])):
                head_only = (a, b)
        return both or head_only

    def expand(self, w):
        """Candidate library words for a query word: {word: (weight, kind, why)}."""
        w = stem(w)
        out = {}

        def add(word, how, why):
            weight = WEIGHTS[how]
            if word in self.vocab and weight > out.get(word, (0, "", ""))[0]:
                out[word] = (weight, how, why)

        add(w, "exact", w)
        for s in _SYN.get(w, ()):
            add(s, "synonym", "{} (means {})".format(s, w))
        # Only a word with no match of its own is split, and what a part brings is loose.
        if w not in self.vocab and not out:
            parts = self._split(w)
            if parts:
                add(parts[1], "part", "{} (in '{}')".format(parts[1], w))
                add(parts[0], "modifier_part", "{} (in '{}')".format(parts[0], w))
                for s in _SYN.get(parts[1], ()):
                    add(s, "part", "{} (means {}, in '{}')".format(s, parts[1], w))
            if not out:
                for s in difflib.get_close_matches(w, list(self.vocab), n=3, cutoff=0.82):
                    add(s, "spelling", "{} (spelled like '{}')".format(s, w))
        return out

    def search(self, query):
        """Ranked [(key, score, covered_words, why)], the query words, words that matched
        nothing, and words matched only loosely (by a part or a near spelling)."""
        q = list(dict.fromkeys(words(query)))
        cands = {w: self.expand(w) for w in q}
        ranked = []
        strong = set()
        for key, fields in self.items:
            score, covered, why = 0.0, [], {}
            for w, cand in cands.items():
                best, best_kind, best_why = 0.0, None, None
                for word, (weight, kind, text) in cand.items():
                    for field, fw in FIELD_WEIGHTS.items():
                        if word in fields[field] and weight * fw > best:
                            best, best_kind, best_why = weight * fw, kind, text
                if best:
                    score += best
                    covered.append(w)
                    if best_kind in STRONG:
                        strong.add(w)
                    if best_why != w:
                        why[w] = best_why
            if covered:
                ranked.append((key, score, covered, why))
        ranked.sort(key=lambda t: (-len(t[2]), -t[1]))
        missing = [w for w in q if not any(w in t[2] for t in ranked)]
        loose = [w for w in q if w not in missing and w not in strong]
        return ranked, q, missing, loose

    def nearest(self, w, n=6, found=()):
        """Library words to suggest for a word it does not know: its synonyms and parts the
        library has, close spellings, then the tags most shared by `found` (keys of the loose
        results: for starfish, what the fish matches have in common)."""
        w = stem(w)
        out = [s for s in sorted(_SYN.get(w, ())) if s in self.vocab]
        parts = self._split(w)
        out += [p for p in (parts or ()) if p in self.vocab and p not in out]
        out += [s for s in difflib.get_close_matches(w, list(self.vocab), n=n, cutoff=0.8) if s not in out]
        if found:
            fields = dict(self.items)
            counts = {}
            for key in found:
                for t in fields.get(key, {}).get("tag", ()):
                    counts[t] = counts.get(t, 0) + 1
            common = self._common_tags()
            shared = sorted((t for t, c in counts.items() if c > 1 and t not in out and t not in common),
                            key=lambda t: -counts[t])
            out += shared[:3]
        return out[:n]

    def _common_tags(self):
        """Tags on more than 4% of items ('collection', 'props'): they say nothing about a word."""
        if not hasattr(self, "_common"):
            df = {}
            for _key, fields in self.items:
                for t in fields["tag"]:
                    df[t] = df.get(t, 0) + 1
            self._common = {t for t, c in df.items() if c > max(3, 0.04 * len(self.items))}
        return self._common
