# SPDX-License-Identifier: GPL-3.0-or-later
"""
Mesh repair in one call: what inspect_mesh finds, fixed on the base mesh and checked again, in one
undo step. The safe fixes by default (duplicate vertices, loose vertices and edges, zero-area
faces, normals made consistent and outward); the ones that change shape when asked (filling holes
up to a size, removing interior faces, removing tiny debris fragments). An object marked
open_shell never has its holes filled; a mesh shared by several objects is left alone.
"""

import bmesh
import bpy

from .registry import ToolError, get_object, r, tool
from .tools_inspect import _mesh_health, intents_of

FIXES = ("duplicates", "loose", "zero_area", "normals", "holes", "interior", "fragments")
SAFE = ("duplicates", "loose", "zero_area", "normals")


def _codes(findings):
    return sorted({f["code"] for f in findings if f.get("severity") != "note" or f["code"] in ("loose_verts", "zero_area")})


def _islands(bm):
    seen, out = set(), []
    for f in bm.faces:
        if f.index in seen:
            continue
        group, area, stack = [], 0.0, [f]
        while stack:
            g = stack.pop()
            if g.index in seen:
                continue
            seen.add(g.index)
            group.append(g)
            area += g.calc_area()
            stack.extend(h for e in g.edges for h in e.link_faces if h.index not in seen)
        out.append((area, group))
    return out


def _repair(ob, fix, merge_m, hole_sides, fragment_share, intents):
    me = ob.data
    bm = bmesh.new()
    done = {}
    try:
        bm.from_mesh(me)
        if "duplicates" in fix:
            n = len(bm.verts)
            bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=merge_m)
            done["merged_verts"] = n - len(bm.verts)
        if "zero_area" in fix:
            n = len(bm.faces)
            bmesh.ops.dissolve_degenerate(bm, dist=max(merge_m * 0.1, 1e-7), edges=list(bm.edges))
            done["degenerate_removed"] = n - len(bm.faces)
        if "interior" in fix:
            # A face whose every edge is shared by more than two faces sits inside the shape.
            inner = [f for f in bm.faces if all(len(e.link_faces) > 2 for e in f.edges)]
            if inner:
                bmesh.ops.delete(bm, geom=inner, context='FACES_ONLY')
            done["interior_removed"] = len(inner)
        if "loose" in fix:
            wire = [e for e in bm.edges if not e.link_faces]
            if wire:
                bmesh.ops.delete(bm, geom=wire, context='EDGES')
            lone = [v for v in bm.verts if not v.link_edges]
            if lone:
                bmesh.ops.delete(bm, geom=lone, context='VERTS')
            done["loose_removed"] = len(wire) + len(lone)
        if "fragments" in fix:
            bm.faces.index_update()
            isl = _islands(bm)
            total = sum(a for a, _g in isl) or 1.0
            debris = [g for a, g in isl if a < fragment_share * total and len(isl) > 1]
            faces = [f for g in debris for f in g]
            if faces:
                bmesh.ops.delete(bm, geom=faces, context='FACES')
            done["fragments_removed"] = len(debris)
        if "holes" in fix:
            if "open_shell" in intents:
                done["holes_filled"] = "skipped: marked open_shell"
            else:
                n = len(bm.faces)
                boundary = [e for e in bm.edges if len(e.link_faces) == 1]
                if boundary:
                    bmesh.ops.holes_fill(bm, edges=boundary, sides=hole_sides)
                done["holes_filled"] = len(bm.faces) - n
        if "normals" in fix and bm.faces:
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            done["normals"] = "made consistent, facing out"
        bm.to_mesh(me)
    finally:
        bm.free()
    me.update()
    return done


@tool("repair_mesh",
      "Fix what inspect_mesh finds, on the base mesh (modifiers stay), in one undo step, and check "
      "again: fix picks which (default: duplicates (merge by distance), loose (vertices and edges "
      "with no faces), zero_area (degenerate faces), normals (consistent, facing out)); add holes "
      "(fill openings up to hole_max_sides edges; never on objects marked open_shell), interior "
      "(faces inside the shape) or fragments (pieces under fragment_share of the surface: "
      "generation debris). Returns what changed and the findings before and after.",
      {"objects": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 32},
       "fix": {"type": "array", "items": {"type": "string", "enum": list(FIXES)}},
       "merge_mm": {"type": "number", "minimum": 0.0001, "maximum": 50, "default": 0.01,
                    "description": "Vertices closer than this merge (millimetres)."},
       "hole_max_sides": {"type": "integer", "minimum": 3, "maximum": 512, "default": 16},
       "fragment_share": {"type": "number", "minimum": 0.0001, "maximum": 0.2, "default": 0.002}},
      required=("objects",), mutating=True)
def repair_mesh(args):
    fix = set(args.get("fix") or SAFE)
    unknown = fix - set(FIXES)
    if unknown:
        raise ToolError("Unknown fix: {} (choose from {}).".format(", ".join(sorted(unknown)), ", ".join(FIXES)))
    merge_m = float(args.get("merge_mm", 0.01)) / 1000.0
    dg = bpy.context.evaluated_depsgraph_get()
    out, skipped = [], []
    for name in args["objects"]:
        ob = get_object(name)
        if ob.type != 'MESH':
            skipped.append({"object": ob.name, "why": "not a mesh ({})".format(ob.type.lower())})
            continue
        if ob.data.users > 1 or ob.data.library:
            skipped.append({"object": ob.name, "why": "its mesh is shared by {} objects (or linked); make it single "
                                                       "user first".format(ob.data.users)})
            continue
        if ob.mode != 'OBJECT':
            raise ToolError("{} is in {} mode; switch to Object mode first.".format(ob.name, ob.mode.lower()))
        intents = intents_of(ob)
        stats0, before = _mesh_health(ob, dg, False, intents)
        done = _repair(ob, fix, merge_m, int(args.get("hole_max_sides", 16)),
                       float(args.get("fragment_share", 0.002)), intents)
        stats1, after = _mesh_health(ob, bpy.context.evaluated_depsgraph_get(), False, intents)
        out.append({"object": ob.name, "fixed": done,
                    "before": _codes(before), "after": _codes(after),
                    "left": [f["message"] for f in after if f.get("severity") in ("error", "warning")
                             and not f.get("expected")],
                    "verts": [stats0["verts"], stats1["verts"]], "faces": [stats0["faces"], stats1["faces"]],
                    "closed": stats1.get("closed")})
    if not out and skipped:
        raise ToolError("Nothing repaired: " + "; ".join("{}: {}".format(s["object"], s["why"]) for s in skipped))
    data = {"repaired": out}
    if skipped:
        data["skipped"] = skipped
    return {"data": data}
