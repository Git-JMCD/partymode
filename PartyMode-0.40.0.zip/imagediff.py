# SPDX-License-Identifier: GPL-3.0-or-later
"""
Measure the difference between two renders of the same view (try_edit's before/after).

Pixels are read by loading each PNG as a temporary image and removing it again, so the
file is left as it was. The result says how much of the frame changed, how strongly,
where (a box and a coarse text map), and whether the changed area got lighter or darker,
so an edit can be checked by numbers as well as by eye.
"""

import os
import tempfile
import uuid

import bpy
import numpy as np

# Below this per-pixel difference (any channel, 0-1) a pixel counts as unchanged:
# PNG rounding and anti-aliasing shimmer stay under it.
NOISE = 4.0 / 255.0
_MAP_COLS, _MAP_ROWS = 8, 6


def _pixels(png):
    """PNG bytes -> float array (rows, cols, 3), top row first, values as stored (0-1)."""
    path = os.path.join(tempfile.gettempdir(), "agent_diff_{}.png".format(uuid.uuid4().hex[:8]))
    with open(path, "wb") as fh:
        fh.write(png)
    img = None
    try:
        img = bpy.data.images.load(path, check_existing=False)
        w, h = img.size
        buf = np.empty(w * h * img.channels, dtype=np.float32)
        img.pixels.foreach_get(buf)
        arr = buf.reshape(h, w, img.channels)[::-1, :, :3]
        return np.ascontiguousarray(arr)
    finally:
        if img is not None:
            bpy.data.images.remove(img)
        try:
            os.remove(path)
        except OSError:
            pass


def _lum(a):
    return a[..., 0] * 0.2126 + a[..., 1] * 0.7152 + a[..., 2] * 0.0722


def _where(cx, cy):
    col = "left" if cx < 1 / 3 else ("right" if cx > 2 / 3 else "centre")
    row = "top" if cy < 1 / 3 else ("bottom" if cy > 2 / 3 else "middle")
    if col == "centre" and row == "middle":
        return "centre"
    return "{}-{}".format(row, col) if col != "centre" else row + "-centre"


def compare(png_before, png_after):
    """Numbers for one view. Changed means a pixel moved by more than NOISE in any channel."""
    a, b = _pixels(png_before), _pixels(png_after)
    if a.shape != b.shape:
        return {"error": "the two renders differ in size: {} vs {}".format(a.shape[:2], b.shape[:2])}
    h, w = a.shape[:2]
    d = np.abs(b - a).max(axis=2)
    changed = d > NOISE
    share = float(changed.mean())
    out = {"changed_share": round(share, 4), "mean_change": round(float(d.mean()), 4)}
    if changed.sum() < max(4, h * w * 0.0002):
        out["verdict"] = "no visible change"
        return out
    ys, xs = np.nonzero(changed)
    x0, x1 = xs.min() / w, (xs.max() + 1) / w
    y0, y1 = ys.min() / h, (ys.max() + 1) / h
    dl = (_lum(b) - _lum(a))[changed]
    drgb = (b - a)[changed]
    out.update({
        "strength": round(float(np.percentile(d[changed], 90)), 3),
        "box": [round(float(x0), 3), round(float(y0), 3), round(float(x1), 3), round(float(y1), 3)],
        "where": _where((x0 + x1) / 2, (y0 + y1) / 2),
        "in_changed_area": {"brightness": round(float(dl.mean()), 3),
                            "rgb": [round(float(v), 3) for v in drgb.mean(axis=0)],
                            "lighter_share": round(float((dl > NOISE).mean()), 3),
                            "darker_share": round(float((dl < -NOISE).mean()), 3)},
    })
    # A coarse map, top row first: "." unchanged, "+" some change (>2%), "#" mostly changed (>30%).
    rows = []
    for r in range(_MAP_ROWS):
        line = ""
        for c in range(_MAP_COLS):
            cell = changed[r * h // _MAP_ROWS:(r + 1) * h // _MAP_ROWS, c * w // _MAP_COLS:(c + 1) * w // _MAP_COLS]
            f = float(cell.mean()) if cell.size else 0.0
            line += "#" if f > 0.3 else ("+" if f > 0.02 else ".")
        rows.append(line)
    out["map"] = rows
    out["verdict"] = ("small change" if share < 0.01 else
                      "local change" if share < 0.15 else "large change")
    return out


def diff_image(png_before, png_after):
    """The after render, unchanged pixels dimmed to grey, changed pixels kept and outlined
    in magenta. Returns PNG bytes."""
    a, b = _pixels(png_before), _pixels(png_after)
    if a.shape != b.shape:
        return None
    changed = np.abs(b - a).max(axis=2) > NOISE
    grey = _lum(b)[..., None] * 0.35 + 0.08
    out = np.where(changed[..., None], b, np.repeat(grey, 3, axis=2))
    edge = changed & ~(np.roll(changed, 1, 0) & np.roll(changed, -1, 0) & np.roll(changed, 1, 1) & np.roll(changed, -1, 1))
    out[edge] = (1.0, 0.1, 0.8)
    h, w = out.shape[:2]
    rgba = np.concatenate([out[::-1], np.ones((h, w, 1), dtype=np.float32)], axis=2).astype(np.float32)
    name = "agent_diff_" + uuid.uuid4().hex[:8]
    path = os.path.join(tempfile.gettempdir(), name + ".png")
    img = bpy.data.images.new(name, w, h, alpha=False)
    try:
        img.pixels.foreach_set(rgba.ravel())
        img.filepath_raw = path
        img.file_format = 'PNG'
        img.save()
        with open(path, "rb") as fh:
            return fh.read()
    finally:
        bpy.data.images.remove(img)
        try:
            os.remove(path)
        except OSError:
            pass
