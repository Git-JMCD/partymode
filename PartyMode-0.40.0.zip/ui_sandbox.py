# SPDX-License-Identifier: GPL-3.0-or-later
"""
The Sandbox in the chat: a board (an endless canvas) with the items as cards where you put them,
docked on the chat's right or in an area of its own; pasting and dropping images and SVGs in, and
attaching items to the next message (see sandbox.py for the store, board.py for places).

Ctrl+V in the message box keeps working for text; SVG text (Figma's "Copy as SVG") and clipboard
images (Figma's "Copy as PNG", screenshots) go into the Sandbox and are attached to the message.
Dropping image or SVG files on the chat does the same.
"""

import math
import os

import bpy

from . import board, sandbox
from . import ui_draw as D

_S = {"attached": {}}  # chat key -> [item ids] going with the next message
_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tga", ".tif", ".tiff", ".svg")
RED = (0.94, 0.23, 0.2, 1.0)


# ---------------------------------------------------------------------------
# Attachments.

def attached(key):
    have = {i["id"] for i in sandbox.items()}
    ids = [i for i in _S["attached"].get(key, []) if i in have]
    _S["attached"][key] = ids
    return ids


def attach(key, item_id, on=True):
    ids = [i for i in _S["attached"].get(key, []) if i != item_id]
    if on:
        ids.append(item_id)
    _S["attached"][key] = ids


def take(key):
    ids = attached(key)
    _S["attached"].pop(key, None)
    return [sandbox.get(i) for i in ids if sandbox.get(i)]


def context_text(items):
    if not items:
        return ""
    lines = ["The user attached {} from the Sandbox for this message (call view_sandbox with "
             "these ids to see {}):".format("an item" if len(items) == 1 else "{} items".format(len(items)),
                                            "it" if len(items) == 1 else "them")]
    lines += ["- " + sandbox.summary(i) for i in items]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Getting things in.

def _clipboard_image(context, area):
    """An image on the system clipboard, as a new datablock, or None. Blender's paste needs an
    Image Editor: the chat's own area becomes one for this call and changes straight back."""
    if area is None:
        return None
    old_type, old_ui = area.type, area.ui_type
    before = set(bpy.data.images)
    try:
        area.type = 'IMAGE_EDITOR'
        space = area.spaces.active
        region = next((rg for rg in area.regions if rg.type == 'WINDOW'), None)
        with context.temp_override(area=area, region=region, space_data=space):
            if not bpy.ops.image.clipboard_paste.poll():
                return None
            bpy.ops.image.clipboard_paste()
        space.image = None
    except RuntimeError:
        return None
    finally:
        area.type = old_type
        try:
            area.ui_type = old_ui
        except TypeError:
            pass
    made = [i for i in bpy.data.images if i not in before]
    return made[-1] if made else None


def paste(context, text, key=None, area=None):
    """Clipboard into the Sandbox when it holds SVG or an image (attached to the message for
    chat `key`). Returns the item, or None when it was plain text (the caller types it)."""
    item = None
    if text and sandbox.looks_like_svg(text):
        item = sandbox.add_svg(text, "Pasted SVG")
    elif not (text or "").strip():
        img = _clipboard_image(context, area)
        if img is not None:
            item = sandbox.add_image(img, "Pasted image")
    if item is not None:
        if key is not None:
            attach(key, item["id"])
        board.place_missing(_S.get("last_center"))
        _push_undo("Sandbox: paste")
        _redraw()
    return item


def add_files(paths, key=None, near=None):
    added = []
    for path in paths:
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == ".svg":
                with open(path, encoding="utf-8", errors="replace") as fh:
                    item = sandbox.add_svg(fh.read(), os.path.splitext(os.path.basename(path))[0])
            elif ext in _EXTS:
                item = sandbox.add_image_file(path)
            else:
                continue
        except (RuntimeError, ValueError, OSError) as ex:
            print("agent_bridge: could not add", path, ex)
            continue
        added.append(item)
        if key is not None:
            attach(key, item["id"])
    if added:
        board.place_missing(near or _S.get("last_center"))
        _push_undo("Sandbox: add {}".format(len(added)))
        _redraw()
    return added


def _tick():
    """Redraw while a background render runs (its progress), and once more when it ends."""
    from . import renderjob
    _redraw()
    return 0.5 if renderjob.running() else None


def _push_undo(name):
    try:
        bpy.ops.ed.undo_push(message=name)
    except RuntimeError:
        pass


def _redraw():
    wm = bpy.context.window_manager
    for win in getattr(wm, "windows", ()):
        for area in win.screen.areas:
            area.tag_redraw()


class AGENT_OT_sandbox_add_files(bpy.types.Operator):
    bl_idname = "agent.sandbox_add_files"
    bl_label = "Add to Sandbox"
    bl_description = "Add images or SVG files to the Sandbox (they go with your next message)"
    bl_options = {'REGISTER'}

    directory: bpy.props.StringProperty(subtype='DIR_PATH', options={'SKIP_SAVE', 'HIDDEN'})
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement, options={'SKIP_SAVE', 'HIDDEN'})
    filter_glob: bpy.props.StringProperty(default=";".join("*" + e for e in _EXTS), options={'HIDDEN'})
    attach: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE', 'HIDDEN'})

    def execute(self, context):
        from . import ui_space
        paths = [os.path.join(self.directory, f.name) for f in self.files if f.name]
        on_board = getattr(self, "_near", None) is not None
        key = ui_space._session_key(context.window_manager) if self.attach and not on_board else None
        added = add_files(paths, key, getattr(self, "_near", None))
        self.report({'INFO'} if added else {'WARNING'},
                    "Added {} to the Sandbox".format(len(added)) if added else "Nothing to add")
        return {'FINISHED'} if added else {'CANCELLED'}

    def invoke(self, context, event):
        if self.files and self.directory:  # dropped files: on the board, where they were dropped
            self._near = _drop_point(context, event)
            return self.execute(context)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class AGENT_OT_sandbox_note(bpy.types.Operator):
    bl_idname = "agent.sandbox_note"
    bl_label = "Sandbox Note"
    bl_description = "Pin a note in the Sandbox: a brief, a reminder, a rule of thumb for this file"
    bl_options = {'REGISTER', 'UNDO'}

    text: bpy.props.StringProperty(name="Note", default="")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def execute(self, context):
        if not self.text.strip():
            return {'CANCELLED'}
        sandbox.add_note(self.text.strip())
        board.place_missing(_S.get("last_center"))
        _redraw()
        return {'FINISHED'}


def _drop_point(context, event):
    """The board point under a drop, or None when it was not over a board."""
    from . import ui_space
    area, region = context.area, context.region
    if area is None or region is None:
        return None
    st = ui_space._area_state(area)
    x, y = event.mouse_x - region.x, event.mouse_y - region.y
    if not in_board(st, x, y) or st.get("sbv") is None:
        return None
    return board.to_board(st["sbv"], context.preferences.system.ui_scale, st["scrap_rect"], x, y)


class AGENT_FH_sandbox(bpy.types.FileHandler):
    bl_idname = "AGENT_FH_sandbox"
    bl_label = "Sandbox"
    bl_import_operator = "agent.sandbox_add_files"
    bl_file_extensions = ";".join(_EXTS)

    @classmethod
    def poll_drop(cls, context):
        from . import ui_space
        return context.area is not None and (ui_space.is_host(context.area) or is_pane(context.area))


# ---------------------------------------------------------------------------
# The board: the items as cards on an endless canvas (board.py) where they stay where they are
# put. It shows docked at the chat's right edge (drag its left edge to resize) or fills an area
# of its own (agent.sandbox_pane), which Blender resizes like any area.

DOCK_W = 440.0
TOOLBAR_H = 52.0


def width(cv, on):
    if not on:
        return 0.0
    s = cv.s
    return min(max((_S.get("dock_w") or DOCK_W) * s, 260 * s), cv.w * 0.95)


_ACTIONS = {
    "image": (("plane", "Plane"), ("palette", "Palette"), ("make_3d", "3D")),
    "render": (("plane", "Plane"), ("palette", "Palette"), ("make_3d", "3D")),
    "svg": (("logo", "Logo"), ("curves", "Curves"), ("plane", "Plane"), ("palette", "Palette")),
    "note": (),
}


def _actions(it):
    """A card's buttons: what it can become, and the page it came from (for web pictures)."""
    return tuple(_ACTIONS[it["kind"]]) + ((("source", "Source"),) if it.get("source") else ())


def _thumb(item):
    path = sandbox.thumb_path(item)
    return (path, D.texture(path, max_w=480)) if path else (None, None)


def view_of(st, pane, s, its):
    """This pane's view of the board: on its first draw, framing everything."""
    v = st.get("sbv")
    if v is None:
        v = st["sbv"] = board.new_view()
        board.fit(v, s, pane, its, top_pad=TOOLBAR_H * s)
    return v


def _place_later(near):
    """Save places for new items after this draw (a draw must not change the file)."""
    if _S.get("placing"):
        return
    _S["placing"] = True

    def run():
        _S["placing"] = False
        if board.place_missing(near):
            _redraw()
        return None
    bpy.app.timers.register(run, first_interval=0.0)


def _grid(cv, v, s, pane):
    k = v["z"] * s
    step = 24.0
    while step * k < 14 * s:
        step *= 4
    bx0, by0 = board.to_board(v, s, pane, pane[0], pane[3])
    bx1, by1 = board.to_board(v, s, pane, pane[2], pane[1])
    gx0, gy0 = math.floor(bx0 / step) * step, math.floor(by0 / step) * step
    nx, ny = int((bx1 - gx0) / step) + 2, int((by1 - gy0) / step) + 2
    if nx * ny > 8000:
        return
    pts = [board.to_screen(v, s, pane, gx0 + i * step, gy0 + j * step) for i in range(nx) for j in range(ny)]
    cv.dots(pts, D.alpha(cv.color("text"), 0.13), 1.6 * s)


def card_boxes(st, its, s):
    """[(item, (x0, y0, x1, y1) on screen, card width)] for the pane drawn last, a dragged card
    where it is going."""
    v, pane = st.get("sbv"), st.get("scrap_rect")
    if v is None or pane is None:
        return []
    drag = _S.get("drag") or {}
    plan = st.get("scrap_plan") or {}
    k = v["z"] * s
    out = []
    for it in its:
        pos = it.get("pos") or plan.get(it["id"])
        if pos is None:
            continue
        cw = None
        if drag.get("id") == it["id"]:
            pos = drag.get("pos") or pos
            cw = drag.get("cw")
        size = board.card_size(dict(it, cw=cw) if cw else it)
        sx0, sy1 = board.to_screen(v, s, pane, pos[0], pos[1])
        out.append((it, (sx0, sy1 - size[1] * k, sx0 + size[0] * k, sy1), size[0]))
    return out


def draw(cv, m, area, st, hits, hovered, key, pane=None):
    """The board in `pane` (x0, y0, x1, y1 region pixels), or docked at the chat's right edge."""
    from . import ui_space
    s = m.s
    docked = pane is None
    if docked:
        x0 = cv.w - st["scrap_w"]
        if st.get("scrap_overlay"):
            cv.rect(0, 0, x0, cv.h, "scrim")
            hits.append((("scrap_scrim",), 0, 0, x0, cv.h))
        pane = (x0, 0, cv.w, cv.h)
    st["scrap_rect"] = pane
    px0, py0, px1, py1 = pane
    its = sandbox.items()
    near = (st["sbv"]["cx"], st["sbv"]["cy"]) if st.get("sbv") else None
    plan = board.plan_missing(its, near)  # new items: drawn there now, saved just after
    st["scrap_plan"] = plan
    if plan:
        _place_later(near)
    v = view_of(st, pane, s, [dict(i, pos=plan[i["id"]]) if i["id"] in plan else i for i in its])
    _S["last_center"] = (v["cx"], v["cy"])
    k = v["z"] * s
    cv.rect(px0, py0, px1, py1, "drawer")
    cv.clip(px0, py0, px1, py1)
    _grid(cv, v, s, pane)
    hits.append((("scrap_bg",), px0, py0, px1, py1))
    att = set(attached(key))
    drag_id = (_S.get("drag") or {}).get("id")
    boxes = card_boxes(st, its, s)
    boxes.sort(key=lambda b: b[0]["id"] == drag_id)  # the card being dragged on top
    acc = ui_space.agent_color(None, 0.95)
    hov_box = None
    for it, box, cw in boxes:
        bx0, by0, bx1, by1 = box
        if bx1 < px0 or bx0 > px1 or by1 < py0 or by0 > py1:
            continue
        hid = ("scrap_card", it["id"])
        hov = hovered(hid) or any(h for h in (hovered(("scrap_act", it["id"], a)) for a, _l in _actions(it))) \
            or hovered(("scrap_del", it["id"])) or hovered(("scrap_save", it["id"])) \
            or hovered(("scrap_resize", it["id"])) or it["id"] == drag_id
        _card(cv, m, it, box, cw, k, it["id"] in att, hov, acc)
        hits.append((hid, max(bx0, px0), max(by0, py0), min(bx1, px1), min(by1, py1)))
        if hov:
            hov_box = (it, box)
    if hov_box and not drag_id:
        _card_controls(cv, m, hits, hovered, *hov_box)
    if not its:
        lines = ("Paste images or SVG here (Ctrl+V),", "drop files on the chat or the board,",
                 "or ask the agent to pin a render.")
        cy = (py0 + py1) / 2 + 20 * s
        for i, line in enumerate(lines):
            lw = D.measure(line, m.small)
            cv.text((px0 + px1 - lw) / 2, cy - i * 20 * s, line, m.small, "muted")
    _toolbar(cv, m, hits, hovered, pane, v, docked)
    if docked:
        eh = hovered(("scrap_edge",)) or (_S.get("drag") or {}).get("mode") == "EDGE"
        cv.rect(px0, py0, px0 + (2.0 if eh else 1.0) * s, py1, acc if eh else "border")
        hits.append((("scrap_edge",), px0 - 5 * s, py0, px0 + 5 * s, py1))
    cv.unclip()


def _card(cv, m, it, box, cw, k, on, hov, acc):
    s = m.s
    from . import looks
    x0, y0, x1, y1 = box
    rad = min(10 * k, looks.radius("card", s, 20 * s), 10 * s)
    cv.rect(x0 - 1 * s, y0 - 3 * s, x1 + 1 * s, y1 - 1 * s, "shadow", rad + 2 * s, soft=8 * s)
    cv.rect(x0, y0, x1, y1, "surface2" if hov else "surface", rad,
            line=acc if on else ("border2" if hov else "border"), width=(1.6 if on else 1) * s)
    small, tiny = board.NOTE_SIZE * k, 11 * k
    if it["kind"] == "note":
        if small >= 4:
            for i, ln in enumerate(board.note_lines(it, cw)):
                cv.text(x0 + 10 * k, y1 - 22 * k - i * board.NOTE_LINE * k, ln, small, "text")
        if tiny >= 5:
            cv.text(x0 + 10 * k, y0 + 9 * k, "note" + ("" if it.get("by") == "you" else "  ·  " + it.get("by", "")),
                    tiny, "faint")
    else:
        _path, t = _thumb(it)
        ix0, iy0, ix1, iy1 = x0 + 4 * k, y0 + board.CAPTION_H * k, x1 - 4 * k, y1 - 4 * k
        if t and ix1 > ix0 and iy1 > iy0:
            tex, tw, th = t
            f = min((ix1 - ix0) / tw, (iy1 - iy0) / th)
            w2, h2 = tw * f, th * f
            ax, ay = (ix0 + ix1 - w2) / 2, (iy0 + iy1 - h2) / 2
            cv.image(tex, ax, ay, ax + w2, ay + h2, min(7 * k, 7 * s))
        sx = x0 + 10 * k
        for col in (it.get("colors") or [])[:5]:
            rgb = tuple(int(col[i:i + 2], 16) / 255 for i in (1, 3, 5))  # the chat draws in screen colour
            cv.rect(sx, y0 + 26 * k, sx + 10 * k, y0 + 36 * k, rgb + (1.0,), 3 * k)
            sx += 13 * k
        if tiny >= 5:
            kind = {"image": "image", "svg": "SVG", "render": "render"}.get(it["kind"], it["kind"])
            cap = "{}  ·  {}".format(it.get("title") or it["id"], it.get("license") or kind)
            cv.text(x0 + 10 * k, y0 + 9 * k, D.ellipsize(cap, tiny, x1 - x0 - 20 * k), tiny, "muted")
    if on:
        r = 8 * s
        mx, my = x1 - 6 * s - r, y1 - 6 * s - r
        cv.rect(mx - r, my - r, mx + r, my + r, acc, r)
        q = 3 * s
        cv.line([(mx - q, my), (mx - q * 0.2, my - q * 0.8), (mx + q, my + q)], (1, 1, 1, 1), 1.4 * s)


def _card_controls(cv, m, hits, hovered, it, box):
    """On the hovered card: its actions along the top, remove at the top right, and the resize
    grip at the bottom right. These keep their size at any zoom."""
    s = m.s
    x0, y0, x1, y1 = box
    ax, ay = x0 + 6 * s, y1 - 6 * s
    if x1 - x0 > 110 * s and y1 - y0 > 60 * s:
        for action, lab in _actions(it):
            aid = ("scrap_act", it["id"], action)
            w = D.measure(lab, m.tiny, 600) + 14 * s
            if ax + w > x1 - 54 * s:
                break
            cv.rect(ax, ay - 20 * s, ax + w, ay, (0.08, 0.08, 0.09, 0.92 if hovered(aid) else 0.78), 10 * s)
            cv.text(ax + 7 * s, ay - 10 * s - m.tiny * 0.36, lab, m.tiny, (1, 1, 1, 1), 600)
            hits.append((aid, ax, ay - 20 * s, ax + w, ay))
            ax += w + 4 * s
    did = ("scrap_del", it["id"])
    dx, dy = x1 - 16 * s, y1 - 16 * s
    cv.rect(dx - 10 * s, dy - 10 * s, dx + 10 * s, dy + 10 * s, (0.08, 0.08, 0.09, 0.92 if hovered(did) else 0.7), 10 * s)
    q = 3.5 * s
    cv.line([(dx - q, dy - q), (dx + q, dy + q)], (1, 1, 1, 1), 1.3 * s)
    cv.line([(dx - q, dy + q), (dx + q, dy - q)], (1, 1, 1, 1), 1.3 * s)
    hits.append((did, dx - 10 * s, dy - 10 * s, dx + 10 * s, dy + 10 * s))
    sid = ("scrap_save", it["id"])  # save as a file: a down arrow onto a tray, left of remove
    sx = dx - 24 * s
    cv.rect(sx - 10 * s, dy - 10 * s, sx + 10 * s, dy + 10 * s, (0.08, 0.08, 0.09, 0.92 if hovered(sid) else 0.7), 10 * s)
    cv.line([(sx, dy + 4.5 * s), (sx, dy - 2 * s)], (1, 1, 1, 1), 1.3 * s)
    cv.line([(sx - 3 * s, dy + 1 * s), (sx, dy - 2.2 * s), (sx + 3 * s, dy + 1 * s)], (1, 1, 1, 1), 1.3 * s)
    cv.line([(sx - 4.5 * s, dy - 2 * s), (sx - 4.5 * s, dy - 4.5 * s), (sx + 4.5 * s, dy - 4.5 * s),
             (sx + 4.5 * s, dy - 2 * s)], (1, 1, 1, 1), 1.3 * s)
    hits.append((sid, sx - 10 * s, dy - 10 * s, sx + 10 * s, dy + 10 * s))
    rid = ("scrap_resize", it["id"])
    g = 14 * s
    col = (1, 1, 1, 0.9) if hovered(rid) else (1, 1, 1, 0.45)
    for f in (0.35, 0.7):
        cv.line([(x1 - 4 * s - g * f, y0 + 4 * s), (x1 - 4 * s, y0 + 4 * s + g * f)], col, 1.3 * s)
    hits.append((rid, x1 - g - 4 * s, y0, x1 + 4 * s, y0 + g + 4 * s))


def _pill_w(m, label):
    from . import looks
    font = "mono" if looks.get()["upper"] else "ui"
    return D.measure(looks.label(label), m.tiny + 0.5 * m.s, 500, font) + 20 * m.s


def _pill(cv, m, hits, hovered, hid, x, y, label, h=26.0, strong=False):
    """A floating button with its top-left at (x, y); returns its width."""
    from . import looks
    s = m.s
    size = m.tiny + 0.5 * s
    font = "mono" if looks.get()["upper"] else "ui"
    label = looks.label(label)
    w = D.measure(label, size, 500, font) + 20 * s
    hov = hovered(hid)
    cv.rect(x, y - h * s, x + w, y, "surface2" if (hov or strong) else "surface", looks.radius("button", s, h * s),
            line="border2" if hov else "border", width=1 * s)
    cv.text(x + 10 * s, y - h * s / 2 - size * 0.36, label, size, "text", 500, font)
    hits.append((hid, x, y - h * s, x + w, y))
    return w


def _toolbar(cv, m, hits, hovered, pane, v, docked):
    """Add buttons at the top left; zoom, Fit and (docked) Pop out at the top right; and any
    background renders under them."""
    from . import renderjob, ui_space
    s = m.s
    px0, py0, px1, py1 = pane
    y = py1 - 12 * s
    right = [("scrap_fit", "Fit"), ("scrap_zoom", "{}%".format(round(v["z"] * 100)))]
    if docked:
        right.insert(0, ("scrap_popout", "Pop out"))
    x = px1 - 12 * s
    for hid, lab in right:
        x -= _pill_w(m, lab)
        _pill(cv, m, hits, hovered, (hid,), x, y, lab)
        x -= 6 * s
    limit = x
    bx = px0 + 12 * s
    for action, lab in (("paste", "Paste"), ("files", "Add file"), ("note", "Note"), ("render", "Render")):
        w = _pill_w(m, lab)
        if bx + w > limit:
            break
        _pill(cv, m, hits, hovered, ("scrap_tool", action), bx, y, lab)
        bx += w + 6 * s
    y -= 36 * s
    jw = min(300 * s, px1 - px0 - 24 * s)
    for job in renderjob.running():
        jh = 46 * s
        jx = px0 + 12 * s
        cv.rect(jx, y - jh, jx + jw, y, "surface", 10 * s, line="border", width=1 * s)
        frac = job.get("fraction") or 0.0
        cv.rect(jx + 10 * s, y - jh + 9 * s, jx + 10 * s + (jw - 90 * s) * frac, y - jh + 13 * s,
                ui_space.agent_color(None, 0.9), 2 * s)
        line = "{}  ·  {}".format(job.get("title", "Render"), job.get("progress", "starting"))
        cv.text(jx + 10 * s, y - 20 * s, D.ellipsize(line, m.tiny, jw - 90 * s), m.tiny, "text", 500)
        cid = ("scrap_cancel", job["job_id"])
        cw0 = D.measure("Cancel", m.tiny, 600) + 16 * s
        cx1 = jx + jw - 8 * s
        cv.rect(cx1 - cw0, y - jh / 2 - 11 * s, cx1, y - jh / 2 + 11 * s, "border2" if hovered(cid) else "surface2", 11 * s)
        cv.text(cx1 - cw0 + 8 * s, y - jh / 2 - m.tiny * 0.36, "Cancel", m.tiny, "text", 600)
        hits.append((cid, cx1 - cw0, y - jh / 2 - 11 * s, cx1, y - jh / 2 + 11 * s))
        y -= jh + 8 * s
    if renderjob.running() and not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.5)


def draw_area(context, cv, area, region):
    """An area of its own showing the board."""
    from . import ui_space
    st = ui_space._area_state(area)
    st["region"] = (region.x, region.y, region.width, region.height)
    m = D.Metrics(cv.s)
    hits = []
    st["hits"] = hits
    st["scrap_w"] = 0.0
    st["pane"] = True
    cv.rect(0, 0, cv.w, cv.h, "drawer")
    draw(cv, m, area, st, hits, lambda hid: ui_space._hovered(area, hid),
         ui_space._session_key(context.window_manager), pane=(0, 0, cv.w, cv.h))
    ui_space._draw_toast(cv, m, st, 0, cv.w)


def in_board(st, x, y):
    r = st.get("scrap_rect")
    return bool(r) and (st.get("scrap_w") or st.get("pane")) and r[0] <= x <= r[2] and r[1] <= y <= r[3]


def zoom(area, st, x, y, factor):
    v, pane = st.get("sbv"), st.get("scrap_rect")
    if v is None or pane is None:
        return
    board.zoom_at(v, bpy.context.preferences.system.ui_scale, pane, x, y, factor)
    area.tag_redraw()


def pan(area, st, dx, dy):
    v = st.get("sbv")
    if v is None:
        return
    k = v["z"] * bpy.context.preferences.system.ui_scale
    v["cx"] -= dx / k
    v["cy"] += dy / k
    area.tag_redraw()


def fit(area, st):
    v, pane = st.get("sbv"), st.get("scrap_rect")
    if v is None or pane is None:
        return
    board.fit(v, bpy.context.preferences.system.ui_scale, pane, sandbox.items(), top_pad=TOOLBAR_H * bpy.context.preferences.system.ui_scale)
    area.tag_redraw()


def cursor(hid):
    """The pointer over a board part, or None."""
    if not hid:
        return None
    return {"scrap_edge": 'MOVE_X', "scrap_resize": 'SCROLL_XY'}.get(hid[0])


_DRAG_CURSOR = {'PAN': 'HAND', 'CARD': 'SCROLL_XY', 'RESIZE': 'SCROLL_XY', 'EDGE': 'MOVE_X'}


class AGENT_OT_sandbox_drag(bpy.types.Operator):
    """Drag on the board: a card moves, empty board pans, a card's corner resizes it, the
    docked board's edge changes its width. A card clicked without dragging goes with the
    next message (or comes off it)."""
    bl_idname = "agent.sandbox_drag"
    bl_label = "Drag on the Sandbox"
    bl_options = {'INTERNAL'}

    mode: bpy.props.EnumProperty(items=(('CARD', "Card", ""), ('PAN', "Pan", ""), ('RESIZE', "Resize", ""),
                                        ('EDGE', "Edge", "")))
    item: bpy.props.StringProperty()
    key: bpy.props.StringProperty()
    button: bpy.props.StringProperty(default='LEFTMOUSE')

    def invoke(self, context, event):
        from . import ui_space
        area = context.area
        self._area = area
        self._st = ui_space._area_state(area)
        self._start = (event.mouse_x, event.mouse_y)
        self._moved = False
        v = self._st.get("sbv")
        self._view0 = dict(v) if v else None
        it = sandbox.get(self.item) if self.item else None
        self._it = it
        if it is not None:
            plan = self._st.get("scrap_plan") or {}
            self._pos0 = list(it.get("pos") or plan.get(it["id"]) or (0.0, 0.0))
            self._cw0 = board.card_w(it)
        self._w0 = _S.get("dock_w") or DOCK_W
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _k(self):
        v = self._view0 or board.new_view()
        return v["z"] * bpy.context.preferences.system.ui_scale

    def modal(self, context, event):
        t = event.type
        if t in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            dx, dy = event.mouse_x - self._start[0], event.mouse_y - self._start[1]
            if not self._moved and abs(dx) + abs(dy) < 4:
                return {'RUNNING_MODAL'}
            if not self._moved:
                context.window.cursor_modal_set(_DRAG_CURSOR.get(self.mode, 'DEFAULT'))
            self._moved = True
            k = self._k()
            if self.mode == 'CARD' and self._it:
                _S["drag"] = {"id": self.item, "mode": "CARD", "pos": [self._pos0[0] + dx / k, self._pos0[1] - dy / k]}
            elif self.mode == 'RESIZE' and self._it:
                _S["drag"] = {"id": self.item, "mode": "RESIZE",
                              "cw": min(max(self._cw0 + dx / k, board.MIN_CW), board.MAX_CW)}
            elif self.mode == 'PAN' and self._view0:
                v = self._st["sbv"]
                v["cx"] = self._view0["cx"] - dx / k
                v["cy"] = self._view0["cy"] + dy / k
            elif self.mode == 'EDGE':
                _S["drag"] = {"mode": "EDGE"}
                _S["dock_w"] = max(260.0, self._w0 - dx / bpy.context.preferences.system.ui_scale)
            self._area.tag_redraw()
            return {'RUNNING_MODAL'}
        if t == self.button and event.value == 'RELEASE':
            self._finish(context)
            return {'FINISHED'}
        if t in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            if self._moved:
                context.window.cursor_modal_restore()
            if self.mode == 'PAN' and self._view0:
                self._st["sbv"].update(self._view0)
            if self.mode == 'EDGE':
                _S["dock_w"] = self._w0
            _S["drag"] = None
            self._area.tag_redraw()
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def _finish(self, context):
        if self._moved:
            context.window.cursor_modal_restore()
        drag = _S.get("drag") or {}
        _S["drag"] = None
        if not self._moved:
            if self.mode == 'CARD' and self._it:
                attach(self.key, self.item, self.item not in attached(self.key))
        elif self.mode == 'CARD' and drag.get("pos"):
            board.move(self.item, *drag["pos"])
            _push_undo("Sandbox: move")
        elif self.mode == 'RESIZE' and drag.get("cw"):
            board.move(self.item, *self._pos0, width=drag["cw"])
            _push_undo("Sandbox: resize")
        _redraw()


class AGENT_OT_sandbox_save(bpy.types.Operator):
    """Save this Sandbox item as a file: a picture as it came in, an SVG as SVG, a note as text"""
    bl_idname = "agent.sandbox_save"
    bl_label = "Save"
    bl_options = {'INTERNAL'}

    item: bpy.props.StringProperty(options={'HIDDEN'})
    filepath: bpy.props.StringProperty(subtype='FILE_PATH', options={'SKIP_SAVE'})
    filter_glob: bpy.props.StringProperty(default="*.png;*.jpg;*.gif;*.bmp;*.webp;*.svg;*.txt", options={'HIDDEN'})

    def _file(self):
        it = sandbox.get(self.item)
        got = sandbox.file_of(it) if it else None
        return it, got

    def invoke(self, context, event):
        it, got = self._file()
        if got is None:
            self.report({'WARNING'}, "Nothing to save in that item.")
            return {'CANCELLED'}
        folder = os.path.dirname(bpy.data.filepath) or os.path.expanduser("~")
        self.filepath = os.path.join(folder, sandbox.file_name(it) + got[1])
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        it, got = self._file()
        if got is None or not self.filepath:
            return {'CANCELLED'}
        data, ext = got
        path = bpy.path.abspath(self.filepath)
        if not os.path.splitext(path)[1]:
            path += ext
        try:
            with open(path, "wb") as fh:
                fh.write(data)
        except OSError as ex:
            self.report({'ERROR'}, "Could not save: {}".format(ex))
            return {'CANCELLED'}
        from . import ui_space
        ui_space._toast("Saved {}".format(os.path.basename(path)), error=False, seconds=2.5)
        return {'FINISHED'}


def _pane_text():
    """The text an area shows to host the board (made once, marked)."""
    text = next((t for t in bpy.data.texts if t.get("agent_sandbox")), None)
    if text is None:
        text = bpy.data.texts.new("Agent Sandbox")
        text["agent_sandbox"] = True
        text.write("This text shows the Agent Sandbox board. Pick another text to edit code here.\n")
    return text


def is_pane(area):
    """An area showing the board on its own."""
    if area is None or area.type != 'TEXT_EDITOR':
        return False
    text = area.spaces.active.text
    return text is not None and bool(text.get("agent_sandbox"))


def _panes(screen):
    return [a for a in screen.areas if is_pane(a)]


class AGENT_OT_sandbox_pane(bpy.types.Operator):
    """Show the Sandbox board in an area of its own beside the chat (resize it like any area),
    or close it"""
    bl_idname = "agent.sandbox_pane"
    bl_label = "Sandbox in Its Own Area"
    bl_options = {'REGISTER'}

    def execute(self, context):
        from . import ui_space
        screen = context.window.screen
        open_ = _panes(screen)
        if open_:
            for a in open_:
                with context.temp_override(window=context.window, screen=screen, area=a):
                    bpy.ops.screen.area_close()
            return {'FINISHED'}
        host = context.area if ui_space.is_host(context.area) else next(
            (a for a in screen.areas if ui_space.is_host(a)), None)
        if host is None:
            host = max(screen.areas, key=lambda a: a.width * a.height)
        # A wide chat gives the board its right part; a narrow one keeps its width and the board
        # takes the left part of the big editor beside it (the viewport, usually).
        beside = [a for a in screen.areas if a.x > host.x + host.width - 4 and a.x < host.x + host.width + 8
                  and a.y < host.y + host.height and a.y + a.height > host.y]
        target = host if host.width >= 800 or not beside else max(beside, key=lambda a: a.width * a.height)
        if target == host:
            factor = 0.55  # the new (left) part stays the chat
        else:
            factor = min(0.4, max(0.2, 560.0 * context.preferences.system.ui_scale / max(1, target.width)))
        before = set(a.as_pointer() for a in screen.areas)
        region = next((r for r in target.regions if r.type == 'WINDOW'), None)
        with context.temp_override(window=context.window, screen=screen, area=target, region=region):
            bpy.ops.screen.area_split(direction='VERTICAL', factor=factor)
        new = next((a for a in screen.areas if a.as_pointer() not in before), None)
        if new is None:
            self.report({'WARNING'}, "No room to split this area")
            return {'CANCELLED'}
        right = target if target == host else new  # Blender puts the new area on the left
        right.type = 'TEXT_EDITOR'
        sp = right.spaces.active
        sp.text = _pane_text()
        for flag in ("show_region_footer", "show_region_ui", "show_line_numbers", "show_syntax_highlight"):
            if hasattr(sp, flag):
                setattr(sp, flag, False)
        context.window_manager.agent_ui_sandbox = False  # it moved out of the chat
        _redraw()
        return {'FINISHED'}


class AGENT_OT_sandbox_fit(bpy.types.Operator):
    """Frame every card on the board"""
    bl_idname = "agent.sandbox_fit"
    bl_label = "Fit the Sandbox"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        from . import ui_space
        for a in context.window.screen.areas:
            if is_pane(a) or (ui_space.is_host(a) and context.window_manager.agent_ui_sandbox):
                fit(a, ui_space._area_state(a))
        return {'FINISHED'}


def draw_pane_header(layout, context):
    from . import ui_space
    icon = ui_space.agent_icon("sandbox")
    if icon:
        layout.label(text="Sandbox", icon_value=icon)
    else:
        layout.label(text="Sandbox", icon='IMAGE_REFERENCE')
    n = len(sandbox.items())
    layout.label(text="{} item{}".format(n, "" if n == 1 else "s"))
    layout.separator_spacer()
    layout.operator(AGENT_OT_sandbox_fit.bl_idname, text="Fit", icon='FULLSCREEN_EXIT')
    layout.operator(AGENT_OT_sandbox_pane.bl_idname, text="", icon='X')


_ICON = os.path.join(os.path.dirname(__file__), "icons", "sandbox.png")


def draw_tab(cv, m, area, st, hits, hovered):
    """The Sandbox's tab on the chat's right edge (on the drawer's edge while it is open), with
    the Sandbox icon and how many items it holds; a click opens or closes it."""
    s = m.s
    tw, th = 34 * s, 64 * s
    edge = max(cv.w - st.get("scrap_w", 0.0), tw)  # stays on screen when the board is wide
    x0, x1 = edge - tw, edge + 12 * s
    y1 = cv.h - 74 * s
    y0 = y1 - th
    hid = ("scrap_tab",)
    hov = hovered(hid)
    is_open = bool(st.get("scrap_w"))
    acc = ui_space_color()
    cv.rect(x0 - 2 * s, y0 - 3 * s, x1, y1 - 1 * s, "shadow", 12 * s, soft=10 * s)
    cv.rect(x0, y0, x1, y1, "surface2" if (hov or is_open) else "surface", 12 * s,
            line=D.alpha(acc, 0.8) if is_open else ("border2" if hov else "border"), width=1 * s)
    t = D.texture(_ICON, max_w=64)
    cx = x0 + tw / 2
    if t:
        tex, _w, _h = t
        k = 20 * s
        cv.image(tex, cx - k / 2, y1 - 10 * s - k, cx + k / 2, y1 - 10 * s, 0, opacity=1.0 if (hov or is_open) else 0.85)
    n = len(sandbox.items())
    label = str(n) if n else "+"
    lw = D.measure(label, m.tiny, 600)
    cv.text(cx - lw / 2, y0 + 12 * s, label, m.tiny, "text" if (hov or is_open) else "muted", 600)
    hits.append((hid, x0, y0, edge, y1))
    if hov:
        tip = "Close the Sandbox" if is_open else "Sandbox: references, logos, notes, renders"
        w = D.measure(tip, m.tiny, 500) + 18 * s
        px1 = x0 - 6 * s
        cy = (y0 + y1) / 2
        cv.rect(px1 - w, cy - 12 * s, px1, cy + 12 * s, (0.08, 0.08, 0.09, 0.92), 12 * s)
        cv.text(px1 - w + 9 * s, cy - m.tiny * 0.36, tip, m.tiny, (1, 1, 1, 1), 500)


def ui_space_color():
    from . import ui_space
    return ui_space.agent_color(None, 1.0)


def activate(context, area, hid, key):
    """A click on the board or a Sandbox chip."""
    from . import ui_space
    kind = hid[0]
    if kind in ("scrap_card", "scrap_bg", "scrap_resize", "scrap_edge"):
        mode = {"scrap_card": 'CARD', "scrap_bg": 'PAN', "scrap_resize": 'RESIZE', "scrap_edge": 'EDGE'}[kind]
        with context.temp_override(window=context.window, area=area):
            bpy.ops.agent.sandbox_drag('INVOKE_DEFAULT', mode=mode, item=hid[1] if len(hid) > 1 else "", key=key)
        return
    elif kind == "scrap_fit":
        fit(area, ui_space._area_state(area))
    elif kind == "scrap_zoom":
        st = ui_space._area_state(area)
        r = st.get("scrap_rect")
        if r and st.get("sbv"):
            zoom(area, st, (r[0] + r[2]) / 2, (r[1] + r[3]) / 2, 1.0 / st["sbv"]["z"])
    elif kind == "scrap_popout":
        with context.temp_override(window=context.window, area=area):
            bpy.ops.agent.sandbox_pane()
    elif kind == "scrap_chip":
        attach(key, hid[1], False)
    elif kind == "scrap_del":
        if sandbox.remove(hid[1]):
            _push_undo("Sandbox: remove")
    elif kind == "scrap_scrim":
        context.window_manager.agent_ui_sandbox = False
    elif kind == "scrap_open":
        context.window_manager.agent_ui_sandbox = True
    elif kind == "scrap_tab":
        context.window_manager.agent_ui_sandbox = not context.window_manager.agent_ui_sandbox
    elif kind == "scrap_cancel":
        from . import renderjob
        renderjob.cancel(hid[1])
        ui_space._toast("Render cancelled")
    elif kind == "scrap_tool":
        if hid[1] == "paste":
            if paste(context, context.window_manager.clipboard, None, area) is None:
                ui_space._toast("Nothing to paste: copy an image or SVG first (text goes in the message box).")
        elif hid[1] == "files":
            with context.temp_override(window=context.window, area=area):
                bpy.ops.agent.sandbox_add_files('INVOKE_DEFAULT', attach=False)
        elif hid[1] == "note":
            with context.temp_override(window=context.window, area=area):
                bpy.ops.agent.sandbox_note('INVOKE_DEFAULT')
        elif hid[1] == "render":
            from . import renderjob
            from .registry import ToolError
            try:
                job = renderjob.start()
            except ToolError as ex:
                ui_space._toast(str(ex))
            else:
                ui_space._toast("Rendering in the background: {}".format(job["title"]))
    elif kind == "scrap_save":
        bpy.ops.agent.sandbox_save('INVOKE_DEFAULT', item=hid[1])
    elif kind == "scrap_act" and hid[2] == "source":
        it = sandbox.get(hid[1])
        if it and it.get("source", "").startswith(("https://", "http://")):
            bpy.ops.wm.url_open(url=it["source"])
    elif kind == "scrap_act":
        item_id, action = hid[1], hid[2]
        args = {"item": item_id, "action": action}
        if action == "palette":
            sel = [o.name for o in context.selected_objects if o.type in ('MESH', 'CURVE', 'SURFACE', 'FONT')]
            if not sel:
                ui_space._toast("Select the objects to tint first.")
                return
            args["objects"] = sel
        res = ui_space._run_tool("sandbox_use", args, "Sandbox: " + action)
        data = res.get("data") or {}
        if res.get("isError"):
            ui_space._toast(data.get("error", "That did not work."))
        else:
            what = data.get("object") or ("job " + str(data.get("job_id"))) if action == "make_3d" else data.get("object")
            ui_space._toast("{}: {}".format({"plane": "Plane", "logo": "Logo", "curves": "Curves", "palette": "Tinted",
                                             "make_3d": "Making 3D"}[action], what or "done"))
            chat_note = "From the Sandbox: {} {} ({})".format(action.replace("_", " "), item_id, what or "done")
            from . import chat, ui_chat
            sid = ui_chat._current_id(context.window_manager)
            if sid:
                chat.user_action(sid, chat_note)
    _redraw()


def chip_width(m, item, size):
    return D.measure(_chip_label(item), size, 500) + 30 * m.s


def _chip_label(item):
    return D.ellipsize(item.get("title") or item["id"], 13, 110)


_classes = (AGENT_OT_sandbox_add_files, AGENT_OT_sandbox_note, AGENT_FH_sandbox, AGENT_OT_sandbox_drag,
            AGENT_OT_sandbox_save, AGENT_OT_sandbox_pane, AGENT_OT_sandbox_fit)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.agent_ui_sandbox = bpy.props.BoolProperty(
        name="Sandbox", description="Show the Sandbox: references, logos, notes and renders kept in this file",
        default=False, update=lambda self, ctx: _redraw())


def unregister():
    if hasattr(bpy.types.WindowManager, "agent_ui_sandbox"):
        del bpy.types.WindowManager.agent_ui_sandbox
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    _S["attached"].clear()
    _S["drag"] = None
