# SPDX-License-Identifier: GPL-3.0-or-later
"""view_marks: the areas the user marked in Blender (a box dragged over a viewport or editor),
as pictures plus what is inside each box. See ui_mark."""

from . import ui_mark
from .registry import ToolError, tool


def _public(m, status):
    facts = {k: v for k, v in m["facts"].items() if k != "short"}
    return {"mark": m["n"], "id": m["id"], "status": status, "editor": m["editor_label"],
            "file": m.get("file", ""), "facts": facts,
            "images": ["the {} with mark {} boxed in red".format(m["editor_label"], m["n"]),
                       "close-up of mark {}".format(m["n"])]}


@tool("view_marks",
      "See the areas the user marked in Blender: they drag a box over part of a 3D viewport or any "
      "editor to show you what they mean. Returns, per mark, two pictures (the editor with the box "
      "in red, and a close-up) and what is inside: in a 3D viewport the objects under the box with "
      "their share of it, faces hit (face_indices), materials, world centre and size in metres and "
      "the local bounds, plus the view; in the node editor, the nodes. No arguments: the newest "
      "marks (waiting in the message box, else the last message's).",
      {"marks": {"type": "array", "items": {"type": "integer"}, "maxItems": 6,
                 "description": "Mark numbers, as the message names them (mark 1, mark 2...)."}})
def view_marks(args):
    wanted = args.get("marks")
    if wanted:
        found = [ui_mark.find("m{}".format(n)) for n in wanted]
        missing = [n for n, m in zip(wanted, found) if m is None]
        marks = [m for m in found if m is not None]
        if missing and not marks:
            raise ToolError("No mark {} here (marks are kept until Blender closes).".format(
                ", ".join(str(n) for n in missing)))
    else:
        marks = ui_mark.latest()
    if not marks:
        return {"data": {"marks": [], "note": "The user has not marked anything yet."}}
    pending = {m["id"] for m in ui_mark.pending()}
    images = []
    out = []
    for m in marks:
        out.append(_public(m, "waiting in the message box" if m["id"] in pending else "sent with a message"))
        images += m["images"]
    return {"data": {"marks": out}, "images": images}
