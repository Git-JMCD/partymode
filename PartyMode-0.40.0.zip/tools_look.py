# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only tools for orienting in the scene."""

import os

import bpy

from . import rules
from .registry import ToolError, bounds_dict, get_object, r, tool, vec, world_bounds

_MAX_ROOTS = 80
_MAX_TREE_NODES = 2000


def _mesh_counts(ob):
    me = ob.data
    tris = sum(len(p.vertices) - 2 for p in me.polygons) if len(me.polygons) < 200000 else None
    return {"verts": len(me.vertices), "faces": len(me.polygons), "tris": tris}


def _tree_bounds(ob, dg):
    """World bounds of an object and everything under it (an empty's group has the size of its
    contents), or None."""
    lo = hi = None
    for o in (ob, *ob.children_recursive):
        b = world_bounds(o, dg)
        if b is None:
            continue
        lo = b[0].copy() if lo is None else type(lo)(map(min, lo, b[0]))
        hi = b[1].copy() if hi is None else type(hi)(map(max, hi, b[1]))
    return (lo, hi) if lo is not None else None


def addon_build():
    """Which add-on is running: its version (from the extension manifest; "development" when run
    from a source folder) and where it was loaded from."""
    folder = os.path.dirname(os.path.abspath(__file__))
    version = "development"
    try:
        with open(os.path.join(folder, "blender_manifest.toml"), encoding="utf-8") as fh:
            for line in fh:
                if line.strip().startswith("version"):
                    version = line.split("=", 1)[1].strip().strip('"')
                    break
    except OSError:
        pass
    out = {"version": version, "module": __package__, "folder": folder}
    from . import updates
    latest = updates.status()["latest"]
    new = latest if updates.newer(latest, version) else ""  # not available(): it asks for this version
    if new:
        out["update"] = "PartyMode {} is out: the user can install it from the add-on's preferences".format(new)
    return out


@tool("scene_overview",
      "Start here. Compact orientation: file, mode, frame, camera, units, render engine, "
      "object counts, scene size, selection, and every top-level object with type, "
      "location, world bounds (evaluated, metres) and child count.")
def scene_overview(args):
    ctx = bpy.context
    scene = ctx.scene
    dg = ctx.evaluated_depsgraph_get()
    counts, total_verts, total_faces = {}, 0, 0
    for ob in scene.objects:
        counts[ob.type] = counts.get(ob.type, 0) + 1
        if ob.type == 'MESH' and ob.data:
            total_verts += len(ob.data.vertices)
            total_faces += len(ob.data.polygons)

    roots = [ob for ob in scene.objects if ob.parent is None]
    root_info = []
    lo = hi = None
    for ob in roots:
        b = _tree_bounds(ob, dg)
        if b is not None:
            lo = b[0].copy() if lo is None else type(lo)(map(min, lo, b[0]))
            hi = b[1].copy() if hi is None else type(hi)(map(max, hi, b[1]))
        if len(root_info) < _MAX_ROOTS:
            root_info.append({
                "name": ob.name, "type": ob.type,
                "location": vec(ob.matrix_world.translation),
                "bounds": bounds_dict(b),
                "children": len(ob.children_recursive),
                "visible": ob.visible_get(),
            })

    us = scene.unit_settings
    data = {
        "file": os.path.basename(bpy.data.filepath) or "(unsaved)",
        "unsaved_changes": bpy.data.is_dirty,
        "blender": bpy.app.version_string,
        "agent_build": hasattr(bpy.app, "agent"),
        "addon": addon_build(),
        "scene": scene.name,
        "mode": ctx.mode,
        "frame": scene.frame_current,
        "frame_range": [scene.frame_start, scene.frame_end],
        "fps": r(scene.render.fps / scene.render.fps_base, 3),
        "camera": scene.camera.name if scene.camera else None,
        "render_engine": scene.render.engine,
        "units": {"system": us.system, "length": us.length_unit, "scale": r(us.scale_length)},
        "active": ctx.view_layer.objects.active.name if ctx.view_layer.objects.active else None,
        "selected": [ob.name for ob in ctx.selected_objects][:50],
        "object_counts": counts,
        "mesh_totals": {"verts": total_verts, "faces": total_faces},
        "scene_bounds": bounds_dict((lo, hi)) if lo is not None else None,
        "roots": root_info,
    }
    if len(roots) > _MAX_ROOTS:
        data["roots_truncated"] = len(roots) - _MAX_ROOTS
    house_rules = rules.active_rules()
    if house_rules:
        data["house_rules"] = house_rules
        data["house_rules_note"] = "Follow these; they are the user's standing preferences."
    from . import intercom
    data["agents"] = intercom.overview(args.get("_client", "agent"))
    return {"data": data}


@tool("scene_hierarchy",
      "The whole outliner in one call: every root object with nested children "
      "(name, type, materials on meshes) plus the collection tree. Use instead of "
      "walking objects one by one.")
def scene_hierarchy(args):
    scene = bpy.context.scene
    budget = [_MAX_TREE_NODES]

    def node(ob):
        budget[0] -= 1
        n = {"name": ob.name, "type": ob.type}
        if ob.type == 'MESH':
            mats = [s.material.name for s in ob.material_slots if s.material]
            n["materials"] = mats
        kids = [c for c in ob.children if c.name in scene.objects]
        if kids:
            if budget[0] > 0:
                n["children"] = [node(c) for c in kids if budget[0] > 0]
            else:
                n["children_truncated"] = len(kids)
        return n

    def coll(c):
        out = {"name": c.name, "objects": len(c.objects)}
        if c.children:
            out["children"] = [coll(cc) for cc in c.children]
        return out

    roots = [ob for ob in scene.objects if ob.parent is None]
    data = {
        "objects": [node(ob) for ob in roots if budget[0] > 0],
        "collections": coll(scene.collection),
    }
    if budget[0] <= 0:
        data["truncated"] = True
    return {"data": data}


def _material_summary(mat):
    out = {"name": mat.name, "users": mat.users}
    if mat.use_nodes and mat.node_tree:
        bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        if bsdf is not None:
            def inp(name):
                s = bsdf.inputs.get(name)
                if s is None:
                    return None
                if s.is_linked:
                    return "linked:" + s.links[0].from_node.type.lower()
                v = s.default_value
                return vec(v, 3) if hasattr(v, "__len__") else r(v, 3)
            out["principled"] = {k: inp(k) for k in ("Base Color", "Metallic", "Roughness", "Alpha")}
        out["nodes"] = len(mat.node_tree.nodes)
    else:
        out["viewport_color"] = vec(mat.diffuse_color, 3)
    return out


def _details(ob, dg):
    d = {
        "name": ob.name, "type": ob.type,
        "parent": ob.parent.name if ob.parent else None,
        "children": [c.name for c in ob.children][:50],
        "collections": [c.name for c in ob.users_collection],
        "location": vec(ob.location), "rotation_euler": vec(ob.rotation_euler),
        "rotation_mode": ob.rotation_mode, "scale": vec(ob.scale),
        "world_location": vec(ob.matrix_world.translation),
        "dimensions": vec(ob.dimensions),
        "bounds": bounds_dict(world_bounds(ob, dg)),
        "visible": ob.visible_get(), "hide_render": ob.hide_render,
        "data": ob.data.name if ob.data else None,
        "data_users": ob.data.users if ob.data else None,
    }
    if ob.type == 'MESH':
        me = ob.data
        d["mesh"] = _mesh_counts(ob)
        ob_eval = ob.evaluated_get(dg)
        try:
            me_eval = ob_eval.data
            d["mesh_evaluated"] = {"verts": len(me_eval.vertices), "faces": len(me_eval.polygons)}
        except Exception:
            pass
        d["uv_layers"] = [uv.name for uv in me.uv_layers]
        d["attributes"] = [a.name for a in me.attributes if not a.name.startswith(".")][:30]
    d["modifiers"] = [{"name": m.name, "type": m.type, "show_viewport": m.show_viewport,
                       "show_render": m.show_render} for m in ob.modifiers]
    d["constraints"] = [{"name": c.name, "type": c.type, "enabled": c.enabled} for c in ob.constraints]
    d["materials"] = [_material_summary(s.material) if s.material else None for s in ob.material_slots]
    if ob.type == 'CAMERA':
        cam = ob.data
        d["camera"] = {"type": cam.type, "lens_mm": r(cam.lens, 2), "sensor_mm": r(cam.sensor_width, 2),
                       "ortho_scale": r(cam.ortho_scale, 3), "clip": [r(cam.clip_start), r(cam.clip_end)]}
    elif ob.type == 'LIGHT':
        lt = ob.data
        d["light"] = {"type": lt.type, "energy": r(lt.energy, 3), "color": vec(lt.color, 3)}
    elif ob.type == 'ARMATURE':
        d["armature"] = {"bones": len(ob.data.bones), "root_bones": [b.name for b in ob.data.bones if not b.parent][:20]}
    props = {k: (v if isinstance(v, (int, float, str, bool)) else str(v))
             for k, v in ob.items() if not k.startswith("_")}
    if props:
        d["custom_properties"] = props
    if ob.animation_data and ob.animation_data.action:
        d["action"] = ob.animation_data.action.name
    return d


@tool("object_details",
      "Rich details for named objects: transforms, evaluated world bounds, hierarchy, "
      "mesh stats (before and after modifiers), UVs, modifiers, constraints, materials, "
      "camera/light/armature data, custom properties.",
      {"names": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 40}},
      required=("names",))
def object_details(args):
    dg = bpy.context.evaluated_depsgraph_get()
    out, missing = [], []
    for name in args["names"]:
        try:
            out.append(_details(get_object(name), dg))
        except ToolError as ex:
            missing.append(str(ex))
    data = {"objects": out}
    if missing:
        data["missing"] = missing
    return {"data": data}
