# SPDX-License-Identifier: GPL-3.0-or-later
"""
This Blender's MCP server for an agent that only starts MCP servers as programs (stdio):

    python -I mcp_stdio.py http://127.0.0.1:9900/mcp?client=chat-grok

Each JSON-RPC message on stdin goes to the HTTP server; each answer comes back on stdout, one
per line. Calls run side by side (a long one, like wait_for_job, doesn't hold up the rest).
Nothing here touches bpy.
"""

import json
import sys
import threading
import urllib.error
import urllib.request

URL = sys.argv[1]
_out = threading.Lock()
_session = {"id": None}


def _post(line):
    headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
    if _session["id"]:
        headers["Mcp-Session-Id"] = _session["id"]
    req = urllib.request.Request(URL, data=line.encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=900) as res:
            sid = res.headers.get("Mcp-Session-Id")
            if sid:
                _session["id"] = sid
            body = res.read().decode("utf-8", "replace").strip()
    except urllib.error.HTTPError as ex:
        body = ex.read().decode("utf-8", "replace").strip()
    except (urllib.error.URLError, OSError) as ex:
        try:
            rid = json.loads(line).get("id")
        except ValueError:
            rid = None
        if rid is None:
            return
        body = json.dumps({"jsonrpc": "2.0", "id": rid,
                           "error": {"code": -32000, "message": "Blender is not answering: {}".format(ex)}})
    if body:
        with _out:
            sys.stdout.write(body.replace("\n", " ") + "\n")
            sys.stdout.flush()


def main():
    first = True
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        if first:  # the handshake first, so every later call has the session id
            _post(line)
            first = False
        else:
            threading.Thread(target=_post, args=(line,), daemon=True).start()


if __name__ == "__main__":
    main()
