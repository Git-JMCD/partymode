# SPDX-License-Identifier: GPL-3.0-or-later
"""
Check results drawn in the 3D viewport: where inspect_geometry failed (a part sunk in, floating,
colliding) and where inspect_mesh found holes or flipped faces, as a box around the spot with a
short label, seen through the model. A mark goes when the same check passes, when its object is
checked again, after a few minutes, or with View > Clear Check Marks; the preference "Show check
results in the viewport" turns them off.
"""

import re
import time

import bpy

SHOW = {"on": True}
LIFETIME_S = 300
COLOURS = {"error": (1.0, 0.27, 0.22, 1.0), "warning": (1.0, 0.68, 0.18, 1.0)}
_marks = {}          # key -> {"severity", "label", "lo", "hi", "points", "t"}
_handles = []
_timer = {"on": False}


def _redraw():
    wm = bpy.context.window_manager if bpy.context else None
    for win in (wm.windows if wm else ()):
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _tick():
    now = time.time()
    gone = [k for k, m in _marks.items() if now - m["t"] > LIFETIME_S]
    for k in gone:
        del _marks[k]
    if gone:
        _redraw()
    if not _marks:
        _timer["on"] = False
        return None
    return 5.0


def _changed():
    if not bpy.app.background:
        _redraw()
        if _marks and not _timer["on"]:
            _timer["on"] = True
            bpy.app.timers.register(_tick, first_interval=5.0)


def active():
    return {k: dict(m) for k, m in _marks.items() if time.time() - m["t"] <= LIFETIME_S}


def clear():
    _marks.clear()
    _changed()


def _box(lo, hi, pad):
    lo = [float(v) for v in lo]
    hi = [float(v) for v in hi]
    for i in range(3):  # never a flat box: at least `pad` across
        if hi[i] - lo[i] < pad:
            mid = (hi[i] + lo[i]) / 2
            lo[i], hi[i] = mid - pad / 2, mid + pad / 2
    return lo, hi


def _metres(text):
    """'by 0.0041 m' -> 'by 4.1 mm' for short distances, so labels read at a glance."""
    def mm(hit):
        v = float(hit.group(1))
        return "{:g} mm".format(round(v * 1000, 1)) if abs(v) < 1.0 else hit.group(0)
    return re.sub(r"(-?\d+(?:\.\d+)?) m\b", mm, text)


_SAYINGS = (
    (r"sunk into the support by (.+)", "{src} sunk {0} into {tgt}"),
    (r"floating (.+) above/away from the support", "{src} floats {0} off {tgt}"),
    (r"below the top of the support.*", "{src} hangs below the top of {tgt}"),
    (r"not touching: (.+) apart", "{src} is {0} short of {tgt}"),
    (r"colliding \(overlap (.+)\)", "{src} hits {tgt} ({0} overlap)"),
    (r"only (.+) clearance", "{src} clears {tgt} by only {0}"),
)


def _say(src, tgt, verdict):
    v = _metres(verdict or "failed")
    for pattern, words in _SAYINGS:
        hit = re.fullmatch(pattern, v)
        if hit:
            return words.format(*hit.groups(), src=src, tgt=tgt)
    return "{}: {} ({})".format(src, v, tgt)


def from_geometry(checks):
    """inspect_geometry results: a mark per failed check, none for those that pass. Returns how many."""
    n = 0
    for c in checks:
        key = "geo:{}>{}:{}".format(c.get("source"), c.get("target"), c.get("relationship"))
        _marks.pop(key, None)
        ev = c.get("evidence") or {}
        if c.get("passed") or "bounds_min" not in ev:
            continue
        size = max(hi - lo for lo, hi in zip(ev["bounds_min"], ev["bounds_max"]))
        lo, hi = _box(ev["bounds_min"], ev["bounds_max"], max(size * 0.15, 0.02))
        _marks[key] = {"severity": "error", "lo": lo, "hi": hi, "points": ev.get("worst_points", [])[:4],
                       "label": _say(c["source"], c["target"], c.get("verdict")),
                       "t": time.time()}
        n += 1
    _changed()
    return n


def from_mesh(objects):
    """inspect_mesh results: holes and flipped faces with their places. Returns how many marks."""
    n = 0
    for o in objects:
        name = o.get("name")
        for k in [k for k in _marks if k.startswith("mesh:{}:".format(name))]:
            del _marks[k]
        for f in o.get("findings", []):
            if f.get("severity") not in COLOURS:
                continue
            places = f.get("largest") or ([f["where"]] if f.get("where") else [])
            for i, p in enumerate(places[:3]):
                size = max(p["size"]) if p.get("size") else 0.05
                c, half = p["centre"], [max(v, size * 0.2, 0.01) / 2 for v in p.get("size", (size,) * 3)]
                lo, hi = [c[j] - half[j] for j in range(3)], [c[j] + half[j] for j in range(3)]
                what = {"holes": "hole", "flipped": "flipped faces"}.get(f["code"], f["code"])
                _marks["mesh:{}:{}:{}".format(name, f["code"], i)] = {
                    "severity": f["severity"], "lo": lo, "hi": hi, "points": [],
                    "label": "{}: {}{}".format(name, what, " {}".format(i + 1) if len(places) > 1 else ""),
                    "t": time.time()}
                n += 1
    _changed()
    return n


def note(n):
    if not n or bpy.app.background or not SHOW["on"]:
        return None
    return "{} problem spot(s) marked in the 3D viewport (red: a failed check, amber: a warning); they go when " \
           "the check passes, after 5 minutes, or with View > Clear Check Marks.".format(n)


# ---------------------------------------------------------------------------
# Drawing.

_EDGES = ((0, 1), (1, 3), (3, 2), (2, 0), (4, 5), (5, 7), (7, 6), (6, 4), (0, 4), (1, 5), (2, 6), (3, 7))


def _corners(lo, hi):
    return [(x, y, z) for z in (lo[2], hi[2]) for y in (lo[1], hi[1]) for x in (lo[0], hi[0])]


def _draw_3d():
    if not SHOW["on"] or not _marks:
        return
    import gpu
    from gpu_extras.batch import batch_for_shader
    region = bpy.context.region
    gpu.state.depth_test_set('NONE')
    gpu.state.blend_set('ALPHA')
    line = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    for m in list(_marks.values()):
        col = COLOURS.get(m["severity"], COLOURS["error"])
        pts = _corners(m["lo"], m["hi"])
        segs = [p for a, b in _EDGES for p in (pts[a], pts[b])]
        line.bind()
        line.uniform_float("viewportSize", (region.width, region.height))
        line.uniform_float("lineWidth", 2.0)
        line.uniform_float("color", col)
        batch_for_shader(line, 'LINES', {"pos": segs}).draw(line)
        if m["points"]:
            dot = gpu.shader.from_builtin('POINT_UNIFORM_COLOR')
            gpu.state.point_size_set(7.0)
            dot.bind()
            dot.uniform_float("color", col)
            batch_for_shader(dot, 'POINTS', {"pos": [tuple(p) for p in m["points"]]}).draw(dot)
            gpu.state.point_size_set(1.0)
    gpu.state.blend_set('NONE')


def _draw_labels():
    if not SHOW["on"] or not _marks:
        return
    import blf
    import gpu
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    from gpu_extras.batch import batch_for_shader
    region, rv3d = bpy.context.region, bpy.context.region_data
    if rv3d is None:
        return
    s = bpy.context.preferences.system.ui_scale
    rect = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    for m in list(_marks.values()):
        top = ((m["lo"][0] + m["hi"][0]) / 2, (m["lo"][1] + m["hi"][1]) / 2, m["hi"][2])
        at = location_3d_to_region_2d(region, rv3d, top)
        if at is None:
            continue
        size = 11 * s
        blf.size(0, size)
        tw, _th = blf.dimensions(0, m["label"])
        w, h = tw + 12 * s, size + 8 * s
        x, y = at.x - w / 2, at.y + 8 * s
        col = COLOURS.get(m["severity"], COLOURS["error"])
        rect.bind()
        rect.uniform_float("color", (col[0] * 0.55, col[1] * 0.55, col[2] * 0.55, 0.92))
        batch_for_shader(rect, 'TRIS', {"pos": [(x, y), (x + w, y), (x + w, y + h), (x, y), (x + w, y + h),
                                                (x, y + h)]}).draw(rect)
        blf.color(0, 1, 1, 1, 1)
        blf.position(0, x + 6 * s, y + 5 * s, 0)
        blf.draw(0, m["label"])
    gpu.state.blend_set('NONE')


class AGENT_OT_clear_check_marks(bpy.types.Operator):
    """Remove the agent's check marks from the 3D viewport"""
    bl_idname = "agent.clear_check_marks"
    bl_label = "Clear Check Marks"

    @classmethod
    def poll(cls, context):
        return bool(_marks)

    def execute(self, context):
        clear()
        return {'FINISHED'}


def _menu(self, context):
    if _marks:
        self.layout.operator(AGENT_OT_clear_check_marks.bl_idname, icon='X')


def register():
    bpy.utils.register_class(AGENT_OT_clear_check_marks)
    bpy.types.VIEW3D_MT_view.append(_menu)
    space = bpy.types.SpaceView3D
    _handles.append(space.draw_handler_add(_draw_3d, (), 'WINDOW', 'POST_VIEW'))
    _handles.append(space.draw_handler_add(_draw_labels, (), 'WINDOW', 'POST_PIXEL'))


def unregister():
    for h in _handles:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
        except (ValueError, RuntimeError):
            pass
    _handles.clear()
    bpy.types.VIEW3D_MT_view.remove(_menu)
    bpy.utils.unregister_class(AGENT_OT_clear_check_marks)
