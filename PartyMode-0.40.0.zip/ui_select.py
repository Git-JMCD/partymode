# SPDX-License-Identifier: GPL-3.0-or-later
"""
Selecting text in the chat: drag across the conversation to select, double-click a word, Ctrl+C
to copy. The conversation's text is drawn from laid-out runs (ui_draw ops), so a position is
(block, run, character) and the selection is the range between two of them in reading order.
"""

import bpy

from . import ui_draw as D


def capture(st, blocks, col_x, oy, view_bottom, view_top):
    """Note where the text runs are this draw: all blocks' ops (to copy, even scrolled away) and
    the visible runs in region pixels (to hit and highlight)."""
    st["sel_ops"] = [ops for _by, ops, _h, _hits in blocks]
    runs = []
    for bi, (by, ops, _h, _hits) in enumerate(blocks):
        top = oy - by
        for oi, op in enumerate(ops):
            if op[0] != "t":
                continue
            _, x, y, text, size, weight, _color, font = op
            base = top - y
            if view_bottom - 2 * size < base < view_top + 2 * size and text.strip():
                runs.append(((bi, oi), col_x + x, base, text, size, weight, font))
    st["sel_runs"] = runs
    st["sel_view"] = (col_x, view_bottom, view_top)


def _chars(run, x):
    """The character index in a run nearest the pixel x."""
    _key, rx, _base, text, size, weight, font = run
    if x <= rx:
        return 0
    prev = 0.0
    for i in range(1, len(text) + 1):
        w = D.measure(text[:i], size, weight, font)
        if rx + w >= x:
            return i if (rx + w - x) < (x - rx - prev) else i - 1
        prev = w
    return len(text)


def key_at(st, x, y):
    """(block, run, char) nearest (x, y) among the visible runs, or None."""
    runs = st.get("sel_runs") or []
    if not runs:
        return None
    # The line under the pointer (the nearest one); then the run on it nearest in x.
    def line_dist(r):
        base, size = r[2], r[4]
        lo, hi = base - size * 0.35, base + size * 1.0
        return 0.0 if lo <= y <= hi else min(abs(y - lo), abs(y - hi))
    best = min(line_dist(r) for r in runs)
    line = [r for r in runs if line_dist(r) - best < 0.5]
    line_base = min(line, key=lambda r: abs(r[2] - y))[2]
    line = [r for r in line if abs(r[2] - line_base) < 0.5]
    line.sort(key=lambda r: r[1])
    for r in line:
        w = D.measure(r[3], r[4], r[5], r[6])
        if x <= r[1] + w or r is line[-1]:
            if x < r[1] and r is not line[0]:
                prev = line[line.index(r) - 1]
                return prev[0] + (len(prev[3]),)
            return r[0] + (_chars(r, x),)
    return None


def _ordered(st):
    sel = st.get("sel")
    if not sel or sel.get("a") is None or sel.get("b") is None:
        return None
    a, b = sel["a"], sel["b"]
    return (a, b) if a <= b else (b, a)


def has_selection(st):
    r = _ordered(st)
    return bool(r) and r[0] != r[1]


def clear(st):
    st.pop("sel", None)


def draw_highlight(cv, st, color):
    """A tint behind the selected part of each visible run (drawn over the text, see-through)."""
    r = _ordered(st)
    if not r or r[0] == r[1]:
        return
    a, b = r
    for key, rx, base, text, size, weight, font in st.get("sel_runs") or []:
        k0, k1 = key + (0,), key + (len(text),)
        if k1 <= a or k0 >= b:
            continue
        c0 = a[2] if key == a[:2] else 0
        c1 = b[2] if key == b[:2] else len(text)
        if c1 <= c0:
            continue
        x0 = rx + D.measure(text[:c0], size, weight, font)
        x1 = rx + D.measure(text[:c1], size, weight, font)
        cv.rect(x0 - 1, base - size * 0.34, x1 + 1, base + size * 0.98, color, 2 * cv.s)


def text_of(st):
    """The selected text, with line breaks where lines change and blank lines between blocks."""
    r = _ordered(st)
    if not r or r[0] == r[1]:
        return ""
    a, b = r
    out = []
    for bi, ops in enumerate(st.get("sel_ops") or []):
        if bi < a[0] or bi > b[0]:
            continue
        parts, last = [], None
        for oi, op in enumerate(ops):
            if op[0] != "t":
                continue
            key = (bi, oi)
            text = op[3]
            if key + (len(text),) <= a or key + (0,) >= b:
                continue
            c0 = a[2] if key == a[:2] else 0
            c1 = b[2] if key == b[:2] else len(text)
            piece = text[c0:c1]
            if not piece:
                continue
            x, y, size = op[1], op[2], op[4]
            if last is not None:
                if abs(y - last[1]) > size * 2.0:  # more than a line apart: a new paragraph
                    parts.append("\n\n")
                elif abs(y - last[1]) > 0.5:
                    parts.append("\n")
                elif x - last[0] > size * 0.2:
                    parts.append(" ")
            parts.append(piece)
            last = (x + D.measure(text[:c1], size, op[5], op[7]), y)
        if parts:
            out.append("".join(parts).strip("\n"))
    return "\n\n".join(p for p in out if p)


def select_word(st, x, y):
    """Double-click: the word under the pointer."""
    k = key_at(st, x, y)
    if k is None:
        return False
    run = next((r for r in st.get("sel_runs") or [] if r[0] == k[:2]), None)
    if run is None:
        return False
    text, i = run[3], min(k[2], len(run[3]) - 1)
    word = lambda c: c.isalnum() or c in "_.-@/:"  # noqa: E731 - names, numbers, paths stay whole
    if not word(text[i]) and i > 0 and word(text[i - 1]):
        i -= 1
    s0 = s1 = i
    while s0 > 0 and word(text[s0 - 1]):
        s0 -= 1
    while s1 < len(text) and word(text[s1]):
        s1 += 1
    if s1 == s0:
        s1 = s0 + 1
    st["sel"] = {"a": k[:2] + (s0,), "b": k[:2] + (s1,)}
    return True


def in_view(st, x, y):
    v = st.get("sel_view")
    return bool(v) and v[1] <= y <= v[2] and x >= v[0] - 8 * bpy.context.preferences.system.ui_scale


class AGENT_OT_select_text(bpy.types.Operator):
    """Drag across the chat to select text (Ctrl+C copies it)"""
    bl_idname = "agent.select_text"
    bl_label = "Select Chat Text"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        from . import ui_space
        self._area = context.area
        st = ui_space._area_state(self._area)
        rg = ui_space._main_region(self._area)
        self._rx, self._ry = (rg.x, rg.y) if rg else (0, 0)
        k = key_at(st, event.mouse_x - self._rx, event.mouse_y - self._ry)
        if k is None:
            clear(st)
            self._area.tag_redraw()
            return {'PASS_THROUGH'}
        st["sel"] = {"a": k, "b": k}
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        from . import ui_space
        st = ui_space._area_state(self._area)
        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            k = key_at(st, event.mouse_x - self._rx, event.mouse_y - self._ry)
            if k is not None and st.get("sel"):
                st["sel"]["b"] = k
                self._area.tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            if not has_selection(st):
                clear(st)
            self._area.tag_redraw()
            return {'FINISHED'}
        if event.type in {'ESC', 'RIGHTMOUSE'}:
            clear(st)
            self._area.tag_redraw()
            return {'FINISHED'}
        return {'RUNNING_MODAL'}


_classes = (AGENT_OT_select_text,)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
