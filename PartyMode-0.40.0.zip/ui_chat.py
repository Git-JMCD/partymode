# SPDX-License-Identifier: GPL-3.0-or-later
"""
Chat with the agent from Blender's sidebar (Agent tab), backed by `chat`.
The same sessions open in the browser chat page (Open in browser).
"""

import re
import textwrap
import webbrowser
import zlib

import bpy
import bpy.utils.previews

from . import chat, server

_ROWS = 14
_previews = None
_session_items = []   # Kept alive: Blender needs enum item strings to outlive the callback.
_cache = {"rev": -1, "id": None, "messages": []}


def _port():
    live = server.port()
    if live:
        return live
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences.port if addon else 9900


def _current_id(wm):
    sid = wm.agent_chat_session
    return None if sid in {"", "NEW"} else sid


def _sessions_enum(self, context):
    global _session_items
    items = [("NEW", "New chat", "Start a new conversation", 'ADD', 0)]
    for s in chat.list_sessions()[:200]:
        # Stable number per session: Blender stores the selection by number, and the
        # list reorders as sessions are updated.
        try:
            number = int(s["id"][:7], 16) or 1
        except ValueError:  # a hand-made or older id: any stable number will do
            number = (zlib.crc32(s["id"].encode()) & 0x0FFFFFFF) or 1
        items.append((s["id"], s["title"][:40] or "Untitled", "{} turns".format(s["turns"]), 'TEXT', number))
    _session_items = items
    return items


def _messages(local_id):
    if _cache["rev"] != chat.S.revision or _cache["id"] != local_id:
        _cache.update(rev=chat.S.revision, id=local_id, messages=chat.transcript(local_id) if local_id else [])
    return _cache["messages"]


def _thumb(local_id, name):
    global _previews
    if _previews is None:
        _previews = bpy.utils.previews.new()
    key = local_id + "/" + name
    if key not in _previews:
        path = chat.image_path(local_id, name)
        if path is None:
            return 0
        _previews.load(key, path, 'IMAGE')
    return _previews[key].icon_id


def _plain(text):
    """Markdown to panel text: drop emphasis/code marks, bullets as dots."""
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"^```.*$", "", text, flags=re.M)
    text = re.sub(r"^(\s*)[-*] ", r"\1• ", text, flags=re.M)
    return re.sub(r"^#+ ", "", text, flags=re.M)


def _wrap(col, text, width, icon='NONE'):
    lines = []
    for para in _plain(text).splitlines() or [""]:
        indent = "   " if para.lstrip().startswith("• ") else ""
        lines += textwrap.wrap(para, width, subsequent_indent=indent) or [""]
    for i, line in enumerate(lines[:40]):
        col.label(text=line, icon=icon if i == 0 else 'BLANK1' if icon != 'NONE' else 'NONE')
    if len(lines) > 40:
        col.label(text="… (open in browser for the rest)")


_quiet = [False]


def set_input(wm, text):
    """Set the chat field without the send-on-Enter update firing."""
    _quiet[0] = True
    try:
        wm.agent_chat_input = text
    finally:
        _quiet[0] = False


def _send_from_field(self, context):
    """Pressing Enter in the chat field sends the message."""
    wm = context.window_manager
    if _quiet[0] or not wm.agent_chat_input.strip():
        return
    _quiet[0] = True
    try:
        bpy.ops.agent.chat_send()
    finally:
        _quiet[0] = False


class AGENT_OT_chat_send(bpy.types.Operator):
    bl_idname = "agent.chat_send"
    bl_label = "Send"
    bl_description = "Send the message to the agent"

    def execute(self, context):
        wm = context.window_manager
        text = wm.agent_chat_input.strip()
        if not text:
            return {'CANCELLED'}
        try:
            local_id = chat.send(text, _current_id(wm), bpy.data.filepath)
        except (RuntimeError, ValueError) as ex:
            self.report({'WARNING'}, str(ex))
            return {'CANCELLED'}
        set_input(wm, "")
        if wm.agent_chat_session != local_id:
            _sessions_enum(None, context)
            wm.agent_chat_session = local_id
        return {'FINISHED'}


class AGENT_OT_chat_stop(bpy.types.Operator):
    bl_idname = "agent.chat_stop"
    bl_label = "Stop"
    bl_description = "Stop the agent's current answer"

    def execute(self, context):
        from . import cancel
        chat.stop()
        cancel.stop("stopped from the chat")
        return {'FINISHED'}


class AGENT_OT_chat_new(bpy.types.Operator):
    bl_idname = "agent.chat_new"
    bl_label = "New Chat"
    bl_description = "Start a new conversation"

    def execute(self, context):
        context.window_manager.agent_chat_session = "NEW"
        return {'FINISHED'}


class AGENT_OT_chat_open_browser(bpy.types.Operator):
    bl_idname = "agent.chat_open_browser"
    bl_label = "Open Chat in Browser"
    bl_description = "Open this conversation (and all past sessions) in the full chat page"

    def execute(self, context):
        sid = _current_id(context.window_manager)
        url = "http://127.0.0.1:{}/chat{}".format(_port(), "?session=" + sid if sid else "")
        webbrowser.open(url)
        return {'FINISHED'}


class VIEW3D_PT_agent_chat(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PartyMode"
    bl_label = "Chat"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        if not server.is_running():
            layout.label(text="Start the agent server to chat.", icon='UNLINKED')
            return
        row = layout.row(align=True)
        row.prop(wm, "agent_chat_session", text="")
        row.operator(AGENT_OT_chat_new.bl_idname, text="", icon='ADD')
        row.operator(AGENT_OT_chat_open_browser.bl_idname, text="", icon='URL')

        local_id = _current_id(wm)
        width = max(18, int(context.region.width / (7.2 * context.preferences.system.ui_scale)) - 4)
        box = layout.box()
        col = box.column(align=True)
        messages = _messages(local_id)
        if not messages:
            col.label(text="Ask for a prop, a fix, a check…", icon='INFO')
        shown = messages[-_ROWS:]
        if len(messages) > _ROWS:
            col.label(text="(earlier messages in the browser view)")
        for e in shown:
            role = e.get("role")
            if role == "user":
                col.separator()
                _wrap(col, e["text"], width, 'USER')
            elif role == "assistant":
                col.separator()
                _wrap(col, e["text"], width, 'LIGHT')
            elif role == "tool":
                col.label(text="{}{}".format(e["tool"], " · " + e["detail"][:28] if e.get("detail") else ""),
                          icon='TOOL_SETTINGS')
            elif role == "tool_result" and e.get("images"):
                for name in e["images"][:2]:
                    icon = _thumb(local_id, name)
                    if icon:
                        col.template_icon(icon_value=icon, scale=8)
            elif role == "tool_result" and not e.get("ok"):
                col.label(text=e["tool"] + " failed", icon='ERROR')
            elif role == "system":
                _wrap(col, e["text"], width, 'ERROR')

        turn = chat.live()
        if turn and turn["local_id"] == local_id:
            if turn["text"]:
                col.separator()
                _wrap(col, turn["text"], width, 'LIGHT')
            col.label(text=turn["activity"] + "…", icon='TIME')

        busy = chat.live() is not None
        row = layout.row(align=True)
        row.enabled = not busy
        row.prop(wm, "agent_chat_input", text="", icon='GREASEPENCIL')
        if busy:
            layout.operator(AGENT_OT_chat_stop.bl_idname, icon='CANCEL')
        else:
            row.operator(AGENT_OT_chat_send.bl_idname, text="", icon='PLAY')


_classes = (AGENT_OT_chat_send, AGENT_OT_chat_stop, AGENT_OT_chat_new, AGENT_OT_chat_open_browser,
            VIEW3D_PT_agent_chat)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    wm = bpy.types.WindowManager
    wm.agent_chat_input = bpy.props.StringProperty(
        name="Message", description="Message for the agent (Enter to send)",
        options={'SKIP_SAVE'}, update=_send_from_field)
    wm.agent_chat_session = bpy.props.EnumProperty(
        name="Session", description="Conversation to show and continue", items=_sessions_enum)


def unregister():
    global _previews
    wm = bpy.types.WindowManager
    del wm.agent_chat_input
    del wm.agent_chat_session
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None
