# SPDX-License-Identifier: GPL-3.0-or-later
"""
The agents the chat can run: Claude Code, Codex (OpenAI) and OpenCode (open and local
models: OpenRouter, Hugging Face, Gemini, Ollama, LM Studio...).

Each runner is driven headless, connected only to this Blender's MCP server, with the
same limits: the Blender tools plus (where the runner has one) reading files; no shell,
no file edits, no web. A runner turns its own JSONL output into common events:

    ("session", id)              the runner's session id (to resume next turn)
    ("model", name)              the model that actually answered
    ("delta", text)              streamed text (Claude only)
    ("text", text)               a finished block of the reply
    ("tool", call_id, name, input)
    ("result", call_id, name, ok, text, [png bytes])
    ("context", tokens, window)  how full the model's context is (window 0 = unknown)
    ("done", error_or_None)

Runners that do not stream their context size report it after the turn
(`context_after`), from their own session logs.
Nothing here touches bpy (runs on worker threads).
"""

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import threading
import time
import uuid

try:
    import tomllib
except ImportError:  # pragma: no cover - Python < 3.11
    tomllib = None

SERVER = "agent-blender"
# Long tool calls (wait_for_job, renders) must not be cut off by the agent's own MCP timeout.
TOOL_TIMEOUT_S = 660


def _home(*parts):
    return os.path.join(os.path.expanduser("~"), *parts)


# On macOS and Linux, Blender opened from the Dock or a launcher doesn't get the PATH a terminal has
# (Homebrew, npm, nvm...), so programs installed there aren't found. The usual install folders are
# added straight away, and the PATH from the user's own shell once it answers (in the background:
# this is called while menus draw).
_shell = {"path": None, "asked": False}
_shell_lock = threading.Lock()


def _ask_shell():
    shell = os.environ.get("SHELL") or ("/bin/zsh" if os.uname().sysname == "Darwin" else "/bin/bash")
    path = ""
    try:
        # Interactive login, so PATH set in .zshrc or .bashrc counts too (nvm usually lives there).
        out = subprocess.run([shell, "-ilc", 'printf "\n__PATH__%s\n" "$PATH"'], stdin=subprocess.DEVNULL,
                             capture_output=True, text=True, timeout=15).stdout
        path = next((line[8:] for line in out.splitlines() if line.startswith("__PATH__")), "")
    except (OSError, subprocess.SubprocessError, ValueError):
        pass
    with _shell_lock:
        _shell["path"] = path


def _usual_dirs():
    dirs = [_home(".local", "bin"), "/opt/homebrew/bin", "/usr/local/bin", _home(".npm-global", "bin"),
            _home(".volta", "bin"), _home(".bun", "bin"), _home(".opencode", "bin")]
    nvm = _home(".nvm", "versions", "node")
    try:
        versions = sorted(os.listdir(nvm), key=lambda v: [int(n) if n.isdigit() else 0
                                                          for n in v.lstrip("v").split(".")], reverse=True)
        dirs += [os.path.join(nvm, v, "bin") for v in versions]
    except OSError:
        pass
    return dirs


def search_path():
    """The PATH to find agents (and for them to find node) with."""
    if os.name == "nt":
        return os.environ.get("PATH", "")
    return os.pathsep.join(_search_dirs())


def _search_dirs():
    own = os.environ.get("PATH", "")
    with _shell_lock:
        if not _shell["asked"]:
            _shell["asked"] = True
            threading.Thread(target=_ask_shell, name="agent-shell-path", daemon=True).start()
        shell = _shell["path"] or ""
    seen, dirs = set(), []
    for d in own.split(os.pathsep) + shell.split(":") + _usual_dirs():
        if d and d not in seen:
            seen.add(d)
            dirs.append(d)
    return dirs


def _which(name):
    return shutil.which(name, path=search_path())


def _png(data):
    try:
        return base64.b64decode(data)
    except (ValueError, TypeError):
        return None


# Claude Code adds a text part like "[Image: source: C:\...\blob.png]" after each image it saves;
# it is not part of the tool's reply (which is JSON) and would break reading it.
_IMAGE_NOTE = re.compile(r"^\s*\[Image: source: [^\]]*\]\s*$")


def _parts(content):
    """MCP tool result content -> (text, [png bytes])."""
    texts, images = [], []
    for part in content if isinstance(content, list) else []:
        if not isinstance(part, dict):
            continue
        kind = part.get("type")
        if kind == "text":
            text = part.get("text", "")
            if not _IMAGE_NOTE.match(text):
                texts.append(text)
        elif kind == "image":
            data = part.get("data") or (part.get("source") or {}).get("data")
            png = _png(data) if data else None
            if png:
                images.append(png)
        elif kind == "file" and str(part.get("uri", "")).startswith("data:image/"):
            png = _png(part["uri"].split(",", 1)[-1])
            if png:
                images.append(png)
    if isinstance(content, str):
        texts.append(content)
    return "".join(texts), images


# ---------------------------------------------------------------------------
# Claude Code

def _flags():
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)


class _Runner:
    @staticmethod
    def recover(cmd, cwd, error, attempt):
        return None

    @classmethod
    def context_after(cls, exe, session, model, env_for=None):
        """(tokens, window) after a turn, for runners whose stream does not say; None if unknown."""
        return None


class Claude(_Runner):
    key = "claude"
    label = "Claude"
    description = "Claude Code (your Claude sign-in)"
    efforts = ("low", "medium", "high", "xhigh", "max")
    ALLOWED = ["mcp__" + SERVER, "Read", "Glob", "Grep"]
    DISALLOWED = ["Bash", "Edit", "Write", "NotebookEdit", "WebFetch", "WebSearch", "Task", "Agent"]

    @staticmethod
    def find(custom=""):
        if custom and os.path.isfile(custom):
            return custom
        found = _which("claude")
        if found and found.lower().endswith((".cmd", ".bat")):
            found = None  # never route a message through a batch file
        for p in (found, _home(".local", "bin", "claude.exe"), _home(".local", "bin", "claude")):
            if p and os.path.isfile(p):
                return p
        return None

    @staticmethod
    def defaults():
        model = effort = ""
        try:
            with open(_home(".claude", "settings.json"), encoding="utf-8") as fh:
                data = json.load(fh)
            model, effort = str(data.get("model") or ""), str(data.get("effortLevel") or "")
        except (OSError, ValueError):
            pass
        source = "your Claude Code settings"
        if os.environ.get("ANTHROPIC_MODEL"):
            model, source = os.environ["ANTHROPIC_MODEL"], "the ANTHROPIC_MODEL variable"
        return {"model": model, "effort": effort, "source": source}

    WEB = ["WebSearch", "WebFetch"]

    @classmethod
    def command(cls, exe, work, text, resume, model, effort, system, mcp_url, research=False, ask=True):
        cfg = os.path.join(work, "claude-mcp.json")
        with open(cfg, "w", encoding="utf-8") as fh:
            json.dump({"mcpServers": {SERVER: {"type": "http", "url": mcp_url}}}, fh)
        allowed, disallowed = list(cls.ALLOWED), list(cls.DISALLOWED)
        if research:  # a research turn: the web, each search and page asked in Blender (or allowed outright)
            disallowed = [t for t in disallowed if t not in cls.WEB]
            if not ask:
                allowed += cls.WEB
        cmd = [exe, "-p", "--output-format", "stream-json", "--verbose", "--include-partial-messages",
               "--strict-mcp-config", "--mcp-config", cfg, "--allowedTools", *allowed,
               "--disallowedTools", *disallowed, "--append-system-prompt", system]
        if research and ask:
            cmd += ["--permission-prompt-tool", "mcp__{}__web_permission".format(SERVER)]
        if model:
            cmd += ["--model", model]
        if effort:
            cmd += ["--effort", effort]
        if resume:
            cmd += ["--resume", resume]
        return cmd, text, work  # the message goes on stdin

    @classmethod
    def context_after(cls, exe, session, model, env_for=None):
        """For chats from before the meter: the last reply's size in Claude Code's own log
        (the window is not logged; the chat remembers it from later turns)."""
        root = _home(".claude", "projects")
        try:
            folders = os.listdir(root)
        except OSError:
            return None
        path = next((os.path.join(root, f, session + ".jsonl") for f in folders
                     if os.path.isfile(os.path.join(root, f, session + ".jsonl"))), None)
        if path is None:
            return None
        tokens = 0
        try:
            with open(path, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    if '"usage"' not in line:
                        continue
                    try:
                        usage = (json.loads(line).get("message") or {}).get("usage") or {}
                    except ValueError:
                        continue
                    got = sum(int(usage.get(k) or 0) for k in
                              ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens"))
                    tokens = got or tokens
        except OSError:
            return None
        return (tokens, 0) if tokens else None

    @staticmethod
    def parse(msg, st):
        kind = msg.get("type")
        out = []
        if kind == "system" and msg.get("subtype") == "init":
            st["_model"] = msg.get("model") or st.get("_model", "")
            out += [("session", msg.get("session_id")), ("model", msg.get("model"))]
        elif kind == "stream_event":
            ev = msg.get("event", {})
            if ev.get("type") == "content_block_delta" and ev.get("delta", {}).get("type") == "text_delta":
                out.append(("delta", ev["delta"]["text"]))
        elif kind == "assistant":
            usage = msg.get("message", {}).get("usage") or {}
            if usage:
                st["_ctx"] = sum(int(usage.get(k) or 0) for k in
                                 ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens"))
                out.append(("context", st["_ctx"], st.get("_window", 0)))
            for block in msg.get("message", {}).get("content", []):
                if block.get("type") == "text" and block.get("text", "").strip():
                    out.append(("text", block["text"]))
                elif block.get("type") == "tool_use":
                    name = block.get("name", "").replace("mcp__{}__".format(SERVER), "")
                    st[block.get("id")] = name
                    out.append(("tool", block.get("id"), name, block.get("input")))
        elif kind == "user":
            for block in msg.get("message", {}).get("content", []):
                if block.get("type") == "tool_result":
                    text, images = _parts(block.get("content"))
                    cid = block.get("tool_use_id")
                    out.append(("result", cid, st.get(cid, "tool"), not block.get("is_error"), text, images))
        elif kind == "result":
            if msg.get("session_id"):
                out.append(("session", msg["session_id"]))
            usage = msg.get("modelUsage") or {}
            if usage and st.get("_ctx"):
                # The answering model's window (helper models, if any, report their own).
                main = usage.get(st.get("_model", "")) or max(
                    usage.values(), key=lambda u: int(u.get("cacheReadInputTokens") or 0)
                    + int(u.get("inputTokens") or 0) + int(u.get("cacheCreationInputTokens") or 0))
                st["_window"] = int(main.get("contextWindow") or 0)
                out.append(("context", st["_ctx"], st["_window"]))
            err = "Error: {}".format(msg.get("result") or msg.get("subtype")) if msg.get("is_error") else None
            out.append(("done", err))
        return out


# ---------------------------------------------------------------------------
# Codex (OpenAI)

class Codex(_Runner):
    key = "codex"
    label = "Codex"
    description = "OpenAI Codex (your ChatGPT sign-in)"
    efforts = ("low", "medium", "high", "xhigh")
    # Everything that could act outside Blender is switched off; the read-only sandbox
    # blocks its file editor (apply_patch) as well.
    DISABLE = ("shell_tool", "unified_exec", "browser_use", "browser_use_external", "in_app_browser",
               "computer_use", "apps", "goals")

    @staticmethod
    def find(custom=""):
        if custom and os.path.isfile(custom):
            return custom
        found = _which("codex")
        if found and found.lower().endswith((".cmd", ".bat")):
            found = None
        local = os.environ.get("LOCALAPPDATA", "")
        for p in (found, os.path.join(local, "Programs", "OpenAI", "Codex", "bin", "codex.exe")):
            if p and os.path.isfile(p):
                return p
        return None

    @staticmethod
    def defaults():
        model = effort = ""
        path = os.path.join(os.environ.get("CODEX_HOME") or _home(".codex"), "config.toml")
        if tomllib is not None:
            try:
                with open(path, "rb") as fh:
                    data = tomllib.load(fh)
                model, effort = str(data.get("model") or ""), str(data.get("model_reasoning_effort") or "")
            except (OSError, ValueError):
                pass
        return {"model": model, "effort": effort, "source": "your Codex settings"}

    @staticmethod
    def models():
        """[(slug, name, description)] that Codex offers this account, from the list it caches
        (models_cache.json, refreshed by Codex itself); hidden ones are left out."""
        path = os.path.join(os.environ.get("CODEX_HOME") or _home(".codex"), "models_cache.json")
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            return []
        out = []
        for m in sorted(data.get("models") or [], key=lambda m: m.get("priority", 99)):
            if isinstance(m, dict) and m.get("slug") and m.get("visibility", "list") == "list":
                out.append((m["slug"], m.get("display_name") or m["slug"], m.get("description") or ""))
        return out

    @classmethod
    def command(cls, exe, work, text, resume, model, effort, system, mcp_url, tool_names=(), research=False,
                ask=True):
        # Instructions come from AGENTS.md in the working folder; the user's own Codex
        # config (with its other MCP servers) is skipped, so its defaults are passed here.
        with open(os.path.join(work, "AGENTS.md"), "w", encoding="utf-8") as fh:
            fh.write(system)
        d = cls.defaults()
        model = model or d["model"]
        effort = {"max": "xhigh"}.get(effort, effort) or d["effort"]
        cmd = [exe, "exec"] + (["resume", resume] if resume else [])
        cmd += ["--json", "--skip-git-repo-check", "--ignore-user-config",
                "-c", 'sandbox_mode="read-only"', "-c", 'web_search="{}"'.format("live" if research else "disabled"),
                "-c", "mcp_servers.{}.url={}".format(SERVER, json.dumps(mcp_url)),
                "-c", "mcp_servers.{}.tool_timeout_sec={}".format(SERVER, TOOL_TIMEOUT_S)]
        for feature in cls.DISABLE:
            cmd += ["--disable", feature]
        # Headless Codex cannot ask before a tool that changes the scene, so this
        # Blender's own tools (every edit undoable and reported) are approved up front.
        for name in tool_names:
            cmd += ["-c", "mcp_servers.{}.tools.{}.approval_mode=\"approve\"".format(SERVER, name)]
        if model:
            cmd += ["-m", model]
        if effort:
            cmd += ["-c", "model_reasoning_effort={}".format(json.dumps(effort))]
        return cmd + ["-"], text, work

    @classmethod
    def context_after(cls, exe, session, model, env_for=None):
        root = os.path.join(os.environ.get("CODEX_HOME") or _home(".codex"), "sessions")
        newest = None
        for folder, _dirs, files in os.walk(root):
            for name in files:
                if session in name and name.endswith(".jsonl"):
                    path = os.path.join(folder, name)
                    if newest is None or os.path.getmtime(path) > os.path.getmtime(newest):
                        newest = path
        if newest is None:
            return None
        found = None
        try:
            with open(newest, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    if '"token_count"' not in line:
                        continue
                    try:
                        info = (json.loads(line).get("payload") or {}).get("info") or {}
                    except ValueError:
                        continue
                    last = info.get("last_token_usage") or {}
                    if last:
                        found = (int(last.get("input_tokens") or 0), int(info.get("model_context_window") or 0))
        except OSError:
            return None
        return found

    @staticmethod
    def parse(msg, st):
        kind = msg.get("type")
        item = msg.get("item") or {}
        out = []
        if kind == "thread.started":
            out.append(("session", msg.get("thread_id")))
            if st.get("_model"):
                out.append(("model", st["_model"]))
        elif kind in ("item.started", "item.completed") and item.get("type") == "mcp_tool_call":
            if kind == "item.started":
                out.append(("tool", item.get("id"), item.get("tool", "tool"), item.get("arguments")))
            else:
                text, images = _parts((item.get("result") or {}).get("content"))
                if item.get("error"):
                    text = str(item["error"].get("message") if isinstance(item["error"], dict) else item["error"])
                ok = item.get("status") == "completed" and not item.get("error")
                out.append(("result", item.get("id"), item.get("tool", "tool"), ok, text, images))
        elif kind in ("item.started", "item.completed") and item.get("type") == "web_search":
            # Codex's own web search (a research turn): shown as a step, and the turn marked as having used the web.
            if kind == "item.started":
                out.append(("tool", item.get("id"), "web_search", {"query": item.get("query", "")}))
            else:
                out.append(("result", item.get("id"), "web_search", True, "", []))
        elif kind == "item.completed" and item.get("type") == "agent_message" and item.get("text", "").strip():
            out.append(("text", item["text"]))
        elif kind == "turn.completed":
            out.append(("done", None))
        elif kind in ("turn.failed", "error"):
            err = msg.get("error") or msg.get("message") or "Codex reported an error"
            out.append(("done", "Error: " + (err.get("message", str(err)) if isinstance(err, dict) else str(err))))
        return out


# ---------------------------------------------------------------------------
# OpenCode (open and local models)

class OpenCode(_Runner):
    key = "opencode"
    _env_for = None
    label = "OpenCode"
    description = "OpenCode: open and local models (OpenRouter, Hugging Face, Gemini, Ollama, LM Studio)"
    efforts = ()  # set per model in OpenCode (variants), not here

    @staticmethod
    def find(custom=""):
        if custom and os.path.isfile(custom) and not custom.lower().endswith((".cmd", ".bat")):
            return custom
        found = _which("opencode")
        candidates = []
        if found:
            if os.name == "nt" and (found.lower().endswith((".cmd", ".bat", ".ps1"))
                                    or not os.path.splitext(found)[1]):
                # npm wrapper: run the real program next to it, never the batch file.
                candidates.append(os.path.join(os.path.dirname(found), "node_modules", "@opencode", "cli",
                                               "bin", "opencode.exe"))
            else:
                candidates.append(found)
        candidates.append(os.path.join(os.environ.get("APPDATA", ""), "npm", "node_modules", "@opencode", "cli",
                                       "bin", "opencode.exe"))
        return next((p for p in candidates if p and os.path.isfile(p)), None)

    @staticmethod
    def _global_config():
        try:
            with open(_home(".config", "opencode", "opencode.json"), encoding="utf-8-sig") as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return {}

    @classmethod
    def defaults(cls):
        model = str(cls._global_config().get("model") or "")
        return {"model": model, "effort": "", "source": "your OpenCode settings"}

    @classmethod
    def command(cls, exe, work, text, resume, model, effort, system, mcp_url, tool_names=(), env_for=None,
                research=False, ask=True):
        # A project config in the runner's own folder: only this Blender's MCP server
        # (the user's other servers switched off) and an agent that may use nothing but
        # the Blender tools and reading files.
        servers = {name: dict(cfg, disabled=True)
                   for name, cfg in ((cls._global_config().get("mcp") or {}).get("servers") or {}).items()}
        servers[SERVER] = {"type": "remote", "url": mcp_url, "codemode": False}
        permissions = ([{"action": "*", "resource": "*", "effect": "deny"}]
                       + [{"action": a, "resource": "*", "effect": "allow"}
                          for a in ("read", "grep", "glob", "external_directory")]
                       + [{"action": "{}_{}".format(SERVER, n), "resource": "*", "effect": "allow"}
                          for n in tool_names]
                       + ([{"action": a, "resource": "*", "effect": "allow"} for a in ("webfetch", "websearch")]
                          if research else []))
        cfg = {"$schema": "https://opencode.ai/config.json",
               "mcp": {"servers": servers, "timeout": {"execution": TOOL_TIMEOUT_S * 1000}},
               "default_agent": "blender",
               "agents": {"blender": {"description": "The assistant built into Blender (agent-blender)",
                                      "mode": "primary", "system": system, "permissions": permissions}}}
        # OpenCode's background service keeps each folder's config once loaded, so every
        # version of this config gets its own folder (a changed config always loads fresh).
        body = json.dumps(cfg, indent=1, sort_keys=True)
        digest = hashlib.sha1(body.encode("utf-8")).hexdigest()[:12]
        # The folder in use for this config version (see recover()).
        pointer = os.path.join(work, digest + ".folder")
        try:
            with open(pointer, encoding="utf-8") as fh:
                name = fh.read().strip() or digest
        except OSError:
            name = digest
        folder = cls._write(work, name, body, pointer)
        cls._env_for = env_for
        cls.warm_up(exe, folder, env_for)
        cmd = [exe, "run", "--format", "json", "--agent", "blender"]
        if model:
            cmd += ["-m", model]
        if resume:
            cmd += ["--session", resume]
        return cmd, text, folder

    @staticmethod
    def warm_up(exe, folder, env_for=None, timeout=45.0):
        """A folder's first run starts before OpenCode has connected to this Blender, so the
        model sees no Blender tools. `opencode mcp list` connects it without asking a model."""
        marker = os.path.join(folder, ".ready")
        if os.path.isfile(marker):
            return True
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        t0 = time.time()
        while time.time() - t0 < timeout:
            try:
                out = subprocess.run([exe, "mcp", "list"], cwd=folder, capture_output=True, timeout=40,
                                     env=env_for(folder) if env_for else None, creationflags=flags)
                for line in out.stdout.decode("utf-8", "replace").splitlines():
                    if SERVER in line and "connected" in line and "disconnected" not in line:
                        open(marker, "w").close()
                        return True
            except (OSError, subprocess.SubprocessError):
                pass
            time.sleep(1.5)
        return False

    @staticmethod
    def _write(work, name, body, pointer):
        folder = os.path.join(work, name)
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, "opencode.json")
        if not os.path.isfile(path):
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(body)
        with open(pointer, "w", encoding="utf-8") as fh:
            fh.write(name)
        return folder

    @classmethod
    def recover(cls, cmd, cwd, error, attempt):
        """OpenCode's background service keeps a folder's config once loaded; a folder it
        loaded in a bad state (e.g. while this Blender's server was down) keeps answering
        "Agent not found", even after a fix or after being deleted. A fresh folder always
        loads, so move this config version to a new one and retry.
        Returns (cmd, cwd) to retry with, or None to give up."""
        if "Agent not found" not in (error or "") or attempt >= 3:
            return None
        try:
            with open(os.path.join(cwd, "opencode.json"), encoding="utf-8") as fh:
                body = fh.read()
        except OSError:
            return None
        work = os.path.dirname(cwd)
        digest = os.path.basename(cwd).split("-")[0]
        folder = cls._write(work, "{}-{}".format(digest, uuid.uuid4().hex[:6]), body,
                            os.path.join(work, digest + ".folder"))
        cls.warm_up(cmd[0], folder, cls._env_for)
        return cmd, folder

    _windows = {}  # "provider/model" -> context window, from `opencode api model.list`

    @staticmethod
    def _json_out(exe, args, env_for, timeout=60):
        folder = os.path.expanduser("~")
        try:
            out = subprocess.run([exe] + args, capture_output=True, timeout=timeout, cwd=folder,
                                 env=env_for(folder) if env_for else None, creationflags=_flags())
        except (OSError, subprocess.SubprocessError):
            return None
        text = out.stdout.decode("utf-8", "replace")
        start = min([i for i in (text.find("{"), text.find("[")) if i >= 0] or [-1])
        if start < 0:
            return None
        try:
            return json.loads(text[start:])
        except ValueError:
            return None

    @classmethod
    def window(cls, exe, model, env_for=None):
        if model not in cls._windows:
            data = cls._json_out(exe, ["api", "model.list"], env_for) or {}
            items = data.get("data") if isinstance(data, dict) else data
            for m in items if isinstance(items, list) else []:
                if isinstance(m, dict) and m.get("providerID") and m.get("id"):
                    limit = (m.get("limit") or {}).get("context") or 0
                    cls._windows["{}/{}".format(m["providerID"], m["id"])] = int(limit)
            cls._windows.setdefault(model, 0)
        return cls._windows.get(model, 0)

    @classmethod
    def context_after(cls, exe, session, model, env_for=None):
        data = cls._json_out(exe, ["session", "export", session], env_for)
        if not isinstance(data, dict):
            return None
        tokens = 0
        for m in data.get("messages") or []:
            t = (m.get("info") or m).get("tokens") if isinstance(m, dict) else None
            if t and (t.get("input") or (t.get("cache") or {}).get("read")):
                cache = t.get("cache") or {}
                tokens = int(t.get("input") or 0) + int(cache.get("read") or 0) + int(cache.get("write") or 0)
        if not tokens:
            return None
        return tokens, cls.window(exe, model, env_for) if model else 0

    @staticmethod
    def parse(msg, st):
        kind = msg.get("type")
        part = msg.get("part") or {}
        out = []
        if msg.get("sessionID") and not st.get("_session"):
            st["_session"] = msg["sessionID"]
            out.append(("session", msg["sessionID"]))
            if st.get("_model"):
                out.append(("model", st["_model"]))
        if kind == "text" and part.get("text", "").strip():
            out.append(("text", part["text"]))
        elif kind == "tool_use":
            state = part.get("state") or {}
            name = part.get("tool", "tool")
            name = name[len(SERVER) + 1:] if name.startswith(SERVER + "_") else name
            cid = part.get("id") or part.get("partID")
            out.append(("tool", cid, name, state.get("input")))
            meta = state.get("metadata") or {}
            text, images = _parts(meta.get("content"))
            if not text:
                text = str(state.get("output") or state.get("error") or "")
            out.append(("result", cid, name, state.get("status") == "completed", text, images))
        elif kind == "error":
            err = msg.get("error") or {}
            out.append(("done", "Error: " + str(err.get("message") if isinstance(err, dict) else err)))
        return out


RUNNERS = {r.key: r for r in (Claude, Codex, OpenCode)}


def get(key):
    return RUNNERS.get(key) or Claude
