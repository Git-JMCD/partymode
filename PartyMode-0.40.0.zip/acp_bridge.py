# SPDX-License-Identifier: GPL-3.0-or-later
"""
One chat turn with an ACP agent (Agent Client Protocol: Grok Build, GitHub Copilot, Gemini CLI,
OpenCode and the rest), run as its own process so the chat drives it like any other agent:

    python -I acp_bridge.py <config.json>     (the message comes on stdin)

It starts the agent, opens (or reloads) a session with this Blender's MCP server in it, sends
the message, and prints one JSON event per line as the turn goes (runners.ACP.parse reads them):

    {"t": "caps", "load": bool}        what the agent can do (resume a session or not)
    {"t": "session", "id": ...}        the session, to resume next turn
    {"t": "model", "id": ...}, {"t": "models", "list": [[id, name], ...]}
    {"t": "delta", "text": ...}        reply text as it streams
    {"t": "text", "text": ...}         a finished piece of the reply
    {"t": "tool", "id", "name", "input"}  /  {"t": "result", "id", "name", "ok", "text", "images"}
    {"t": "done", "error": null or a message}

Permission requests are answered here, with the same limits as the other agents: this
Blender's tools are allowed, and so is reading; the agent's own shell, file edits, deletes and
moves are refused, and the web only goes with a research message. Nothing here touches bpy.
"""

import base64
import json
import os
import signal
import subprocess
import sys
import threading

PROTOCOL = 1


def emit(**ev):
    sys.stdout.write(json.dumps(ev) + "\n")
    sys.stdout.flush()


class Agent:
    """JSON-RPC over the agent's stdin and stdout (one JSON message per line)."""

    def __init__(self, cmd, cwd, env, on_note, on_request):
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        self.proc = subprocess.Popen(cmd, cwd=cwd, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, creationflags=flags,
                                     start_new_session=os.name != "nt")
        self.on_note, self.on_request = on_note, on_request
        self.lock = threading.Lock()
        self.waiting = {}  # request id -> [event, reply]
        self.next_id = 0
        self.err = []
        threading.Thread(target=self._read, daemon=True).start()
        threading.Thread(target=lambda: self.err.extend(
            self.proc.stderr.read().decode("utf-8", "replace").splitlines()[-30:]), daemon=True).start()

    def _write(self, msg):
        data = (json.dumps(msg) + "\n").encode("utf-8")
        with self.lock:
            self.proc.stdin.write(data)
            self.proc.stdin.flush()

    def _read(self):
        for raw in self.proc.stdout:
            try:
                msg = json.loads(raw)
            except ValueError:
                continue
            if not isinstance(msg, dict):
                continue
            if "method" in msg and "id" in msg:  # the agent asks us something
                try:
                    result = self.on_request(msg["method"], msg.get("params") or {})
                    self._write({"jsonrpc": "2.0", "id": msg["id"], "result": result})
                except LookupError:
                    self._write({"jsonrpc": "2.0", "id": msg["id"],
                                 "error": {"code": -32601, "message": "Not offered by PartyMode"}})
            elif "method" in msg:
                self.on_note(msg["method"], msg.get("params") or {})
            elif "id" in msg:
                slot = self.waiting.get(msg["id"])
                if slot:
                    slot[1] = msg
                    slot[0].set()
        for slot in list(self.waiting.values()):  # the agent ended: nothing more will come
            slot[0].set()

    def call(self, method, params, timeout=None):
        with self.lock:
            rid = self.next_id
            self.next_id += 1
        slot = self.waiting[rid] = [threading.Event(), None]
        self._write({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})
        slot[0].wait(timeout)
        del self.waiting[rid]
        reply = slot[1]
        if reply is None:
            tail = " ".join(self.err[-3:]).strip()
            raise RuntimeError("The agent stopped answering" + (": " + tail[-300:] if tail else "."))
        if "error" in reply:
            err = reply["error"] or {}
            raise RuntimeError(err.get("message") or json.dumps(err))
        return reply.get("result")

    def notify(self, method, params):
        self._write({"jsonrpc": "2.0", "method": method, "params": params})

    def kill(self):
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/T", "/F", "/PID", str(self.proc.pid)], capture_output=True,
                               creationflags=subprocess.CREATE_NO_WINDOW, timeout=15)
            else:
                os.killpg(self.proc.pid, signal.SIGTERM)
        except (OSError, subprocess.SubprocessError):
            try:
                self.proc.kill()
            except OSError:
                pass


def tool_name(title, raw_input, known):
    """This Blender's tool behind an ACP tool call, from its title ("partymode_run_python",
    "run_python (partymode MCP Server)"...): the longest known name in it, or ""."""
    for text in ((title or "").lower(), json.dumps(raw_input).lower() if raw_input else ""):
        for name in sorted(known, key=len, reverse=True):
            if name in text:  # also inside the input, for agents that wrap MCP calls in code
                return name
    return ""


def allowed(call, known, research):
    """Whether a permission request may go ahead (see the module docstring). Judged by the call's
    title only: a shell command that merely mentions a tool's name stays refused."""
    if tool_name(call.get("title"), None, known):
        return True
    kind = call.get("kind") or "other"
    if kind in ("read", "search", "think"):
        return True
    return kind == "fetch" and research


def main():
    with open(sys.argv[1], encoding="utf-8") as fh:
        cfg = json.load(fh)
    message = sys.stdin.read()
    known = cfg.get("tool_names") or []
    research = bool(cfg.get("research"))
    state = {"text": [], "loading": False, "calls": {}}

    def flush():
        if state["text"]:
            text = "".join(state["text"])
            state["text"] = []
            if text.strip():
                emit(t="text", text=text)

    def on_note(method, params):
        if method != "session/update" or state["loading"]:  # a reloaded session replays its history
            return
        up = params.get("update") or {}
        kind = up.get("sessionUpdate")
        if kind == "agent_message_chunk":
            c = up.get("content") or {}
            if c.get("type") == "text" and c.get("text"):
                state["text"].append(c["text"])
                emit(t="delta", text=c["text"])
        elif kind == "tool_call":
            flush()
            cid = up.get("toolCallId") or ""
            name = tool_name(up.get("title"), up.get("rawInput"), known) or (up.get("title") or "tool")
            state["calls"][cid] = name
            emit(t="tool", id=cid, name=name, input=up.get("rawInput") if isinstance(up.get("rawInput"), dict) else {})
            if up.get("status") in ("completed", "failed"):
                result(cid, up)
        elif kind == "tool_call_update" and up.get("status") in ("completed", "failed"):
            result(up.get("toolCallId") or "", up)

    def result(cid, up):
        texts, images = [], []
        for item in up.get("content") or []:
            c = item.get("content") if item.get("type") == "content" else item
            if not isinstance(c, dict):
                continue
            if c.get("type") == "text":
                texts.append(c.get("text", ""))
            elif c.get("type") == "image" and c.get("data"):
                images.append(c["data"])
        if not texts and up.get("rawOutput") is not None:
            raw = up["rawOutput"]
            texts.append(raw if isinstance(raw, str) else json.dumps(raw))
        emit(t="result", id=cid, name=state["calls"].get(cid, "tool"), ok=up.get("status") == "completed",
             text="\n".join(texts), images=images)

    def on_request(method, params):
        if method == "session/request_permission":
            call = params.get("toolCall") or {}
            options = params.get("options") or []
            want = ("allow_once", "allow_always") if allowed(call, known, research) else ("reject_once", "reject_always")
            pick = next((o for kind in want for o in options if o.get("kind") == kind), None)
            if pick is None:
                return {"outcome": {"outcome": "cancelled"}}
            return {"outcome": {"outcome": "selected", "optionId": pick.get("optionId")}}
        raise LookupError(method)  # files and terminals are not offered: the agent works through Blender

    try:
        agent = Agent(cfg["command"], cfg["cwd"], dict(os.environ), on_note, on_request)
    except OSError as ex:
        emit(t="done", error="Could not run the agent ({}): {}".format(cfg["command"][0], ex))
        return

    def stop(*_args):
        agent.kill()
        os._exit(1)
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, stop)
        except (OSError, ValueError):
            pass

    error = None
    try:
        init = agent.call("initialize", {"protocolVersion": PROTOCOL,
                                         "clientCapabilities": {"fs": {"readTextFile": False, "writeTextFile": False},
                                                                "terminal": False},
                                         "clientInfo": {"name": "partymode", "version": cfg.get("version", "")}},
                          timeout=90) or {}
        caps = init.get("agentCapabilities") or {}
        can_load = bool(caps.get("loadSession"))
        http = bool((caps.get("mcpCapabilities") or {}).get("http"))
        emit(t="caps", load=can_load, http=http, images=bool((caps.get("promptCapabilities") or {}).get("image")))
        if http:
            server = {"type": "http", "name": cfg["server"], "url": cfg["mcp_url"], "headers": []}
        else:  # stdio only: a small proxy to this Blender's HTTP server
            server = {"name": cfg["server"], "command": cfg["python"],
                      "args": ["-I", cfg["proxy"], cfg["mcp_url"]], "env": []}
        session, fresh = cfg.get("resume"), False
        if session and can_load:
            state["loading"] = True
            try:
                agent.call("session/load", {"sessionId": session, "cwd": cfg["cwd"], "mcpServers": [server]},
                           timeout=120)
            except RuntimeError:
                session = None  # gone: start again, with the whole brief
            state["loading"] = False
        else:
            session = None
        model_option = None  # the agent's model setting, when it has one (session config options)
        if not session:
            got = agent.call("session/new", {"cwd": cfg["cwd"], "mcpServers": [server]}, timeout=120) or {}
            session, fresh = got.get("sessionId"), True
            listed, current = [], None
            # Newer agents list models as a config option; older ones as "models".
            for opt in got.get("configOptions") or []:
                if opt.get("category") == "model" or opt.get("id") == "model":
                    model_option = opt.get("id")
                    listed = [[o.get("value"), o.get("name") or o.get("value")]
                              for o in opt.get("options") or [] if o.get("value")]
                    current = opt.get("currentValue")
                    break
            if not listed:
                models = got.get("models") or {}
                listed = [[m.get("modelId"), m.get("name") or m.get("modelId")]
                          for m in models.get("availableModels") or [] if m.get("modelId")]
                current = models.get("currentModelId")
            if listed:
                emit(t="models", list=listed)
            if current:
                emit(t="model", id=current)
        emit(t="session", id=session)
        if cfg.get("check"):  # the Agents tab's Test: it starts, connects to Blender, lists its models
            info = init.get("agentInfo") or {}
            emit(t="check", agent="{} {}".format(info.get("name", ""), info.get("version", "")).strip(),
                 load=can_load, http=http)
            emit(t="done", error=None)
            agent.kill()
            return
        if cfg.get("model"):
            try:
                if model_option or not fresh:
                    agent.call("session/set_config_option", {"sessionId": session, "configId": model_option or "model",
                                                             "value": cfg["model"]}, timeout=30)
                else:
                    agent.call("session/set_model", {"sessionId": session, "modelId": cfg["model"]}, timeout=30)
                emit(t="model", id=cfg["model"])
            except RuntimeError:
                try:  # the other way round
                    agent.call("session/set_model", {"sessionId": session, "modelId": cfg["model"]}, timeout=30)
                    emit(t="model", id=cfg["model"])
                except RuntimeError:
                    pass  # this agent picks its model its own way
        text = (cfg.get("system", "") + "\n\n---\n\n" + message) if fresh and cfg.get("system") else message
        reply = agent.call("session/prompt", {"sessionId": session, "prompt": [{"type": "text", "text": text}]}) or {}
        flush()
        if reply.get("stopReason") in ("refusal",):
            error = "The agent refused this message."
    except RuntimeError as ex:
        flush()
        error = str(ex)
    except (OSError, ValueError, KeyError) as ex:
        error = "Could not run the agent: {}".format(ex)
    emit(t="done", error=error)
    agent.kill()


if __name__ == "__main__":
    main()
