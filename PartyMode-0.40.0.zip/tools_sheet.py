# SPDX-License-Identifier: GPL-3.0-or-later
"""
Contact sheets in one call: a turntable (views all round a prop at one framing) or a character
across clips (a few frames of each, at one size), assembled into one labelled picture, shown and
pinned to the Sandbox. For reviews, catalogues and thumbnails.
"""

import math
import os
import tempfile

import bpy
import numpy as np
from mathutils import Vector

from . import sandbox
from .registry import ToolError, get_object, r, tool
from .tools_inspect import _png
from .tools_render import _targets, _union_bounds, render_view

_MAX_CELLS = 36
_PAD = 6
_LABEL_H = 26
_BG = np.array([22, 23, 26], dtype=np.uint8)


def _decode(png):
    """PNG bytes -> RGB array, top row first."""
    import imbuf
    fd, path = tempfile.mkstemp(suffix=".png", prefix="agent_cell_")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(png)
        ib = imbuf.load(path)
        try:
            with ib.with_buffer() as buf:
                a = np.asarray(buf).copy()
        finally:
            ib.free()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if a.dtype != np.uint8:
        a = (np.clip(a, 0, 1) * 255).astype(np.uint8)
    return np.flipud(a[..., :3])


def _label(text, w, h=_LABEL_H, size=15):
    """The text as a mask (h x w, 0-1), drawn with Blender's own font."""
    import blf
    import imbuf
    ib = imbuf.new((w, h))
    try:
        with blf.bind_imbuf(0, ib, display_name="sRGB"):
            blf.size(0, size)
            blf.color(0, 1, 1, 1, 1)
            tw = blf.dimensions(0, text)[0]
            while tw > w - 12 and len(text) > 4:  # too long: shorten it
                text = text[:-2].rstrip() + "…"
                text = text.replace("……", "…")
                tw = blf.dimensions(0, text)[0]
            blf.position(0, 8, (h - size * 0.7) / 2, 0)
            blf.draw_buffer(0, text)
        with ib.with_buffer() as buf:
            a = np.asarray(buf).copy()
    finally:
        ib.free()
    return np.flipud(a[..., 3].astype(np.float32) / 255.0)


def _sheet(cells, cols, cw, ch, title):
    """Cells [(rgb, label)] on a grid with a title row; returns PNG bytes and the size."""
    rows = math.ceil(len(cells) / cols)
    W = cols * cw + (cols + 1) * _PAD
    H = _LABEL_H + 6 + rows * (ch + _LABEL_H) + (rows + 1) * _PAD
    img = np.empty((H, W, 3), dtype=np.uint8)
    img[:] = _BG
    tmask = _label(title, W, _LABEL_H + 6, 17)
    img[:tmask.shape[0]] = (img[:tmask.shape[0]] * (1 - tmask[..., None]) + 235 * tmask[..., None]).astype(np.uint8)
    for i, (rgb, lab) in enumerate(cells):
        rr, cc = divmod(i, cols)
        x = _PAD + cc * (cw + _PAD)
        y = _LABEL_H + 6 + _PAD + rr * (ch + _LABEL_H + _PAD)
        h, w = min(ch, rgb.shape[0]), min(cw, rgb.shape[1])
        img[y:y + h, x:x + w] = rgb[:h, :w]
        if lab:
            m = _label(lab, cw)
            band = img[y + ch:y + ch + _LABEL_H, x:x + cw]
            img[y + ch:y + ch + _LABEL_H, x:x + cw] = (band * (1 - m[..., None]) + 200 * m[..., None]).astype(np.uint8)
    return _png(img), (W, H)


def _small(png_bytes, max_w=1600):
    """A copy no wider than max_w for the chat (the Sandbox keeps the full one)."""
    rgb = _decode(png_bytes)
    f = int(math.ceil(rgb.shape[1] / max_w))
    if f <= 1:
        return png_bytes
    return _png(rgb[::f, ::f])


@tool("contact_sheet",
      "One picture of many views, labelled, shown and pinned to the Sandbox. mode turntable: views all "
      "round objects (views, default 8) at one framing and an elevation (degrees). mode clips: an "
      "armature across actions (default: the actions made for it, up to 8), frames_per_clip frames "
      "of each evenly through the clip, at one size; each row is one clip. look solid (fast shape "
      "check) or lit. For reviews, asset catalogues and thumbnails.",
      {"mode": {"type": "string", "enum": ["turntable", "clips"], "default": "turntable"},
       "objects": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 32,
                   "description": "What to show (turntable); for clips, the armature first."},
       "views": {"type": "integer", "minimum": 2, "maximum": 24, "default": 8},
       "elevation_deg": {"type": "number", "minimum": -30, "maximum": 80, "default": 20},
       "actions": {"type": "array", "items": {"type": "string"}, "maxItems": 12},
       "frames_per_clip": {"type": "integer", "minimum": 1, "maximum": 8, "default": 4},
       "look": {"type": "string", "enum": ["solid", "lit"], "default": "solid"},
       "cell": {"type": "integer", "minimum": 128, "maximum": 768, "default": 320},
       "title": {"type": "string"}},
      required=("objects",), mutating=True)  # it pins to the Sandbox: one undo step
def contact_sheet(args):
    mode = args.get("mode", "turntable")
    look = args.get("look", "solid")
    cell = int(args.get("cell", 320))
    scene = bpy.context.scene
    names = list(args["objects"])
    if mode == "clips":
        return _clips(names, args, look, cell, scene)
    n = int(args.get("views", 8))
    elev = math.radians(float(args.get("elevation_deg", 20)))
    dg = bpy.context.evaluated_depsgraph_get()
    targets = _targets(scene, names)
    bounds = _union_bounds(targets, dg)
    if bounds is None:
        raise ToolError("Nothing with an extent to show.")
    center = (bounds[0] + bounds[1]) / 2
    radius = max((bounds[1] - bounds[0]).length / 2, 0.01)
    cells = []
    for k in range(n):
        a = 2 * math.pi * k / n
        d = Vector((math.sin(a) * math.cos(elev), -math.cos(a) * math.cos(elev), math.sin(elev)))
        res = render_view({"view": "hero", "focus_objects": names, "focus_point": list(center), "focus_radius": radius,
                           "look": look, "width": cell, "height": cell, "_direction": d})
        cells.append((_decode(res["images"][0]), "{:.0f}°".format(math.degrees(a))))
    title = args.get("title") or "Turntable: {}".format(", ".join(names[:3]))
    cols = n if n <= 8 else math.ceil(math.sqrt(n * 1.5))
    png, size = _sheet(cells, cols, cell, cell, title)
    it = sandbox.add_png(png, title, "agent", kind="render")
    return {"data": {"mode": "turntable", "views": n, "elevation_deg": r(math.degrees(elev), 1), "size": list(size),
                     "sandbox_item": it["id"], "framed_radius_m": r(radius)}, "images": [_small(png)]}


def _clip_actions(arm, wanted):
    if wanted:
        missing = [a for a in wanted if a not in bpy.data.actions]
        if missing:
            raise ToolError("No action {}.".format(", ".join(map(repr, missing))))
        return [bpy.data.actions[a] for a in wanted]
    bone_names = {b.name for b in arm.data.bones}
    own = []
    for act in bpy.data.actions:
        paths = []
        try:
            for layer in act.layers:
                for strip in layer.strips:
                    for bag in strip.channelbags:
                        paths += [fc.data_path for fc in bag.fcurves]
        except AttributeError:
            paths = [fc.data_path for fc in getattr(act, "fcurves", [])]
        if any(p.startswith('pose.bones["') and p.split('"')[1] in bone_names for p in paths):
            own.append(act)
    return own[:8]


def _clips(names, args, look, cell, scene):
    arm = get_object(names[0])
    if arm.type != 'ARMATURE':
        raise ToolError("For clips, give the armature first ({} is a {}).".format(arm.name, arm.type.lower()))
    acts = _clip_actions(arm, args.get("actions"))
    if not acts:
        raise ToolError("No actions found for {}: pass actions=[...].".format(arm.name))
    per = int(args.get("frames_per_clip", 4))
    if len(acts) * per > _MAX_CELLS:
        raise ToolError("That is {} pictures; keep it to {} (fewer clips or frames).".format(len(acts) * per, _MAX_CELLS))
    ad = arm.animation_data or arm.animation_data_create()
    keep_action, keep_slot = ad.action, getattr(ad, "action_slot", None)
    keep_frame = scene.frame_current
    dg = bpy.context.evaluated_depsgraph_get()
    plan = []
    try:
        # Pass 1: where the character is in each picture, and the largest size, so every cell is the same scale.
        biggest = 0.01
        for act in acts:
            ad.action = act
            if getattr(act, "slots", None):
                ad.action_slot = act.slots[0]
            a, b = act.frame_range
            frames = [int(round(a + (b - a) * i / max(1, per - 1))) for i in range(per)] if per > 1 else [int(round(a))]
            for f in frames:
                scene.frame_set(f)
                dg = bpy.context.evaluated_depsgraph_get()
                bounds = _union_bounds(_targets(scene, names), dg)
                if bounds is None:
                    continue
                biggest = max(biggest, (bounds[1] - bounds[0]).length / 2)
                plan.append((act, f, (bounds[0] + bounds[1]) / 2))
        cells = []
        for act, f, center in plan:
            ad.action = act
            if getattr(act, "slots", None):
                ad.action_slot = act.slots[0]
            scene.frame_set(f)
            res = render_view({"view": "hero", "focus_objects": names, "focus_point": list(center),
                               "focus_radius": biggest, "look": look, "width": cell, "height": cell})
            cells.append((_decode(res["images"][0]), "{}  f{}".format(act.name, f)))
    finally:
        ad.action = keep_action
        if keep_slot is not None:
            try:
                ad.action_slot = keep_slot
            except (TypeError, RuntimeError):
                pass
        scene.frame_set(keep_frame)
    title = args.get("title") or "Clips: {}".format(arm.name)
    png, size = _sheet(cells, per, cell, cell, title)
    it = sandbox.add_png(png, title, "agent", kind="render")
    return {"data": {"mode": "clips", "clips": [a.name for a in acts], "frames_per_clip": per, "size": list(size),
                     "sandbox_item": it["id"]}, "images": [_small(png)]}
