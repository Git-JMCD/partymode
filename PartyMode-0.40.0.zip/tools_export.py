# SPDX-License-Identifier: GPL-3.0-or-later
"""
Export for a game engine or the web, then prove it worked: the file is imported
back into a temporary collection and compared with the original (size, faces,
materials, UVs, animation), and everything temporary is removed again.
"""

import os
import re

import bpy

from .registry import ToolError, get_object, r, tool, ui_override, vec, world_bounds

_TARGETS = {
    "unreal": {"format": "fbx", "prefix": "SM_"},
    "unity": {"format": "fbx", "prefix": ""},
    "godot": {"format": "glb", "prefix": ""},
    "web": {"format": "glb", "prefix": ""},
    "generic": {"format": "glb", "prefix": ""},
}
_ID_KINDS = ("objects", "meshes", "materials", "images", "actions", "armatures", "cameras", "lights", "collections")


def _gather(names):
    obs = []
    for n in names:
        ob = get_object(n)
        obs.append(ob)
        obs.extend(ob.children_recursive)
    return list(dict.fromkeys(obs))


def _measure(obs):
    dg = bpy.context.evaluated_depsgraph_get()
    meshes = [ob for ob in obs if ob.type == 'MESH']
    lo = hi = None
    tris = 0
    for ob in meshes:
        b = world_bounds(ob, dg)
        if b:
            lo = b[0].copy() if lo is None else type(lo)(map(min, lo, b[0]))
            hi = b[1].copy() if hi is None else type(hi)(map(max, hi, b[1]))
        me = ob.evaluated_get(dg).data
        tris += sum(len(p.vertices) - 2 for p in me.polygons)
    mats = sorted({s.material.name.split(".")[0] for ob in meshes for s in ob.material_slots if s.material})
    return {
        "meshes": len(meshes),
        "tris": tris,
        "size_m": vec(hi - lo, 4) if lo is not None else None,
        "materials": mats,
        "uv_meshes": sum(1 for ob in meshes if ob.data.uv_layers),
        "armatures": sum(1 for ob in obs if ob.type == 'ARMATURE'),
        "animated": sum(1 for ob in obs if ob.animation_data and ob.animation_data.action),
    }


def _preflight(obs, target):
    warnings = []
    meshes = [ob for ob in obs if ob.type == 'MESH']
    if not meshes:
        raise ToolError("Nothing to export: no meshes among those objects.")
    for ob in meshes:
        det = ob.matrix_world.to_3x3().determinant()
        if det < 0:
            warnings.append("{}: negative scale (mirrored); normals may flip in the engine".format(ob.name))
        elif any(abs(s - 1) > 1e-4 for s in ob.scale):
            warnings.append("{}: unapplied scale {} (engines and collision prefer applied scale)".format(ob.name, vec(ob.scale, 3)))
        if not ob.data.uv_layers:
            warnings.append("{}: no UV map (textures and lightmaps will not work)".format(ob.name))
        if not any(s.material for s in ob.material_slots):
            warnings.append("{}: no material".format(ob.name))
        if target == "unreal" and re.search(r"[^A-Za-z0-9_]", ob.name):
            warnings.append("{}: name has spaces or symbols; Unreal renames these".format(ob.name))
    for img in {n.image for ob in meshes for s in ob.material_slots if s.material and s.material.node_tree
                for n in s.material.node_tree.nodes if n.type == 'TEX_IMAGE' and n.image}:
        if not img.packed_file and img.source == 'FILE' and not os.path.isfile(bpy.path.abspath(img.filepath)):
            warnings.append("texture {!r} is missing on disk ({})".format(img.name, img.filepath))
    dg = bpy.context.evaluated_depsgraph_get()
    roots = [ob for ob in obs if ob.parent is None or ob.parent not in obs]
    for ob in roots:
        b = world_bounds(ob, dg) if ob.type == 'MESH' else None
        if b and abs(ob.matrix_world.translation.z - b[0].z) > 0.01 * max(1e-6, (b[1] - b[0]).length):
            warnings.append("{}: pivot is not at the base (it is {:.3f} m above the bottom); props usually "
                            "want it there".format(ob.name, ob.matrix_world.translation.z - b[0].z))
    if target == "unreal":
        for ob in roots:
            if ob.type == 'MESH' and not ob.name.startswith(("SM_", "SK_")):
                warnings.append("{}: Unreal convention is SM_<Name> for static meshes".format(ob.name))
                break
    return warnings


def _export(obs, path, fmt, target):
    has_anim = any(ob.animation_data and ob.animation_data.action for ob in obs) or any(ob.type == 'ARMATURE' for ob in obs)
    with bpy.context.temp_override(**ui_override(), selected_objects=obs, selected_editable_objects=obs,
                                   active_object=obs[0], object=obs[0]):
        for ob in bpy.context.view_layer.objects:
            ob.select_set(ob in obs)
        if fmt == "fbx":
            bpy.ops.export_scene.fbx(
                filepath=path, use_selection=True, apply_unit_scale=True,
                apply_scale_options='FBX_SCALE_UNITS', mesh_smooth_type='FACE', use_tspace=True,
                add_leaf_bones=False, bake_anim=has_anim, path_mode='COPY', embed_textures=True,
                use_mesh_modifiers=True, bake_space_transform=(target == "unity"))
        else:
            bpy.ops.export_scene.gltf(filepath=path, export_format='GLB', use_selection=True,
                                      export_apply=True, export_yup=True, export_animations=has_anim)


# ---------------------------------------------------------------------------
# Extras: levels of detail, collision, what a material loses, axes.

# Nodes a format cannot carry: procedural textures and effects come through as nothing (bake them).
_LOST_NODES = {
    "ShaderNodeTexNoise": "Noise", "ShaderNodeTexVoronoi": "Voronoi", "ShaderNodeTexWave": "Wave",
    "ShaderNodeTexMagic": "Magic", "ShaderNodeTexGradient": "Gradient", "ShaderNodeTexBrick": "Brick",
    "ShaderNodeTexChecker": "Checker", "ShaderNodeTexWhiteNoise": "White Noise", "ShaderNodeTexGabor": "Gabor",
    "ShaderNodeTexMusgrave": "Musgrave", "ShaderNodeValToRGB": "Color Ramp", "ShaderNodeBump": "Bump",
    "ShaderNodeAmbientOcclusion": "Ambient Occlusion", "ShaderNodeLayerWeight": "Layer Weight",
    "ShaderNodeFresnel": "Fresnel", "ShaderNodeGroup": "node group", "ShaderNodeAttribute": "Attribute",
    "ShaderNodeTexSky": "Sky", "ShaderNodeWireframe": "Wireframe",
}
_HELPER = re.compile(r"((_LOD[1-9]\d*|-colonly|-convcolonly|_collision)(\.\d{3})?$|^UCX_|^UBX_)")  # .001: imported beside the temp ones
_AXES = {
    "unreal": "FBX: Blender's -Y forward and Z up become Unreal's +X forward and Z up; 1 Blender unit = 1 m = 100 Unreal units.",
    "unity": "FBX with the axes baked in: Blender's -Y forward and Z up become Unity's +Z forward and Y up; 1 unit = 1 m.",
    "godot": "glTF: Y up, -Z forward (Blender's -Y), 1 unit = 1 m.",
    "web": "glTF: Y up, -Z forward (Blender's -Y), 1 unit = 1 m (three.js and Babylon read it as is).",
    "generic": "glTF: Y up, -Z forward (Blender's -Y), 1 unit = 1 m.",
}


def _material_notes(obs, fmt):
    """Per material, the nodes the file will not carry."""
    notes = []
    seen = set()
    for ob in obs:
        if ob.type != 'MESH':
            continue
        for slot in ob.material_slots:
            mat = slot.material
            if not mat or mat.name in seen or not (mat.use_nodes and mat.node_tree):
                continue
            seen.add(mat.name)
            lost = sorted({_LOST_NODES[n.bl_idname] for n in mat.node_tree.nodes if n.bl_idname in _LOST_NODES})
            if lost:
                what = "FBX takes base colour, metallic, roughness, normal and alpha (values or images)" \
                    if fmt == "fbx" else "glTF takes the Principled BSDF's values and image textures"
                notes.append({"material": mat.name, "lost": lost,
                              "note": "{}; {} come through as nothing. Bake them to textures first.".format(
                                  what, ", ".join(lost))})
    return notes


def _static_meshes(obs):
    return [ob for ob in obs if ob.type == 'MESH' and not (ob.data.shape_keys)
            and not any(m.type == 'ARMATURE' for m in ob.modifiers) and not (ob.parent and ob.parent.type == 'ARMATURE')]


def _bvh(ob, dg):
    from mathutils.bvhtree import BVHTree
    ev = ob.evaluated_get(dg)
    me = ev.to_mesh()
    try:
        mw = ob.matrix_world
        verts = [mw @ v.co for v in me.vertices]
        polys = [tuple(p.vertices) for p in me.polygons]
        return BVHTree.FromPolygons(verts, polys), verts
    finally:
        ev.to_mesh_clear()


def _deviation(a_tree, a_verts, b_tree, b_verts, cap=20000):
    """(max, mean) distance in metres between two surfaces, both ways, sampled at their vertices."""
    import random
    rng = random.Random(1)
    dists = []
    for tree, verts in ((b_tree, a_verts), (a_tree, b_verts)):
        sample = verts if len(verts) <= cap else rng.sample(verts, cap)
        for v in sample:
            hit = tree.find_nearest(v)
            if hit[0] is not None:
                dists.append(hit[3])
    if not dists:
        return 0.0, 0.0
    return max(dists), sum(dists) / len(dists)


def _make_lods(obs, ratios, target, screen_px, fov_deg):
    """Decimated copies of each static mesh; returns (temp objects by level, report)."""
    import math
    dg = bpy.context.evaluated_depsgraph_get()
    levels, report = {}, []
    k = screen_px / (2 * math.tan(math.radians(fov_deg) / 2))  # pixels per metre of error at 1 m
    for ob in _static_meshes(obs):
        src_tree, src_verts = _bvh(ob, dg)
        base_tris = sum(len(p.vertices) - 2 for p in ob.evaluated_get(dg).data.polygons)
        entry = {"object": ob.name, "tris": base_tris, "levels": []}
        for n, ratio in enumerate(ratios, 1):
            me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
            copy = bpy.data.objects.new("{}_LOD{}".format(ob.name, n), me)
            copy.matrix_world = ob.matrix_world.copy()
            bpy.context.scene.collection.objects.link(copy)
            mod = copy.modifiers.new("lod", 'DECIMATE')
            mod.ratio = ratio
            mod.use_collapse_triangulate = True
            dg.update()
            lod_me = bpy.data.meshes.new_from_object(copy.evaluated_get(bpy.context.evaluated_depsgraph_get()))
            copy.modifiers.remove(mod)
            old = copy.data
            copy.data = lod_me
            bpy.data.meshes.remove(old)
            if ob.parent is not None and target == "unity":
                copy.parent = ob.parent
                copy.matrix_world = ob.matrix_world.copy()
            dg = bpy.context.evaluated_depsgraph_get()
            tree, verts = _bvh(copy, dg)
            err, mean = _deviation(src_tree, src_verts, tree, verts)
            tris = sum(len(p.vertices) - 2 for p in lod_me.polygons)
            entry["levels"].append({
                "name": copy.name, "ratio": ratio, "tris": tris, "max_error_mm": r(err * 1000, 2),
                "mean_error_mm": r(mean * 1000, 3),
                # Where the worst error is under a pixel on a screen this tall: swap to this level from there.
                "switch_at_m": r(err * k, 2),
                "px_at": {"{} m".format(d): r(err * k / d, 2) for d in (5, 10, 25, 50)}})
            levels.setdefault(n, []).append(copy)
        report.append(entry)
    return levels, report


_HULL_MAX = 48  # points in a convex collision hull (Unreal and Godot want them simple)


def _spread(points, n):
    """n of the points, each as far as it can be from the ones already kept (the extremes first)."""
    keep = [max(points, key=lambda p: p.length)]
    best = [(p - keep[0]).length for p in points]
    while len(keep) < n:
        i = max(range(len(points)), key=best.__getitem__)
        if best[i] <= 1e-9:
            break
        keep.append(points[i])
        for j, p in enumerate(points):
            d = (p - points[i]).length
            if d < best[j]:
                best[j] = d
    return keep


def _make_collision(obs, kind, target):
    """A box or convex hull per root mesh, named for the engine; returns (temp objects, report)."""
    import bmesh
    dg = bpy.context.evaluated_depsgraph_get()
    made, report = [], []
    roots = [ob for ob in _static_meshes(obs) if ob.parent is None or ob.parent not in obs]
    for ob in roots:
        ev = ob.evaluated_get(dg)
        me = ev.to_mesh()
        try:
            pts = [v.co.copy() for v in me.vertices]
        finally:
            ev.to_mesh_clear()
        if not pts:
            continue
        bm = bmesh.new()
        if kind == "box":
            lo = [min(p[i] for p in pts) for i in range(3)]
            hi = [max(p[i] for p in pts) for i in range(3)]
            for x in (lo[0], hi[0]):
                for y in (lo[1], hi[1]):
                    for z in (lo[2], hi[2]):
                        bm.verts.new((x, y, z))
            bmesh.ops.convex_hull(bm, input=list(bm.verts))
        else:
            for p in pts:
                bm.verts.new(p)
            out = bmesh.ops.convex_hull(bm, input=list(bm.verts))
            # Points inside the hull are left over: drop them.
            inner = [v for v in bm.verts if not v.link_faces]
            bmesh.ops.delete(bm, geom=inner, context='VERTS')
            if len(bm.verts) > _HULL_MAX:  # engines want simple hulls: keep well-spread points, hull again
                keep = _spread([v.co.copy() for v in bm.verts], _HULL_MAX)
                bm.clear()
                for p in keep:
                    bm.verts.new(p)
                bmesh.ops.convex_hull(bm, input=list(bm.verts))
                bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context='VERTS')
            del out
        if target == "unreal":
            name = "{}_{}_00".format("UBX" if kind == "box" else "UCX", ob.name)
        elif target == "godot":
            name = "{}-convcolonly".format(ob.name)
        else:
            name = "{}_collision".format(ob.name)
        cme = bpy.data.meshes.new(name)
        bm.to_mesh(cme)
        nverts = len(bm.verts)
        bm.free()
        col = bpy.data.objects.new(name, cme)
        col.matrix_world = ob.matrix_world.copy()
        bpy.context.scene.collection.objects.link(col)
        col.display_type = 'WIRE'
        made.append(col)
        report.append({"object": ob.name, "collision": name, "kind": kind, "verts": nverts,
                       "how": {"unreal": "Unreal picks it up by name on import (keep 'Generate Missing Collision' off).",
                               "godot": "Godot's importer makes a convex collision shape from it and drops the mesh.",
                               "unity": "Add a Mesh Collider (Convex) on import and give it this mesh.",
                               }.get(target, "A separate mesh for your engine's physics.")})
    return made, report


def _remove(temp):
    for ob in temp:
        me = ob.data
        bpy.data.objects.remove(ob)
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)


def _reimport(path, fmt):
    """Import ``path`` into a temporary collection; return (objects, cleanup)."""
    before = {k: set(getattr(bpy.data, k)) for k in _ID_KINDS}
    coll = bpy.data.collections.new("__agent_export_check")
    bpy.context.scene.collection.children.link(coll)
    layer_coll = bpy.context.view_layer.layer_collection.children[coll.name]
    with bpy.context.temp_override(**ui_override(), collection=coll):
        prev = bpy.context.view_layer.active_layer_collection
        bpy.context.view_layer.active_layer_collection = layer_coll
        try:
            if fmt == "fbx":
                bpy.ops.import_scene.fbx(filepath=path)
            else:
                bpy.ops.import_scene.gltf(filepath=path)
        finally:
            bpy.context.view_layer.active_layer_collection = prev
    new_obs = [ob for ob in bpy.data.objects if ob not in before["objects"]]

    def cleanup():
        for kind in _ID_KINDS:
            coll_data = getattr(bpy.data, kind)
            for block in [b for b in coll_data if b not in before[kind]]:
                try:
                    coll_data.remove(block)
                except Exception:
                    pass
    return new_obs, cleanup


@tool("export_asset",
      "Export objects (children included) for a target engine and verify the file: pre-flight "
      "checks (scale, UVs, materials, missing textures, pivot, naming, material nodes the format "
      "won't carry), export with that target's settings (unreal/unity: FBX with unit scaling, "
      "embedded textures; godot/web/generic: GLB), then import the file back into a temporary "
      "collection and compare size, triangles, materials, UVs and animation with the original. "
      "Optional: lods (ratios like [0.5, 0.25]: decimated levels of detail, each measured against "
      "the original in mm and as the distance where its error drops under a pixel; Unity gets them "
      "in the same file as _LOD0.., others as <file>_LOD1.. files) and collision (box or convex, "
      "named for the engine: UCX_/UBX_ for Unreal, -convcolonly for Godot). The scene is left unchanged.",
      {"objects": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 64},
       "target": {"type": "string", "enum": list(_TARGETS), "default": "unreal"},
       "format": {"type": "string", "enum": ["fbx", "glb"]},
       "folder": {"type": "string", "description": "Where to write (default: an 'exports' folder next to the .blend)."},
       "file_name": {"type": "string"},
       "lods": {"type": "array", "items": {"type": "number", "minimum": 0.02, "maximum": 0.95}, "maxItems": 4,
                "description": "Triangle ratios for levels of detail, e.g. [0.5, 0.25, 0.1]."},
       "collision": {"type": "string", "enum": ["box", "convex"]},
       "screen_px": {"type": "integer", "default": 1080, "description": "Screen height for the LOD pixel error."},
       "fov_deg": {"type": "number", "default": 60, "description": "Camera field of view for the LOD pixel error."}},
      required=("objects",), mutating=True, push_undo=False)
def export_asset(args):
    target = args.get("target", "unreal")
    fmt = args.get("format") or _TARGETS[target]["format"]
    obs = _gather(args["objects"])
    warnings = _preflight(obs, target)
    if args.get("folder"):
        folder = args["folder"]
    elif bpy.data.filepath:
        folder = os.path.join(os.path.dirname(bpy.data.filepath), "exports")
    else:
        folder = bpy.utils.user_resource('CONFIG', path=os.path.join("agent_bridge", "exports"), create=True)
    os.makedirs(folder, exist_ok=True)
    base = args.get("file_name") or (_TARGETS[target]["prefix"] + re.sub(r"[^A-Za-z0-9_]+", "_", obs[0].name).strip("_"))
    path = os.path.join(folder, base + "." + fmt)

    selection = [ob.name for ob in bpy.context.selected_objects]
    active = bpy.context.view_layer.objects.active
    source = _measure(obs)
    ratios = sorted({float(x) for x in args.get("lods") or ()}, reverse=True)
    temp, renamed, extra_files, lod_report, col_report = [], [], [], [], []
    try:
        if ratios:
            levels, lod_report = _make_lods(obs, ratios, target, int(args.get("screen_px") or 1080),
                                            float(args.get("fov_deg") or 60))
            temp += [ob for level in levels.values() for ob in level]
        if args.get("collision"):
            made, col_report = _make_collision(obs, args["collision"], target)
            temp += made
        if ratios and target == "unity":
            # Unity makes a LOD Group from _LOD0, _LOD1... in one file.
            for ob in _static_meshes(obs):
                renamed.append((ob, ob.name))
                ob.name = ob.name + "_LOD0"
            main = obs + temp
        else:
            main = obs + [ob for ob in temp if not re.search(r"_LOD[1-9]\d*$", ob.name)]
            for n, level in (levels.items() if ratios else ()):
                lod_path = os.path.join(folder, "{}_LOD{}.{}".format(base, n, fmt))
                _export(level, lod_path, fmt, target)
                extra_files.append(lod_path)
        _export(main, path, fmt, target)
        new_obs, cleanup = _reimport(path, fmt)
        try:
            back = _measure([ob for ob in new_obs if not _HELPER.search(ob.name)])
        finally:
            cleanup()
    finally:
        for ob, name in renamed:
            ob.name = name
        _remove(temp)
        for ob in bpy.context.view_layer.objects:
            ob.select_set(ob.name in selection)
        bpy.context.view_layer.objects.active = active

    problems = []
    if source["size_m"] and back["size_m"]:
        s_src, s_back = sorted(source["size_m"]), sorted(back["size_m"])
        ratio = max(b / a for a, b in zip(s_src, s_back) if a > 1e-6)
        if abs(ratio - 1) > 0.01:
            problems.append("size changed {:.3f}x on the way through ({} -> {} m)".format(ratio, source["size_m"], back["size_m"]))
    if back["tris"] != source["tris"]:
        problems.append("triangle count changed {} -> {}".format(source["tris"], back["tris"]))
    lost = sorted(set(source["materials"]) - set(back["materials"]))
    if lost:
        problems.append("materials lost: {}".format(lost))
    if back["uv_meshes"] < source["uv_meshes"]:
        problems.append("UV maps lost on {} mesh(es)".format(source["uv_meshes"] - back["uv_meshes"]))
    if source["animated"] and not back["animated"]:
        problems.append("animation did not come through")
    out = {"file": path, "format": fmt, "target": target, "bytes": os.path.getsize(path),
           "verified": not problems, "problems": problems, "warnings": warnings,
           "original": source, "reimported": back, "axes": _AXES.get(target, "")}
    notes = _material_notes(obs, fmt)
    if notes:
        out["material_notes"] = notes
    if lod_report:
        out["lods"] = lod_report
        if extra_files:
            out["lod_files"] = extra_files
    if col_report:
        out["collision"] = col_report
    return {"data": out, "isError": False}
