# SPDX-License-Identifier: GPL-3.0-or-later
"""
Material verbs: looks built from tested node groups instead of raw node code.

shade_wet, shade_dirt, shade_wear and shade_tint add an effect to the materials of the
given objects. Each effect is one node group inserted between whatever fed the
Principled BSDF (a texture, a colour) and the BSDF, so the original shading stays
underneath and remove_shader_effect takes it back out. Applying an effect again
updates it in place. Effects stack in a fixed order, tint > dirt > wear > wet
(water goes on last, over everything). describe_material reads a material back as
compact text.

Dirt and wear need to know where creases and edges are. EEVEE's ambient-occlusion node
finds neither, so the masks are baked into the mesh instead (rays cast from every vertex,
against the object and what touches it) as float attributes "agent_dirt" / "agent_wear":
the look is then the same in EEVEE, Cycles and the viewport, and survives export. The
mask follows the mesh's vertex density; the tool says when a mesh is too coarse.

Sockets are always found by name *and* type among the live ones: a Mix node has three
sockets called "A" (float, vector, colour), and wiring the wrong one is the classic
mistake these verbs exist to avoid.
"""

import hashlib
import math

import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

from .registry import ToolError, get_object, tool, world_bounds

VERSION = 2
_ATTR = {"dirt": "agent_dirt", "wear": "agent_wear"}
ORDER = ("tint", "dirt", "wear", "wet")
LABELS = {"tint": "Tint to palette", "dirt": "Dirt in creases", "wear": "Edge wear", "wet": "Wetness"}
_PORTS = {"tint": (("Base Color", "Color"),),
          "dirt": (("Base Color", "Color"), ("Roughness", "Roughness")),
          "wear": (("Base Color", "Color"), ("Roughness", "Roughness")),
          "wet": (("Base Color", "Color"), ("Roughness", "Roughness"))}
_SHADEABLE = {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'}


# ---------------------------------------------------------------------------
# Building node groups: sockets by name and type, constants or links.

def _sock(sockets, name, kind=None, owner=""):
    found = [s for s in sockets if s.name == name and s.enabled and (kind is None or s.type == kind)]
    if len(found) != 1:
        raise RuntimeError("{}: {} live socket(s) named {!r} of type {}".format(owner, len(found), name, kind))
    return found[0]


class _Builder:
    def __init__(self, tree):
        self.t = tree
        self.n = tree.nodes
        self.gi = self.n.new("NodeGroupInput")
        self.go = self.n.new("NodeGroupOutput")
        self.x = 0

    def node(self, kind, **props):
        node = self.n.new(kind)
        for k, v in props.items():
            setattr(node, k, v)
        self.x += 180
        node.location = (self.x, 0)
        return node

    def feed(self, socket, value):
        if isinstance(value, bpy.types.NodeSocket):
            self.t.links.new(value, socket)
        else:
            socket.default_value = value

    def arg(self, name):
        return self.gi.outputs[name]

    def math(self, op, a, b=0.0, clamp=False):
        node = self.node("ShaderNodeMath", operation=op, use_clamp=clamp)
        self.feed(node.inputs[0], a)
        self.feed(node.inputs[1], b)
        return node.outputs[0]

    def map_range(self, value, from_min, from_max, to_min=0.0, to_max=1.0, smooth=True):
        node = self.node("ShaderNodeMapRange", data_type='FLOAT',
                         interpolation_type='SMOOTHSTEP' if smooth else 'LINEAR', clamp=True)
        for name, v in (("Value", value), ("From Min", from_min), ("From Max", from_max),
                        ("To Min", to_min), ("To Max", to_max)):
            self.feed(_sock(node.inputs, name, 'VALUE', "Map Range"), v)
        return _sock(node.outputs, "Result", 'VALUE', "Map Range")

    def mix_color(self, factor, a, b, blend='MIX'):
        node = self.node("ShaderNodeMix", data_type='RGBA', blend_type=blend, clamp_factor=True)
        self.feed(_sock(node.inputs, "Factor", 'VALUE', "Mix"), factor)
        self.feed(_sock(node.inputs, "A", 'RGBA', "Mix"), a)
        self.feed(_sock(node.inputs, "B", 'RGBA', "Mix"), b)
        return _sock(node.outputs, "Result", 'RGBA', "Mix")

    def mix_float(self, factor, a, b):
        node = self.node("ShaderNodeMix", data_type='FLOAT', clamp_factor=True)
        self.feed(_sock(node.inputs, "Factor", 'VALUE', "Mix"), factor)
        self.feed(_sock(node.inputs, "A", 'VALUE', "Mix"), a)
        self.feed(_sock(node.inputs, "B", 'VALUE', "Mix"), b)
        return _sock(node.outputs, "Result", 'VALUE', "Mix")

    def position(self):
        return self.node("ShaderNodeNewGeometry").outputs["Position"]

    def noise(self, vector, scale):
        node = self.node("ShaderNodeTexNoise")
        self.feed(node.inputs["Vector"], vector)
        self.feed(node.inputs["Scale"], scale)
        node.inputs["Detail"].default_value = 4.0
        return node.outputs["Factor"]

    def out(self, name, socket):
        self.t.links.new(socket, self.go.inputs[name])


# name, socket type, default, min, max
_COLOR, _FLOAT = 'NodeSocketColor', 'NodeSocketFloat'
_SPECS = {
    "wet": ([("Color", _COLOR, (0.5, 0.5, 0.5, 1.0), None, None), ("Roughness", _FLOAT, 0.5, 0.0, 1.0),
             ("Amount", _FLOAT, 1.0, 0.0, 1.0), ("Whole Surface", _FLOAT, 0.0, 0.0, 1.0),
             ("Water Line", _FLOAT, 0.0, -1e5, 1e5), ("Falloff", _FLOAT, 0.05, 0.0, 100.0),
             ("Breakup", _FLOAT, 0.3, 0.0, 1.0), ("Darken", _FLOAT, 0.35, 0.0, 1.0),
             ("Wet Roughness", _FLOAT, 0.08, 0.0, 1.0), ("Noise Scale", _FLOAT, 4.0, 0.0, 1000.0)],
            ["Color", "Roughness", "Mask"]),
    "dirt": ([("Color", _COLOR, (0.5, 0.5, 0.5, 1.0), None, None), ("Roughness", _FLOAT, 0.5, 0.0, 1.0),
              ("Amount", _FLOAT, 0.8, 0.0, 1.0), ("Dirt Color", _COLOR, (0.06, 0.045, 0.03, 1.0), None, None),
              ("Creases", _FLOAT, 1.0, 0.0, 1.0),
              ("Spread", _FLOAT, 0.35, 0.03, 1.0), ("Bottom", _FLOAT, 0.0, 0.0, 1.0),
              ("Ground Z", _FLOAT, 0.0, -1e5, 1e5), ("Bottom Height", _FLOAT, 0.2, 0.0, 1000.0),
              ("Breakup", _FLOAT, 0.5, 0.0, 1.0), ("Dirt Roughness", _FLOAT, 0.9, 0.0, 1.0),
              ("Noise Scale", _FLOAT, 6.0, 0.0, 1000.0)],
             ["Color", "Roughness", "Mask"]),
    "wear": ([("Color", _COLOR, (0.5, 0.5, 0.5, 1.0), None, None), ("Roughness", _FLOAT, 0.5, 0.0, 1.0),
              ("Amount", _FLOAT, 1.0, 0.0, 1.0), ("Wear Color", _COLOR, (0.6, 0.55, 0.45, 1.0), None, None),
              ("Spread", _FLOAT, 0.4, 0.03, 1.0),
              ("Breakup", _FLOAT, 0.6, 0.0, 1.0), ("Wear Roughness", _FLOAT, 0.35, 0.0, 1.0),
              ("Noise Scale", _FLOAT, 20.0, 0.0, 1000.0)],
             ["Color", "Roughness", "Mask"]),
    "tint": ([("Color", _COLOR, (0.5, 0.5, 0.5, 1.0), None, None), ("Strength", _FLOAT, 0.6, 0.0, 1.0),
              ("Low", _FLOAT, 0.0, 0.0, 1.0), ("High", _FLOAT, 0.8, 0.0, 1.0)],
             ["Color", "Mask"]),
}


def _new_tree(name, kind, extra=None):
    tree = bpy.data.node_groups.get(name)
    if tree is not None and tree.get("agent_effect") == kind and tree.get("agent_effect_version") == VERSION:
        return tree, False
    if tree is None:
        tree = bpy.data.node_groups.new(name, "ShaderNodeTree")
    tree.nodes.clear()
    tree.interface.clear()
    ins, outs = _SPECS[kind]
    for out in outs:
        tree.interface.new_socket(out, in_out='OUTPUT', socket_type=_FLOAT if out in ("Roughness", "Mask") else _COLOR)
    for name_, stype, default, lo, hi in ins:
        s = tree.interface.new_socket(name_, in_out='INPUT', socket_type=stype)
        s.default_value = default
        if lo is not None:
            s.min_value, s.max_value = lo, hi
    tree["agent_effect"] = kind
    tree["agent_effect_version"] = VERSION
    if extra:
        tree["agent_effect_key"] = extra
    tree.use_fake_user = False
    return tree, True


def _wet_tree():
    tree, build = _new_tree("Agent Wetness", "wet")
    if not build:
        return tree
    b = _Builder(tree)
    a = b.arg
    pos = b.position()
    sep = b.node("ShaderNodeSeparateXYZ")
    b.feed(sep.inputs["Vector"], pos)
    falloff = b.math('MAXIMUM', a("Falloff"), 0.001)
    # A ragged water line: shift the height by noise, up to the falloff.
    wobble = b.math('MULTIPLY', b.math('SUBTRACT', b.noise(pos, a("Noise Scale")), 0.5),
                    b.math('MULTIPLY', b.math('MULTIPLY', falloff, a("Breakup")), 4.0))
    z = b.math('ADD', sep.outputs["Z"], wobble)
    below = b.map_range(z, b.math('ADD', a("Water Line"), falloff), b.math('SUBTRACT', a("Water Line"), falloff))
    mask = b.math('MULTIPLY', b.math('MAXIMUM', below, a("Whole Surface")), a("Amount"), clamp=True)
    wet = b.node("ShaderNodeHueSaturation")
    wet.inputs["Saturation"].default_value = 1.15
    b.feed(wet.inputs["Value"], b.math('SUBTRACT', 1.0, a("Darken")))
    b.feed(wet.inputs["Color"], a("Color"))
    b.out("Color", b.mix_color(mask, a("Color"), wet.outputs["Color"]))
    b.out("Roughness", b.mix_float(mask, a("Roughness"), a("Wet Roughness")))
    b.out("Mask", mask)
    b.go.location = (b.x + 200, 0)
    return tree


def _breakup(b, pos, scale, amount):
    """1 where noise is high, down to 1 - amount where it is low."""
    return b.map_range(b.noise(pos, scale), 0.35, 0.65, b.math('SUBTRACT', 1.0, amount), 1.0)


def _dirt_tree():
    tree, build = _new_tree("Agent Dirt", "dirt")
    if not build:
        return tree
    b = _Builder(tree)
    a = b.arg
    pos = b.position()
    baked = b.node("ShaderNodeAttribute", attribute_type='GEOMETRY', attribute_name=_ATTR["dirt"])
    crease = b.math('MULTIPLY', b.map_range(baked.outputs["Fac"], 0.02, a("Spread")), a("Creases"))
    sep = b.node("ShaderNodeSeparateXYZ")
    b.feed(sep.inputs["Vector"], pos)
    low = b.map_range(sep.outputs["Z"], b.math('ADD', a("Ground Z"), a("Bottom Height")), a("Ground Z"))
    mask = b.math('MAXIMUM', crease, b.math('MULTIPLY', low, a("Bottom")))
    mask = b.math('MULTIPLY', b.math('MULTIPLY', mask, _breakup(b, pos, a("Noise Scale"), a("Breakup"))),
                  a("Amount"), clamp=True)
    b.out("Color", b.mix_color(mask, a("Color"), a("Dirt Color")))
    b.out("Roughness", b.mix_float(mask, a("Roughness"), a("Dirt Roughness")))
    b.out("Mask", mask)
    b.go.location = (b.x + 200, 0)
    return tree


def _wear_tree():
    tree, build = _new_tree("Agent Edge Wear", "wear")
    if not build:
        return tree
    b = _Builder(tree)
    a = b.arg
    pos = b.position()
    baked = b.node("ShaderNodeAttribute", attribute_type='GEOMETRY', attribute_name=_ATTR["wear"])
    edge = b.map_range(baked.outputs["Fac"], 0.02, a("Spread"))
    mask = b.math('MULTIPLY', b.math('MULTIPLY', edge, _breakup(b, pos, a("Noise Scale"), a("Breakup"))),
                  a("Amount"), clamp=True)
    b.out("Color", b.mix_color(mask, a("Color"), a("Wear Color")))
    b.out("Roughness", b.mix_float(mask, a("Roughness"), a("Wear Roughness")))
    b.out("Mask", mask)
    b.go.location = (b.x + 200, 0)
    return tree


def _luminance(c):
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def _tint_tree(palette):
    key = ",".join("{:.4f}".format(v) for c in palette for v in c[:3])
    tree, build = _new_tree("Agent Tint " + hashlib.sha1(key.encode()).hexdigest()[:6], "tint", key)
    if not build:
        return tree
    b = _Builder(tree)
    a = b.arg
    bw = b.node("ShaderNodeRGBToBW")
    b.feed(bw.inputs["Color"], a("Color"))
    level = b.map_range(bw.outputs["Val"], a("Low"), a("High"), smooth=False)
    ramp = b.node("ShaderNodeValToRGB")
    b.feed(ramp.inputs["Factor"], level)
    stops = sorted(palette, key=_luminance)
    els = ramp.color_ramp.elements
    while len(els) > 1:
        els.remove(els[-1])
    els[0].position, els[0].color = 0.0, tuple(stops[0][:3]) + (1.0,)
    for i, c in enumerate(stops[1:], 1):
        els.new(i / max(1, len(stops) - 1)).color = tuple(c[:3]) + (1.0,)
    if len(stops) == 1:
        els.new(1.0).color = tuple(stops[0][:3]) + (1.0,)
    b.out("Color", b.mix_color(a("Strength"), a("Color"), ramp.outputs["Color"]))
    b.out("Mask", level)
    b.go.location = (b.x + 200, 0)
    return tree


# ---------------------------------------------------------------------------
# Finding the BSDFs and keeping the effect chain in order.

def _effect(node):
    return node.node_tree.get("agent_effect") if node.type == 'GROUP' and node.node_tree else None


def _output(nt):
    outs = [n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL']
    return next((n for n in outs if n.is_active_output), outs[0] if outs else None)


def _principled(mat):
    """Principled BSDFs that reach the material output's surface (through mix/add shaders)."""
    nt = mat.node_tree
    out = _output(nt) if nt else None
    if out is None:
        return []
    found, seen, todo = [], set(), [out.inputs["Surface"]]
    while todo:
        sock = todo.pop()
        for link in sock.links:
            node = link.from_node
            if node.name in seen:
                continue
            seen.add(node.name)
            if node.type == 'BSDF_PRINCIPLED':
                found.append(node)
            elif node.type in ('MIX_SHADER', 'ADD_SHADER'):
                todo += [s for s in node.inputs if s.type == 'SHADER']
    return found


def _walk(bsdf, target, port):
    """Effects feeding `target` (source first), the source socket (or None) and the default."""
    chain = []
    sock = bsdf.inputs[target]
    while sock.is_linked:
        node = sock.links[0].from_node
        if not _effect(node) or port not in node.inputs:
            break
        chain.append(node)
        sock = node.inputs[port]
    src = sock.links[0].from_socket if sock.is_linked else None
    v = sock.default_value
    return chain[::-1], src, (tuple(v) if hasattr(v, "__len__") else v)


def _relink(nt, bsdf, target, port, chain, src, default):
    chain = sorted(chain, key=lambda n: ORDER.index(_effect(n)))
    prev = src
    for node in chain:
        sock = node.inputs[port]
        for link in list(sock.links):
            nt.links.remove(link)
        if prev is not None:
            nt.links.new(prev, sock)
        else:
            sock.default_value = default
        prev = node.outputs[port]
    sock = bsdf.inputs[target]
    for link in list(sock.links):
        nt.links.remove(link)
    if prev is not None:
        nt.links.new(prev, sock)
    else:
        sock.default_value = default
    return chain


def _place(bsdf, chain):
    for i, node in enumerate(chain):
        node.location = (bsdf.location.x - 230 * (len(chain) - i), bsdf.location.y + 320)


def _source_text(src, default):
    if src is None:
        if isinstance(default, tuple):
            return "colour " + str([round(c, 3) for c in default[:3]])
        return "value {}".format(round(default, 3))
    node = src.node
    if node.type == 'TEX_IMAGE' and node.image:
        return "image '{}'".format(node.image.name)
    return "{} ({})".format(node.label or node.name, src.name)


def _ensure_material(ob):
    mat = bpy.data.materials.new(ob.name + " Material")
    if mat.node_tree is None or not _principled(mat):
        if hasattr(mat, "use_nodes"):
            try:
                mat.use_nodes = True
            except AttributeError:
                pass
    if not ob.material_slots:
        ob.data.materials.append(mat)
    else:
        ob.material_slots[0].material = mat
    return mat


def _targets(args):
    names = args.get("objects") or [o.name for o in bpy.context.selected_objects]
    if not names:
        raise ToolError("Name the objects to shade (or select them).")
    obs, skipped, created = [], [], []
    for n in names:
        ob = get_object(n)
        (obs if ob.type in _SHADEABLE else skipped).append(ob)
    for ob in obs:
        if not any(s.material for s in ob.material_slots):
            created.append(_ensure_material(ob).name)
    mats = {}
    for ob in obs:
        for slot in ob.material_slots:
            if slot.material:
                mats.setdefault(slot.material.name, [slot.material, []])[1].append(ob)
    chosen = {o.name for o in obs}
    only = set(args.get("materials") or [])
    unknown = only - set(mats)
    if unknown:
        raise ToolError("Not a material of these objects: {}. They have: {}.".format(
            ", ".join(sorted(unknown)), ", ".join(sorted(mats))))
    out = []
    for name, (mat, users) in mats.items():
        if only and name not in only:
            continue
        others = sorted({o.name for o in bpy.data.objects if o.name not in chosen
                         and any(s.material == mat for s in o.material_slots)})
        if others and args.get("single_user"):
            new = mat.copy()
            for ob in users:
                for slot in ob.material_slots:
                    if slot.material == mat:
                        slot.material = new
            mat, others = new, []
        out.append((mat, sorted({o.name for o in users}), others))
    return out, [o.name for o in skipped], created


def _report(mat, users, others):
    bsdfs = _principled(mat)
    row = {"material": mat.name, "objects": users}
    if others:
        row["also_changes"] = others  # same material: pass single_user=true to change only these
    if not bsdfs:
        row["skipped"] = "no Principled BSDF reaches the material output"
        return row
    chain, src, default = _walk(bsdfs[0], "Base Color", "Color")
    row["effects"] = [_effect(n) for n in chain]
    row["base_from"] = _source_text(src, default)
    if len(bsdfs) > 1:
        row["bsdfs"] = len(bsdfs)
    return row


def _apply(kind, args, tree_for, values):
    """Insert or update `kind` on every target material; values: group input name -> value
    (only those the caller gave are changed on an existing effect)."""
    targets, skipped, created = _targets(args)
    rows = []
    for mat, users, others in targets:
        nt = mat.node_tree
        for bsdf in _principled(mat):
            chain, _src, _d = _walk(bsdf, "Base Color", "Color")
            node = next((n for n in chain if _effect(n) == kind), None)
            fresh = node is None
            if fresh:
                node = nt.nodes.new("ShaderNodeGroup")
                node.node_tree = tree_for()
                node.label = "Agent: " + LABELS[kind]
                node.width = 200
                for target, port in _PORTS[kind]:
                    ch, src, default = _walk(bsdf, target, port)
                    _relink(nt, bsdf, target, port, ch + [node], src, default)
            elif kind == "tint":
                node.node_tree = tree_for()
            for name, value in values(fresh).items():
                node.inputs[name].default_value = value
            _place(bsdf, _walk(bsdf, "Base Color", "Color")[0])
        rows.append(_report(mat, users, others))
    data = {"effect": kind, "materials": rows,
            "look": "render_view look=lit (the solid look does not show materials)"}
    if skipped:
        data["skipped_objects"] = skipped
    if created:
        data["created_materials"] = created
    return {"data": data}


def _given(args, mapping, defaults_on_create):
    """Group input values: on create every default plus what was given; on update only what was given."""
    def values(fresh):
        out = dict(defaults_on_create) if fresh else {}
        for arg, (name, conv) in mapping.items():
            if args.get(arg) is not None:
                out[name] = conv(args[arg])
        return out
    return values


# ---------------------------------------------------------------------------
# Baked masks: how hidden each vertex is within `distance` (dirt: rays out over the
# surface; wear: rays into the body, which near a convex edge soon meet the other face).

def _hemisphere(n, seed=7):
    """n cosine-weighted directions around +Z (a Fibonacci spiral, so evenly spread)."""
    i = np.arange(n) + 0.5
    rr = np.sqrt(i / n)
    phi = i * math.pi * (3.0 - math.sqrt(5.0)) + seed
    return np.stack([rr * np.cos(phi), rr * np.sin(phi), np.sqrt(1.0 - rr * rr)], axis=1)


def _world_mesh(ob, dg):
    ev = ob.evaluated_get(dg)
    me = ev.data
    me.calc_loop_triangles()
    co = np.empty(len(me.vertices) * 3)
    me.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3)
    m = np.array(ob.matrix_world)
    co = co @ m[:3, :3].T + m[:3, 3]
    tris = np.empty(len(me.loop_triangles) * 3, dtype=np.int32)
    me.loop_triangles.foreach_get("vertices", tris)
    return co, tris.reshape(-1, 3)


def _bvh(obs, dg):
    cos, tris, base = [], [], 0
    for ob in obs:
        co, tr = _world_mesh(ob, dg)
        cos.append(co)
        tris.append(tr + base)
        base += len(co)
    if not cos:
        return None
    co = np.concatenate(cos)
    tr = np.concatenate(tris)
    return BVHTree.FromPolygons(co.tolist(), tr.tolist())


def _nearby(ob, dg, margin):
    lo, hi = world_bounds(ob, dg)
    out = []
    for other in bpy.context.scene.objects:
        if other == ob or other.type != 'MESH' or not other.visible_get() or other.hide_render:
            continue
        olo, ohi = world_bounds(other, dg)
        if all(olo[i] <= hi[i] + margin and ohi[i] >= lo[i] - margin for i in range(3)):
            out.append(other)
    return out


def _bake(ob, kind, distance, rays=24, include_nearby=True):
    """Write the mask for `kind` to the mesh; returns a short report."""
    dg = bpy.context.evaluated_depsgraph_get()
    me = ob.data
    n = len(me.vertices)
    co = np.empty(n * 3)
    me.vertices.foreach_get("co", co)
    nor = np.empty(n * 3)
    me.vertices.foreach_get("normal", nor)
    m = np.array(ob.matrix_world)
    co = co.reshape(-1, 3) @ m[:3, :3].T + m[:3, 3]
    nm = np.linalg.inv(m[:3, :3]).T
    nor = nor.reshape(-1, 3) @ nm.T
    nor /= np.maximum(np.linalg.norm(nor, axis=1, keepdims=True), 1e-12)
    if kind == "wear":
        nor = -nor  # into the body
    occluders = [ob] + (_nearby(ob, dg, distance) if kind == "dirt" and include_nearby else [])
    tree = _bvh(occluders, dg)
    if n > 150_000:
        rays = 8
    dirs = _hemisphere(rays)
    # A frame around each normal, turned by a per-vertex angle so neighbours sample differently.
    helper = np.where(np.abs(nor[:, :1]) < 0.9, [[1.0, 0.0, 0.0]], [[0.0, 1.0, 0.0]])
    t = np.cross(nor, helper)
    t /= np.maximum(np.linalg.norm(t, axis=1, keepdims=True), 1e-12)
    bt = np.cross(nor, t)
    ang = (np.arange(n) * 2.399963) % (2 * math.pi)
    c, sn = np.cos(ang)[:, None], np.sin(ang)[:, None]
    t, bt = t * c + bt * sn, bt * c - t * sn
    eps = max(distance * 1e-3, 1e-5)
    starts = co + nor * eps
    hidden = np.zeros(n, dtype=np.float32)
    ray = tree.ray_cast
    # Wear: the far side of a thin wall is parallel to the start, a convex edge's other face is
    # not; skip hits on parallel faces (either winding: generated meshes often mix them).
    parallel = 0.9 if kind == "wear" else 2.0
    for i in range(n):
        o = Vector(starts[i])
        ti, bi, ni = t[i], bt[i], nor[i]
        nv = Vector(ni)
        hits = 0
        for dx, dy, dz in dirs:
            d = Vector((ti[0] * dx + bi[0] * dy + ni[0] * dz, ti[1] * dx + bi[1] * dy + ni[1] * dz,
                        ti[2] * dx + bi[2] * dy + ni[2] * dz))
            loc, hn, _idx, _dist = ray(o, d, distance)
            if loc is not None and abs(hn.dot(nv)) < parallel:
                hits += 1
        hidden[i] = hits / len(dirs)
    name = _ATTR[kind]
    attr = me.attributes.get(name)
    if attr is not None and (attr.domain != 'POINT' or attr.data_type != 'FLOAT'):
        me.attributes.remove(attr)
        attr = None
    if attr is None:
        attr = me.attributes.new(name, 'FLOAT', 'POINT')
    attr.data.foreach_set("value", hidden)
    me.update()
    ob["agent_" + kind + "_distance"] = distance
    # Coarse meshes: the mask can only change from vertex to vertex.
    edges = np.empty(len(me.edges) * 2, dtype=np.int32)
    me.edges.foreach_get("vertices", edges)
    edges = edges.reshape(-1, 2)
    spacing = float(np.median(np.linalg.norm(co[edges[:, 0]] - co[edges[:, 1]], axis=1))) if len(edges) else 0.0
    report = {"object": ob.name, "vertices": n, "rays": len(dirs), "distance_m": round(distance, 4),
              "masked_share": round(float((hidden > 0.05).mean()), 3), "edge_spacing_m": round(spacing, 4)}
    if kind == "dirt" and len(occluders) > 1:
        report["also_against"] = [o.name for o in occluders[1:]][:12]
    if spacing > distance * 1.5:
        report["coarse"] = ("edges are ~{:.3g} m apart, longer than the {:.3g} m reach: the mask is blotchy. "
                            "Subdivide, or use a larger distance.").format(spacing, distance)
    return report


def _bake_targets(args, kind, given, default, rebake):
    """Bake each mesh's mask. `given` is the caller's distance (None: keep each mesh's last one)."""
    names = args.get("objects") or [o.name for o in bpy.context.selected_objects]
    reports, skipped = [], []
    for n in names:
        ob = bpy.data.objects.get(n)
        if ob is None:
            continue
        if ob.type != 'MESH':
            skipped.append(ob.name)
            continue
        last = ob.get("agent_" + kind + "_distance")
        distance = float(given if given is not None else (last if last is not None else default))
        same = last is not None and abs(float(last) - distance) < 1e-9
        if not rebake and same and ob.data.attributes.get(_ATTR[kind]) is not None:
            reports.append({"object": ob.name, "baked": "kept (same distance; rebake=true to redo)"})
            continue
        reports.append(_bake(ob, kind, distance, include_nearby=args.get("include_nearby", True)))
    out = {"baked": reports}
    if skipped:
        out["not_baked"] = {"objects": skipped, "why": "not meshes: no mask (convert to mesh first)"}
    return out


# ---------------------------------------------------------------------------
# Colours.

def _srgb_to_linear(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _color(v):
    """'#rrggbb', 'rrggbb' or [r, g, b] (0-1, as picked on screen) -> linear RGBA."""
    if isinstance(v, str):
        h = v.strip().lstrip("#")
        if len(h) == 3:
            h = "".join(ch * 2 for ch in h)
        if len(h) != 6:
            raise ToolError("Colour {!r}: use #rrggbb.".format(v))
        try:
            rgb = [int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
        except ValueError:
            raise ToolError("Colour {!r}: use #rrggbb.".format(v)) from None
    elif isinstance(v, (list, tuple)) and len(v) in (3, 4):
        rgb = [float(x) for x in v[:3]]
    else:
        raise ToolError("Colour {!r}: use #rrggbb or [r, g, b].".format(v))
    return tuple(_srgb_to_linear(max(0.0, min(1.0, c))) for c in rgb) + (1.0,)


_COLOR_ARG = {"anyOf": [{"type": "string"}, {"type": "array", "items": {"type": "number"}, "minItems": 3,
                                                                       "maxItems": 4}]}
_OBJECTS = {"type": "array", "items": {"type": "string"}, "maxItems": 64,
            "description": "Objects to shade (default: the selection)."}
_SINGLE = {"type": "boolean", "default": False,
           "description": "Give these objects their own copy of a shared material first."}
_MATS = {"type": "array", "items": {"type": "string"}, "maxItems": 32,
         "description": "Only these of the objects' materials (default: all of them)."}


def _f(v):
    return float(v)


# ---------------------------------------------------------------------------
# Tools.

@tool("shade_wet",
      "Make surfaces look wet: darker, a little more saturated, glossy. water_line (world Z in "
      "metres) wets only what is below it, with a soft ragged edge (falloff, breakup); leave it "
      "out to wet the whole surface. Keeps textures underneath; applying again updates it.",
      {"objects": _OBJECTS, "amount": {"type": "number", "minimum": 0, "maximum": 1},
       "water_line": {"type": "number"}, "falloff": {"type": "number", "minimum": 0},
       "breakup": {"type": "number", "minimum": 0, "maximum": 1},
       "darken": {"type": "number", "minimum": 0, "maximum": 1},
       "roughness": {"type": "number", "minimum": 0, "maximum": 1, "description": "Roughness when wet."},
       "noise_scale": {"type": "number", "minimum": 0}, "single_user": _SINGLE, "materials": _MATS},
      mutating=True)
def shade_wet(args):
    defaults = {}
    if "water_line" not in args:
        defaults["Whole Surface"] = 1.0
    values = _given(args, {"amount": ("Amount", _f), "water_line": ("Water Line", _f), "falloff": ("Falloff", _f),
                           "breakup": ("Breakup", _f), "darken": ("Darken", _f),
                           "roughness": ("Wet Roughness", _f), "noise_scale": ("Noise Scale", _f)}, defaults)

    def vals(fresh):
        out = values(fresh)
        if "water_line" in args:
            out["Whole Surface"] = 0.0
        return out
    return _apply("wet", args, _wet_tree, vals)


@tool("shade_dirt",
      "Dirt gathered in creases and corners, and where the object meets what touches it (a mask "
      "baked into the mesh: distance is how far a crease reaches, spread how far the dirt fades "
      "out; works in EEVEE, Cycles and exports), optionally grime rising from the "
      "ground (bottom 0-1, bottom_height m above ground_z, which defaults to the objects' lowest "
      "point). Keeps textures underneath; applying again updates it.",
      {"objects": _OBJECTS, "amount": {"type": "number", "minimum": 0, "maximum": 1}, "color": _COLOR_ARG,
       "creases": {"type": "number", "minimum": 0, "maximum": 1},
       "distance": {"type": "number", "minimum": 0.001, "description": "How far a crease reaches (m, default 0.1)."},
       "include_nearby": {"type": "boolean", "default": True,
                          "description": "Count objects touching it (dirt where a castle meets the sand)."},
       "rebake": {"type": "boolean", "default": False, "description": "Redo the mask (after changing the shape)."},
       "spread": {"type": "number", "minimum": 0.03, "maximum": 1},
       "bottom": {"type": "number", "minimum": 0, "maximum": 1}, "bottom_height": {"type": "number", "minimum": 0},
       "ground_z": {"type": "number"}, "breakup": {"type": "number", "minimum": 0, "maximum": 1},
       "roughness": {"type": "number", "minimum": 0, "maximum": 1}, "noise_scale": {"type": "number", "minimum": 0},
       "single_user": _SINGLE, "materials": _MATS},
      mutating=True)
def shade_dirt(args):
    defaults = {}
    if args.get("ground_z") is None:
        names = args.get("objects") or [o.name for o in bpy.context.selected_objects]
        lows = [world_bounds(get_object(n))[0].z for n in names if bpy.data.objects.get(n)]
        if lows:
            defaults["Ground Z"] = min(lows)
    values = _given(args, {"amount": ("Amount", _f), "color": ("Dirt Color", _color), "creases": ("Creases", _f),
                           "spread": ("Spread", _f), "bottom": ("Bottom", _f),
                           "bottom_height": ("Bottom Height", _f), "ground_z": ("Ground Z", _f),
                           "breakup": ("Breakup", _f), "roughness": ("Dirt Roughness", _f),
                           "noise_scale": ("Noise Scale", _f)}, defaults)
    bake = _bake_targets(args, "dirt", args.get("distance"), 0.1, args.get("rebake"))
    result = _apply("dirt", args, _dirt_tree, values)
    result["data"].update(bake)
    return result


@tool("shade_wear",
      "Worn edges: convex edges and corners show a wear colour (bare metal, lighter paint, rubbed "
      "stone): a mask baked into the mesh, so it follows its vertex density. width is how far in "
      "from an edge the wear reaches (m); breakup makes it patchy. "
      "Keeps textures underneath; applying again updates it.",
      {"objects": _OBJECTS, "amount": {"type": "number", "minimum": 0, "maximum": 1}, "color": _COLOR_ARG,
       "width": {"type": "number", "minimum": 0.0005, "description": "How far in from an edge (m, default 0.02)."},
       "rebake": {"type": "boolean", "default": False, "description": "Redo the mask (after changing the shape)."},
       "spread": {"type": "number", "minimum": 0.03, "maximum": 1},
       "breakup": {"type": "number", "minimum": 0, "maximum": 1},
       "roughness": {"type": "number", "minimum": 0, "maximum": 1}, "noise_scale": {"type": "number", "minimum": 0},
       "single_user": _SINGLE, "materials": _MATS},
      mutating=True)
def shade_wear(args):
    values = _given(args, {"amount": ("Amount", _f), "color": ("Wear Color", _color),
                           "spread": ("Spread", _f), "breakup": ("Breakup", _f),
                           "roughness": ("Wear Roughness", _f), "noise_scale": ("Noise Scale", _f)}, {})
    bake = _bake_targets(args, "wear", args.get("width"), 0.02, args.get("rebake"))
    result = _apply("wear", args, _wear_tree, values)
    result["data"].update(bake)
    return result


@tool("shade_tint",
      "Pull materials toward a palette (2-6 colours as #rrggbb, as picked on screen): a gradient map "
      "from the surface's own light and dark (darkest colour for its darks, lightest for its lights), "
      "blended in by strength, so texture detail stays. low/high pick which brightness range spans the "
      "palette. Applying again updates it (a new palette replaces the old).",
      {"objects": _OBJECTS, "palette": {"type": "array", "items": _COLOR_ARG, "minItems": 1, "maxItems": 6},
       "strength": {"type": "number", "minimum": 0, "maximum": 1},
       "low": {"type": "number", "minimum": 0, "maximum": 1}, "high": {"type": "number", "minimum": 0, "maximum": 1},
       "single_user": _SINGLE, "materials": _MATS},
      required=("palette",), mutating=True)
def shade_tint(args):
    palette = [_color(c) for c in args["palette"]]
    values = _given(args, {"strength": ("Strength", _f), "low": ("Low", _f), "high": ("High", _f)}, {})
    return _apply("tint", args, lambda: _tint_tree(palette), values)


@tool("remove_shader_effect",
      "Take a shade_* effect back out of the objects' materials (effect: wet, dirt, wear, tint or all), "
      "reconnecting what it was layered over.",
      {"objects": _OBJECTS, "effect": {"type": "string", "enum": [*ORDER, "all"], "default": "all"},
       "materials": _MATS},
      mutating=True)
def remove_shader_effect(args):
    kinds = set(ORDER) if args.get("effect", "all") == "all" else {args["effect"]}
    targets, skipped, _created = _targets(dict(args, single_user=False))
    rows = []
    for mat, users, others in targets:
        nt = mat.node_tree
        removed = []
        for bsdf in _principled(mat):
            gone = set()
            for target, port in (("Base Color", "Color"), ("Roughness", "Roughness")):
                chain, src, default = _walk(bsdf, target, port)
                keep = [n for n in chain if _effect(n) not in kinds]
                gone |= {n.name for n in chain if _effect(n) in kinds}
                _relink(nt, bsdf, target, port, keep, src, default)
            for name in gone:
                node = nt.nodes.get(name)
                if node is not None:
                    removed.append(_effect(node))
                    nt.nodes.remove(node)
        row = _report(mat, users, others)
        row["removed"] = sorted(set(removed))
        rows.append(row)
    for tree in list(bpy.data.node_groups):
        if tree.get("agent_effect") and tree.users == 0:
            bpy.data.node_groups.remove(tree)
    data = {"materials": rows}
    if skipped:
        data["skipped_objects"] = skipped
    return {"data": data}


# ---------------------------------------------------------------------------
# Reading a material back.

_PRINCIPLED_KEYS = ("Base Color", "Metallic", "Roughness", "IOR", "Alpha", "Normal", "Emission Color",
                    "Emission Strength", "Coat Weight", "Transmission Weight", "Subsurface Weight")


def _value(v):
    if hasattr(v, "__len__"):
        return "(" + ", ".join("{:g}".format(round(x, 3)) for x in v[:3]) + ")"
    return "{:g}".format(round(v, 3)) if isinstance(v, float) else str(v)


def _describe(mat, limit=60):
    nt = mat.node_tree
    users = sorted({o.name for o in bpy.data.objects if any(s.material == mat for s in o.material_slots)})
    lines = ['"{}" used by {}'.format(mat.name, ", ".join(users[:8]) + (" …" if len(users) > 8 else "") or "nothing")]
    out = _output(nt) if nt else None
    if out is None:
        return lines + ["  (no node tree output)"]
    ids, order = {}, []

    def ref(node):
        if node.name not in ids:
            ids[node.name] = "n{}".format(len(ids) + 1)
            order.append(node)
        return ids[node.name]

    for sock in out.inputs:
        if sock.is_linked and sock.enabled:
            link = sock.links[0]
            lines.append("  output.{} <- {}.{}".format(sock.name, ref(link.from_node), link.from_socket.name))
    i = 0
    while i < len(order) and len(lines) < limit:
        node = order[i]
        i += 1
        kind = _effect(node)
        title = node.label or node.name
        if node.type == 'TEX_IMAGE' and node.image:
            title += ' "{}" ({}, {})'.format(node.image.name, node.image.colorspace_settings.name,
                                            node.projection.lower())
        elif kind:
            title += " [effect {}]".format(kind)
        elif node.type == 'GROUP' and node.node_tree:
            title += " [group {}]".format(node.node_tree.name)
        parts = []
        for sock in node.inputs:
            if not sock.enabled or sock.type == 'SHADER' and not sock.is_linked:
                continue
            if sock.is_linked:
                link = sock.links[0]
                parts.append("{} <- {}.{}".format(sock.name, ref(link.from_node), link.from_socket.name))
            elif node.type == 'BSDF_PRINCIPLED':
                if sock.name in _PRINCIPLED_KEYS and hasattr(sock, "default_value") and sock.name != "Normal":
                    parts.append("{} {}".format(sock.name, _value(sock.default_value)))
            elif hasattr(sock, "default_value") and sock.type in ('VALUE', 'RGBA', 'INT', 'BOOLEAN') \
                    and (kind or sum(1 for x in node.inputs if x.enabled) <= 8):
                parts.append("{} {}".format(sock.name, _value(sock.default_value)))
        lines.append("  {} {}: {}".format(ids[node.name], title, "; ".join(parts) or "-"))
    if i < len(order):
        lines.append("  … {} more node(s)".format(len(order) - i))
    return lines


@tool("describe_material",
      "Read materials back as compact text: what feeds the output, each node's inputs (links as "
      "<- nX.Socket, values otherwise), images with colour space and projection, shade_* effects "
      "with their settings. Give objects (their materials) or material names.",
      {"objects": {"type": "array", "items": {"type": "string"}, "maxItems": 32},
       "materials": {"type": "array", "items": {"type": "string"}, "maxItems": 32}})
def describe_material(args):
    mats = []
    for n in args.get("materials") or []:
        mat = bpy.data.materials.get(n)
        if mat is None:
            raise ToolError("No material {!r}.".format(n))
        mats.append(mat)
    names = args.get("objects") or ([] if mats else [o.name for o in bpy.context.selected_objects])
    for n in names:
        for slot in get_object(n).material_slots:
            if slot.material and slot.material not in mats:
                mats.append(slot.material)
    if not mats:
        raise ToolError("Name objects or materials (or select objects).")
    return {"data": {"materials": {m.name: "\n".join(_describe(m)) for m in mats[:16]},
                     "note": None if len(mats) <= 16 else "first 16 of {}".format(len(mats))}}
