# SPDX-License-Identifier: GPL-3.0-or-later
"""
The Agent tab in the 3D View sidebar (N panel): what the agent is doing, what it
changed (click to select), save points, and undo for its last edit.
"""

import time

import bpy

from . import cancel, history, server, undo
from .registry import TOOLS

_MAX_ROWS = 8


def _ago(t: float) -> str:
    s = int(time.time() - t)
    if s < 60:
        return "{}s".format(s)
    if s < 3600:
        return "{}m".format(s // 60)
    return "{}h".format(s // 3600)


def _agent_events():
    """Agent edits worth showing: ones that changed something, failed, or are save points."""
    def shown(e):
        ch = e.get("changes") or {}
        return (e["status"] == "failed" or e["tool"] in {"checkpoint", "restore_checkpoint"}
                or any(ch.get(k) for k in ("created", "modified", "deleted")))
    return [e for e in history.events(100) if e["by"] == "agent" and shown(e)]


class AGENT_OT_select_changed(bpy.types.Operator):
    bl_idname = "agent.select_changed"
    bl_label = "Select What Changed"
    bl_description = "Select the objects this agent edit created or modified"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        events = _agent_events()
        if not 0 <= self.index < len(events):
            return {'CANCELLED'}
        names = [n for n in events[self.index].get("objects", []) if n in context.view_layer.objects]
        if not names:
            self.report({'INFO'}, "Nothing left to select from that edit")
            return {'CANCELLED'}
        for ob in context.selected_objects:
            ob.select_set(False)
        for n in names:
            context.view_layer.objects[n].select_set(True)
        context.view_layer.objects.active = context.view_layer.objects[names[0]]
        return {'FINISHED'}


class AGENT_OT_undo_last(bpy.types.Operator):
    bl_idname = "agent.undo_last"
    bl_label = "Undo Agent's Last Edit"
    bl_description = "Undo the most recent step if it was made by the agent"

    @classmethod
    def poll(cls, context):
        st = undo.stack()
        return st is not None and st.active is not None and history.is_agent_step(st.active.name)

    def execute(self, context):
        bpy.ops.ed.undo()
        return {'FINISHED'}


class AGENT_OT_checkpoint(bpy.types.Operator):
    bl_idname = "agent.checkpoint"
    bl_label = "Make Save Point"
    bl_description = "Save the whole file as a named save point (undo step plus a copy on disk)"

    name: bpy.props.StringProperty(name="Name", default="")

    def invoke(self, context, event):
        self.name = time.strftime("save %H:%M:%S")
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        TOOLS["checkpoint"].fn({"name": self.name or time.strftime("save %H:%M:%S")})
        return {'FINISHED'}


class AGENT_OT_restore_checkpoint(bpy.types.Operator):
    bl_idname = "agent.restore_checkpoint"
    bl_label = "Restore Save Point"
    bl_description = "Return the whole file to this save point (later edits are undone)"

    name: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        TOOLS["restore_checkpoint"].fn({"name": self.name})
        return {'FINISHED'}


class AGENT_OT_toggle_server(bpy.types.Operator):
    bl_idname = "agent.toggle_server"
    bl_label = "Start/Stop Agent Server"
    bl_description = "Start or stop the MCP server that agents connect to"

    def execute(self, context):
        from . import start, stop
        if server.is_running():
            stop()
        else:
            start()
        return {'FINISHED'}


class VIEW3D_PT_agent(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PartyMode"
    bl_label = "Activity"
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        agent = getattr(bpy.app, "agent", None)
        status = agent.get_status() if agent else ""

        box = layout.box()
        row = box.row()
        if server.is_running():
            row.label(text=status or "ready", icon='LINKED')
        else:
            row.label(text="server stopped", icon='UNLINKED')
        row.operator(AGENT_OT_toggle_server.bl_idname, text="", icon='PAUSE' if server.is_running() else 'PLAY')
        running = cancel.busy()
        if running:
            box.label(text="{} ({}s) — Esc to stop".format(running["label"], running["running_s"]), icon='TIME')

        col = layout.column(align=True)
        col.label(text="Recent agent edits")
        events = _agent_events()[:_MAX_ROWS]
        if not events:
            col.label(text="none yet", icon='DOT')
        for i, e in enumerate(events):
            row = col.row(align=True)
            ch = e.get("changes") or {}
            counts = "+{created} ~{modified} -{deleted}".format(**ch) if ch else ""
            icon = 'ERROR' if e["status"] == "failed" else 'CHECKMARK'
            row.label(text="{}  {}  {}".format(e["label"][:28], counts, _ago(e["t"])), icon=icon)
            sub = row.row(align=True)
            sub.enabled = bool(e.get("objects"))
            sub.operator(AGENT_OT_select_changed.bl_idname, text="", icon='RESTRICT_SELECT_OFF').index = i
        layout.operator(AGENT_OT_undo_last.bl_idname, icon='LOOP_BACK')

        from .tools_safety import _checkpoints
        col = layout.column(align=True)
        row = col.row()
        row.label(text="Save points")
        row.operator(AGENT_OT_checkpoint.bl_idname, text="", icon='ADD')
        for cp in sorted(_checkpoints.values(), key=lambda c: c["t"], reverse=True)[:_MAX_ROWS]:
            row = col.row(align=True)
            row.label(text="{}  {}".format(cp["name"][:30], _ago(cp["t"])), icon='BOOKMARKS')
            row.operator(AGENT_OT_restore_checkpoint.bl_idname, text="", icon='RECOVER_LAST').name = cp["name"]

        user = [e for e in history.events(50) if e["by"] == "user"][:3]
        if user:
            col = layout.column(align=True)
            col.label(text="Your recent edits (the agent sees these)")
            for e in user:
                col.label(text="{}  {}".format(e["edit"][:34], _ago(e["t"])), icon='USER')


_classes = (
    AGENT_OT_select_changed, AGENT_OT_undo_last, AGENT_OT_checkpoint,
    AGENT_OT_restore_checkpoint, AGENT_OT_toggle_server, VIEW3D_PT_agent,
)
_last_revision = [-1]


def _redraw_tick():
    """Redraw the Agent panel when something new happened (cheap no-op otherwise)."""
    from . import chat
    rev = (history.revision[0], chat.S.revision)
    if rev != _last_revision[0] or cancel.busy() or chat.live():
        _last_revision[0] = rev
        wm = bpy.context.window_manager
        for win in (wm.windows if wm else ()):
            for area in win.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'UI':
                            region.tag_redraw()
    return 0.5


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    if not bpy.app.timers.is_registered(_redraw_tick):
        bpy.app.timers.register(_redraw_tick, first_interval=0.5, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_redraw_tick):
        bpy.app.timers.unregister(_redraw_tick)
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
