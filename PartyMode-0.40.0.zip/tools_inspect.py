# SPDX-License-Identifier: GPL-3.0-or-later
"""
Mesh health, size sanity and UV checks: problems a render rarely shows until
it is too late (holes, flipped faces, a chair 4 m tall, stretched textures).

Findings are graded (error, warning, note) so real problems stand out, and an
object can carry intent (mark_intent): an open water film or a tiling UV layout
then reads as "expected" instead of a failure.
"""

import struct
import zlib

import bmesh
import bpy
import numpy as np

from .registry import ToolError, get_object, r, tool, vec, world_bounds

_MAX_VERTS = 2_000_000

# Typical real-world sizes in metres: (dimension, min, max). Dimension is "height"
# (world Z), "length" (longest horizontal side) or "longest" (any axis).
SIZES = {
    "chair": ("height", 0.7, 1.2), "stool": ("height", 0.4, 0.85), "table": ("height", 0.65, 0.8),
    "desk": ("height", 0.68, 0.8), "coffee table": ("height", 0.35, 0.5), "bed": ("length", 1.9, 2.3),
    "sofa": ("length", 1.4, 2.8), "door": ("height", 1.9, 2.5), "window": ("height", 0.6, 2.4),
    "wall": ("height", 2.3, 4.0), "house": ("height", 4.0, 15.0), "shelf": ("height", 0.3, 2.4),
    "lamp": ("height", 0.25, 1.9), "mug": ("height", 0.08, 0.13), "cup": ("height", 0.06, 0.12),
    "bottle": ("height", 0.15, 0.4), "plate": ("longest", 0.15, 0.32), "book": ("longest", 0.15, 0.35),
    "person": ("height", 1.5, 2.0), "child": ("height", 0.8, 1.5), "dog": ("height", 0.25, 0.9),
    "cat": ("height", 0.2, 0.3), "car": ("length", 3.5, 5.5), "truck": ("length", 5.0, 12.0),
    "bicycle": ("length", 1.5, 1.9), "tree": ("height", 2.0, 40.0), "bush": ("height", 0.3, 3.0),
    "rock": ("longest", 0.05, 5.0), "crate": ("longest", 0.3, 1.2), "barrel": ("height", 0.6, 1.0),
    "phone": ("longest", 0.12, 0.18), "laptop": ("longest", 0.28, 0.42), "keyboard": ("longest", 0.3, 0.48),
    "monitor": ("longest", 0.4, 0.9), "tv": ("longest", 0.6, 2.0), "pencil": ("longest", 0.14, 0.2),
    "sword": ("longest", 0.6, 1.4), "guitar": ("longest", 0.9, 1.1), "piano": ("longest", 1.2, 2.8),
}


INTENTS = {
    "open_shell": "open edges and holes are deliberate (a water film, a single-sided shell, a decal)",
    "multi_part": "many separate pieces are deliberate (an assembly kept in one object, scattered debris)",
    "tiling_uv": "UVs repeat across the texture (a tiling material): overlap and outside 0-1 are expected",
    "overlapping_uv": "UV islands share texture space on purpose (mirrored or stacked)",
    "mirrored": "negative scale is deliberate",
    "scaled": "unapplied scale is deliberate",
}
_INTENT_PROP = "agent_intent"


def intents_of(ob, extra=()):
    stored = ob.get(_INTENT_PROP, "")
    found = {i.strip() for i in str(stored).split(",") if i.strip()} if stored else set()
    return found | {i for i in extra if i}


def _finding(code, severity, message, intents, expected_by=(), **extra):
    """One graded finding; downgraded to "expected" when the object is marked with a matching intent."""
    marked = sorted(set(expected_by) & intents)
    out = {"code": code, "severity": "expected" if marked else severity, "message": message}
    if marked:
        out["expected_because"] = ", ".join(marked)
    out.update({k: v for k, v in extra.items() if v is not None})
    return out


def _summarise(findings):
    """(issues as plain messages for errors and warnings, ok)."""
    issues = [f["message"] for f in findings if f["severity"] in ("error", "warning")]
    return issues, not issues


def _dims(lo, hi):
    size = hi - lo
    return {"height": float(size[2]), "length": float(max(size[0], size[1])), "longest": float(max(size))}


def _size_check(ob, dg, expected):
    b = world_bounds(ob, dg)
    if b is None:
        return None
    dims = _dims(*b)
    out = {"world_size_m": vec(b[1] - b[0], 3)}
    if dims["longest"] > 1000:
        out["warning"] = "over 1 km across: check units/scale"
    elif 0 < dims["longest"] < 0.001:
        out["warning"] = "under 1 mm across: check units/scale"
    if expected:
        if isinstance(expected, str):
            spec = SIZES.get(expected.lower().strip())
            if spec is None:
                out["expected"] = "unknown kind {!r}; known: {}".format(expected, ", ".join(sorted(SIZES)))
                return out
        else:
            key = next((k for k in ("height", "length", "longest") if k + "_m" in expected), None) \
                if isinstance(expected, dict) else None
            if key is None:
                raise ToolError("expected needs a kind name or one of height_m / length_m / longest_m.")
            want = expected[key + "_m"]
            if isinstance(want, (int, float)):  # one size: within 5%
                want = (want * 0.95, want * 1.05)
            if not (isinstance(want, (list, tuple)) and len(want) == 2
                    and all(isinstance(v, (int, float)) for v in want)):
                raise ToolError("expected {}_m takes a size in metres or [min, max].".format(key))
            spec = (key, min(want), max(want))
        dim, lo, hi = spec
        value = dims[dim]
        out["expected"] = {"dimension": dim, "range_m": [lo, hi], "actual_m": r(value, 3),
                           "ok": lo <= value <= hi}
        if not lo <= value <= hi:
            out["warning"] = "{} is {:.3f} m; a typical {} is {}–{} m (off by {:.1f}x)".format(
                dim, value, expected if isinstance(expected, str) else "target", lo, hi,
                value / hi if value > hi else lo / max(value, 1e-9))
    return out


def _boundary_loops(boundary_edges):
    """Open boundary loops (holes) as lists of vertex indices, largest first."""
    parent = {}

    def find(x):
        while parent.setdefault(x, x) != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for e in boundary_edges:
        a, b = (v.index for v in e.verts)
        parent[find(a)] = find(b)
    groups = {}
    for x in parent:
        groups.setdefault(find(x), []).append(x)
    return sorted(groups.values(), key=len, reverse=True)


def _mesh_health(ob, dg, evaluated: bool, intents=frozenset()):
    bm = bmesh.new()
    try:
        if evaluated:
            bm.from_object(ob, dg)
        else:
            bm.from_mesh(ob.data)
        if len(bm.verts) > _MAX_VERTS:
            raise ToolError("{!r} has {} vertices; mesh checks stop at {}.".format(ob.name, len(bm.verts), _MAX_VERTS))
        bm.verts.index_update()
        bm.faces.index_update()
        mw = ob.matrix_world
        boundary = [e for e in bm.edges if len(e.link_faces) == 1]
        multi = [e for e in bm.edges if len(e.link_faces) > 2]
        wire = [e for e in bm.edges if not e.link_faces]
        flipped = [e for e in bm.edges if len(e.link_faces) == 2 and not e.is_contiguous]
        loose_verts = [v for v in bm.verts if not v.link_edges]
        zero_area = [f for f in bm.faces if f.calc_area() < 1e-12]
        ngons = sum(1 for f in bm.faces if len(f.verts) > 4)
        doubles = len(bmesh.ops.find_doubles(bm, verts=list(bm.verts), dist=1e-5)["targetmap"])
        closed = not boundary and not multi and not wire and bool(bm.faces)
        volume = bm.calc_volume(signed=True) if closed else None
        island_sizes = []
        seen = set()
        for f in bm.faces:
            if f.index in seen:
                continue
            size = 0.0
            stack = [f]
            while stack:
                g = stack.pop()
                if g.index in seen:
                    continue
                seen.add(g.index)
                size += g.calc_area()  # pieces measured by surface area
                stack.extend(h for e in g.edges for h in e.link_faces if h.index not in seen)
            island_sizes.append(size)
        island_sizes.sort(reverse=True)
        stats = {"verts": len(bm.verts), "faces": len(bm.faces),
                 "tris": sum(len(f.verts) - 2 for f in bm.faces), "ngons": ngons, "parts": len(island_sizes)}
        loops = _boundary_loops(boundary) if boundary else []
        co = {v.index: mw @ v.co for v in bm.verts} if loops or flipped else {}

        def where(indices):
            pts = np.array([tuple(co[i]) for i in indices])
            lo, hi = pts.min(axis=0), pts.max(axis=0)
            return {"centre": vec((lo + hi) / 2, 3), "size": vec(hi - lo, 3)}

        hole_places = [dict(where(g), boundary_edges=len(g)) for g in loops[:3]]
        flipped_place = where({v.index for e in flipped for v in e.verts}) if flipped else None
        counts = {"boundary": len(boundary), "multi": len(multi), "flipped": len(flipped),
                  "wire": len(wire), "loose": len(loose_verts), "zero": len(zero_area)}
    finally:
        bm.free()

    det = ob.matrix_world.to_3x3().determinant()
    holes = len(loops)
    f = []
    if holes:
        f.append(_finding("holes", "warning", "{} hole(s): {} open boundary edges".format(holes, counts["boundary"]),
                          intents, ("open_shell",), largest=hole_places,
                          hint=None if "open_shell" in intents else
                          "If the openings are deliberate, mark_intent(objects=[{!r}], intent=[\"open_shell\"])."
                          .format(ob.name)))
    if counts["multi"]:
        f.append(_finding("internal_faces", "warning",
                          "{} edges shared by more than two faces (internal faces?)".format(counts["multi"]), intents))
    if counts["flipped"]:
        f.append(_finding("flipped", "error", "{} edges between faces with opposite normals (flipped faces)"
                          .format(counts["flipped"]), intents, where=flipped_place))
    if volume is not None and volume * (1 if det >= 0 else -1) < 0:
        f.append(_finding("inside_out", "error", "inside-out: normals point inward (recalculate normals outside)",
                          intents))
    if counts["wire"]:
        f.append(_finding("wire_edges", "warning", "{} loose edges with no faces".format(counts["wire"]), intents))
    if counts["loose"]:
        f.append(_finding("loose_verts", "note", "{} loose vertices".format(counts["loose"]), intents))
    if doubles:
        f.append(_finding("duplicates", "warning", "{} duplicate vertices (merge by distance)".format(doubles),
                          intents))
    if counts["zero"]:
        f.append(_finding("zero_area", "note", "{} zero-area faces".format(counts["zero"]), intents))
    if len(island_sizes) > 1:
        total = sum(island_sizes) or 1.0
        tiny = sum(1 for a in island_sizes if a < 0.01 * total)
        main = island_sizes[0] / total
        msg = "{} separate parts: the biggest has {:.0%} of the surface".format(len(island_sizes), main)
        if tiny >= 10:
            f.append(_finding("fragments", "warning", msg + ", {} are tiny fragments (generation debris?)".format(tiny),
                              intents, ("multi_part",), tiny_fragments=tiny))
        else:
            f.append(_finding("parts", "note", msg, intents, ("multi_part",)))
    scale = ob.scale
    if det < 0:
        f.append(_finding("negative_scale", "warning", "negative scale (mirrored): exports and modifiers may flip normals",
                          intents, ("mirrored",)))
    elif any(abs(sc - 1.0) > 1e-4 for sc in scale) and ob.type == 'MESH':
        f.append(_finding("unapplied_scale", "warning", "unapplied scale {} (apply before export, bevels and physics)"
                          .format(vec(scale, 3)), intents, ("scaled",)))
    if volume is not None:
        stats["volume_m3"] = r(abs(volume) * abs(det), 5)
    stats["closed"] = closed
    return stats, f


@tool("inspect_mesh",
      "Health and size check for mesh objects (changes nothing): holes, flipped or inside-out "
      "normals, internal faces, loose geometry, duplicate vertices, zero-area faces, ngons, "
      "separate parts, unapplied or negative scale, and world size. Pass expected per object "
      "to compare with real-world size: a kind such as \"chair\", \"door\", \"mug\" (see "
      "SIZES) or {\"height_m\": [min, max]} (also length_m, longest_m). Findings are graded "
      "error/warning/note; ones the object's intent explains (mark_intent, or intent here) are "
      "\"expected\". ok means no errors or warnings.",
      {"objects": {"type": "array", "minItems": 1, "maxItems": 32, "items": {
          "type": "object", "required": ["name"], "additionalProperties": False,
          "properties": {
              "name": {"type": "string"},
              "expected": {"description": "A kind name or {height_m|length_m|longest_m: [min, max]}."},
              "intent": {"type": "array", "items": {"type": "string", "enum": sorted(INTENTS)},
                         "description": "Deliberate traits for this check only (mark_intent stores them)."},
          }}},
       "evaluated": {"type": "boolean", "default": True,
                     "description": "Check the mesh after modifiers (default) or the editable base mesh."}},
      required=("objects",))
def inspect_mesh(args):
    dg = bpy.context.evaluated_depsgraph_get()
    evaluated = args.get("evaluated", True)
    results, clean = [], 0
    for item in args["objects"]:
        entry = {"name": item["name"]}
        try:
            ob = get_object(item["name"])
            if ob.type != 'MESH':
                raise ToolError("{!r} is a {}, not a mesh.".format(ob.name, ob.type))
            intents = intents_of(ob, item.get("intent", ()))
            stats, findings = _mesh_health(ob, dg, evaluated, intents)
            size = _size_check(ob, dg, item.get("expected"))
            if size and size.get("warning"):
                findings.append(_finding("size", "warning", size["warning"], intents))
            order = {"error": 0, "warning": 1, "note": 2, "expected": 3}
            findings.sort(key=lambda x: order[x["severity"]])
            issues, ok = _summarise(findings)
            entry.update(stats=stats, size=size, findings=findings, issues=issues, ok=ok)
            if intents:
                entry["intent"] = sorted(intents)
            clean += ok
        except ToolError as ex:
            entry.update(ok=False, error=str(ex))
        results.append(entry)
    data = {"clean": clean, "with_issues": len(results) - clean, "objects": results}
    from . import check_marks
    shown = check_marks.note(check_marks.from_mesh(results))
    if shown:
        data["viewport"] = shown
    return {"data": data}


# ---------------------------------------------------------------------------
# UVs.

def _png(rgb: np.ndarray) -> bytes:
    """Encode an (h, w, 3) uint8 array as PNG, no dependencies."""
    h, w, _ = rgb.shape
    raw = b"".join(b"\x00" + rgb[y].tobytes() for y in range(h))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _raster_tris(uv_tris, size, island_of, colors, image, count):
    """Fill UV triangles into ``image`` (island colours) and ``count`` (coverage per pixel)."""
    for t, tri in enumerate(uv_tris):
        p = tri * (size - 1)
        x0, y0 = np.floor(p.min(axis=0)).astype(int)
        x1, y1 = np.ceil(p.max(axis=0)).astype(int)
        x0, y0 = max(x0, 0), max(y0, 0)
        x1, y1 = min(x1, size - 1), min(y1, size - 1)
        if x1 < x0 or y1 < y0:
            continue
        xs, ys = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        (ax, ay), (bx, by), (cx, cy) = p
        den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
        if abs(den) < 1e-12:
            continue
        w1 = ((by - cy) * (xs - cx) + (cx - bx) * (ys - cy)) / den
        w2 = ((cy - ay) * (xs - cx) + (ax - cx) * (ys - cy)) / den
        inside = (w1 >= 0) & (w2 >= 0) & (w1 + w2 <= 1)
        if not inside.any():
            continue
        yy, xx = np.nonzero(inside)
        yy, xx = yy + y0, xx + x0
        count[yy, xx] += 1
        image[size - 1 - yy, xx] = colors[island_of[t] % len(colors)]


@tool("inspect_uv",
      "Check a mesh's UV map (changes nothing): islands, how much of the 0-1 square is used, "
      "faces outside it, overlapping areas, stretch (UV vs surface area spread) and texel "
      "density spread. Returns a picture of the layout with islands coloured and overlaps "
      "in white.",
      {"name": {"type": "string"}, "uv_layer": {"type": "string"},
       "image_size": {"type": "integer", "minimum": 128, "maximum": 1024, "default": 512},
       "intent": {"type": "array", "items": {"type": "string", "enum": sorted(INTENTS)},
                  "description": "Deliberate traits for this check only (mark_intent stores them)."}},
      required=("name",))
def inspect_uv(args):
    ob = get_object(args["name"])
    if ob.type != 'MESH':
        raise ToolError("{!r} is not a mesh.".format(ob.name))
    me = ob.data
    if not me.uv_layers:
        raise ToolError("{!r} has no UV map. Unwrap it first.".format(ob.name))
    layer = me.uv_layers.get(args["uv_layer"]) if args.get("uv_layer") else me.uv_layers.active
    if layer is None:
        raise ToolError("No UV map {!r}; maps: {}.".format(args["uv_layer"], [u.name for u in me.uv_layers]))
    if len(me.polygons) > 200_000:
        raise ToolError("Too many faces for the UV check ({}).".format(len(me.polygons)))

    me.calc_loop_triangles()
    n_tri = len(me.loop_triangles)
    loops = np.empty(n_tri * 3, dtype=np.int64)
    me.loop_triangles.foreach_get("loops", loops)
    tri_poly = np.empty(n_tri, dtype=np.int64)
    me.loop_triangles.foreach_get("polygon_index", tri_poly)
    uv = np.empty(len(me.loops) * 2, dtype=np.float64)
    layer.uv.foreach_get("vector", uv)
    uv = uv.reshape(-1, 2)
    uv_tris = uv[loops].reshape(-1, 3, 2)
    vidx = np.empty(len(me.loops), dtype=np.int64)
    me.loops.foreach_get("vertex_index", vidx)
    co = np.empty(len(me.vertices) * 3)
    me.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3) * np.array(ob.scale)
    xyz_tris = co[vidx[loops]].reshape(-1, 3, 3)

    uv_area = 0.5 * np.abs(np.cross(uv_tris[:, 1] - uv_tris[:, 0], uv_tris[:, 2] - uv_tris[:, 0]))
    xyz_area = 0.5 * np.linalg.norm(np.cross(xyz_tris[:, 1] - xyz_tris[:, 0], xyz_tris[:, 2] - xyz_tris[:, 0]), axis=1)
    valid = xyz_area > 1e-12
    density = np.sqrt(uv_area[valid] / xyz_area[valid])
    zero_uv = int((uv_area[valid] < 1e-12).sum())
    nz = density[density > 0]
    spread = float(np.percentile(nz, 95) / np.percentile(nz, 5)) if len(nz) > 10 else 1.0

    # Islands: polygons joined by shared UV-space edges.
    parent = list(range(len(me.polygons)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    edge_owner = {}
    for poly in me.polygons:
        ls = list(poly.loop_indices)
        for a, b in zip(ls, ls[1:] + ls[:1]):
            va, vb = vidx[a], vidx[b]
            key = (min(va, vb), max(va, vb),
                   tuple(np.round(uv[a if va < vb else b], 5)), tuple(np.round(uv[b if va < vb else a], 5)))
            other = edge_owner.setdefault(key, poly.index)
            if other != poly.index:
                parent[find(other)] = find(poly.index)
    roots = {}
    island_of_poly = [roots.setdefault(find(i), len(roots)) for i in range(len(me.polygons))]
    island_of_tri = [island_of_poly[p] for p in tri_poly]

    size = int(args.get("image_size", 512))
    image = np.full((size, size, 3), 34, dtype=np.uint8)
    image[:, ::max(1, size // 8)] = 60
    image[::max(1, size // 8), :] = 60
    count = np.zeros((size, size), dtype=np.int32)
    rng = np.random.default_rng(1)
    colors = (rng.uniform(70, 230, size=(64, 3))).astype(np.uint8)
    inside_tris = uv_tris.clip(0, 1)
    _raster_tris(inside_tris, size, island_of_tri, colors, image, count)
    overlap_px = count > 1
    image[size - 1 - np.nonzero(overlap_px)[0], np.nonzero(overlap_px)[1]] = 255
    covered = count > 0
    out_of_bounds = int(((uv_tris < -1e-4) | (uv_tris > 1 + 1e-4)).any(axis=(1, 2)).sum())

    intents = intents_of(ob, args.get("intent", ()))
    findings = []
    overlap_frac = float(overlap_px.sum() / max(covered.sum(), 1))
    looks_tiling = out_of_bounds > 0.25 * max(n_tri, 1)
    tiling_hint = (None if intents & {"tiling_uv", "overlapping_uv"} else
                   "This looks like a tiling layout; if it is deliberate, mark_intent(objects=[{!r}], "
                   "intent=[\"tiling_uv\"]).".format(ob.name)) if looks_tiling else None
    if overlap_frac > 0.01:
        findings.append(_finding("uv_overlap", "warning",
                                 "{:.0%} of the used UV area overlaps (fine only for mirrored/stacked islands)"
                                 .format(overlap_frac), intents, ("tiling_uv", "overlapping_uv"), hint=tiling_hint))
    if out_of_bounds:
        findings.append(_finding("uv_outside", "warning", "{} triangles outside the 0-1 square".format(out_of_bounds),
                                 intents, ("tiling_uv",), hint=tiling_hint))
    if zero_uv:
        findings.append(_finding("uv_collapsed", "warning",
                                 "{} triangles with zero UV area (collapsed)".format(zero_uv), intents))
    if spread > 4:
        findings.append(_finding("uv_density", "warning" if spread > 8 else "note",
                                 "texel density varies {:.1f}x across the mesh (stretched or uneven)".format(spread),
                                 intents))
    issues, ok = _summarise(findings)
    data = {
        "name": ob.name, "uv_layer": layer.name, "islands": len(roots),
        "coverage": r(covered.mean(), 3), "overlap_fraction": r(overlap_frac, 3),
        "out_of_bounds_tris": out_of_bounds, "density_spread_p95_p5": r(spread, 2),
        "findings": findings, "issues": issues, "ok": ok, "intent": sorted(intents),
        "image": "islands coloured, overlaps white, grid = 1/8 tiles",
    }
    return {"data": data, "images": [_png(image)]}


@tool("mark_intent",
      "Record what is deliberate about objects, so checks report it as expected instead of a problem "
      "(stored on the object as the custom property agent_intent; undoable). intent: " +
      "; ".join("{} = {}".format(k, v) for k, v in sorted(INTENTS.items())) +
      ". replace=true sets exactly these; clear=true removes all.",
      {"objects": {"type": "array", "minItems": 1, "maxItems": 64, "items": {"type": "string"}},
       "intent": {"type": "array", "items": {"type": "string", "enum": sorted(INTENTS)}, "default": []},
       "replace": {"type": "boolean", "default": False},
       "clear": {"type": "boolean", "default": False}},
      required=("objects",), mutating=True)
def mark_intent(args):
    out = {}
    for name in args["objects"]:
        ob = get_object(name)
        if args.get("clear"):
            new = set()
        elif args.get("replace"):
            new = set(args.get("intent", []))
        else:
            new = intents_of(ob, args.get("intent", []))
        unknown = new - set(INTENTS)
        if unknown:
            raise ToolError("Unknown intent {}; known: {}.".format(sorted(unknown), ", ".join(sorted(INTENTS))))
        if new:
            ob[_INTENT_PROP] = ",".join(sorted(new))
        elif _INTENT_PROP in ob:
            del ob[_INTENT_PROP]
        out[ob.name] = sorted(new)
    return {"data": {"intent": out}}
