# SPDX-License-Identifier: GPL-3.0-or-later
"""
Preview renders made for checking work: pick a view, isolate objects, get an
image plus the numbers behind it. Every setting touched is restored after.
"""

import math
import os
import tempfile

import bpy
from mathutils import Vector

from . import cancel
from .registry import ToolError, bounds_dict, get_object, r, tool, vec, world_bounds

_RENDER_TIMEOUT_S = 300

_TEMP_CAM = "__agent_view_cam"
_VIEW_DIRS = {
    "hero": Vector((1.0, -1.25, 0.8)),   # 3/4 from front-right, slightly above.
    "front": Vector((0.0, -1.0, 0.0)),
    "back": Vector((0.0, 1.0, 0.0)),
    "left": Vector((-1.0, 0.0, 0.0)),
    "right": Vector((1.0, 0.0, 0.0)),
    "top": Vector((0.0, 0.0, 1.0)),
}
_RENDERABLE = {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META', 'CURVES', 'POINTCLOUD', 'VOLUME', 'GREASEPENCIL'}


def _targets(scene, names):
    if names:
        obs = [get_object(n) for n in names]
        # A focused parent brings its children along.
        out = []
        for ob in obs:
            out.append(ob)
            out.extend(c for c in ob.children_recursive if c.type in _RENDERABLE)
        return list(dict.fromkeys(out))
    return [ob for ob in scene.objects if ob.type in _RENDERABLE and ob.visible_get() and not ob.hide_render]


def _union_bounds(obs, dg):
    lo = hi = None
    for ob in obs:
        b = world_bounds(ob, dg)
        if b is None:
            continue
        lo = b[0].copy() if lo is None else Vector(map(min, lo, b[0]))
        hi = b[1].copy() if hi is None else Vector(map(max, hi, b[1]))
    return (lo, hi) if lo is not None else None


class _Restore:
    """Remember attributes and put them back, newest first."""

    def __init__(self):
        self._saved = []

    def set(self, owner, attr, value):
        self._saved.append((owner, attr, getattr(owner, attr)))
        setattr(owner, attr, value)

    def restore(self):
        for owner, attr, value in reversed(self._saved):
            try:
                setattr(owner, attr, value)
            except Exception:
                pass


def _make_camera(scene, view, center, radius, aspect, direction=None):
    """A camera framing a sphere; `direction` (towards the camera) overrides the view's, as a
    turntable's views do (perspective, like hero)."""
    cam_data = bpy.data.cameras.new(_TEMP_CAM)
    cam_ob = bpy.data.objects.new(_TEMP_CAM, cam_data)
    scene.collection.objects.link(cam_ob)
    direction = (Vector(direction) if direction is not None else _VIEW_DIRS[view]).normalized()
    cam_data.clip_start = max(0.001, radius * 0.01)
    cam_data.clip_end = radius * 100 + 100
    if view == "hero":
        cam_data.lens = 50
        # Blender fits the sensor to the wider side, so the narrow side limits framing.
        fov = 2 * math.atan(cam_data.sensor_width / (2 * cam_data.lens))
        fov_narrow = fov if aspect <= 1 else 2 * math.atan(math.tan(fov / 2) / aspect)
        dist = radius / math.sin(fov_narrow / 2) * 1.05
    else:
        cam_data.type = 'ORTHO'
        cam_data.ortho_scale = radius * 2.2 * max(aspect, 1 / aspect)
        dist = radius * 4
    cam_ob.location = center + direction * dist
    if view == "top":
        cam_ob.rotation_euler = (0.0, 0.0, 0.0)  # Looking straight down, +Y up in frame.
    else:
        cam_ob.rotation_euler = (-direction).to_track_quat('-Z', 'Y').to_euler()
    return cam_ob


@tool("render_view",
      "Render a check image of the scene and return it with the numbers behind it. "
      "view: camera (the scene camera), hero (3/4 overview), top, front, back, left, right. "
      "focus_objects isolates named objects (children included) and frames them; "
      "focus_point + focus_radius frames a close-up. look: solid (fast neutral studio "
      "lighting with cavity, best for checking shape) or lit (EEVEE with the scene's own "
      "lights and world). Settings are restored afterwards; the file is not changed. "
      "Every image stays in your context: the 768x576 default is enough for checks; go "
      "larger only to read fine detail, and prefer a focus close-up to a bigger render.",
      {"view": {"type": "string", "enum": ["camera", *_VIEW_DIRS], "default": "hero"},
       "focus_objects": {"type": "array", "items": {"type": "string"}, "maxItems": 64},
       "focus_point": {"type": "array", "items": {"type": "number"}, "minItems": 3, "maxItems": 3},
       "focus_radius": {"type": "number", "minimum": 0.001, "default": 1.0},
       "look": {"type": "string", "enum": ["solid", "lit"], "default": "solid"},
       "width": {"type": "integer", "minimum": 64, "maximum": 2048, "default": 768},
       "height": {"type": "integer", "minimum": 64, "maximum": 2048, "default": 576}})
def render_view(args):
    scene = bpy.context.scene
    dg = bpy.context.evaluated_depsgraph_get()
    view = args.get("view", "hero")
    look = args.get("look", "solid")
    width, height = int(args.get("width", 768)), int(args.get("height", 576))
    focus = args.get("focus_objects") or []
    targets = _targets(scene, focus)
    if not targets and view != "camera":
        raise ToolError("Nothing visible to render.")

    if args.get("focus_point"):
        center = Vector(args["focus_point"])
        radius = float(args.get("focus_radius", 1.0))
        bounds = (center - Vector((radius,) * 3), center + Vector((radius,) * 3))
    else:
        bounds = _union_bounds(targets, dg)
        if bounds is None:
            raise ToolError("The objects have no extent to frame.")
        center = (bounds[0] + bounds[1]) / 2
        radius = max((bounds[1] - bounds[0]).length / 2, 0.01)

    restore = _Restore()
    cam_ob = None
    out_path = os.path.join(tempfile.gettempdir(), "agent_view_{}.png".format(os.getpid()))
    try:
        if view == "camera":
            if scene.camera is None:
                raise ToolError("The scene has no camera; use view='hero' or add one.")
        else:
            cam_ob = _make_camera(scene, view, center, radius, width / height, args.get("_direction"))
            restore.set(scene, "camera", cam_ob)

        if focus:
            keep = set(targets)
            for ob in scene.objects:
                if ob.type in _RENDERABLE and ob not in keep and not ob.hide_render:
                    restore.set(ob, "hide_render", True)

        rd = scene.render
        restore.set(rd, "resolution_x", width)
        restore.set(rd, "resolution_y", height)
        restore.set(rd, "resolution_percentage", 100)
        restore.set(rd, "filepath", out_path)
        restore.set(rd, "use_file_extension", True)
        restore.set(rd.image_settings, "file_format", 'PNG')
        restore.set(rd.image_settings, "color_mode", 'RGB')
        restore.set(rd, "film_transparent", False)
        if look == "solid":
            restore.set(rd, "engine", 'BLENDER_WORKBENCH')
            sh = scene.display.shading
            restore.set(sh, "light", 'STUDIO')
            restore.set(sh, "color_type", 'MATERIAL')
            restore.set(sh, "show_cavity", True)
            restore.set(sh, "show_object_outline", True)
            restore.set(sh, "show_shadows", False)
        else:
            if rd.engine not in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT', 'CYCLES'}:
                restore.set(rd, "engine", 'BLENDER_EEVEE')
            if rd.engine == 'CYCLES':
                restore.set(scene.cycles, "samples", min(scene.cycles.samples, 32))

        try:
            with cancel.running("rendering a check view", _RENDER_TIMEOUT_S):
                bpy.ops.render.render(write_still=True)
        except cancel.AgentStopped:
            raise ToolError("Render stopped: {}.".format(cancel.last_reason() or "stopped"))
        with open(out_path, "rb") as fh:
            png = fh.read()
    finally:
        restore.restore()
        if cam_ob is not None:
            cam_data = cam_ob.data
            bpy.data.objects.remove(cam_ob)
            bpy.data.cameras.remove(cam_data)
        try:
            os.remove(out_path)
        except OSError:
            pass

    shown = []
    for ob in targets[:40]:
        b = world_bounds(ob, dg)
        if b is not None:
            shown.append({"name": ob.name, "bounds": bounds_dict(b)})
    data = {
        "view": view, "look": look, "size": [width, height],
        "frame_center": vec(center), "frame_radius_m": r(radius),
        "framed_bounds": bounds_dict(bounds),
        "objects": shown,
    }
    if len(targets) > 40:
        data["objects_truncated"] = len(targets) - 40
    return {"data": data, "images": [png]}
