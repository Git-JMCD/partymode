# SPDX-License-Identifier: GPL-3.0-or-later
"""
Tool registry and shared helpers.

A tool handler runs on Blender's main thread and returns a dict:
    {"data": <JSON-friendly>, "text": str?, "images": [png bytes]?, "isError": bool?}
Mutating tools additionally get a receipt, a change report, an undo step and a
history entry from the server; handlers just make the edit.
"""

from typing import Callable, NamedTuple

import bpy
from mathutils import Vector


class Tool(NamedTuple):
    name: str
    description: str
    schema: dict
    fn: Callable
    mutating: bool
    # Wrap the call in a named undo step (off for tools that walk the undo stack themselves).
    push_undo: bool
    # Run on Blender's main thread (all bpy work). Off only for tools that must answer
    # while the main thread is busy, such as `stop`.
    on_main: bool
    # Optional slow, bpy-free work (downloads) run on the server thread before ``fn``;
    # takes the args and returns them, possibly with more keys (e.g. local file paths).
    prepare: Callable | None


TOOLS: "dict[str, Tool]" = {}


def tool(name: str, description: str, properties: dict | None = None,
         required: tuple = (), mutating: bool = False, push_undo: bool | None = None,
         on_main: bool = True, prepare: Callable | None = None):
    schema = {"type": "object", "properties": dict(properties or {}), "additionalProperties": False}
    if required:
        schema["required"] = list(required)
    if mutating:
        schema["properties"]["call_id"] = {
            "type": "string",
            "description": "Optional idempotency key. Re-sending a call with the same call_id "
                           "returns the first result and never runs the edit twice.",
        }
        schema["properties"]["label"] = {
            "type": "string", "description": "Short name for this edit (undo step and history).",
        }

    def deco(fn):
        TOOLS[name] = Tool(name, description, schema, fn, mutating,
                           mutating if push_undo is None else push_undo, on_main, prepare)
        return fn
    return deco


class ToolError(Exception):
    """An error the agent should see as a plain message (no traceback)."""


# ---------------------------------------------------------------------------
# Helpers shared by tools.

def r(v, nd=4):
    return round(float(v), nd)


def vec(v, nd=4):
    return [r(x, nd) for x in v]


def get_object(name: str):
    ob = bpy.data.objects.get(name)
    if ob is None:
        close = [n for n in bpy.data.objects.keys() if name.lower() in n.lower()][:8]
        hint = " Similar: {}".format(", ".join(close)) if close else ""
        raise ToolError("No object named {!r}.{}".format(name, hint))
    return ob


def world_bounds(ob, depsgraph=None):
    """Axis-aligned world bounds of the evaluated object, or None for objects without extent."""
    if ob.type not in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META', 'CURVES', 'POINTCLOUD', 'VOLUME',
                       'GREASEPENCIL', 'ARMATURE', 'LATTICE'}:
        return None
    if depsgraph is None:
        depsgraph = bpy.context.evaluated_depsgraph_get()
    ob_eval = ob.evaluated_get(depsgraph)
    mw = ob_eval.matrix_world
    corners = [mw @ Vector(c) for c in ob_eval.bound_box]
    lo = Vector((min(c.x for c in corners), min(c.y for c in corners), min(c.z for c in corners)))
    hi = Vector((max(c.x for c in corners), max(c.y for c in corners), max(c.z for c in corners)))
    return lo, hi


def bounds_dict(b):
    if b is None:
        return None
    lo, hi = b
    return {"min": vec(lo), "max": vec(hi), "size": vec(hi - lo)}


def ui_override():
    """A context override with a window (and a 3D view when one is open)."""
    wm = bpy.context.window_manager
    if wm is None or not wm.windows:
        return {}
    window = wm.windows[0]
    override = {"window": window, "screen": window.screen}
    for area in window.screen.areas:
        if area.type == 'VIEW_3D':
            region = next((rg for rg in area.regions if rg.type == 'WINDOW'), None)
            override.update(area=area, region=region)
            break
    return override
