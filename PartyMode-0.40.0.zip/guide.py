# SPDX-License-Identifier: GPL-3.0-or-later
"""How to work in this build: sent as MCP instructions and served by `agent_guide`."""

from .registry import ToolError, tool

INSTRUCTIONS = """\
PartyMode: Blender with an agent built in. You drive the user's open Blender.

Loop: look, edit in small steps, check, then report only what you have checked.
1. Look: scene_overview first, then scene_hierarchy or object_details.
2. Edit: run_python, one part or change per call, real sizes in metres, exact names,
   print() what you need to confirm. Use `steps` for long edits.
3. Every edit returns `changes` (objects created / modified with which fields /
   deleted, data created or edited) and is one named undo step; `undo` reverts it.
4. Check: render_view to see it (focus_objects to isolate), inspect_geometry to
   prove parts rest on, touch or clear each other, inspect_mesh for mesh health. A
   failure is a claim: read its evidence before fixing, then re-check.
5. Timeouts: an edit may still finish. Call call_status(call_id) or re-send the
   same call with the same call_id; never send it again with a new id. If
   call_status says blender_busy.stuck, stop polling and tell the user.
   timeout_s, stop and Escape only interrupt Python, never a bpy.ops operator
   mid-run: quad-remesh with remesh_asset, never bpy.ops QuadriFlow.
6. history shows what the user did by hand. A message about marked areas (mark 1...):
   view_marks first; about attached Sandbox items (s1...): view_sandbox.
7. House rules (scene_overview.house_rules) are the user's standing preferences: follow
   them. Add one only when the user asks (add_rule).
8. Before risky work: checkpoint. Unsure about a change: try_edit (before/after, measured).
9. Unsure of an API name: api_lookup (types, operators, a node's sockets and menu choices).
   A failed run_python on an API mistake comes with `hint`: read it before trying again.
10. Other agents may be working here too: scene_overview.agents says who; claims stop
   edits to what another agent is working on (ask them with post_note).
11. Feedback about this add-on itself (a bug, an idea): feedback_add keeps it outside the
   scene for its developers.
More: agent_guide(topic): tools (which tool for what: Sandbox, research, cleanup,
animation, lighting, remesh, export, materials), agents, build, check, materials, recovery.
"""

_TOOLS = """\
# Which tool for what
- Sandbox (sandbox): the file's shared board of references, SVG logos, notes and renders.
  sandbox_use turns an item into a plane, a 3D logo or a palette; pin renders worth keeping
  with sandbox_add; sandbox_arrange moves cards (nearby cards belong together).
- Reference pictures: search_images (openly licensed, the user is asked first), then
  sandbox_add url=... with credit, license and source.
- A messy or heavy file: inspect_scene, then clean_scene (one undo step).
- Mesh problems: inspect_mesh / inspect_uv (graded error, warning, note); mark_intent records
  what is deliberate (open_shell, tiling_uv...); repair_mesh fixes the rest (one undo step).
- Props: search_assets (free CC0 Poly Haven) or generate_3d (the user's own GPU) before
  modelling from scratch; wait_for_job waits in one call (do not poll generation_status).
  A generated or scanned mesh to keep: remesh_asset (clean quads, detail baked into textures).
- An animation: inspect_animation (foot sliding, the loop seam, an in-place clip's travel speed).
- Review pictures: contact_sheet (a turntable, or a character across clips).
- Lighting: light_scene (studio, golden_hour, noon, overcast, night; light_from_deg says where
  it comes from, seen from the camera).
- Material looks: shade_wet, shade_dirt, shade_wear, shade_tint layer over what feeds the
  Principled BSDF (remove_shader_effect takes it out); describe_material reads one back.
- Delivery: export_asset (lods, collision; read material_notes: bake what the format drops).
- A final render: render_scene (in the background, lands in the Sandbox; wait_for_job waits).
"""

_AGENTS = """\
# Working with other agents
- Several agents can drive this Blender: terminal agents and the chat's agent. scene_overview
  .agents says who is here and what they changed; history names who made each edit; a reply's
  heads_up warns when you touch what another agent just changed.
- Working on something for a while with others around: claim_objects first, release_objects
  when done; a name with no object yet is reserved, so claim what you are about to build. An
  edit stopped by someone's claim: ask them (post_note) before sending it again.
- post_note / read_notes talk to them; chat_log reads Blender's chat.
- A team (the user ticked helpers in the chat's agent menu): the lead hands out tasks with
  team_assign and gets their reports in a review turn; a helper sticks to its task and objects.
  A helper does one task at a time: a task for a busy helper is queued and starts after it.
"""

_TOPICS = {
    "tools": _TOOLS,
    "agents": _AGENTS,
    "build": """\
# Building
- One part per run_python call; name every object you create and print its
  dimensions so the reply proves the size.
- Model at real scale in metres (a chair seat is ~0.45 m high, a door ~2.0 m).
- Parent parts of one asset under an empty or keep them in one collection.
- Prefer bmesh or data API for precise geometry; bpy.ops needs the right mode
  and selection, so set both explicitly.
- Check `changes` in every reply: an edit that reports nothing changed did
  nothing, whatever the script printed.
- Generated meshes (generate_3d, TripoSG, scans) come split along their UV seams into
  hundreds of pieces. remesh_asset welds, remeshes to quads, measures the new surface
  against the original (shape_vs_original in mm, folded_share) and bakes colour,
  roughness and normal. detail=simple (4000 faces) for plain props, detailed (12000)
  for carved ones. Fix the original's colours first: the bake copies them. Read the
  reply's warnings: thin walls (a bucket's) fold when remeshed; remesh one side and add
  Solidify, or model it. Then render_view look=lit to compare.
""",
    "check": """\
# Checking
- render_view look=solid shows shape plainly; look=lit shows the real lighting.
- view=hero for an overview, top for layout, front/left/right for alignment
  (orthographic, so heights can be compared by eye).
- inspect_geometry measures evaluated, world-space surfaces:
  rests_on fails when sunk in (penetration_m) or floating (min_distance_m);
  contact passes when touching or fused; clearance fails on any collision.
- A failed check comes with evidence: samples/of (how much failed), worst_points,
  bounds, failing_parts (which loose piece of the object), rest_of_object (does the
  rest pass) and look (a render_view close-up). A failure from one small piece (a
  bridge plank over a moat) is about that piece, not the whole object.
- Failed inspect_geometry checks and inspect_mesh holes are marked in the user's viewport (the
  reply's `viewport` says so): point the user at them; they clear when the check passes.
- inspect_mesh / inspect_uv grade findings error / warning / note; ok means no
  errors or warnings. Deliberate traits: mark_intent(objects, intent) with
  open_shell, multi_part, tiling_uv, overlapping_uv, mirrored, scaled; they then
  show as severity "expected".
- One passing check does not verify the whole build. Check every joint you made.
""",
    "materials": """\
# Materials
- describe_material first: it shows what feeds each input (n2.Color) and the values.
- shade_wet (water_line in world Z, or the whole surface), shade_dirt (creases, contact
  with what touches it, optional grime rising from the ground), shade_wear (convex
  edges), shade_tint (a palette as a gradient map). Each is one group node per
  Principled BSDF; calling again updates it; they stack tint > dirt > wear > wet.
- Dirt and wear bake a mask into the mesh (attributes agent_dirt / agent_wear) so they
  look the same in EEVEE, Cycles and exports. The reply's `baked` says how much of the
  mesh is masked and flags a mesh too coarse for the distance. After reshaping a mesh,
  pass rebake=true.
- A material shared with other objects is reported as also_changes; single_user=true
  gives these objects their own copy. materials=[...] limits which of an object's
  materials get the look (skip the water on a castle).
- Hand-wiring nodes: a Mix node has three sockets named A (float, vector, colour); pick
  by name, type and enabled, never by index.
""",
    "recovery": """\
# Recovery
- Mutating tools take call_id. Same call_id = same result, never a second run.
- A timeout does not mean failure: look at the scene, then call_status(call_id).
- call_status answers even while Blender is busy. blender_busy.stuck means the main
  thread is inside a Blender operator that ignored the stop and may never return:
  don't keep polling; tell the user they can wait or force-quit Blender.
- `undo` steps back one undo step at a time (agent edits are one step each).
  If the user has edited since, history shows it; ask before undoing past them.
""",
}


@tool("agent_guide",
      "How to work in this Blender build. topic: overview, build, check, materials, recovery.",
      {"topic": {"type": "string", "enum": ["overview", *_TOPICS], "default": "overview"}})
def agent_guide(args):
    topic = args.get("topic", "overview")
    if topic == "overview":
        return {"data": {"topic": topic, "text": INSTRUCTIONS, "topics": ["overview", *_TOPICS]}}
    if topic not in _TOPICS:
        raise ToolError("Unknown topic {!r}.".format(topic))
    return {"data": {"topic": topic, "text": _TOPICS[topic]}}
