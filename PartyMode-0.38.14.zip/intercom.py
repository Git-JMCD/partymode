# SPDX-License-Identifier: GPL-3.0-or-later
"""
Agents working in the same Blender, aware of each other.

Several agents can drive one Blender: Claude Code or Codex in a terminal, and the agent the
chat runs. This module gives them names and a way to talk:

- Who is who: each MCP client is named from its handshake (clientInfo) or, for the chat's own
  agent, from its connection address (`?client=chat-codex`). Every edit in `history` and every
  undo step carries that name.
- Notes: `post_note` leaves a message for the others (or one of them); `read_notes` reads what
  is waiting. A note for the chat's agent arrives with its next turn and shows in the chat.
- `chat_log` reads the conversation in Blender's chat; `scene_overview` says who else is around,
  whether the chat's agent is mid-turn, and what the others changed lately.
- Heads-up: an edit to something another agent changed in the last two minutes says so.
- Claims: `claim_objects` says "I'm working on the bucket". Another agent's edit that names a
  claimed object (or a run_python that mentions it in quotes) is stopped before it runs and told
  who claimed it and why; sending the same call again within two minutes goes ahead (it was
  warned). Claims cover the object's children, last 20 minutes unless renewed by the claimer's
  own edits, and end with release_objects.
"""

import json
import os
import threading
import time
import uuid

import bpy

from .registry import ToolError, tool

_lock = threading.Lock()
_sessions = {}     # MCP session id -> {"key", "label", "t"}
_seen = {}         # client key -> {"label", "t"} (last call)
_notes = []        # [{"id", "t", "from", "from_label", "to", "text", "read_by": [...]}]
_loaded = {"path": None}
_claims = {}       # object name -> {"by", "label", "why", "t", "until", "root"}
_warned = {}       # (client, tool, names) -> when it was stopped (a repeat within WARNED_S goes ahead)
CLAIM_MIN = 20
WARNED_S = 120
_MAX_NOTES = 200
HEADS_UP_S = 120

# Agent families, for colours and for addressing notes.
FAMILIES = ("claude", "codex", "opencode")


def family(key):
    k = (key or "").lower()
    return next((f for f in FAMILIES if f in k), "")


def label_for(key):
    """'claude-code' -> 'Claude Code', 'chat-codex' -> 'Codex (chat)', unknown -> as given."""
    k = (key or "").lower()
    if k == "ui":
        return "You (a chat button)"
    if k.startswith("chat-"):
        return {"claude": "Claude", "codex": "Codex", "opencode": "OpenCode"}.get(family(k), k[5:]) + " (chat)"
    if "claude" in k:
        return "Claude Code"
    if "codex" in k:
        return "Codex"
    if "opencode" in k:
        return "OpenCode"
    return key or "an agent"


# ---------------------------------------------------------------------------
# Who is calling.

def remember_session(session_id, client_info, query_client=None):
    name = query_client or (client_info or {}).get("name") or "agent"
    key = name.lower().replace(" ", "-")
    with _lock:
        _sessions[session_id] = {"key": key, "label": label_for(key), "t": time.time()}
    return key


def identify(session_id=None, query_client=None, user_agent=None):
    """The calling client's key: the chat's agents name themselves in the URL; others are
    known by the session their handshake started; failing that, by their User-Agent."""
    with _lock:
        known = _sessions.get(session_id or "")
    if query_client:
        key = query_client.lower()
    elif known:
        key = known["key"]
    else:
        # No handshake (a health check, a quick script): it can still call tools, but it is
        # not listed as another agent.
        return (user_agent or "agent").split("/")[0].lower() or "agent"
    with _lock:
        _seen[key] = {"label": label_for(key), "t": time.time()}
    return key


def others_seen(me, within_s=600):
    now = time.time()
    with _lock:
        return [{"client": v["label"], "family": family(k), "last_call_s": round(now - v["t"])}
                for k, v in sorted(_seen.items(), key=lambda kv: -kv[1]["t"])
                if k != me and now - v["t"] < within_s]


# ---------------------------------------------------------------------------
# Notes.

def _path():
    return os.path.join(bpy.utils.user_resource('CONFIG', path="agent_bridge", create=True), "notes.json")


def _load():
    path = _path()
    if _loaded["path"] == path:
        return
    try:
        with open(path, encoding="utf-8") as fh:
            _notes[:] = json.load(fh)[-_MAX_NOTES:]
    except (OSError, ValueError, TypeError):
        _notes[:] = []
    _loaded["path"] = path


def _save():
    try:
        tmp = _path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(_notes[-_MAX_NOTES:], fh, indent=1)
        os.replace(tmp, _path())
    except OSError:
        pass


def _for(note, me):
    """Is this note for client `me` (and not from it)?"""
    if note["from"] == me:
        return False
    to = note.get("to") or "all"
    if to == "all":
        return True
    if to == "chat":
        return me.startswith("chat-")
    return family(me) == to or me == to


NOTE_MAX_AGE_S = 24 * 3600  # older notes nobody read are not passed on
NOTES_AT_ONCE = 12


def post(sender, text, to="all", about=None):
    """A note; `about` marks a claim notice ({"claim": root}) so it can be dropped once the claim ends."""
    text = (text or "").strip()
    if not text:
        raise ToolError("Write something in the note.")
    note = {"id": uuid.uuid4().hex[:8], "t": time.time(), "from": sender, "from_label": label_for(sender),
            "to": to, "text": text[:2000], "read_by": [sender]}
    if about:
        note["about"] = about
    with _lock:
        _load()
        _notes.append(note)
        _save()
    # The chat's agent hears it with its next turn; the chat shows it now.
    if not sender.startswith("chat-") and to in ("all", "chat") + FAMILIES:
        from . import chat
        chat.agent_note(note["from_label"], note["text"], family(sender))
    return note


def _stale(n, now, live):
    """A note not worth passing on: too old, a claim notice for a claim that has ended (or the
    matching release), or a claim notice another agent has since released."""
    if now - n["t"] > NOTE_MAX_AGE_S:
        return True
    about = n.get("about") or {}
    if "claim" in about:
        held = live.get(about["claim"])
        return held is None or held["by"] != n["from"]
    if "release" in about:
        return now - n["t"] > 3600
    return False


def unread(me, mark=True):
    """Notes waiting for `me`, newest NOTES_AT_ONCE, without stale ones or repeats (the same text
    from the same agent comes once). All of them count as read afterwards."""
    now = time.time()
    with _lock:
        _load()
        live = dict(_active())
        waiting_ = [n for n in _notes if _for(n, me) and me not in n["read_by"]]
        seen, out = set(), []
        for n in reversed(waiting_):
            key = (n["from"], n["text"])
            if key in seen or _stale(n, now, live):
                continue
            seen.add(key)
            out.append(n)
        out = list(reversed(out[:NOTES_AT_ONCE]))
        if mark and waiting_:
            for n in waiting_:
                n["read_by"].append(me)
            _save()
    return out


def waiting(me):
    return len(unread(me, mark=False))


def _public(n):
    return {"id": n["id"], "from": n["from_label"], "to": n.get("to", "all"), "text": n["text"],
            "ago_s": round(time.time() - n["t"])}


# ---------------------------------------------------------------------------
# What the others did.

def recent_by_others(me, within_s=600, limit=12):
    from . import history
    now = time.time()
    out = []
    for e in history.events(200, by="agent"):
        if e.get("client", "agent") == me or now - e["t"] > within_s:
            continue
        changed = e.get("changes") or {}
        if not e.get("objects") and not any(changed.values()):
            continue  # looked, changed nothing
        out.append({"client": label_for(e.get("client")), "label": e.get("label"), "tool": e.get("tool"),
                    "objects": e.get("objects", [])[:8], "ago_s": round(now - e["t"])})
        if len(out) >= limit:
            break
    return out


def heads_up(me, objects):
    """Objects in `objects` that another agent changed in the last HEADS_UP_S seconds."""
    if not objects:
        return []
    from . import history
    now = time.time()
    mine = set(objects)
    notes = {}
    for e in history.events(200, by="agent"):
        if e.get("client", "agent") == me or now - e["t"] > HEADS_UP_S:
            continue
        for ob in set(e.get("objects", [])) & mine:
            notes.setdefault(ob, "{} changed {} {} s ago ({})".format(
                label_for(e.get("client")), ob, round(now - e["t"]), e.get("label") or e.get("tool")))
    return list(notes.values())[:8]


# ---------------------------------------------------------------------------
# Claims.

def _active():
    now = time.time()
    for name in [n for n, c in _claims.items() if c["until"] < now]:
        del _claims[name]
    return _claims


def claims_by_others(me):
    with _lock:
        return {n: dict(c) for n, c in _active().items() if c["by"] != me}


def targets(names):
    """Names to claim -> ({root: [root, child, ...]}, planned): a name with no object yet is
    reserved as it is, so a teammate can claim what it is about to build."""
    import bpy
    out, planned = {}, []
    for n in names:
        ob = bpy.data.objects.get(n)
        if ob is None:
            out[n] = [n]
            planned.append(n)
        else:
            out[ob.name] = [ob.name] + [c.name for c in ob.children_recursive]
    return out, planned


def claim(me, names, why, minutes):
    """names: {root: [root, child, ...]}. Returns (claimed roots, refused)."""
    now = time.time()
    until = now + minutes * 60
    claimed, refused = [], []
    with _lock:
        live = _active()
        for root, covered in names.items():
            held = next((live[n] for n in covered if n in live and live[n]["by"] != me), None)
            if held:
                refused.append({"object": root, "claimed_by": held["label"], "why": held["why"],
                                "for_another_min": round((held["until"] - now) / 60, 1)})
                continue
            for n in covered:
                live[n] = {"by": me, "label": label_for(me), "why": why, "t": now, "until": until, "root": root}
            claimed.append(root)
    return claimed, refused


def release(me, roots=None):
    """End `me`'s claims (all, or those on the roots named); returns the roots released."""
    with _lock:
        live = _active()
        gone = [n for n, c in live.items() if c["by"] == me and (roots is None or c["root"] in roots)]
        released = sorted({live[n]["root"] for n in gone})
        for n in gone:
            del live[n]
    return released


def renew(me, objects):
    """The claimer's own edits keep its claim alive."""
    if not objects:
        return
    with _lock:
        live = _active()
        roots = {live[n]["root"] for n in objects if n in live and live[n]["by"] == me}
        if roots:
            until = time.time() + CLAIM_MIN * 60
            for c in live.values():
                if c["by"] == me and c["root"] in roots:
                    c["until"] = max(c["until"], until)


def names_in(args):
    """Every string in a tool's arguments (lists and nested ones too): names it may act on."""
    out = set()
    for k, v in args.items():
        if k.startswith("_") or k in ("label", "call_id", "code", "steps"):
            continue
        if isinstance(v, str):
            out.add(v)
        elif isinstance(v, (list, tuple)):
            out.update(x for x in v if isinstance(x, str))
            for x in v:
                if isinstance(x, dict):
                    out.update(names_in(x))
        elif isinstance(v, dict):
            out.update(names_in(v))
    return out


def _mentioned(code, names):
    return {n for n in names if "'{}'".format(n) in code or '"{}"'.format(n) in code}


def stop_for_claims(me, tool, args):
    """Before an edit: an error result naming the claims it would cross, or None to go ahead."""
    others = claims_by_others(me)
    if not others:
        return None
    hit = names_in(args) & set(others)
    code = "\n".join([args.get("code") or ""] + list(args.get("steps") or []))
    if code.strip():
        hit |= _mentioned(code, set(others))
    if not hit:
        return None
    key = (me, tool, json.dumps({k: v for k, v in args.items() if not k.startswith("_") and k not in ("label", "call_id")},
                               sort_keys=True, default=str))
    now = time.time()
    with _lock:
        for k in [k for k, t in _warned.items() if now - t > WARNED_S]:
            del _warned[k]
        if key in _warned:
            del _warned[key]
            return None  # warned already: the repeat goes ahead
        _warned[key] = now
    by_root = {}
    for n in sorted(hit):
        c = others[n]
        by_root.setdefault((c["root"], c["label"], c["why"]), c["until"])
    lines = ["{} is claimed by {}{} ({} min left)".format(root, label, ": " + why if why else "",
                                                         round((until - now) / 60, 1))
             for (root, label, why), until in by_root.items()]
    return {"data": {"error": "Not run: " + "; ".join(lines) + ". Ask them first (post_note), or work on "
                              "something else. If you only read it, or they agreed, send the same call again "
                              "within 2 minutes and it goes ahead.",
                     "claimed": [{"object": root, "by": label, "why": why} for (root, label, why) in by_root]},
            "isError": True}


def claims_overview(me):
    with _lock:
        live = _active()
        roots = {}
        for c in live.values():
            roots.setdefault((c["root"], c["by"]), c)
        now = time.time()
        return [{"object": root, "by": "you" if by == me else c["label"], "why": c["why"],
                 "min_left": round((c["until"] - now) / 60, 1)} for (root, by), c in sorted(roots.items())]


def chat_status():
    from . import chat
    live = chat.live()
    if not live:
        return {"busy": False}
    meta = chat.S.sessions.get(live["local_id"], {})
    return {"busy": True, "agent": label_for("chat-" + (live.get("runner") or "claude")),
            "activity": live.get("activity"), "chat": meta.get("title"),
            "for_s": round(time.time() - live.get("started", time.time()))}


def overview(me):
    """For scene_overview: who else is here and what they are doing."""
    out = {"you_are": label_for(me), "chat_agent": chat_status()}
    others = others_seen(me)
    if others:
        out["others"] = others
    recent = recent_by_others(me, within_s=600, limit=6)
    if recent:
        out["recent_by_others"] = recent
    n = waiting(me)
    if n:
        out["notes_waiting"] = "{} note(s) for you: read_notes".format(n)
    held = claims_overview(me)
    if held:
        out["claims"] = held
    return out


# ---------------------------------------------------------------------------
# Tools.

@tool("post_note",
      "Leave a note for the other agents working in this Blender (a terminal agent, the chat's "
      "agent): what you are doing, what to leave alone, a question. to: all, chat (the agent in "
      "Blender's chat; it gets the note with its next turn and the user sees it there), or claude, "
      "codex, opencode.",
      {"text": {"type": "string", "minLength": 1, "maxLength": 2000},
       "to": {"type": "string", "enum": ["all", "chat", *FAMILIES], "default": "all"}},
      required=("text",), on_main=False)
def post_note(args):
    note = post(args.get("_client", "agent"), args["text"], args.get("to", "all"))
    return {"data": {"posted": _public(note), "connected": others_seen(note["from"])}}


@tool("read_notes",
      "Notes other agents left for you (and for everyone), oldest first; marks them read. "
      "all=true also shows ones you have read (the last 30).",
      {"all": {"type": "boolean", "default": False}}, on_main=False)
def read_notes(args):
    me = args.get("_client", "agent")
    if args.get("all"):
        with _lock:
            _load()
            notes = [n for n in _notes if _for(n, me) or n["from"] == me][-30:]
        unread(me)
        return {"data": {"notes": [_public(n) for n in notes], "you_are": label_for(me)}}
    return {"data": {"notes": [_public(n) for n in unread(me)], "you_are": label_for(me),
                     "chat_agent": chat_status()}}


@tool("claim_objects",
      "Say you are working on objects (\"I'm working on the bucket\") so other agents are warned "
      "before they change them, not after: their edits that name a claimed object (or its "
      "children) are stopped once and told who claimed it and why. The other agents and the "
      "user's chat see the claim. Lasts `minutes` (default 20), renewed by your own edits of "
      "it; release_objects ends it. Claiming what another agent holds is refused. A name with no "
      "object yet is reserved: claim what you are about to build before you make it.",
      {"objects": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 32},
       "why": {"type": "string", "maxLength": 200, "description": "What you are doing, in a few words."},
       "minutes": {"type": "number", "minimum": 1, "maximum": 240, "default": CLAIM_MIN}},
      required=("objects",))
def claim_objects(args):
    me = args.get("_client", "agent")
    names, planned = targets(args["objects"])
    why = (args.get("why") or "").strip()
    minutes = float(args.get("minutes", CLAIM_MIN))
    claimed, refused = claim(me, names, why, minutes)
    if not claimed:
        raise ToolError("Already claimed: " + "; ".join("{} by {}{}".format(
            x["object"], x["claimed_by"], " (" + x["why"] + ")" if x["why"] else "") for x in refused)
            + ". Ask them with post_note.")
    them = "it" if len(claimed) == 1 else "them"
    post(me, "Working on {}{}: please leave {} alone until I release {}.".format(
        ", ".join(claimed), " (" + why + ")" if why else "", them, them), about={"claim": claimed[0]})
    data = {"claimed": claimed, "minutes": minutes, "claims": claims_overview(me)}
    reserved = [n for n in planned if n in claimed]
    if reserved:
        data["reserved"] = reserved
        data["note"] = ("No object has these names yet: they are reserved, so make them with exactly these "
                        "names (a typo here reserves nothing useful).")
    if refused:
        data["refused"] = refused
    return {"data": data}


@tool("release_objects",
      "End your claims (all of them, or on the objects named) so others can change them again.",
      {"objects": {"type": "array", "items": {"type": "string"}, "maxItems": 32}})
def release_objects(args):
    me = args.get("_client", "agent")
    gone = release(me, set(args["objects"]) if args.get("objects") else None)
    if gone:
        post(me, "Done with {}: free to change again.".format(", ".join(gone[:8])), about={"release": gone[:8]})
    return {"data": {"released": gone, "claims": claims_overview(me)}}


@tool("chat_log",
      "Read Blender's chat: what the user asked the agent in Blender and what it answered and did "
      "(tools, renders, the user's own chat actions). session: an id from the list (default: the "
      "most recent); last: how many entries.",
      {"session": {"type": "string"}, "last": {"type": "integer", "minimum": 1, "maximum": 200, "default": 30}},
      on_main=False)
def chat_log(args):
    from . import chat
    sessions = chat.list_sessions()
    if not sessions:
        return {"data": {"sessions": [], "note": "No chats yet."}}
    sid = args.get("session") or sessions[0]["id"]
    meta = next((s for s in sessions if s["id"] == sid), None)
    if meta is None:
        raise ToolError("No chat {!r}. Chats: {}.".format(sid, ", ".join(s["id"] for s in sessions[:10])))
    lines = []
    for e in chat.transcript(sid)[-int(args.get("last", 30)):]:
        role = e.get("role")
        if role in ("user", "assistant", "action", "note", "system"):
            who = {"user": "user", "assistant": "agent", "action": "user (chat action)", "system": "error"}.get(
                role, e.get("from", "note"))
            lines.append({"who": who, "text": e.get("text", "")[:1500]})
        elif role == "tool":
            lines.append({"who": "agent tool", "text": "{} {}".format(e.get("tool"), e.get("detail", "")).strip()})
        elif role == "meta":
            lines.append({"who": "turn end", "text": "{} {}s".format(e.get("model", ""), e.get("duration_s"))})
    return {"data": {"session": sid, "title": meta.get("title"), "agent": meta.get("runner"),
                     "entries": lines, "chat_agent": chat_status(),
                     "sessions": [{"id": s["id"], "title": s["title"], "turns": s.get("turns")} for s in sessions[:10]]}}
