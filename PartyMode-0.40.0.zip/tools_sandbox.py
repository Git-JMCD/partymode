# SPDX-License-Identifier: GPL-3.0-or-later
"""The Sandbox's tools: list, look, add (also from the web), search openly licensed images, use
(turn an item into something in the scene), remove. Anything that reaches the web asks the user
first (approvals.py)."""

import math
import os
import re
import tempfile
import threading

import bpy
from mathutils import Matrix, Vector

from . import approvals, board, sandbox, web
from .registry import ToolError, r, tool

_ITEM = {"type": "string", "description": "A Sandbox item id, like s3."}


def _item(item_id):
    it = sandbox.get(item_id)
    if it is None:
        ids = ", ".join(i["id"] for i in sandbox.items()) or "none"
        raise ToolError("No Sandbox item {!r} (items: {}).".format(item_id, ids))
    return it


def _public(it):
    out = {k: it.get(k) for k in ("id", "kind", "title", "by", "w", "h", "colors", "note", "svg_size",
                                  "source", "credit", "license") if it.get(k)}
    if it["kind"] == "svg":
        out["svg_chars"] = it.get("svg_chars")
    if it.get("pos"):
        w, h = board.card_size(it)
        out["board"] = {"x": it["pos"][0], "y": it["pos"][1], "w": round(w), "h": round(h)}
    return out


@tool("sandbox",
      "List the Sandbox: the shelf in this .blend where the user and agents keep references (images "
      "pasted from Figma, screenshots, photos), SVG logos, notes and pinned renders. Each item has an "
      "id (s1, s2...), kind (image, svg, note, render), title, size and main colours. Look with "
      "view_sandbox; use one in the scene with sandbox_use. Items sit on a board where the user "
      "arranges them: `board` is each card's place (x right, y down, top-left corner) and size, "
      "so nearby cards are usually meant together.")
def sandbox_list(args):
    its = sandbox.items()
    return {"data": {"items": [_public(i) for i in its], "count": len(its),
                     "note": "" if its else "The Sandbox is empty."}}


@tool("view_sandbox",
      "See Sandbox items: images, renders and SVG previews as pictures, SVGs also as text (up to "
      "4000 characters), notes as text. Up to 6 at a time.",
      {"items": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 6}},
      required=("items",))
def view_sandbox(args):
    out, images = [], []
    for item_id in args["items"]:
        it = _item(item_id)
        entry = _public(it)
        data = sandbox.png(it)
        if data is not None:
            images.append(data)
            entry["picture"] = len(images)
        if it["kind"] == "svg":
            svg = sandbox.svg_text(it)
            entry["svg"] = svg[:4000] + (" ...(cut)" if len(svg) > 4000 else "")
        out.append(entry)
    return {"data": {"items": out}, "images": images}


def _web_allowed(client):
    """Our web tools follow the Research preference; a chat turn that uses them has used the web."""
    from . import chat
    if chat.S.research_mode == "OFF":
        raise ToolError("Web use is off in the add-on preferences (Research: Off).")
    if (client or "").startswith("chat-"):
        chat._set_live(web_used=True)


def _prepare_add(args):
    """For a url: ask the user, then download it (server thread, before the Blender part)."""
    url = args.get("url")
    if not url:
        return args
    _web_allowed(args.get("_client"))
    ok, why = approvals.ask("pull", "pull a picture into the Sandbox", url, args.get("_client", "agent"))
    if not ok:
        raise ToolError(why)
    try:
        data, kind, ext, final = web.fetch_image(url)
    except web.WebError as ex:
        raise ToolError(str(ex)) from None
    if kind == "svg":
        args["_svg"] = data.decode("utf-8", "replace")
    else:
        fd, path = tempfile.mkstemp(suffix=ext, prefix="agent_web_")
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        args["_path"] = path
    args["_final_url"] = final
    return args


@tool("sandbox_add",
      "Put something in the Sandbox for the user to see and reuse: a note, an image file "
      "(image_path, e.g. a ComfyUI output), SVG text, a picture from the web (url: https, an image "
      "or SVG; the user is asked first; give credit, license and source, the page it came from), "
      "or a fresh render of the scene (render: the render_view arguments, e.g. "
      "{\"view\": \"hero\", \"look\": \"lit\"}). Pin renders worth keeping: a look the user liked, "
      "a before and after.",
      {"note": {"type": "string"}, "image_path": {"type": "string"}, "svg": {"type": "string"},
       "render": {"type": "object", "description": "render_view arguments."},
       "url": {"type": "string", "description": "An https address of an image or SVG to pull in."},
       "credit": {"type": "string", "description": "Who made it (for a picture from the web)."},
       "license": {"type": "string", "description": "Its licence, e.g. CC BY 4.0 (for a picture from the web)."},
       "source": {"type": "string", "description": "The page it came from (for a picture from the web)."},
       "title": {"type": "string"},
       "x": {"type": "number", "description": "Where on the board (optional; by default beside the rest)."},
       "y": {"type": "number"}},
      mutating=True, prepare=_prepare_add)
def sandbox_add(args):
    given = [k for k in ("note", "image_path", "svg", "render", "url") if args.get(k) is not None]
    if len(given) != 1:
        raise ToolError("Pass exactly one of note, image_path, svg, url or render.")
    title = args.get("title", "")
    by = "agent"
    if args.get("url"):
        try:
            if args.get("_svg"):
                it = sandbox.add_svg(args["_svg"], title or "Web SVG", by)
            else:
                it = sandbox.add_image_file(args["_path"], title, by)
        finally:
            if args.get("_path"):
                try:
                    os.remove(args["_path"])
                except OSError:
                    pass
        fields = {k: str(args[k])[:300] for k in ("credit", "license") if args.get(k)}
        fields["source"] = str(args.get("source") or args.get("_final_url") or args["url"])[:500]
        fields["url"] = str(args["url"])[:500]
        it = sandbox.update(it["id"], **fields)
    elif args.get("note") is not None:
        it = sandbox.add_note(args["note"], title, by)
    elif args.get("image_path"):
        it = sandbox.add_image_file(args["image_path"], title, by)
    elif args.get("svg"):
        it = sandbox.add_svg(args["svg"], title, by)
    else:
        from .tools_render import render_view
        res = render_view(dict(args["render"]))
        pics = res.get("images") or []
        if not pics:
            raise ToolError("The render made no picture.")
        it = sandbox.add_png(pics[0], title or "Render", by, kind="render")
    if args.get("x") is not None and args.get("y") is not None:
        board.move(it["id"], args["x"], args["y"], to_front=False)
    else:  # where the user is looking at the board, or beside the rest
        from . import ui_sandbox
        board.place_missing(ui_sandbox._S.get("last_center"))
    return {"data": {"added": _public(sandbox.get(it["id"]))}}


@tool("sandbox_arrange",
      "Move or resize cards on the Sandbox board, e.g. to group references by theme or line up a "
      "before and after. Board units are pixels at 100% zoom; x runs right, y down; x, y is a "
      "card's top-left corner; width is the card's width (90 to 900, height follows).",
      {"moves": {"type": "array", "minItems": 1, "maxItems": 40, "items": {
          "type": "object", "required": ["item"],
          "properties": {"item": _ITEM, "x": {"type": "number"}, "y": {"type": "number"},
                         "width": {"type": "number"}}}}},
      required=("moves",), mutating=True)
def sandbox_arrange(args):
    out = []
    for mv in args["moves"]:
        it = _item(mv["item"])
        x, y = mv.get("x"), mv.get("y")
        if (x is None) != (y is None):
            raise ToolError("Give both x and y for {} (or neither, to only resize).".format(it["id"]))
        if x is None and it.get("pos"):
            x, y = it["pos"]
        board.move(it["id"], x, y, width=mv.get("width"), to_front=False)
        out.append(_public(sandbox.get(it["id"])))
    return {"data": {"moved": out}}


def _prepare_search(args):
    q = (args.get("query") or "").strip()
    if not q:
        raise ToolError("Say what to look for (query).")
    _web_allowed(args.get("_client"))
    ok, why = approvals.ask("search", 'search Openverse for "{}"'.format(q[:80]),
                            "openly licensed pictures", args.get("_client", "agent"))
    if not ok:
        raise ToolError(why)
    try:
        results = web.search_images(q, "all" if args.get("license") == "any" else "commercial",
                                    args.get("count") or 8)
    except web.WebError as ex:
        raise ToolError(str(ex)) from None
    thumbs = [None] * len(results)

    def fetch(i, url):
        thumbs[i] = web.thumbnail(url) if url else None
    workers = [threading.Thread(target=fetch, args=(i, r["thumbnail"]), daemon=True) for i, r in enumerate(results)]
    for w in workers:
        w.start()
    for w in workers:
        w.join(25)
    args["_results"], args["_thumbs"] = results, thumbs
    return args


@tool("search_images",
      "Search openly licensed pictures (Openverse: Wikimedia Commons, Flickr, museums and more) for "
      "references, textures, logos and inspiration. The user is asked first. Returns small previews "
      "(numbered) with each picture's title, creator, licence and page. Pin the ones that fit with "
      "sandbox_add url=<url> credit=<creator> license=<license> source=<page>, grouped on the board. "
      "license: commercial (default: CC0, CC BY, CC BY-SA, public domain: fine for paid work with "
      "credit) or any.",
      {"query": {"type": "string"}, "count": {"type": "integer", "minimum": 1, "maximum": 12},
       "license": {"type": "string", "enum": ["commercial", "any"]}},
      required=("query",), prepare=_prepare_search)
def search_images(args):
    results, thumbs = args.get("_results") or [], args.get("_thumbs") or []
    images, out = [], []
    for r, t in zip(results, thumbs):
        entry = {k: r[k] for k in ("title", "creator", "license", "url", "page", "source", "width", "height") if r.get(k)}
        if t:
            images.append(t)
            entry["preview"] = len(images)
        out.append(entry)
    note = "" if out else "Nothing found: try other words."
    return {"data": {"query": args["query"], "results": out, "note": note}, "images": images}


@tool("web_permission",
      "Used by the chat itself (Claude Code's permission prompt): asks the user before a web search "
      "or page read in a research turn. Do not call it yourself.",
      {"tool_name": {"type": "string"}, "input": {"type": "object"}, "tool_use_id": {"type": "string"}},
      on_main=False)
def web_permission(args):
    name, inp = args.get("tool_name", ""), dict(args.get("input") or {})
    from . import chat
    live = chat.live()
    research = bool(live and live.get("research"))
    if name not in ("WebSearch", "WebFetch") or not research:
        return {"data": {"behavior": "deny", "message": "Not available in this chat turn."}}
    if name == "WebSearch":
        text, detail = 'search the web for "{}"'.format(str(inp.get("query", ""))[:80]), "web search"
    else:
        text, detail = "read a web page", str(inp.get("url", ""))[:200]
    ok, why = approvals.ask("web", text, detail, args.get("_client", "agent"))
    if ok:
        chat._set_live(web_used=True)
        return {"data": {"behavior": "allow", "updatedInput": inp}}
    return {"data": {"behavior": "deny", "message": why}}


@tool("sandbox_remove", "Take an item out of the Sandbox.", {"item": _ITEM}, required=("item",), mutating=True)
def sandbox_remove(args):
    it = _item(args["item"])
    sandbox.remove(it["id"])
    return {"data": {"removed": it["id"], "title": it.get("title")}}


# ---------------------------------------------------------------------------
# Using an item in the scene.

def _clean_name(title, fallback):
    name = re.sub(r"[^\w\- ]+", "", title or "").strip() or fallback
    return name[:48]


def _place(ob, height, scene):
    """Stand an object upright (facing the front view) with its bottom on the 3D cursor."""
    cursor = scene.cursor.location.copy()
    ob.matrix_world = Matrix.Translation(cursor + Vector((0, 0, height / 2))) @ Matrix.Rotation(math.pi / 2, 4, 'X')


def _image_plane(it, size_m, scene, collection):
    img = sandbox.image_of(it)
    if img is None:
        raise ToolError("That item has no picture.")
    name = _clean_name(it.get("title"), it["id"])
    tex = img.copy()
    tex.name = "Scrap_" + name
    tex.use_fake_user = False
    w, h = img.size
    height = size_m
    width = size_m * w / max(1, h)
    me = bpy.data.meshes.new(name)
    me.from_pydata([(-width / 2, -height / 2, 0), (width / 2, -height / 2, 0), (width / 2, height / 2, 0),
                    (-width / 2, height / 2, 0)], [], [(0, 1, 2, 3)])
    uv = me.uv_layers.new(name="UVMap")
    for loop, co in zip(uv.data, ((0, 0), (1, 0), (1, 1), (0, 1))):
        loop.uv = co
    mat = bpy.data.materials.new("Scrap_" + name)
    if mat.node_tree is None:
        mat.use_nodes = True
    nt = mat.node_tree
    bsdf = next(n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED')
    node = nt.nodes.new("ShaderNodeTexImage")
    node.image = tex
    node.location = (bsdf.location.x - 320, bsdf.location.y)
    nt.links.new(node.outputs["Color"], bsdf.inputs["Base Color"])
    nt.links.new(node.outputs["Alpha"], bsdf.inputs["Alpha"])
    me.materials.append(mat)
    ob = bpy.data.objects.new(name, me)
    collection.objects.link(ob)
    _place(ob, height, scene)
    return ob, {"size_m": [r(width), r(height)]}


def _svg_object(it, mode, size_m, depth, scene, collection):
    svg = sandbox.svg_text(it)
    if not svg:
        raise ToolError("That item has no SVG.")
    made = sandbox.import_svg(svg, scene, collection)
    curves = [o for o in made if o.type == 'CURVE']
    for o in made:
        if o.type != 'CURVE':
            bpy.data.objects.remove(o)
    if not curves:
        raise ToolError("The SVG has no shapes Blender can import.")
    for o in curves:  # the importer adds a collection of its own: keep the shapes in ours
        for c in list(o.users_collection):
            c.objects.unlink(o)
            if not c.objects and not c.children and c is not collection and c.users <= 1:
                bpy.data.collections.remove(c)
        collection.objects.link(o)
    # One frame for all the shapes: centred, size_m wide, in their own (XY) plane.
    for o in curves:
        o.data.transform(o.matrix_world)
        o.matrix_world = Matrix.Identity(4)
    corners = [Vector(c) for o in curves for c in o.bound_box]
    lo = Vector([min(c[i] for c in corners) for i in range(3)])
    hi = Vector([max(c[i] for c in corners) for i in range(3)])
    k = size_m / max(hi.x - lo.x, hi.y - lo.y, 1e-9)
    centre = (lo + hi) / 2
    for o in curves:
        o.data.transform(Matrix.Scale(k, 4) @ Matrix.Translation(-centre))
    name = _clean_name(it.get("title"), it["id"])
    info = {"parts": len(curves)}
    if mode == "logo":
        # Each shape becomes a mesh first: joining curves would keep only one shape's material.
        d = depth if depth is not None else size_m * 0.04
        for o in curves:
            o.data.extrude = d / 2
            o.data.bevel_depth = d * 0.12
            o.data.bevel_resolution = 2
        with bpy.context.temp_override(active_object=curves[0], object=curves[0], selected_objects=curves,
                                       selected_editable_objects=curves):
            bpy.ops.object.convert(target='MESH')
        meshes = [o for o in collection.objects if o.type == 'MESH' and o.name in {c.name for c in curves}]
        ob = meshes[0]
        if len(meshes) > 1:
            with bpy.context.temp_override(active_object=ob, object=ob, selected_objects=meshes,
                                           selected_editable_objects=meshes):
                bpy.ops.object.join()
        # The bevel adds a little all round: scale to exactly size_m wide.
        dims = ob.dimensions
        if dims.x > 0:
            ob.data.transform(Matrix.Scale(size_m / max(dims.x, dims.y), 4))
        ob.name = ob.data.name = name
        info["depth_m"] = r(ob.dimensions.z)
        width, height = ob.dimensions.x, ob.dimensions.y
        _place(ob, height, scene)
    else:
        # Curves stay one object per shape (each keeps its colour) under an empty named after the item.
        ob = bpy.data.objects.new(name, None)
        ob.empty_display_size = size_m / 2
        collection.objects.link(ob)
        width, height = (hi.x - lo.x) * k, (hi.y - lo.y) * k
        for o in curves:
            o.parent = ob
            o.name = name + "_shape"
        _place(ob, height, scene)
    info["size_m"] = [r(width), r(height)]
    return ob, info


@tool("sandbox_use",
      "Use a Sandbox item in the scene. plane: an image or render as a picture on an upright plane "
      "(size_m tall). logo: an SVG as a solid 3D logo (size_m wide, depth in metres, default 4% of the "
      "width), stood on the 3D cursor facing the front view. curves: an SVG as flat curves. palette: "
      "an item's colours tinted onto objects (shade_tint; objects default to the selection). make_3d: "
      "an image turned into a 3D model on the user's GPU (ComfyUI; returns a job_id for wait_for_job).",
      {"item": _ITEM, "action": {"type": "string", "enum": ["plane", "logo", "curves", "palette", "make_3d"]},
       "size_m": {"type": "number", "minimum": 0.001, "default": 0.5},
       "depth": {"type": "number", "minimum": 0},
       "objects": {"type": "array", "items": {"type": "string"}},
       "strength": {"type": "number", "minimum": 0, "maximum": 1},
       "quality": {"type": "string", "enum": ["mesh", "pbr"]}},
      required=("item", "action"), mutating=True)
def sandbox_use(args):
    it = _item(args["item"])
    action = args["action"]
    scene = bpy.context.scene
    size_m = float(args.get("size_m", 0.5))
    if action == "palette":
        colors = it.get("colors") or []
        if len(colors) < 1:
            raise ToolError("That item has no colours.")
        from .tools_shade import shade_tint
        tint = {"palette": colors[:6]}
        if args.get("objects"):
            tint["objects"] = args["objects"]
        if args.get("strength") is not None:
            tint["strength"] = args["strength"]
        res = shade_tint(tint)
        res["data"]["palette_from"] = it["id"]
        return res
    if action == "make_3d":
        if it["kind"] not in ("image", "render"):
            raise ToolError("make_3d needs an image or a render.")
        from .tools_generate import generate_3d
        img = sandbox.image_of(it)
        return generate_3d({"image": img.name, "quality": args.get("quality", "pbr")})
    collection = bpy.data.collections.get("Sandbox") or bpy.data.collections.new("Sandbox")
    if collection.name not in scene.collection.children:
        scene.collection.children.link(collection)
    if action == "plane":
        if it["kind"] not in ("image", "render", "svg"):
            raise ToolError("A plane needs an image, a render or an SVG.")
        ob, info = _image_plane(it, size_m, scene, collection)
    else:
        if it["kind"] != "svg":
            raise ToolError("{} needs an SVG item.".format(action))
        ob, info = _svg_object(it, action, size_m, args.get("depth"), scene, collection)
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    if ob.name in bpy.context.view_layer.objects:
        ob.select_set(True)
        bpy.context.view_layer.objects.active = ob
    info.update(object=ob.name, type=ob.type, collection=collection.name, from_item=it["id"])
    return {"data": info}
