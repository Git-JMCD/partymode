# SPDX-License-Identifier: GPL-3.0-or-later
"""
The agent menu: the message box's agent chip opens it. Pick who answers (Claude, Codex,
OpenCode) in their colours, the model from a list (OpenCode's can be long: type to filter, or
type any model name), and how hard it thinks. Drawn in the chat's look, like the rest of it.

Choices go to the add-on preferences (their update hands them to the chat); without the
preferences (an add-on loaded from a folder) they go to the chat directly. Program paths stay in
the preferences: "All settings" opens them.
"""

import time

import bpy

from . import chat, looks, runners
from . import ui_draw as D

_M = {"menu": None}  # {"area": pointer, "filter": str, "scroll": rows, "sel": index or None}
ROWS = 7             # list rows shown before it scrolls
RESEARCH_H = 40.0    # the Research switch's row
TEAM_H = 18.0 + 28.0 + 6.0 + 14.0 + 10.0  # the Team section: label, helper chips, a line


# ---------------------------------------------------------------------------
# What there is to pick, and picking it.

def _prefs():
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def is_open(area=None):
    m = _M["menu"]
    return m is not None and (area is None or m["area"] == area.as_pointer())


def open_menu(context, area):
    from . import ui_space
    _M["menu"] = {"area": area.as_pointer(), "filter": "", "scroll": 0, "sel": None}
    ui_space._fetch_opencode_models()
    with context.temp_override(window=context.window, area=area):
        bpy.ops.agent.menu_keys('INVOKE_DEFAULT')
    area.tag_redraw()


def close_menu():
    _M["menu"] = None
    from . import ui_space
    ui_space._redraw_all()


def models(runner):
    """[(value, label, note)] for the runner's model list; value "" is its default."""
    d = chat.defaults(runner)
    default = chat.model_label(d.get("model") or "") or "the agent's own choice"
    out = [("", "Default", default)]
    if runner == "claude":
        out += chat.models()
    elif runner == "codex":
        from . import runners
        out += runners.get("codex").models()
    elif runner == "opencode":
        from . import ui_space
        out += [(name, name.split("/", 1)[-1], name.split("/", 1)[0]) for name in ui_space._oc_models["items"]]
    current = chat.S.model if chat.S.runner == runner else ""
    if current and not any(v == current for v, _l, _n in out):
        out.insert(1, (current, chat.model_label(current), "current"))
    return out


def shown_models(runner, filt):
    items = models(runner)
    f = filt.strip().lower()
    if f:
        items = [it for it in items if f in it[0].lower() or f in it[1].lower() or f in it[2].lower()]
    return items


def typed_choice(runner, filt):
    """A model name typed in the filter, offered when it matches no listed name exactly."""
    f = filt.strip()
    if not f or runner == "claude" or " " in f or (runner == "opencode" and "/" not in f.strip("/")):
        return None  # OpenCode names are provider/model
    return None if any(v == f for v, _l, _n in models(runner)) else f


def apply(runner=None, model=None, effort=None):
    """Make a choice: through the preferences when the add-on has them."""
    prefs = _prefs()
    if prefs is not None:
        if runner is not None and prefs.chat_runner != runner:
            prefs.chat_runner = runner
        r = prefs.chat_runner
        if model is not None:
            if r == "claude":
                prefs.chat_model = model or "DEFAULT"
            elif r == "codex":
                prefs.codex_model = model
            else:
                prefs.opencode_model = model
        if effort is not None and r in ("claude", "codex"):
            setattr(prefs, r + "_effort", effort or "DEFAULT")
        return
    same = runner is None or runner == chat.S.runner
    chat.set_choice(runner or chat.S.runner,
                    (chat.S.model if same else "") if model is None else model,
                    chat.S.effort if effort is None else effort)


# ---------------------------------------------------------------------------
# Drawing.

def draw(cv, m, area, st, hits, hovered):
    """The menu, above the agent chip (st["chip_rect"]), on top of everything in the area."""
    if not is_open(area) or not st.get("chip_rect"):
        return
    from . import ui_space
    s = m.s
    look = looks.get()
    font = "mono" if look["upper"] else "ui"
    menu = _M["menu"]
    runner = chat.S.runner
    acc = ui_space.agent_color()
    pad = 12 * s
    W = min(380 * s, cv.w - 24 * s)
    cx0, cy0, cx1, cy1 = st["chip_rect"]
    x0 = min(max(12 * s, cx0 - 6 * s), cv.w - W - 12 * s)
    x1 = x0 + W
    filt = menu["filter"]
    items = shown_models(runner, filt)
    typed = typed_choice(runner, filt)
    rows = ([("__typed__", 'Use "{}"'.format(typed), "typed")] if typed else []) + items
    want = rows[:]
    with_filter = runner != "claude"
    efforts = runners.get(runner).efforts
    # Height: top to bottom, so the list can shrink to fit the space above the chip.
    fixed = pad + 18 * s + 30 * s + 14 * s + 18 * s + (34 * s if with_filter else 0) \
        + 14 * s + 18 * s + 26 * s + 12 * s + RESEARCH_H * s + 10 * s + TEAM_H * s + 18 * s + pad
    room = cv.h - (cy1 + 8 * s) - 10 * s
    rh = 26 * s
    nvis = max(1, min(ROWS, len(want), int((room - fixed) / rh)))
    if not want:
        nvis = 1
    H = fixed + nvis * rh
    y0 = cy1 + 8 * s
    y1 = y0 + H
    if y1 > cv.h - 6 * s:  # no room above: open down from the top
        y1 = cv.h - 6 * s
        y0 = y1 - H
    # Clicks anywhere outside close it; inside, the empty parts do nothing.
    hits.append((("menu_off",), 0, 0, cv.w, cv.h))
    r = min(looks.radius("card", s, 24 * s), 14 * s)
    cv.rect(x0, y0 - 6 * s, x1, y1 - 2 * s, "shadow", r, soft=18 * s)
    # A plain shadow; the border carries a little of the agent's colour (mixed, not see-through,
    # so it reads the same over the chat and over a viewport).
    edge = D._mix(cv.pal["border2"][:3], acc[:3], 0.5)
    cv.rect(x0, y0, x1, y1, "surface", r, line=edge, width=1 * s)
    hits.append((("menu_bg",), x0, y0, x1, y1))
    y = y1 - pad

    def label(text, yy):
        size = m.tiny
        t = "[ {} ]".format(looks.label(text)) if look["brackets"] else looks.label(text)
        cv.text(x0 + pad, yy - 13 * s, t, size, "faint", 500, font)

    # Agent: three chips in their colours.
    label("Agent", y)
    y -= 18 * s
    gap = 6 * s
    aw = (W - 2 * pad - 2 * gap) / 3
    ch = 30 * s
    cr = looks.radius("chip", s, ch)
    size = m.small
    for i, rn in enumerate(runners.RUNNERS.values()):
        ax = x0 + pad + i * (aw + gap)
        hid = ("menu_agent", rn.key)
        on = rn.key == runner
        hov = hovered(hid)
        col = ui_space.agent_color(rn.key)
        found = bool(chat.executable(rn.key))
        cv.rect(ax, y - ch, ax + aw, y, D.alpha(col, 0.16) if on else ("surface2" if hov else D.alpha(cv.pal["surface2"], 0.5)),
                cr, line=D.alpha(col, 0.9) if on else ("border2" if hov else "border"), width=1 * s)
        if on and look["glow"]:
            cv.rect(ax + 9 * s, y - ch / 2 - 6 * s, ax + 21 * s, y - ch / 2 + 6 * s, D.alpha(col, 0.5), 6 * s, soft=6 * s)
        cv.rect(ax + 11 * s, y - ch / 2 - 4 * s, ax + 19 * s, y - ch / 2 + 4 * s, col, 1 * s if look["upper"] else 4 * s)
        name = rn.label.upper() if look["upper"] else rn.label
        cv.text(ax + 26 * s, y - ch / 2 - size * 0.36, D.ellipsize(name, size, aw - 32 * s, 600, font), size,
                "text" if found else "faint", 600, font)
        hits.append((hid, ax, y - ch, ax + aw, y))
    y -= ch + 14 * s

    # Model: a filter field (Codex, OpenCode), then the list.
    label("Model", y)
    if runner == "opencode" and ui_space._oc_models["state"] in ("fetching", "idle") and len(items) <= 1:
        note = "loading models…" if ui_space._oc_models["state"] == "fetching" else ""
        if note:
            nw = D.measure(note, m.tiny, 400, font)
            cv.text(x1 - pad - nw, y - 13 * s, looks.label(note), m.tiny, "faint", 400, font)
    y -= 18 * s
    if with_filter:
        fh = 28 * s
        fr = looks.radius("chip", s, fh)
        cv.rect(x0 + pad, y - fh, x1 - pad, y, "bg", fr, line=D.alpha(acc, 0.8) if filt else "border", width=1 * s)
        tx = x0 + pad + 10 * s
        fsize = m.small
        if filt:
            cv.text(tx, y - fh / 2 - fsize * 0.36, D.ellipsize(filt, fsize, W - 2 * pad - 24 * s), fsize, "text")
            if int(time.time() / 0.53) % 2 == 0:
                cx = tx + min(D.measure(filt, fsize), W - 2 * pad - 24 * s)
                cv.rect(cx + 1 * s, y - fh + 7 * s, cx + 2.5 * s, y - 7 * s, acc)
        else:
            hint = "Type to filter, or any provider/model" if runner == "opencode" else "Type a model name"
            cv.text(tx, y - fh / 2 - fsize * 0.36, hint, fsize, "faint")
        hits.append((("menu_bg",), x0 + pad, y - fh, x1 - pad, y))
        y -= fh + 6 * s
    menu["scroll"] = max(0, min(menu["scroll"], len(rows) - nvis))
    sel = menu["sel"]
    current = chat.S.model
    top = y
    if not rows:
        cv.text(x0 + pad + 4 * s, y - rh / 2 - m.small * 0.36, "No model matches", m.small, "faint")
    for n, (value, lab, note) in enumerate(rows[menu["scroll"]:menu["scroll"] + nvis]):
        i = n + menu["scroll"]
        hid = ("menu_model", value)
        on = (value == current) if value != "__typed__" else False
        hov = hovered(hid) or sel == i
        if on or hov:
            cv.rect(x0 + pad - 4 * s, y - rh + 1 * s, x1 - pad + 4 * s, y - 1 * s,
                    D.alpha(acc, 0.16 if on else 0.07), min(8 * s, looks.radius("chip", s, rh)))
        if on:
            k = 3 * s
            mx, my = x0 + pad + 6 * s, y - rh / 2
            cv.line([(mx - k, my), (mx - k * 0.2, my - k * 0.8), (mx + k, my + k)], acc, 1.5 * s)
        lsize = m.small
        lfont = "mono" if (runner != "claude" and value) else font
        cv.text(x0 + pad + 18 * s, y - rh / 2 - lsize * 0.36,
                D.ellipsize(lab, lsize, W * 0.62, 600 if on else 400, lfont), lsize, "text", 600 if on else 400, lfont)
        if note:
            nsize = m.tiny
            nfont = font if runner == "claude" else "mono"  # Claude's notes are prose
            nw = D.measure(note, nsize, 400, nfont)
            room_n = W * 0.34
            note_s = D.ellipsize(note, nsize, room_n, 400, nfont)
            cv.text(x1 - pad - min(D.measure(note_s, nsize, 400, nfont), room_n), y - rh / 2 - nsize * 0.36, note_s,
                    nsize, "faint", 400, nfont)
        hits.append((hid, x0 + pad - 4 * s, y - rh, x1 - pad + 4 * s, y))
        y -= rh
    if len(rows) > nvis:  # a scrollbar
        track = nvis * rh
        th = max(18 * s, track * nvis / len(rows))
        frac = menu["scroll"] / max(1, len(rows) - nvis)
        ty1 = top - (track - th) * frac
        cv.rect(x1 - 7 * s, ty1 - th, x1 - 4 * s, ty1, D.alpha(cv.pal["text"], 0.22), 1.5 * s)
    st["menu_list"] = (x0, top - nvis * rh, x1, top)
    y = top - nvis * rh - 14 * s

    # Reasoning: segments (none for OpenCode: set per model there).
    label("Reasoning", y)
    y -= 18 * s
    sh = 26 * s
    if efforts:
        opts = [("", "Default")] + [(e, {"xhigh": "X-high"}.get(e, e.capitalize())) for e in efforts]
        sw = (W - 2 * pad) / len(opts)
        sr = looks.radius("chip", s, sh)
        cv.rect(x0 + pad, y - sh, x1 - pad, y, D.alpha(cv.pal["surface2"], 0.5), sr, line="border", width=1 * s)
        current_e = chat.S.effort if chat.S.effort in efforts else ""
        for i, (e, lab) in enumerate(opts):
            sx = x0 + pad + i * sw
            hid = ("menu_effort", e)
            on = e == current_e
            if on:
                cv.rect(sx + 2 * s, y - sh + 2 * s, sx + sw - 2 * s, y - 2 * s, D.alpha(acc, 0.22), max(0.0, sr - 2 * s),
                        line=D.alpha(acc, 0.8), width=1 * s)
            elif hovered(hid):
                cv.rect(sx + 2 * s, y - sh + 2 * s, sx + sw - 2 * s, y - 2 * s, D.alpha(cv.pal["text"], 0.06), max(0.0, sr - 2 * s))
            lab = looks.label(lab)
            esize = m.tiny + 0.5 * s
            lw = D.measure(lab, esize, 600 if on else 500, font)
            cv.text(sx + (sw - lw) / 2, y - sh / 2 - esize * 0.36, D.ellipsize(lab, esize, sw - 4 * s, 500, font), esize,
                    "text" if on else "muted", 600 if on else 500, font)
            hits.append((hid, sx, y - sh, sx + sw, y))
    else:
        cv.text(x0 + pad, y - sh / 2 - m.small * 0.36, "Set per model in OpenCode", m.small, "faint")
    y -= sh + 12 * s

    # Research: the next message may use the web, with the scene read-only (or the preference's say).
    mode = chat.S.research_mode
    hid = ("menu_research",) if mode == "MESSAGE" else ("menu_settings",)
    on = chat.S.research if mode == "MESSAGE" else mode == "AUTO"
    rh2 = RESEARCH_H * s
    hov = hovered(hid)
    cv.rect(x0 + pad, y - rh2, x1 - pad, y, D.alpha(acc, 0.12) if on else (D.alpha(cv.pal["text"], 0.05) if hov else
            D.alpha(cv.pal["surface2"], 0.5)), min(10 * s, looks.radius("chip", s, rh2)),
            line=D.alpha(acc, 0.7) if on else "border", width=1 * s)
    ui_space._globe(cv, x0 + pad + 16 * s, y - rh2 / 2, 6 * s, s, acc if on else cv.pal["muted"])
    t1 = looks.label({"MESSAGE": "Research the next message", "AUTO": "Research: Auto",
                      "OFF": "Research: Off"}[mode])
    cv.text(x0 + pad + 32 * s, y - 16 * s, t1, m.small, "text", 600, font)
    asks = "asks first" if ui_space.approvals.asking() else "does not ask"
    if mode == "MESSAGE":
        t2 = "{}  ·  scene read-only  ·  {}".format("Web on" if on else "Web off", asks)
    elif mode == "AUTO":
        t2 = "web when it helps  ·  {}  ·  set in All settings".format(asks)
    else:
        t2 = "no web  ·  set in All settings"
    cv.text(x0 + pad + 32 * s, y - 31 * s, D.ellipsize(t2, m.tiny, W - 2 * pad - 90 * s), m.tiny, "faint")
    if mode == "MESSAGE":
        tw, th = 30 * s, 16 * s  # the switch
        tx1 = x1 - pad - 10 * s
        tx0 = tx1 - tw
        ty0 = y - rh2 / 2 - th / 2
        cv.rect(tx0, ty0, tx1, ty0 + th, acc if on else "border2", th / 2)
        kx = tx1 - th / 2 if on else tx0 + th / 2
        cv.rect(kx - th / 2 + 2 * s, ty0 + 2 * s, kx + th / 2 - 2 * s, ty0 + th - 2 * s, (1, 1, 1, 1), th / 2 - 2 * s)
    else:  # set in the preferences: the row opens them
        ax, ay, k = x1 - pad - 16 * s, y - rh2 / 2, 3.5 * s
        cv.line([(ax - k * 0.6, ay + k), (ax + k * 0.6, ay), (ax - k * 0.6, ay - k)], "muted", 1.4 * s)
    hits.append((hid, x0 + pad, y - rh2, x1 - pad, y))
    y -= rh2 + 10 * s

    # Team: helpers that work with the agent above on each message (team.py).
    label("Team", y)
    y -= 18 * s
    others = [rn for rn in runners.RUNNERS.values() if rn.key != runner]
    tw = (W - 2 * pad - gap * (len(others) - 1)) / max(1, len(others))
    th = 28 * s
    tr = looks.radius("chip", s, th)
    picked = []
    for i, rn in enumerate(others):
        tx = x0 + pad + i * (tw + gap)
        hid = ("menu_team", rn.key)
        on = rn.key in chat.S.team_helpers
        found = bool(chat.executable(rn.key))
        col = ui_space.agent_color(rn.key)
        hov = hovered(hid)
        if on and found:
            picked.append(rn.label)
        cv.rect(tx, y - th, tx + tw, y, D.alpha(col, 0.14) if on else ("surface2" if hov else D.alpha(cv.pal["surface2"], 0.5)),
                tr, line=D.alpha(col, 0.85) if on else ("border2" if hov else "border"), width=1 * s)
        bx, by, k = tx + 10 * s, y - th / 2, 5 * s  # a tick box
        cv.rect(bx, by - k, bx + 2 * k, by + k, col if on else "bg", 1.5 * s if look["upper"] else 3 * s,
                line=None if on else "border2", width=1 * s)
        if on:
            cv.line([(bx + k * 0.45, by), (bx + k * 0.85, by - k * 0.45), (bx + k * 1.6, by + k * 0.5)], (1, 1, 1, 1), 1.4 * s)
        name = rn.label.upper() if look["upper"] else rn.label
        size = m.small
        cv.text(bx + 2 * k + 8 * s, y - th / 2 - size * 0.36, D.ellipsize(name, size, tw - 2 * k - 26 * s, 600, font),
                size, "text" if found else "faint", 600, font)
        hits.append((hid, tx, y - th, tx + tw, y))
    y -= th + 6 * s
    lead = runners.get(runner).label
    if picked:
        line = "{} leads: plans, hands {} tasks, checks the result".format(lead, " and ".join(picked))
    else:
        line = "Tick helpers to work as a team with {}".format(lead)
    cv.text(x0 + pad, y - 11 * s, D.ellipsize(looks.label(line) if look["upper"] else line, m.tiny, W - 2 * pad),
            m.tiny, "faint")
    y -= 14 * s + 10 * s

    # Footer: where the defaults come from, and the rest of the settings.
    d = chat.defaults(runner)
    bits = [b for b in (chat.model_label(d.get("model") or ""), d.get("effort") or "") if b]
    found = bool(chat.executable(runner))
    if not found:
        foot, fcol = "{} was not found: set its program in All settings".format(runners.get(runner).label), "error"
    else:
        foot, fcol = "Default: {} (from {})".format(" · ".join(bits) or "the agent's own choice", d.get("source", "")), "faint"
    from . import updates
    new = updates.available()
    if found and new:
        foot, fcol = "PartyMode {} is out: install it in All settings".format(new), "muted"
    link = looks.label("All settings")
    lw = D.measure(link, m.tiny, 600, font)
    cv.text(x0 + pad, y - 13 * s, D.ellipsize(foot, m.tiny, W - 2 * pad - lw - 14 * s), m.tiny, fcol)
    hid = ("menu_settings",)
    cv.text(x1 - pad - lw, y - 13 * s, link, m.tiny, acc if hovered(hid) else "muted", 600, font)
    hits.append((hid, x1 - pad - lw - 4 * s, y - 18 * s, x1 - pad + 4 * s, y))


# ---------------------------------------------------------------------------
# Input.

def activate(context, area, hid):
    kind = hid[0]
    menu = _M["menu"]
    if kind == "model":
        if is_open(area):
            close_menu()
        else:
            open_menu(context, area)
        return
    if menu is None:
        return
    if kind == "menu_off":
        close_menu()
    elif kind == "menu_agent":
        apply(runner=hid[1])
        menu.update(filter="", scroll=0, sel=None)
        from . import ui_space
        ui_space._fetch_opencode_models()
    elif kind == "menu_model":
        value = hid[1]
        if value == "__typed__":
            value = typed_choice(chat.S.runner, menu["filter"]) or ""
        apply(model=value)
    elif kind == "menu_effort":
        apply(effort=hid[1])
    elif kind == "menu_research":
        chat.set_research(not chat.S.research)
    elif kind == "menu_team":
        key = hid[1]
        prefs = _prefs()
        if prefs is not None:
            setattr(prefs, "team_" + key, not getattr(prefs, "team_" + key))
        else:
            on = key in chat.S.team_helpers
            chat.S.team_helpers = [k for k in chat.S.team_helpers if k != key] + ([] if on else [key])
            chat.S.revision += 1
    elif kind == "menu_settings":
        close_menu()
        try:
            bpy.ops.preferences.addon_show(module=__package__)
        except RuntimeError:
            pass
    area.tag_redraw()


def scroll(area, st, x, y, lines):
    """The wheel over the model list scrolls it. Returns True when it did."""
    r = st.get("menu_list")
    if not is_open(area) or not r or not (r[0] <= x <= r[2] and r[1] <= y <= r[3]):
        return False
    _M["menu"]["scroll"] = max(0, _M["menu"]["scroll"] + (-1 if lines > 0 else 1) * 2)
    area.tag_redraw()
    return True


class AGENT_OT_menu_keys(bpy.types.Operator):
    """Keys while the agent menu is open: type to filter, arrows and Enter to pick, Esc to close"""
    bl_idname = "agent.menu_keys"
    bl_label = "Agent Menu Keys"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        from . import ui_space
        menu = _M["menu"]
        if menu is None:
            return {'FINISHED', 'PASS_THROUGH'}
        area = ui_space._find_area(menu["area"])
        if area is None:
            _M["menu"] = None
            return {'FINISHED', 'PASS_THROUGH'}
        t, v = event.type, event.value
        if v != 'PRESS':
            return {'PASS_THROUGH'}
        runner = chat.S.runner
        rows = ([("__typed__",)] if typed_choice(runner, menu["filter"]) else []) + \
            [(it[0],) for it in shown_models(runner, menu["filter"])]
        if t == 'ESC':
            close_menu()
            return {'FINISHED'}
        if t in {'RET', 'NUMPAD_ENTER'}:
            sel = menu["sel"]
            if sel is None and rows and menu["filter"].strip():
                sel = 0
            if sel is not None and sel < len(rows):
                value = rows[sel][0]
                apply(model=(typed_choice(runner, menu["filter"]) or "") if value == "__typed__" else value)
            close_menu()
            return {'FINISHED'}
        if t in {'UP_ARROW', 'DOWN_ARROW'}:
            if rows:
                sel = menu["sel"]
                sel = 0 if sel is None else sel + (1 if t == 'DOWN_ARROW' else -1)
                menu["sel"] = max(0, min(len(rows) - 1, sel))
                if menu["sel"] < menu["scroll"]:
                    menu["scroll"] = menu["sel"]
                elif menu["sel"] >= menu["scroll"] + ROWS:
                    menu["scroll"] = menu["sel"] - ROWS + 1
            area.tag_redraw()
            return {'RUNNING_MODAL'}
        if runner == "claude":
            return {'PASS_THROUGH'}  # no filter for a short list
        if t == 'BACK_SPACE':
            menu["filter"] = "" if event.ctrl else menu["filter"][:-1]
        elif event.unicode and not event.ctrl and event.unicode.isprintable():
            menu["filter"] += event.unicode
        else:
            return {'PASS_THROUGH'}
        menu.update(scroll=0, sel=None)
        area.tag_redraw()
        return {'RUNNING_MODAL'}


_classes = (AGENT_OT_menu_keys,)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    _M["menu"] = None
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
