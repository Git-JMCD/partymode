# SPDX-License-Identifier: GPL-3.0-or-later
"""
Drawing for the Agent editor's canvas: anti-aliased rounded shapes (one small SDF
shader), images, lines, and text with real layout (wrapping, bold, headings, lists,
code, tables) from the Markdown the agent writes.

Layout works in "doc space": x to the right, y *down* from the top of a block, so
blocks can be cached and stacked. `draw_ops` maps them into region pixels (y up).
"""

import os
import re

import blf
import bpy
import gpu
import imbuf
import numpy as np
from gpu_extras.batch import batch_for_shader

# ---------------------------------------------------------------------------
# Colours: derived from the active Blender theme, so light themes work too.


def _mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3)) + (1.0,)


def palette():
    th = bpy.context.preferences.themes[0]
    ui = th.user_interface
    base = tuple(th.properties.space.back)[:3]
    light = sum(base) / 3 > 0.5
    toward = (0.0, 0.0, 0.0) if light else (1.0, 1.0, 1.0)
    bg = _mix(base, (1.0, 1.0, 1.0) if light else (0.0, 0.0, 0.0), 0.0 if light else 0.22)
    text = tuple(ui.wcol_regular.text)[:3] if not light else (0.08, 0.08, 0.09)
    accent = tuple(ui.wcol_menu_item.inner_sel)[:3]
    pal = {
        "bg": bg,
        "drawer": _mix(bg[:3], toward, 0.035),
        "surface": _mix(bg[:3], toward, 0.07),
        "surface2": _mix(bg[:3], toward, 0.115),
        "border": _mix(bg[:3], toward, 0.13),
        "border2": _mix(bg[:3], toward, 0.22),
        "text": text + (1.0,),
        "muted": _mix(text, bg[:3], 0.42),
        "faint": _mix(text, bg[:3], 0.62),
        "accent": accent + (1.0,),
        "accent_text": (1.0, 1.0, 1.0, 1.0),
        "error": (0.93, 0.38, 0.33, 1.0),
        "ok": (0.38, 0.78, 0.5, 1.0),
        "code_bg": _mix(bg[:3], toward, 0.09),
        "shadow": (0.0, 0.0, 0.0, 0.45 if not light else 0.15),
        "scrim": (0.0, 0.0, 0.0, 0.55),
    }
    from . import looks
    looks.amend_palette(pal, light)
    agent = AGENT["color"] or pal["accent"]
    pal["agent"] = tuple(agent[:3]) + (1.0,)
    pal["code_text"] = pal["text"] if looks.name() == "CLASSIC" else pal["agent"]
    return pal


# The answering agent's colour, set by the chat before it draws (palette()["agent"]).
AGENT = {"color": None}


def alpha(color, a):
    return color[:3] + (color[3] * a if len(color) > 3 else a,)


# ---------------------------------------------------------------------------
# Shapes: one quad per rectangle, the rounded box is a signed distance in the shader.

_SHAPE_VS = """
void main() {
  float pad = soft + 2.0;
  px = mix(rect.xy - pad, rect.zw + pad, pos);
  gl_Position = vec4(px / params.xy * 2.0 - 1.0, 0.0, 1.0);
}
"""
_SHAPE_FS = """
void main() {
  vec2 c = (rect.xy + rect.zw) * 0.5;
  vec2 h = (rect.zw - rect.xy) * 0.5;
  float r = min(params.z, min(h.x, h.y));
  vec2 q = abs(px - c) - h + r;
  float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
  float aa = max(soft, 1.0);
  float outer = clamp(0.5 - d / aa, 0.0, 1.0);
  float inner = clamp(0.5 - (d + params.w), 0.0, 1.0);
  %s
  vec4 col = params.w > 0.0 ? mix(line, body, inner) : body;
  // A 3D viewport draws into a linear buffer (Blender's own shaders convert for it).
  if (to_linear > 0.5) {
    col.rgb = mix(col.rgb / 12.92, pow((col.rgb + 0.055) / 1.055, vec3(2.4)), step(0.04045, col.rgb));
    // Blending there happens in linear light, where a see-through tint reads far stronger than
    // the same tint blended in the chat's sRGB; weaken it to look the same over dark surfaces.
    if (col.a < 0.999) col.a = pow(col.a, 2.2);
  }
  FragColor = vec4(col.rgb, col.a * outer);
}
"""
_BODY_FLAT = """
  float t = clamp((px.y - rect.y) / max(rect.w - rect.y, 1.0), 0.0, 1.0);
  vec4 body = mix(fill, fill2, t);
"""
_BODY_IMAGE = """
  vec2 uv = (px - rect.xy) / max(rect.zw - rect.xy, vec2(1.0));
  vec4 body = texture(image, mix(uvrect.xy, uvrect.zw, uv));
  body.rgb *= fill.rgb;  // a tint (white keeps the picture's own colours)
  body.a *= fill.a;
"""

_shaders = {}
_quad = {}


def _shader(textured):
    if textured in _shaders:
        return _shaders[textured]
    info = gpu.types.GPUShaderCreateInfo()
    info.push_constant('VEC4', 'rect')
    info.push_constant('VEC4', 'params')  # viewport w, h, radius, border width
    info.push_constant('VEC4', 'fill')
    info.push_constant('VEC4', 'fill2')
    info.push_constant('VEC4', 'line')
    info.push_constant('FLOAT', 'soft')
    info.push_constant('FLOAT', 'to_linear')
    if textured:
        info.push_constant('VEC4', 'uvrect')  # the part of the picture to draw (a sprite sheet's frame)
        info.sampler(0, 'FLOAT_2D', 'image')
    iface = gpu.types.GPUStageInterfaceInfo("agent_ui_shape_iface" + ("_img" if textured else ""))
    iface.smooth('VEC2', 'px')
    info.vertex_in(0, 'VEC2', 'pos')
    info.vertex_out(iface)
    info.fragment_out(0, 'VEC4', 'FragColor')
    info.vertex_source(_SHAPE_VS)
    info.fragment_source(_SHAPE_FS % (_BODY_IMAGE if textured else _BODY_FLAT))
    shader = gpu.shader.create_from_info(info)
    _shaders[textured] = shader
    _quad[textured] = batch_for_shader(shader, 'TRI_FAN', {"pos": ((0, 0), (1, 0), (1, 1), (0, 1))})
    return shader


def _set(sh, name, value):
    """A shader value, skipped when the compiler dropped it as unused (Blender 5.2 does: the
    picture shader never reads fill2, and setting it there raises)."""
    try:
        sh.uniform_float(name, value)
    except ValueError:
        pass


class Canvas:
    """Per-draw drawing context: region size, palette, scale."""

    def __init__(self, region, linear=False):
        """linear: the target is a 3D viewport's linear buffer (colours are converted)."""
        self.w = region.width
        self.h = region.height
        self.linear = linear
        self.pal = palette()
        self.s = bpy.context.preferences.system.ui_scale
        self._scissor = None
        gpu.state.blend_set('ALPHA')

    def color(self, c):
        return self.pal[c] if isinstance(c, str) else c

    def rect(self, x0, y0, x1, y1, fill, radius=0.0, line=None, width=0.0, top=None, soft=1.0):
        """Rounded rectangle in region pixels (y up). `top` makes a vertical gradient."""
        if x1 <= x0 or y1 <= y0:
            return
        gpu.state.blend_set('ALPHA')  # text drawing (blf) switches blending off
        sh = _shader(False)
        sh.bind()
        fill = self.color(fill)
        _set(sh, "rect", (x0, y0, x1, y1))
        _set(sh, "params", (self.w, self.h, radius, width if line else 0.0))
        _set(sh, "fill", fill)
        _set(sh, "fill2", self.color(top) if top else fill)
        _set(sh, "line", self.color(line) if line else fill)
        _set(sh, "soft", soft)
        _set(sh, "to_linear", 1.0 if self.linear else 0.0)
        _quad[False].draw(sh)

    def image(self, tex, x0, y0, x1, y1, radius=0.0, opacity=1.0, tint=None, uv=(0.0, 0.0, 1.0, 1.0)):
        """tint: a colour (or palette name) to multiply the picture by, e.g. a white logo drawn in
        the theme's text colour. uv: the part of the picture to draw (u0, v0, u1, v1; v up)."""
        gpu.state.blend_set('ALPHA')
        sh = _shader(True)
        sh.bind()
        rgb = tuple(self.color(tint)[:3]) if tint is not None else (1.0, 1.0, 1.0)
        _set(sh, "rect", (x0, y0, x1, y1))
        _set(sh, "params", (self.w, self.h, radius, 0.0))
        _set(sh, "fill", rgb + (opacity,))
        _set(sh, "fill2", rgb + (opacity,))
        _set(sh, "line", (0.0, 0.0, 0.0, 0.0))
        _set(sh, "soft", 1.0)
        _set(sh, "to_linear", 1.0 if self.linear else 0.0)
        _set(sh, "uvrect", tuple(uv))
        sh.uniform_sampler("image", tex)
        _quad[True].draw(sh)

    def line(self, points, color, width=1.5):
        gpu.state.blend_set('ALPHA')
        sh = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        sh.bind()
        sh.uniform_float("viewportSize", (self.w, self.h))
        sh.uniform_float("lineWidth", width)
        sh.uniform_float("color", self.color(color))
        batch_for_shader(sh, 'LINE_STRIP', {"pos": [(x, y, 0.0) for x, y in points]}).draw(sh)

    def pattern(self, kind, rect, step, color, alpha, fade_y):
        """An agent texture over rect: dots, crosshairs or staggered dashes on a `step` grid, in
        `color` at `alpha` at the top, fading out by y = fade_y (region pixels)."""
        x0, y0, x1, y1 = rect
        s = self.s
        st = step * s
        if st < 4 or x1 <= x0 or y1 <= y0:
            return
        c = self.color(color)
        if self.linear:
            c = tuple(v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in c[:3]) + (1.0,)
        pos, col = [], []
        # Every mark sits on whole pixels, so each row draws the same thickness.
        px = max(1, round(s))  # a hairline
        step_x = max(4, round(st))
        step_y = max(3, round(st * (0.55 if kind == "dash" else 1.0)))
        half = {"dots": max(1, round(1.0 * s)), "cross": max(2, round(3.0 * s)), "dash": max(2, round(2.5 * s))}[kind]
        row = 0
        y = round(y1 - st / 2)
        while y > max(y0, fade_y):
            a = alpha * max(0.0, min(1.0, (y - fade_y) / max(1.0, y1 - fade_y)))
            rc = (c[0], c[1], c[2], a)
            off = step_x // 2 if kind == "dash" and row % 2 else 0
            x = round(x0 + st / 2) - off
            while x < x1:
                if kind == "dots":
                    bars = ((x - half, y - half, x + half, y + half),)
                elif kind == "cross":
                    bars = ((x - half, y, x + half + px, y + px), (x, y - half, x + px, y + half + px))
                else:
                    bars = ((x - half, y, x + half, y + px),)
                for bx0, by0, bx1, by1 in bars:
                    pos += ((bx0, by0), (bx1, by0), (bx1, by1), (bx0, by0), (bx1, by1), (bx0, by1))
                    col += (rc,) * 6
                x += step_x
            y -= step_y
            row += 1
            if len(pos) > 120000:
                break
        if not pos:
            return
        gpu.state.blend_set('ALPHA')
        sh = gpu.shader.from_builtin('SMOOTH_COLOR')
        sh.bind()
        batch_for_shader(sh, 'TRIS', {"pos": pos, "color": col}).draw(sh)

    def dots(self, pts, color, size=2.0):
        """Small squares centred on pts, in one draw (a board's dot grid)."""
        if not pts:
            return
        gpu.state.blend_set('ALPHA')
        r = size / 2
        tris = []
        for x, y in pts:
            a, b, c, d = (x - r, y - r), (x + r, y - r), (x + r, y + r), (x - r, y + r)
            tris += (a, b, c, a, c, d)
        sh = gpu.shader.from_builtin('UNIFORM_COLOR')
        sh.bind()
        sh.uniform_float("color", self.color(color))
        batch_for_shader(sh, 'TRIS', {"pos": tris}).draw(sh)

    def clip(self, x0, y0, x1, y1):
        """Draw only inside this rectangle (region pixels) until unclip()."""
        if self._scissor is None:
            self._scissor = tuple(gpu.state.scissor_get())
        bx, by = self._scissor[0], self._scissor[1]
        gpu.state.scissor_test_set(True)
        gpu.state.scissor_set(int(bx + x0), int(by + y0), max(0, int(x1 - x0)), max(0, int(y1 - y0)))

    def unclip(self):
        if self._scissor is not None:
            gpu.state.scissor_set(*self._scissor)

    def text(self, x, y, s, size, color, weight=400, font="ui"):
        """Draw one run with its baseline at y (region pixels)."""
        fid = font_id(font, weight)
        set_font(fid, size, weight)
        blf.color(fid, *self.color(color))
        blf.position(fid, round(x), round(y), 0)
        blf.draw(fid, s)

    def finish(self):
        self.unclip()
        restore_fonts()
        gpu.state.blend_set('NONE')


# ---------------------------------------------------------------------------
# Fonts and measuring.

_fonts = {}
_font_state = {}
_widths = {}


_loaded = {}  # font file -> blf id (each loaded once)


def _load(path):
    if path not in _loaded:
        fid = blf.load(path) if path and os.path.isfile(path) else -1
        _loaded[path] = fid if fid >= 0 else 0
    return _loaded[path]


def font_id(name, weight=400):
    """A font by role: ui (prose), mono (names, numbers, code), head (headings), from the look;
    its semibold file from weight 600."""
    from . import looks
    key = (name, weight >= looks.SEMIBOLD)
    if key not in _fonts:
        path = looks.font_path(name, weight)
        if path:
            _fonts[key] = _load(path)
        elif name == "mono":
            _fonts[key] = _load(os.path.join(bpy.utils.system_resource('DATAFILES'), "fonts", "DejaVuSansMono.woff2"))
        else:
            _fonts[key] = 0
    return _fonts[key]


def reset_fonts():
    """A new look: fonts by role and measures start again."""
    restore_fonts()
    _fonts.clear()
    _widths.clear()
    _font_state.clear()


def unload_fonts():
    restore_fonts()
    for path, fid in list(_loaded.items()):
        if fid:
            try:
                blf.unload(path)
            except (ValueError, RuntimeError):
                pass
    _loaded.clear()
    _fonts.clear()


def set_font(fid, size, weight=400):
    key = (round(size * 4) / 4, weight)
    if _font_state.get(fid) == key:
        return
    blf.size(fid, key[0])
    if hasattr(blf, "weight"):
        blf.weight(fid, weight)
    _font_state[fid] = key


def restore_fonts():
    """Leave fonts as Blender's own UI drawing expects them (regular weight)."""
    if hasattr(blf, "weight"):
        for fid in set(_fonts.values()):
            blf.weight(fid, 0)
    _font_state.clear()


def measure(s, size, weight=400, font="ui"):
    key = (s, round(size * 4), weight, font)
    w = _widths.get(key)
    if w is None:
        fid = font_id(font, weight)
        set_font(fid, size, weight)
        w = blf.dimensions(fid, s)[0]
        if w <= 0 and s.strip() and size > 0 and fid and recover_fonts():
            return measure(s, size, weight, font)  # the font went away under us: loaded again
        if len(_widths) > 60000:
            _widths.clear()
        _widths[key] = w
    return w


_recovering = {"t": 0.0}


def recover_fonts():
    """The add-on's fonts load again (Blender can drop them, e.g. while a save point is reopened;
    they then measure and draw as nothing). Returns True when it reloaded, at most once a second."""
    import time
    if time.time() - _recovering["t"] < 1.0:
        return False
    _recovering["t"] = time.time()
    _loaded.clear()
    _fonts.clear()
    _widths.clear()
    _font_state.clear()
    try:
        from . import ui_space
        ui_space._layout_cache.clear()  # laid out with the dead font's widths
    except ImportError:
        pass
    return True


def space_width(size, weight=400, font="ui"):
    return measure("x x", size, weight, font) - measure("xx", size, weight, font)


def ellipsize(s, size, maxw, weight=400, font="ui"):
    if measure(s, size, weight, font) <= maxw:
        return s
    lo, hi = 0, len(s)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if measure(s[:mid].rstrip() + "…", size, weight, font) <= maxw:
            lo = mid
        else:
            hi = mid - 1
    return s[:lo].rstrip() + "…"


def baseline(line_top, line_h, size):
    """Doc-space baseline (y down) of a line box."""
    return line_top + line_h * 0.5 + size * 0.36


# ---------------------------------------------------------------------------
# Images: loaded straight to the GPU (nothing is added to the .blend file).

_textures = {}


def texture(path, max_w=720):
    """(GPUTexture, width, height) for a PNG/JPG, or None. Cached by path and size."""
    key = (path, max_w)
    if key in _textures:
        return _textures[key]
    result = None
    try:
        ib = imbuf.load(path)
        w, h = ib.size
        if w > max_w:
            ib.resize((max_w, max(1, round(h * max_w / w))), method='BILINEAR')
            w, h = ib.size
        if ib.channels != 4 or ib.buffer_type != 'BYTE':
            ib.convert_buffer_type('BYTE')
        with ib.with_buffer() as buf:
            arr = np.asarray(buf)
            if arr.shape[-1] == 3:
                arr = np.concatenate([arr, np.full(arr.shape[:2] + (1,), 255, arr.dtype)], axis=-1)
            data = (arr.astype(np.float32) / 255.0).ravel()
        tex = gpu.types.GPUTexture((w, h), format='RGBA16F', data=gpu.types.Buffer('FLOAT', data.size, data))
        result = (tex, w, h)
        ib.free()
    except Exception as ex:  # noqa: BLE001 - a broken image should not break the editor
        print("agent_bridge: could not load", path, ex)
    if len(_textures) > 120:
        _textures.clear()
    _textures[key] = result
    return result


def image_size(path):
    t = texture(path)
    return (t[1], t[2]) if t else (4, 3)


# ---------------------------------------------------------------------------
# Markdown-lite layout.
#
# Ops (doc space, y down):
#   ("t", x, baseline_y, text, size, weight, color, font)
#   ("r", x0, y0, x1, y1, color, radius)
#   ("l", [(x, y), ...], color, width)
#   ("i", image_path, x0, y0, x1, y1, radius)


class Metrics:
    def __init__(self, s):
        self.s = s
        self.body = 13.5 * s
        self.small = 11.5 * s
        self.tiny = 10.5 * s
        self.mono = 12.0 * s
        self.lh = 1.55
        self.h = {1: 19.0 * s, 2: 16.5 * s, 3: 14.5 * s}

    def line_h(self, size):
        return round(size * self.lh)


_INLINE = re.compile(r"(\*\*[^*\n]+\*\*|__[^_\n]+__|`[^`\n]+`|(?<![\w*])\*[^*\s][^*\n]*\*(?!\w)"
                     r"|(?<![\w_])_[^_\s][^_\n]*_(?![\w_])|\[[^\]\n]+\]\([^)\s]+\))")


def spans(text):
    """Inline Markdown to [(text, style)], style in n (normal), b (bold), c (code), i, a (link)."""
    out = []
    pos = 0
    for m in _INLINE.finditer(text):
        if m.start() > pos:
            out.append((text[pos:m.start()], "n"))
        tok = m.group(0)
        if tok.startswith("**") or tok.startswith("__"):
            out.append((tok[2:-2], "b"))
        elif tok.startswith("`"):
            out.append((tok[1:-1], "c"))
        elif tok.startswith("["):
            out.append((tok[1:tok.index("]")], "a"))
        else:
            out.append((tok[1:-1], "i"))
        pos = m.end()
    if pos < len(text):
        out.append((text[pos:], "n"))
    return out


def _style_font(style, size, weight, m, font="ui"):
    if style == "c":
        return m.mono * size / m.body, 400, "mono"
    if style == "b":
        return size, max(weight, 650), font
    return size, weight, font


def _break_word(word, size, weight, font, maxw):
    """Split a word too long for a line (paths, URLs) into pieces that fit."""
    pieces, cur = [], ""
    for ch in word:
        if cur and measure(cur + ch, size, weight, font) > maxw:
            pieces.append(cur)
            cur = ch
        else:
            cur += ch
    if cur:
        pieces.append(cur)
    return pieces


def flow(span_list, maxw, size, m, weight=400, color="text", indent=0.0, font="ui"):
    """Wrap styled spans into lines: [[(x, text, style, size, weight, font, color, spaced)]]
    where `spaced` says a space came before the word on that line."""
    words = []  # (text, style) with explicit spaces as ' '
    for text, style in span_list:
        for tok in re.findall(r"\S+|\s+", text):
            words.append((" " if tok.isspace() else tok, style))
    lines = [[]]
    x = indent
    pending_space = 0.0
    base_font = font
    for tok, style in words:
        fs, fw, font = _style_font(style, size, weight, m, base_font)
        if tok == " ":
            if lines[-1]:
                pending_space = space_width(fs, fw, font)
            continue
        w = measure(tok, fs, fw, font)
        if lines[-1] and x + pending_space + w > maxw:
            lines.append([])
            x = indent
            pending_space = 0.0
        if w > maxw - indent:
            for piece in _break_word(tok, fs, fw, font, maxw - indent):
                pw = measure(piece, fs, fw, font)
                if lines[-1] and x + pw > maxw:
                    lines.append([])
                    x = indent
                lines[-1].append((x, piece, style, fs, fw, font, color))
                x += pw
            pending_space = 0.0
            continue
        spaced = pending_space > 0
        x += pending_space
        lines[-1].append((x, tok, style, fs, fw, font, color, spaced))
        x += w
        pending_space = 0.0
    return lines


def _merge_runs(line):
    """Join neighbouring words of the same style into one run (fewer draw calls)."""
    runs = []
    for x, text, style, fs, fw, font, color, *sp in line:
        if runs and runs[-1][2] == style and style != "c" and runs[-1][6] == color:
            prev = runs[-1]
            runs[-1] = (prev[0], prev[1] + (" " if sp and sp[0] else "") + text) + prev[2:]
        else:
            runs.append((x, text, style, fs, fw, font, color))
    return runs


def emit_lines(ops, lines, x0, y, size, m, line_h=None):
    """Append text ops for flowed lines starting at doc y; returns the new y."""
    lh = line_h or m.line_h(size)
    for line in lines:
        base = baseline(y, lh, size)
        for x, text, style, fs, fw, font, color in _merge_runs(line):
            if style == "c":
                w = measure(text, fs, fw, font)
                ops.append(("r", x0 + x - 3 * m.s, y + lh * 0.16, x0 + x + w + 3 * m.s, y + lh * 0.86,
                            "code_bg", 4 * m.s))
            col = "accent" if style == "a" else ("code_text" if style == "c" else color)
            ops.append(("t", x0 + x, base, text, fs, fw, col, font))
        y += lh
    return y


_BLOCK_SPECIAL = re.compile(r"^\s*(#{1,6}\s|[-*•]\s|\d+[.)]\s|```|\||>|(---|\*\*\*|___)\s*$)")


def blocks(md):
    lines = md.replace("\r", "").split("\n")
    out = []
    i = 0
    while i < len(lines):
        ln = lines[i]
        st = ln.strip()
        if st.startswith("```"):
            code = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code.append(lines[i].rstrip())
                i += 1
            i += 1
            out.append(("code", code))
            continue
        if not st:
            i += 1
            continue
        mh = re.match(r"^(#{1,6})\s+(.*)", st)
        if mh:
            out.append(("h", min(3, len(mh.group(1))), mh.group(2).strip("# ")))
            i += 1
            continue
        if st.startswith("|") and st.endswith("|") and len(st) > 1:
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{1,}:?", c) for c in cells if c):
                    rows.append(cells)
                i += 1
            if rows:
                out.append(("table", rows))
            continue
        if re.fullmatch(r"(---|\*\*\*|___)", st):
            out.append(("hr",))
            i += 1
            continue
        ml = re.match(r"^(\s*)([-*•]|\d+[.)])\s+(.*)", ln)
        if ml:
            depth = min(3, len(ml.group(1).replace("\t", "  ")) // 2)
            out.append(("li", depth, ml.group(2), ml.group(3)))
            i += 1
            continue
        if st.startswith(">"):
            out.append(("quote", st.lstrip("> ")))
            i += 1
            continue
        para = [st]
        i += 1
        while i < len(lines) and lines[i].strip() and not _BLOCK_SPECIAL.match(lines[i]):
            para.append(lines[i].strip())
            i += 1
        out.append(("p", " ".join(para)))
    return out


def layout_markdown(md, width, m, color="text"):
    """Lay out an agent reply. Returns (ops, height) in doc space."""
    from . import looks
    ops = []
    y = 0.0
    prev = None
    for b in blocks(md):
        kind = b[0]
        if prev is not None:
            if kind == "li" and prev == "li":
                y += 2 * m.s
            elif kind == "h":
                y += 14 * m.s
            else:
                y += 9 * m.s
        if kind == "p":
            y = emit_lines(ops, flow(spans(b[1]), width, m.body, m, color=color), 0, y, m.body, m)
        elif kind == "h":
            size = m.h[b[1]] * (0.86 if looks.get()["upper"] else 1.0)  # the heading font runs wide
            y = emit_lines(ops, flow(spans(b[2]), width, size, m, weight=650, color=color, font="head"), 0, y,
                           size, m, line_h=round(size * 1.35))
        elif kind == "li":
            depth, marker, text = b[1], b[2], b[3]
            indent = (18 + depth * 18) * m.s
            lh = m.line_h(m.body)
            bullet_x = indent - 12 * m.s
            if marker[0].isdigit():
                label = marker.rstrip(".)") + "."
                ops.append(("t", indent - 6 * m.s - measure(label, m.body, 500), baseline(y, lh, m.body), label,
                            m.body, 500, "muted", "ui"))
            elif looks.get()["bullet"] == "chevron":
                ops.append(("t", bullet_x - 3 * m.s, baseline(y, lh, m.body), "›", m.body, 600, "agent", "ui"))
            else:
                cy = y + lh * 0.5 + 0.5 * m.s
                ops.append(("r", bullet_x - 2.2 * m.s, cy - 2.2 * m.s, bullet_x + 2.2 * m.s, cy + 2.2 * m.s,
                            "muted", 3 * m.s))
            y = emit_lines(ops, flow(spans(text), width, m.body, m, color=color, indent=indent), 0, y, m.body, m)
        elif kind == "quote":
            top = y
            y = emit_lines(ops, flow(spans(b[1]), width - 14 * m.s, m.body, m, color="muted"), 14 * m.s, y,
                           m.body, m)
            ops.append(("r", 0, top + 3 * m.s, 3 * m.s, y - 3 * m.s, "border2", 1.5 * m.s))
        elif kind == "hr":
            y += 4 * m.s
            ops.append(("r", 0, y, width, y + max(1.0, m.s), "border", 0))
            y += 4 * m.s
        elif kind == "code":
            y = _layout_code(ops, b[1], width, y, m)
        elif kind == "table":
            y = _layout_table(ops, b[1], width, y, m, color)
        prev = kind
    return ops, y


def _layout_code(ops, code_lines, width, y, m):
    pad = 10 * m.s
    lh = round(m.mono * 1.5)
    rows = []
    for ln in code_lines or [""]:
        ln = ln.replace("\t", "    ")
        rows += _break_word(ln, m.mono, 400, "mono", width - 2 * pad) if ln else [""]
    top = y
    ops.append(("r", 0, top, width, top + len(rows) * lh + 2 * pad, "code_bg", 8 * m.s))
    y += pad
    for row in rows:
        if row:
            ops.append(("t", pad, baseline(y, lh, m.mono), row, m.mono, 400, "text", "mono"))
        y += lh
    return y + pad


def _layout_table(ops, rows, width, y, m, color):
    ncol = max(len(r) for r in rows)
    rows = [r + [""] * (ncol - len(r)) for r in rows]
    pad = 8 * m.s
    natural = [0.0] * ncol
    for ri, r in enumerate(rows):
        for ci, cell in enumerate(r):
            weight = 650 if ri == 0 else 400
            natural[ci] = max(natural[ci], measure(re.sub(r"[*`]", "", cell), m.small + 1 * m.s, weight) + 2 * pad)
    total = sum(natural)
    if total > width:
        floor = 56 * m.s
        extra = width - floor * ncol
        widths = [floor + max(0.0, extra) * (n / total) for n in natural] if extra > 0 else [width / ncol] * ncol
    else:
        widths = natural
    size = m.small + 1 * m.s
    lh = m.line_h(size)
    table_w = sum(widths)
    top = y
    for ri, r in enumerate(rows):
        cell_lines = [flow(spans(cell), widths[ci] - 2 * pad, size, m, weight=650 if ri == 0 else 400,
                           color=color) for ci, cell in enumerate(r)]
        row_h = max(len(cl) for cl in cell_lines) * lh + 2 * pad * 0.6
        if ri == 0:
            ops.append(("r", 0, y, table_w, y + row_h, "surface", 6 * m.s))
        x = 0.0
        for ci, cl in enumerate(cell_lines):
            emit_lines(ops, cl, x + pad, y + pad * 0.6, size, m)
            x += widths[ci]
        y += row_h
        if ri < len(rows) - 1:
            ops.append(("r", 0, y, table_w, y + max(1.0, m.s), "border", 0))
    del top
    return y


def draw_ops(cv, ops, ox, oy, clip_top=None, clip_bottom=None):
    """Draw doc-space ops with the block's top-left at region (ox, oy)."""
    for op in ops:
        kind = op[0]
        if kind == "t":
            _, x, y, text, size, weight, color, font = op
            ry = oy - y
            if (clip_top is not None and ry - size > clip_top) or (clip_bottom is not None and ry + size < clip_bottom):
                continue
            cv.text(ox + x, ry, text, size, color, weight, font)
        elif kind == "r":
            _, x0, y0, x1, y1, color, radius, *soft = op
            cv.rect(ox + x0, oy - y1, ox + x1, oy - y0, color, radius, soft=soft[0] if soft else 1.0)
        elif kind == "l":
            _, pts, color, width = op
            cv.line([(ox + x, oy - y) for x, y in pts], color, width)
        elif kind == "i":
            _, path, x0, y0, x1, y1, radius = op
            tex = texture(path)
            if tex:
                cv.image(tex[0], ox + x0, oy - y1, ox + x1, oy - y0, radius)
            else:
                cv.rect(ox + x0, oy - y1, ox + x1, oy - y0, "surface", radius)
