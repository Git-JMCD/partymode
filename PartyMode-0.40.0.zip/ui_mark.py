# SPDX-License-Identifier: GPL-3.0-or-later
"""
Mark an area: drag a box over part of a 3D viewport or any editor to show the agent what you mean.

A mark keeps a picture (the editor with the box drawn on it, and a close-up) and facts about
what is inside: in a 3D viewport, rays cast through the box name the objects, faces and
materials under it and where they are in metres; in the node editor, the nodes; in the image /
UV editor, the UV range. Marks wait in the message box as chips and go with the next message:
the facts in the prompt, the pictures through the view_marks tool (every agent can call it).
In a 3D viewport the red box is tied to the points under it, so it follows the model when the
view turns.
"""

import math
import os
import tempfile
import time

import blf
import bpy
import gpu
import numpy as np
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

_M = {"pending": [], "sent": {}, "next": 1, "drag": None, "hide": False, "active": False}
RED = (0.94, 0.23, 0.2, 1.0)
_GRID = 20          # rays per side of a 3D box
_MAX_PX = 1024      # longest side of a picture sent to the agent
_KEEP_SENT = 40

EDITORS = {"VIEW_3D": "3D viewport", "NODE_EDITOR": "node editor", "IMAGE_EDITOR": "image / UV editor",
           "PROPERTIES": "properties editor", "OUTLINER": "outliner", "TEXT_EDITOR": "text editor",
           "DOPESHEET_EDITOR": "dope sheet / timeline", "GRAPH_EDITOR": "graph editor",
           "SEQUENCE_EDITOR": "video sequencer", "CLIP_EDITOR": "movie clip editor", "SPREADSHEET": "spreadsheet",
           "NLA_EDITOR": "NLA editor", "INFO": "info editor", "FILE_BROWSER": "file browser"}
_TREES = {"ShaderNodeTree": "shader editor", "GeometryNodeTree": "geometry nodes editor",
          "CompositorNodeTree": "compositor", "TextureNodeTree": "texture nodes"}


# ---------------------------------------------------------------------------
# State other modules read.

def pending(key=None):
    """Marks waiting in a message box (the one for chat `key`, or all)."""
    return [m for m in _M["pending"] if key is None or m["key"] == key]


def remove(mark_id):
    _M["pending"] = [m for m in _M["pending"] if m["id"] != mark_id]
    _redraw()


def take(key):
    """The marks going with this message: out of the box, into the sent list."""
    out = pending(key)
    _M["pending"] = [m for m in _M["pending"] if m["key"] != key]
    now = time.time()
    for m in out:
        m["sent_with"] = now
        _M["sent"][m["id"]] = m
    while len(_M["sent"]) > _KEEP_SENT:
        _M["sent"].pop(next(iter(_M["sent"])))
    _redraw()
    return out


def give_back(key, marks):
    """Marks of a message that waited and was taken back: in the box again."""
    for m in marks:
        m.pop("sent_with", None)
        _M["sent"].pop(m["id"], None)
        m["key"] = key
        if all(p["id"] != m["id"] for p in _M["pending"]):
            _M["pending"].append(m)
    _redraw()


def find(mark_id):
    return next((m for m in _M["pending"] if m["id"] == mark_id), None) or _M["sent"].get(mark_id)


def latest(limit=4):
    """The newest marks: the ones waiting in a message box, else the last message's."""
    if _M["pending"]:
        return _M["pending"][-limit:]
    sent = list(_M["sent"].values())
    if not sent:
        return []
    t = sent[-1]["sent_with"]
    return [m for m in sent if m.get("sent_with") == t][-limit:]


def context_text(marks):
    """What the prompt says about the marks that go with a message."""
    if not marks:
        return ""
    lines = ["The user marked {} for this message (call view_marks to see {}):".format(
        "an area" if len(marks) == 1 else "{} areas".format(len(marks)), "it" if len(marks) == 1 else "them")]
    for m in marks:
        lines.append("- mark {} ({}): {}".format(m["n"], m["editor_label"], m["facts"].get("summary", "")))
    return "\n".join(lines)


def label(m):
    return m["facts"].get("short") or m["editor_label"]


# ---------------------------------------------------------------------------
# Facts.

def _fmt(v, nd=3):
    return "(" + ", ".join("{:.{}g}".format(x, nd) for x in v) + ")"


def _facing(n):
    axis = max(range(3), key=lambda i: abs(n[i]))
    return ("+" if n[axis] > 0 else "-") + "XYZ"[axis] if abs(n[axis]) > 0.7 else "mixed directions"


def _facts_view3d(context, area, region, rect):
    """Rays through a grid inside the box: what is under it, and where."""
    rv3d = area.spaces.active.region_3d
    dg = context.evaluated_depsgraph_get()
    scene = context.scene
    x0, y0, x1, y1 = rect
    hits, points, total = {}, [], 0
    for i in range(_GRID):
        for j in range(_GRID):
            p = (x0 + (i + 0.5) * (x1 - x0) / _GRID, y0 + (j + 0.5) * (y1 - y0) / _GRID)
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, p)
            ray = view3d_utils.region_2d_to_vector_3d(region, rv3d, p)
            total += 1
            ok, loc, nrm, idx, ob, _mx = scene.ray_cast(dg, origin, ray)
            if ok and ob is not None:
                hits.setdefault(ob.name, []).append((loc.copy(), nrm.copy(), idx))
                points.append(loc.copy())
    objects = []
    for name, rows in sorted(hits.items(), key=lambda kv: -len(kv[1])):
        ob = bpy.data.objects.get(name)
        locs = [r[0] for r in rows]
        lo = Vector([min(v[k] for v in locs) for k in range(3)])
        hi = Vector([max(v[k] for v in locs) for k in range(3)])
        normal = sum((r[1] for r in rows), Vector()).normalized()
        entry = {"name": name, "share": round(len(rows) / total, 3), "faces_hit": len({r[2] for r in rows}),
                 "world_centre": [round(x, 4) for x in (lo + hi) / 2], "world_size_m": [round(x, 4) for x in hi - lo],
                 "facing": _facing(normal)}
        if ob is not None:
            inv = ob.matrix_world.inverted()
            local = [inv @ v for v in locs]
            entry["local_min"] = [round(min(v[k] for v in local), 4) for k in range(3)]
            entry["local_max"] = [round(max(v[k] for v in local), 4) for k in range(3)]
            mats = set()
            ev = ob.evaluated_get(dg)
            if ev.type == 'MESH' and ev.data is not None:
                polys, slots = ev.data.polygons, ev.material_slots
                for r in rows:
                    if 0 <= r[2] < len(polys):
                        mi = polys[r[2]].material_index
                        if mi < len(slots) and slots[mi].material:
                            mats.add(slots[mi].material.name)
            entry["materials"] = sorted(mats)
            entry["face_indices"] = sorted({r[2] for r in rows})[:40]
        objects.append(entry)
    background = round(1 - len(points) / total, 3)
    view = {"perspective": rv3d.view_perspective.lower(), "view_location": [round(x, 4) for x in rv3d.view_location],
            "view_distance": round(rv3d.view_distance, 4),
            "view_rotation": [round(x, 5) for x in rv3d.view_rotation]}
    if objects:
        top = objects[0]
        bits = ["{} ({:.0%} of the box; {} faces{}; centre {} m, spans {} m; facing {})".format(
            top["name"], top["share"], top["faces_hit"],
            "; material " + ", ".join(top["materials"][:3]) if top.get("materials") else "",
            _fmt(top["world_centre"]), _fmt(top["world_size_m"]), top["facing"])]
        bits += ["{} ({:.0%})".format(o["name"], o["share"]) for o in objects[1:5]]
        summary = "mostly " + bits[0] + ("; also " + ", ".join(bits[1:]) if len(bits) > 1 else "")
        if background > 0.02:
            summary += "; {:.0%} empty background".format(background)
        short = top["name"]
    else:
        summary, short = "nothing but background (no object under the box)", "background"
    return {"objects": objects, "background_share": background, "view": view, "summary": summary,
            "short": short}, points


def _node_rect(node, region):
    loc = Vector(node.location)
    p = node.parent
    while p is not None:
        loc += Vector(p.location)
        p = p.parent
    scale = bpy.context.preferences.system.ui_scale
    w, h = node.width * scale, (node.dimensions.y or 100 * scale)
    ax, ay = region.view2d.view_to_region(loc.x * scale, loc.y * scale, clip=False)
    return ax, ay - h, ax + w, ay


def _facts_editor(context, area, region, rect):
    space = area.spaces.active
    facts = {}
    x0, y0, x1, y1 = rect
    if area.type == 'NODE_EDITOR' and getattr(space, "edit_tree", None):
        tree = space.edit_tree
        inside = []
        for node in tree.nodes:
            nx0, ny0, nx1, ny1 = _node_rect(node, region)
            if nx1 > x0 and nx0 < x1 and ny1 > y0 and ny0 < y1:
                inside.append({"name": node.name, "type": node.bl_idname,
                               "label": node.label or node.bl_label})
        facts.update(tree=tree.name, tree_type=tree.bl_idname, nodes=inside[:40])
        owner = getattr(space, "id", None)
        if owner is not None:
            facts["owner"] = owner.name
        names = ", ".join(n["label"] for n in inside[:8])
        facts["summary"] = "{} in {}{}".format(names or "no nodes", tree.name,
                                                " (+{} more)".format(len(inside) - 8) if len(inside) > 8 else "")
        facts["short"] = inside[0]["label"] if inside else tree.name
    elif area.type == 'IMAGE_EDITOR':
        u0, v0 = region.view2d.region_to_view(x0, y0)
        u1, v1 = region.view2d.region_to_view(x1, y1)
        img = getattr(space, "image", None)
        facts.update(image=img.name if img else None, uv_min=[round(u0, 4), round(v0, 4)],
                     uv_max=[round(u1, 4), round(v1, 4)], mode=getattr(space, "ui_mode", ""))
        facts["summary"] = "UV / image area u {:.3f}-{:.3f}, v {:.3f}-{:.3f}{}".format(
            u0, u1, v0, v1, " of " + img.name if img else "")
        facts["short"] = img.name if img else "UV area"
    else:
        if area.type == 'PROPERTIES':
            facts["tab"] = space.context.lower()
        facts["summary"] = "part of the {}{}".format(EDITORS.get(area.type, area.type.lower()),
                                                     " ({} tab)".format(facts["tab"]) if "tab" in facts else "")
        facts["short"] = EDITORS.get(area.type, area.type.lower())
    return facts


def _editor_label(area):
    if area.type == 'NODE_EDITOR':
        tree = getattr(area.spaces.active, "edit_tree", None)
        if tree is not None:
            return _TREES.get(tree.bl_idname, "node editor")
    return EDITORS.get(area.type, area.type.lower().replace("_", " "))


# ---------------------------------------------------------------------------
# Pictures.

def _png(rgb):
    from .tools_inspect import _png as encode
    return encode(np.ascontiguousarray(np.flipud(rgb)))  # Blender's rows run bottom-up


def _shrink(rgb):
    h, w, _ = rgb.shape
    f = max(1, math.ceil(max(h, w) / _MAX_PX))
    if f == 1:
        return rgb
    h2, w2 = h // f * f, w // f * f
    return rgb[:h2, :w2].reshape(h2 // f, f, w2 // f, f, 3).mean(axis=(1, 3)).astype(np.uint8)


def _box(rgb, x0, y0, x1, y1, t):
    h, w, _ = rgb.shape
    x0, x1 = max(0, int(x0)), min(w - 1, int(x1))
    y0, y1 = max(0, int(y0)), min(h - 1, int(y1))
    col = (np.array(RED[:3]) * 255).astype(np.uint8)
    rgb[y0:y0 + t, x0:x1 + 1] = col
    rgb[max(y0, y1 - t + 1):y1 + 1, x0:x1 + 1] = col
    rgb[y0:y1 + 1, x0:x0 + t] = col
    rgb[y0:y1 + 1, max(x0, x1 - t + 1):x1 + 1] = col


def _screenshot(window):
    """The window as an (h, w, 3) uint8 array, rows bottom-up, without the marks drawn on it."""
    _M["hide"] = True
    path = os.path.join(tempfile.gettempdir(), "agent_mark_{}.png".format(os.getpid()))
    try:
        with bpy.context.temp_override(window=window, screen=window.screen):
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
            bpy.ops.screen.screenshot(filepath=path, check_existing=False)
    finally:
        _M["hide"] = False
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        px = np.empty(w * h * 4, np.float32)
        img.pixels.foreach_get(px)
    finally:
        bpy.data.images.remove(img)
        try:
            os.remove(path)
        except OSError:
            pass
    return (px.reshape(h, w, 4)[:, :, :3] * 255 + 0.5).astype(np.uint8)


def _region_shot(window, region):
    shot = _screenshot(window)
    sh, sw, _ = shot.shape
    sx, sy = sw / max(1, window.width), sh / max(1, window.height)  # pixel size vs window units
    rx0, ry0 = int(region.x * sx), int(region.y * sy)
    rx1, ry1 = int((region.x + region.width) * sx), int((region.y + region.height) * sy)
    return shot[ry0:ry1, rx0:rx1].copy(), sx, sy


def _grow(rgb, want=480, most=4):
    """Small close-ups scaled up in whole steps (crisp pixels, readable UI text)."""
    h, w, _ = rgb.shape
    f = min(most, max(1, want // max(1, max(h, w))))
    return rgb.repeat(f, axis=0).repeat(f, axis=1) if f > 1 else rgb


def _zoomed(window, area, region, rect, centre):
    """A sharp close-up in a 3D viewport: for one frame the view centres on the marked spot and
    zooms so the box fills it, then goes back exactly as it was."""
    rv3d = area.spaces.active.region_3d
    saved = (rv3d.view_location.copy(), rv3d.view_distance, rv3d.view_rotation.copy(), rv3d.view_camera_zoom,
             rv3d.view_camera_offset[:], rv3d.view_perspective)
    bw, bh = rect[2] - rect[0], rect[3] - rect[1]
    # The box fills about 60% of the view: the middle stays clear of side panels and the bar.
    f = max(bw / region.width, bh / region.height) * 1.6
    eye = _eye(rv3d)
    try:
        if rv3d.view_perspective == 'CAMERA':  # look along the camera, but freely
            cam = bpy.context.scene.camera
            rv3d.view_perspective = 'PERSP'
            if cam is not None:
                rv3d.view_rotation = cam.matrix_world.to_quaternion()
                eye = cam.matrix_world.translation.copy()
        if rv3d.view_perspective == 'PERSP':
            dist = (centre - eye).length * f
        else:
            dist = rv3d.view_distance * f
        rv3d.view_location = centre
        rv3d.view_distance = max(1e-4, dist)
        img, sx, sy = _region_shot(window, region)
    finally:
        loc, dist, rot, czoom, coff, persp = saved
        rv3d.view_perspective = persp
        rv3d.view_location, rv3d.view_distance, rv3d.view_rotation = loc, dist, rot
        rv3d.view_camera_zoom, rv3d.view_camera_offset = czoom, coff
        area.tag_redraw()
    h, w, _ = img.shape
    cw, ch = min(w, int(bw * sx / f * 1.1) + 2), min(h, int(bh * sy / f * 1.1) + 2)
    x0, y0 = max(0, (w - cw) // 2), max(0, (h - ch) // 2)
    return img[y0:y0 + ch, x0:x0 + cw]


def _eye(rv3d):
    return rv3d.view_matrix.inverted().translation


def _pictures(window, area, region, rect, centre=None):
    """The editor with the box drawn on it, and a close-up of the box."""
    editor, sx, sy = _region_shot(window, region)
    bx0, by0, bx1, by1 = rect[0] * sx, rect[1] * sy, rect[2] * sx, rect[3] * sy
    close = None
    if centre is not None:
        try:
            close = _zoomed(window, area, region, rect, centre)
        except (RuntimeError, ValueError):
            close = None
    if close is None or close.size == 0:
        pad_x, pad_y = (bx1 - bx0) * 0.12 + 4, (by1 - by0) * 0.12 + 4
        cx0, cy0 = int(max(0, bx0 - pad_x)), int(max(0, by0 - pad_y))
        cx1, cy1 = int(min(editor.shape[1], bx1 + pad_x)), int(min(editor.shape[0], by1 + pad_y))
        close = _grow(editor[cy0:cy1, cx0:cx1].copy())
    t = max(2, int(round(2 * sx)))
    _box(editor, bx0, by0, bx1, by1, t)
    return _png(_shrink(editor)), _png(_shrink(close))


# ---------------------------------------------------------------------------
# Making a mark.

def _under(window, x, y):
    for area in window.screen.areas:
        if area.x <= x < area.x + area.width and area.y <= y < area.y + area.height:
            region = next((rg for rg in area.regions if rg.type == 'WINDOW'), None)
            if region and region.x <= x < region.x + region.width and region.y <= y < region.y + region.height:
                return area, region
            return None, None
    return None, None


def _centre_hit(context, area, region, rect, points):
    """The point under the middle of the box (else the middle of what the box covered)."""
    if not points:
        return None
    rv3d = area.spaces.active.region_3d
    p = ((rect[0] + rect[2]) / 2, (rect[1] + rect[3]) / 2)
    ok, loc, *_ = context.scene.ray_cast(context.evaluated_depsgraph_get(),
                                         view3d_utils.region_2d_to_origin_3d(region, rv3d, p),
                                         view3d_utils.region_2d_to_vector_3d(region, rv3d, p))
    return loc.copy() if ok else sum(points, Vector()) / len(points)


def make(context, window, area, region, rect, key=None):
    """A mark from a box in region coordinates (x0, y0, x1, y1); the whole region when tiny."""
    from . import ui_space
    x0, y0, x1, y1 = rect
    x0, x1 = sorted((max(0, x0), min(region.width, x1)))
    y0, y1 = sorted((max(0, y0), min(region.height, y1)))
    whole = (x1 - x0) < 6 or (y1 - y0) < 6
    if whole:
        x0, y0, x1, y1 = 0, 0, region.width, region.height
    rect = (x0, y0, x1, y1)
    points = centre = None
    if area.type == 'VIEW_3D':
        facts, points = _facts_view3d(context, area, region, rect)
        centre = _centre_hit(context, area, region, rect, points)
    else:
        facts = _facts_editor(context, area, region, rect)
    facts["whole_editor"] = whole
    pics = _pictures(window, area, region, rect, centre)
    n = _M["next"]
    _M["next"] += 1
    m = {"id": "m{}".format(n), "n": n, "key": key or ui_space._session_key(context.window_manager),
         "area": area.as_pointer(), "editor": area.type, "editor_label": _editor_label(area),
         "rect": rect, "region_size": (region.width, region.height), "points": points,
         "view": None, "facts": facts, "images": list(pics), "t": time.time(),
         "file": os.path.basename(bpy.data.filepath)}
    if area.type == 'VIEW_3D':
        rv3d = area.spaces.active.region_3d
        m["view"] = rv3d.perspective_matrix.copy()
    _M["pending"].append(m)
    _redraw()
    return m


# ---------------------------------------------------------------------------
# Drawing.

def _shader():
    return gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')


def _outline(region, x0, y0, x1, y1, width, color=RED, dash=False):
    sh = _shader()
    pts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
    if dash:
        segs = []
        for a, b in zip(pts, pts[1:]):
            length = math.dist(a, b)
            steps = max(1, int(length / 8))
            for k in range(0, steps, 2):
                t0, t1 = k / steps, min(1.0, (k + 1) / steps)
                segs += [(a[0] + (b[0] - a[0]) * t0, a[1] + (b[1] - a[1]) * t0),
                         (a[0] + (b[0] - a[0]) * t1, a[1] + (b[1] - a[1]) * t1)]
        batch = batch_for_shader(sh, 'LINES', {"pos": segs})
    else:
        batch = batch_for_shader(sh, 'LINE_STRIP', {"pos": pts})
    sh.bind()
    sh.uniform_float("viewportSize", (region.width, region.height))
    sh.uniform_float("lineWidth", width)
    sh.uniform_float("color", color)
    batch.draw(sh)


def _tag(x, y, text, s):
    size = 11 * s
    blf.size(0, size)
    tw, _th = blf.dimensions(0, text)
    w, h = tw + 10 * s, size + 7 * s
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(sh, 'TRIS', {"pos": [(x, y), (x + w, y), (x + w, y + h), (x, y), (x + w, y + h), (x, y + h)]})
    sh.bind()
    sh.uniform_float("color", RED)
    batch.draw(sh)
    blf.color(0, 1, 1, 1, 1)
    blf.position(0, x + 5 * s, y + 4.5 * s, 0)
    blf.draw(0, text)


def rect_now(m, area, region):
    """Where a mark's box is now: the drawn box while the view is unchanged; in a turned 3D view,
    around the points the box covered."""
    if m["points"] and area.type == 'VIEW_3D':
        rv3d = area.spaces.active.region_3d
        same = m["view"] is not None and all(abs(a - b) < 1e-6 for ra, rb in zip(rv3d.perspective_matrix, m["view"])
                                             for a, b in zip(ra, rb))
        if not (same and tuple(m["region_size"]) == (region.width, region.height)):
            pts = [view3d_utils.location_3d_to_region_2d(region, rv3d, p) for p in m["points"]]
            pts = [p for p in pts if p is not None]
            if len(pts) < 3:
                return None
            pad = 4
            return (min(p.x for p in pts) - pad, min(p.y for p in pts) - pad,
                    max(p.x for p in pts) + pad, max(p.y for p in pts) + pad)
    return m["rect"]


def _draw():
    if _M["hide"]:
        return
    ctx = bpy.context
    area, region = ctx.area, ctx.region
    if area is None or region is None or region.type != 'WINDOW':
        return
    ptr = area.as_pointer()
    mine = [m for m in _M["pending"] if m["area"] == ptr]
    drag = _M["drag"] if _M["drag"] and _M["drag"]["area"] == ptr else None
    if not mine and not drag:
        return
    s = ctx.preferences.system.ui_scale
    gpu.state.blend_set('ALPHA')
    for m in mine:
        r = rect_now(m, area, region)
        if r is None:
            continue
        _outline(region, *r, 2.0 * s)
        _tag(r[0], r[3] + 2 * s, str(m["n"]), s)
    if drag:
        x0, y0 = drag["x0"] - region.x, drag["y0"] - region.y
        x1, y1 = drag["x1"] - region.x, drag["y1"] - region.y
        _outline(region, min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1), 1.5 * s, dash=True)
    gpu.state.blend_set('NONE')


def _redraw():
    wm = bpy.context.window_manager
    for win in getattr(wm, "windows", ()):
        for area in win.screen.areas:
            area.tag_redraw()


# ---------------------------------------------------------------------------
# The operator.

class AGENT_OT_mark_area(bpy.types.Operator):
    bl_idname = "agent.mark_area"
    bl_label = "Mark an Area"
    bl_description = ("Drag a box over part of a 3D viewport or any editor to show the agent what you mean "
                      "(a click marks the whole editor); it goes with your next chat message")

    @classmethod
    def poll(cls, context):
        return context.window is not None and not _M["active"]

    def invoke(self, context, event):
        self._win = context.window
        _M["active"], _M["drag"] = True, None
        context.window_manager.modal_handler_add(self)
        self._win.cursor_modal_set('CROSSHAIR')
        try:
            context.workspace.status_text_set("Drag a box over what you mean  ·  click: the whole editor  ·  Esc cancels")
        except (AttributeError, RuntimeError):
            pass
        return {'RUNNING_MODAL'}

    def _end(self, context):
        _M["active"], _M["drag"] = False, None
        try:
            self._win.cursor_modal_restore()
            context.workspace.status_text_set(None)
        except (AttributeError, RuntimeError, ReferenceError):
            pass
        _redraw()

    def modal(self, context, event):
        t, v = event.type, event.value
        if t in {'ESC', 'RIGHTMOUSE'} and v == 'PRESS':
            self._end(context)
            return {'CANCELLED'}
        drag = _M["drag"]
        if drag is None and (t in {'MIDDLEMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM'} or t.startswith('WHEEL')):
            return {'PASS_THROUGH'}  # turn or zoom the view before marking
        x, y = event.mouse_x, event.mouse_y
        if t == 'LEFTMOUSE' and v == 'PRESS':
            area, region = _under(self._win, x, y)
            if area is not None:
                _M["drag"] = {"area": area.as_pointer(), "x0": x, "y0": y, "x1": x, "y1": y}
        elif t == 'MOUSEMOVE' and drag:
            drag["x1"], drag["y1"] = x, y
            _redraw()
        elif t == 'LEFTMOUSE' and v == 'RELEASE' and drag:
            area = next((a for a in self._win.screen.areas if a.as_pointer() == drag["area"]), None)
            region = next((rg for rg in area.regions if rg.type == 'WINDOW'), None) if area else None
            self._end(context)
            if region is None:
                return {'CANCELLED'}
            rect = (min(drag["x0"], x) - region.x, min(drag["y0"], y) - region.y,
                    max(drag["x0"], x) - region.x, max(drag["y0"], y) - region.y)
            try:
                with context.temp_override(window=self._win, area=area, region=region):
                    m = make(bpy.context, self._win, area, region, rect)
            except Exception as ex:  # a failed capture must not leave the user stuck in mark mode
                self.report({'ERROR'}, "Could not mark that area: {}".format(ex))
                return {'CANCELLED'}
            self.report({'INFO'}, "Mark {}: {}".format(m["n"], label(m)))
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._end(context)


_SPACES = ("SpaceView3D", "SpaceNodeEditor", "SpaceImageEditor", "SpaceProperties", "SpaceOutliner",
           "SpaceTextEditor", "SpaceSequenceEditor", "SpaceGraphEditor", "SpaceDopeSheetEditor",
           "SpaceSpreadsheet", "SpaceClipEditor", "SpaceNLA")
_handles = []


def register():
    bpy.utils.register_class(AGENT_OT_mark_area)
    for name in _SPACES:
        space = getattr(bpy.types, name, None)
        if space is not None:
            _handles.append((space, space.draw_handler_add(_draw, (), 'WINDOW', 'POST_PIXEL')))


def unregister():
    for space, h in _handles:
        try:
            space.draw_handler_remove(h, 'WINDOW')
        except (ValueError, RuntimeError):
            pass
    _handles.clear()
    _M["active"], _M["drag"] = False, None
    bpy.utils.unregister_class(AGENT_OT_mark_area)
