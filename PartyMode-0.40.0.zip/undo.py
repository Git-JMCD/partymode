# SPDX-License-Identifier: GPL-3.0-or-later
"""Small helpers over Blender's undo stack (``WindowManager.undo_stack``, 5.3+), and stamped
steps for Blender without it (see below)."""

import bpy

from .registry import ToolError, ui_override


def stack():
    wm = bpy.context.window_manager
    return getattr(wm, "undo_stack", None) if wm is not None else None


def require_stack():
    st = stack()
    if st is None or not ui_override():
        raise ToolError("This needs Blender's undo history, which only exists with a Blender "
                        "window open (not in background mode).")
    return st


def push(name: str) -> bool:
    try:
        with bpy.context.temp_override(**ui_override()):
            bpy.ops.ed.undo_push(message=name)
        return True
    except Exception:
        return False


def active():
    """(index, key) of the active step; key = (address, name) identifies a step."""
    st = stack()
    if st is None or st.active is None:
        return None, None
    return st.active_index, (st.active.as_pointer(), st.active.name)


def find(key):
    """Index of the step with ``key``, or None when it has dropped out of the stack."""
    st = stack()
    if st is None or key is None:
        return None
    for i, step in enumerate(st.steps):
        if (step.as_pointer(), step.name) == key:
            return i
    return None


def goto(index: int) -> None:
    """Jump the undo history to step ``index`` (undo or redo as needed)."""
    with bpy.context.temp_override(**ui_override()):
        bpy.ops.ed.undo_history(item=index)


def next_key():
    """Key of the step a redo would apply, or None."""
    st = stack()
    if st is None:
        return None
    i = st.active_index + 1
    if i < len(st.steps):
        step = st.steps[i]
        return step.as_pointer(), step.name
    return None


# ---------------------------------------------------------------------------
# Without the undo stack (Blender 5.2 and older): stamped steps.
#
# Python can still undo there, but can't read the history, so it can't tell an agent's step from
# the user's. Just before an agent step is pushed, the scene gets MARK = a fresh number, and the
# mark is removed again right after: only Blender's saved copy of that step carries it. Stepping
# back, the state reached must carry the next number down, or something else sits there.

MARK = "partymode_step"
_marks = []   # {"id", "name", "noop"} for the agent's steps, oldest first
_next = [0]


def _scene():
    return bpy.context.scene


def push_marked(name: str, noop: bool = False):
    """Push an undo step; without the undo stack, stamp it. Returns the stamp there (True with the
    undo stack), or None when the push failed."""
    if stack() is not None or not ui_override():
        return True if push(name) else None
    _next[0] += 1
    sid = _next[0]
    scene = _scene()
    scene[MARK] = sid
    ok = push(name)
    if MARK in scene:
        del scene[MARK]
    if not ok:
        return None
    _marks.append({"id": sid, "name": name, "noop": noop})
    del _marks[:-200]
    return sid


def forget_marks() -> None:
    """The user edited by hand: the agent's earlier steps are no longer the latest."""
    _marks.clear()


def clear_mark() -> None:
    scene = _scene()
    if scene is not None and MARK in scene:
        del scene[MARK]


def back_to(sid: int, limit: int = 64) -> bool:
    """Undo until the state stamped `sid` is restored (a trial's start): any number of steps the
    code in between pushed. True when it got there."""
    with bpy.context.temp_override(**ui_override()):
        for _ in range(limit):
            if not bpy.ops.ed.undo.poll():
                return False
            bpy.ops.ed.undo()
            if _scene().get(MARK) == sid:
                while _marks and _marks[-1]["id"] != sid:
                    _marks.pop()
                return True
    return False


def undo_marked(n: int) -> list:
    """Undo up to `n` of the agent's own latest steps (stamped ones) and return their names.
    Stops at the first state that isn't the next agent step down, so it never undoes the user's
    work. Raises when there's nothing of the agent's to undo."""
    cur = _scene().get(MARK)
    if cur is not None:
        # An undo restored a stamped state (the user's Ctrl+Z, or ours): steps above it are undone.
        while _marks and _marks[-1]["id"] != cur:
            _marks.pop()
    if not any(not m["noop"] for m in _marks):
        raise ToolError("On this Blender (no readable undo history; 5.3 has one), PartyMode only undoes the "
                        "agent's own latest edits, and there's none to undo: either nothing was edited by "
                        "an agent, or you've edited by hand since. Ask the user to press Ctrl+Z instead.")
    undone = []
    with bpy.context.temp_override(**ui_override()):
        while _marks and len(undone) < n:
            top = _marks.pop()
            if not bpy.ops.ed.undo.poll():
                break
            bpy.ops.ed.undo()
            landed = _scene().get(MARK)
            if landed == top["id"]:
                # That undid an unstamped step above ours: the user's, which the operations log
                # didn't show. Put it straight back and stop.
                bpy.ops.ed.redo()
                _marks.clear()
                if not undone:
                    clear_mark()
                    raise ToolError("Nothing undone: the latest step is yours, not an agent's (on this "
                                    "Blender PartyMode can only undo the agent's own latest edits). "
                                    "Ask the user to press Ctrl+Z instead.")
                break
            if not top["noop"]:
                undone.append(top["name"])
            if _marks and landed != _marks[-1]["id"]:
                _marks.clear()  # an unstamped step sits here: someone else's
                break
    clear_mark()
    return undone
