# SPDX-License-Identifier: GPL-3.0-or-later
"""
HTTP routes for the browser chat page (/chat) on the bridge's own server.

Same-machine only: the server listens on 127.0.0.1, and these routes also check
the Host and Origin headers so a web page elsewhere cannot reach them through
DNS rebinding or cross-site requests.
"""

import json
import os
import urllib.parse

from . import chat

_HERE = os.path.dirname(__file__)
_LOCAL_HOSTS = {"127.0.0.1", "localhost", "[::1]"}


def _host_ok(headers) -> bool:
    host = (headers.get("Host") or "").rsplit(":", 1)[0]
    if host not in _LOCAL_HOSTS:
        return False
    origin = headers.get("Origin")
    if origin:
        o_host = origin.split("://", 1)[-1].split("/", 1)[0].rsplit(":", 1)[0]
        if o_host not in _LOCAL_HOSTS:
            return False
    return True


def _json(obj, status=200):
    return status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8"


def _session_view(local_id):
    meta = next((m for m in chat.list_sessions() if m["id"] == local_id), None)
    if meta is None:
        return None
    chat.measure(local_id)
    turn = chat.live()
    live = None
    if turn and turn["local_id"] == local_id:
        live = {"text": turn["text"], "activity": turn["activity"], "started": turn["started"]}
    return {"session": meta, "messages": chat.transcript(local_id), "live": live,
            "context": chat.context(local_id), "long": chat.is_long(local_id)}


def handle(method: str, path: str, headers, body: bytes, blend_file_fn):
    """Return (status, body bytes, content type) for a /chat request."""
    if not _host_ok(headers):
        return 403, b"forbidden", "text/plain"
    url = urllib.parse.urlparse(path)
    route = url.path.rstrip("/") or "/"
    q = dict(urllib.parse.parse_qsl(url.query))

    if method == "GET":
        if route == "/chat":
            with open(os.path.join(_HERE, "chat.html"), "rb") as fh:
                return 200, fh.read(), "text/html; charset=utf-8"
        if route == "/chat/api/sessions":
            turn = chat.live()
            return _json({"sessions": chat.list_sessions(), "revision": chat.S.revision,
                          "busy": turn["local_id"] if turn else None})
        if route == "/chat/api/session":
            view = _session_view(q.get("id", ""))
            if view is None:
                return _json({"error": "no such session"}, 404)
            view["revision"] = chat.S.revision
            return _json(view)
        if route == "/chat/api/image":
            p = chat.image_path(q.get("id", ""), q.get("name", ""))
            if p is None:
                return 404, b"", "text/plain"
            with open(p, "rb") as fh:
                return 200, fh.read(), "image/png"
        return 404, b"not found", "text/plain"

    if method == "POST":
        try:
            data = json.loads(body or b"{}")
        except ValueError:
            return _json({"error": "bad json"}, 400)
        try:
            if route == "/chat/api/send":
                local_id = chat.send(data.get("text", ""), data.get("session") or None, blend_file_fn())
                return _json({"session": local_id})
            if route == "/chat/api/stop":
                from . import cancel
                stopped = chat.stop()
                cancel.stop("stopped from the chat")  # Also ends a script it started in Blender.
                return _json({"stopped": stopped})
            if route == "/chat/api/continue":
                return _json({"session": chat.continue_in_new(data["session"])})
            if route == "/chat/api/rename":
                chat.rename(data["session"], data.get("title", ""))
                return _json({"ok": True})
            if route == "/chat/api/delete":
                chat.delete(data["session"])
                return _json({"ok": True})
        except (ValueError, RuntimeError, KeyError) as ex:
            return _json({"error": str(ex)}, 409)
        return _json({"error": "not found"}, 404)
    return 405, b"", "text/plain"
