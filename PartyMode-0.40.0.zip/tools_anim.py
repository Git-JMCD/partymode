# SPDX-License-Identifier: GPL-3.0-or-later
"""
Animation checks that are hard to see by eye and easy to measure: feet sliding while they are on
the ground, and the seam where a loop wraps (a pop, or a held frame when the last frame repeats
the first). In-place clips (the character stays put while the feet sweep back) get the speed the
feet move at: the speed to move the character at in the engine so it doesn't skate.
"""

import math
import re

import bpy

from .registry import ToolError, get_object, r, tool

_FOOT = re.compile(r"(foot|ankle)", re.I)
_TOE = re.compile(r"(toe|ball)", re.I)
BACKWARD = 0.05        # a foot moving back past the body faster than this (m/s), low down, is on the ground
PLANTED_MM = 10.0      # slip under this during a contact reads as planted
IN_PLACE_M = 0.05      # the character travels less than this over the clip: an in-place clip


def _side(name):
    n = name.lower()
    if re.search(r"(^|[._\-\s])(l|left)([._\-\s]|$)", n) or n.endswith(("_l", ".l", "left")) or "left" in n:
        return "left"
    if re.search(r"(^|[._\-\s])(r|right)([._\-\s]|$)", n) or n.endswith(("_r", ".r", "right")) or "right" in n:
        return "right"
    return name


def _feet(arm, names=None):
    """{label: [bone names]}: each foot's bones (foot, and its toe when there is one)."""
    bones = arm.pose.bones
    if names:
        missing = [n for n in names if n not in bones]
        if missing:
            raise ToolError("No bone {} in {} (feet: {}).".format(", ".join(map(repr, missing)), arm.name,
                                                               ", ".join(b.name for b in bones if _FOOT.search(b.name)) or "none"))
        out = {}
        for n in names:
            out.setdefault(_side(n), []).append(n)
        return out
    out = {}
    for pb in bones:
        if _FOOT.search(pb.name) and not re.search(r"(ik|pole|target|ctrl|control|roll|mch)", pb.name, re.I):
            out.setdefault(_side(pb.name), []).append(pb.name)
    for pb in bones:
        if _TOE.search(pb.name) and not re.search(r"(ik|pole|target|ctrl|control|mch)", pb.name, re.I):
            side = _side(pb.name)
            if side in out:
                out[side].append(pb.name)
    return out or _feet_by_position(arm)


def _feet_by_position(arm):
    """Feet for rigs with plain names (bone_12): the lowest bones at rest, split by side (+X is the
    character's left in Blender). Up to two a side: the foot and its toe."""
    rest = arm.data.bones
    if not rest:
        return {}
    lows = {b.name: min(b.head_local.z, b.tail_local.z) for b in rest}
    highs = [max(b.head_local.z, b.tail_local.z) for b in rest]
    ground, top = min(lows.values()), max(highs)
    near = ground + 0.12 * max(top - ground, 1e-6)
    out = {}
    for b in sorted(rest, key=lambda b: lows[b.name]):
        if lows[b.name] > near:
            break
        x = (b.head_local.x + b.tail_local.x) / 2
        if abs(x) < 0.02 * max(top - ground, 1e-6):
            continue  # on the middle line: not a foot
        side = "left" if x > 0 else "right"
        if len(out.setdefault(side, [])) < 2:
            out[side].append(b.name)
    return out if len(out) == 2 else {}


def _range(ob, args):
    scene = bpy.context.scene
    if args.get("frame_start") is not None and args.get("frame_end") is not None:
        return int(args["frame_start"]), int(args["frame_end"])
    act = ob.animation_data.action if ob.animation_data else None
    if act is not None:
        a, b = act.frame_range
        return int(round(a)), int(round(b))
    return scene.frame_start, scene.frame_end


def _root_bone(ob):
    tops = [pb for pb in ob.pose.bones if pb.parent is None]
    return max(tops, key=lambda pb: len(pb.children_recursive)) if tops else None


def _facing(ob, feet):
    """The way the feet point at rest (heel to toe), flat: the character's forward."""
    dx = dy = 0.0
    for names in feet.values():
        for n in names:
            b = ob.data.bones[n]
            d = ob.matrix_world.to_3x3() @ (b.tail_local - b.head_local)
            dx, dy = dx + d.x, dy + d.y
    n = math.hypot(dx, dy)
    return (dx / n, dy / n) if n > 1e-9 else (0.0, -1.0)  # Blender characters face -Y


def _sample(ob, frames, feet):
    """Per frame: each foot's lowest point (world), the root's position, and every bone's pose."""
    scene = bpy.context.scene
    keep = scene.frame_current, scene.frame_subframe
    out = []
    try:
        for f in frames:
            scene.frame_set(f)
            mw = ob.matrix_world
            entry = {"frame": f, "root": tuple(mw.translation)}
            if ob.type == 'ARMATURE':
                pts = {}
                for label, names in feet.items():
                    cands = []
                    for n in names:
                        pb = ob.pose.bones[n]
                        cands.append(mw @ pb.head)
                        cands.append(mw @ pb.tail)
                    pts[label] = tuple(min(cands, key=lambda v: v.z))
                entry["feet"] = pts
                root_bone = _root_bone(ob)
                if root_bone is not None:
                    entry["root"] = tuple(mw @ root_bone.head)
                    inv = root_bone.matrix.inverted()
                    # Each bone against the root, so a clip that travels still compares its pose;
                    # the root itself by its turn and height only.
                    entry["pose"] = {pb.name: ((inv @ pb.matrix).to_quaternion(), (inv @ pb.matrix).translation.copy())
                                     for pb in ob.pose.bones if pb != root_bone}
                    rm = mw @ root_bone.matrix
                    entry["pose"][root_bone.name] = (rm.to_quaternion(), type(rm.translation)((0.0, 0.0, rm.translation.z)))
                else:
                    entry["pose"] = {}
            else:
                entry["pose"] = {ob.name: (mw.to_quaternion(), mw.translation.copy())}
            out.append(entry)
    finally:
        scene.frame_set(keep[0], subframe=keep[1])
    return out


def _contacts(samples, label, fps, forward):
    """[(i0, i1)] runs of samples where the foot is on the ground: in the lower part of its motion
    and moving back past the body (a stance), however little it lifts."""
    zs = [s["feet"][label][2] for s in samples]
    ground = min(zs)
    low = sorted(zs)[len(zs) // 2] + 0.01  # the lower half (a little over), so toe taps don't set the bar
    rel = [(s["feet"][label][0] - s["root"][0], s["feet"][label][1] - s["root"][1]) for s in samples]
    on = []
    for i, z in enumerate(zs):
        a, b = max(0, i - 1), min(len(rel) - 1, i + 1)
        v = ((rel[b][0] - rel[a][0]) * forward[0] + (rel[b][1] - rel[a][1]) * forward[1]) / max(1, b - a) * fps
        on.append(z <= low and v < -BACKWARD)
    runs, start = [], None
    for i, flag in enumerate(on + [False]):
        if flag and start is None:
            start = i
        elif not flag and start is not None:
            if i - start >= 3:  # shorter: a toe tap, not a step
                runs.append((start, i - 1))
            start = None
    return runs, ground


def _slip(points):
    """How far a contact's foot strays from moving steadily (mm), and its steady speed (m/s per frame)."""
    n = len(points)
    if n < 2:
        return 0.0, (0.0, 0.0)
    vx = (points[-1][0] - points[0][0]) / (n - 1)
    vy = (points[-1][1] - points[0][1]) / (n - 1)
    worst = 0.0
    for i, p in enumerate(points):
        ex, ey = points[0][0] + vx * i, points[0][1] + vy * i
        worst = max(worst, math.hypot(p[0] - ex, p[1] - ey))
    return worst * 1000, (vx, vy)


def _deg(angle):
    """A rotation's size in degrees, the short way round."""
    d = math.degrees(angle) % 360.0
    return min(d, 360.0 - d)


def _seam(samples):
    """How the loop wraps: the pose and motion at the end against the start."""
    if len(samples) < 3:
        return None
    first, last = samples[0]["pose"], samples[-1]["pose"]
    before_last = samples[-2]["pose"]
    worst = []
    same = True
    for name, (q0, t0) in first.items():
        q1, t1 = last[name]
        ang = _deg(q0.rotation_difference(q1).angle)
        dist = (t1 - t0).length * 1000
        if ang > 0.05 or dist > 0.05:
            same = False
        # The wrap as motion: last -> first should look like any other step (before_last -> last).
        step_end = _deg(before_last[name][0].rotation_difference(q1).angle)
        step_wrap = _deg(q1.rotation_difference(q0).angle)
        worst.append((name, ang, dist, step_end, step_wrap))
    worst.sort(key=lambda w: -(w[1] + w[2] / 10))
    return {"same_first_and_last": same, "worst": [
        {"bone": n, "rotation_deg": r(a, 2), "offset_mm": r(d, 1), "step_before_end_deg": r(se, 2),
         "step_at_wrap_deg": r(sw, 2)} for n, a, d, se, sw in worst[:5]]}


@tool("inspect_animation",
      "Check an animation (changes nothing): foot sliding and the loop seam. Give an armature (or an "
      "animated object) and optionally the frames, the foot bones and whether it loops. Feet: each "
      "foot's contacts with the ground (frames; feet are found by name, or as the lowest bones at "
      "rest), how far it slips during each (mm; planted under 10); for an in-place clip the speed the "
      "feet sweep back at (move the character at that speed in the engine and it won't skate), and "
      "for a travelling clip how fast the feet still move on the ground against the travel speed. Loop: how far the last frame is from "
      "the first per bone (a pop), and whether the last frame repeats the first (engines then hold "
      "that pose twice: end one frame earlier).",
      {"object": {"type": "string"}, "frame_start": {"type": "integer"}, "frame_end": {"type": "integer"},
       "feet": {"type": "array", "items": {"type": "string"}, "description": "Foot (and toe) bone names; found by name otherwise."},
       "loop": {"type": "boolean", "default": True}},
      required=("object",))
def inspect_animation(args):
    ob = get_object(args["object"])
    if ob.type == 'ARMATURE':
        feet = _feet(ob, args.get("feet"))
    else:
        feet = {}
    f0, f1 = _range(ob, args)
    if f1 - f0 < 2:
        raise ToolError("Need at least 3 frames (got {}-{}).".format(f0, f1))
    if f1 - f0 > 2000:
        raise ToolError("That is {} frames; check up to 2000 at a time.".format(f1 - f0 + 1))
    scene = bpy.context.scene
    fps = scene.render.fps / scene.render.fps_base
    samples = _sample(ob, range(f0, f1 + 1), feet)
    root0, root1 = samples[0]["root"], samples[-1]["root"]
    travel = math.hypot(root1[0] - root0[0], root1[1] - root0[1])
    in_place = travel < IN_PLACE_M
    out = {"object": ob.name, "frames": [f0, f1], "fps": r(fps, 3), "root_travel_m": r(travel, 3),
           "in_place": in_place}
    notes = []
    if ob.type == 'ARMATURE':
        if not feet:
            notes.append("No foot bones found by name: pass feet=[...] to check sliding.")
        foot_out = {}
        speeds = []
        if in_place:
            forward = _facing(ob, feet)
        else:
            forward = ((root1[0] - root0[0]) / travel, (root1[1] - root0[1]) / travel)
        for label, names in feet.items():
            runs, ground = _contacts(samples, label, fps, forward)
            contacts = []
            for i0, i1 in runs:
                pts = [samples[i]["feet"][label] for i in range(i0, i1 + 1)]
                slip, (vx, vy) = _slip(pts)
                speed = math.hypot(vx, vy) * fps
                if not in_place:  # moving characters: a planted foot doesn't move at all
                    slip = max(math.hypot(p[0] - pts[0][0], p[1] - pts[0][1]) for p in pts) * 1000
                contacts.append({"frames": [samples[i0]["frame"], samples[i1]["frame"]], "slip_mm": r(slip, 1),
                                 "planted": slip < PLANTED_MM, "ground_speed_mps": r(speed, 3)})
                speeds.append(speed)
            foot_out[label] = {"bones": names, "ground_z": r(ground, 4), "contacts": contacts,
                               "sliding": [c["frames"] for c in contacts if not c["planted"]]}
        out["feet"] = foot_out
        if not in_place and speeds:
            travel_speed = travel / max((f1 - f0) / fps, 1e-6)
            ground_speed = sum(speeds) / len(speeds)
            out["travel_speed_mps"] = r(travel_speed, 3)
            out["foot_ground_speed_mps"] = r(ground_speed, 3)
            if ground_speed > 0.1 * travel_speed:
                notes.append("The feet keep moving while on the ground ({:.2f} m/s, against the character's {:.2f} m/s): the "
                             "steps don't cover the travel. Check the retarget's scale (hips height) or the root "
                             "motion: about {:.0%} of the travel is skating.".format(
                                 ground_speed, travel_speed, min(1.0, ground_speed / travel_speed)))
        if in_place and speeds:
            mean = sum(speeds) / len(speeds)
            out["travel_speed_mps"] = r(mean, 3)
            spread = max(speeds) - min(speeds)
            notes.append("In-place clip: the feet sweep back at {:.2f} m/s. Move the character at that speed in the "
                         "engine (or as its root motion) and it won't skate{}.".format(
                             mean, "" if spread < 0.15 * max(mean, 1e-6) else
                             "; the contacts differ by {:.2f} m/s, so some steps will still slide".format(spread)))
        slides = sum(len(f["sliding"]) for f in foot_out.values())
        if slides:
            notes.append("{} contact(s) slide more than {:.0f} mm: plant those feet (IK on the contact frames) or "
                         "match the travel to the steps.".format(slides, PLANTED_MM))
    if args.get("loop", True):
        seam = _seam(samples)
        out["loop"] = seam
        if seam and seam["same_first_and_last"]:
            notes.append("The last frame repeats the first: a looping engine shows that pose twice (a hitch). "
                         "End the clip at frame {}.".format(f1 - 1))
        elif seam and seam["worst"] and (seam["worst"][0]["rotation_deg"] > 8 or seam["worst"][0]["offset_mm"] > 20):
            w = seam["worst"][0]
            notes.append("The loop pops at the wrap: {} is {} degrees / {} mm from where it starts.".format(
                w["bone"], w["rotation_deg"], w["offset_mm"]))
    out["notes"] = notes
    return {"data": out}
