# SPDX-License-Identifier: GPL-3.0-or-later
"""Turn freshly imported objects into one tidy, named, real-size object stood on the ground."""

import bpy
from mathutils import Matrix, Vector

from .registry import ToolError, bounds_dict, r, ui_override, world_bounds


def import_file(path: str) -> list:
    """Import a 3D file; return the objects it created."""
    import os
    before = set(bpy.data.objects)
    ext = os.path.splitext(path)[1].lower()
    with bpy.context.temp_override(**ui_override()):
        if ext in {".glb", ".gltf"}:
            bpy.ops.import_scene.gltf(filepath=path)
        elif ext == ".obj":
            bpy.ops.wm.obj_import(filepath=path)
        elif ext == ".fbx":
            bpy.ops.import_scene.fbx(filepath=path)
        elif ext == ".ply":
            bpy.ops.wm.ply_import(filepath=path)
        elif ext == ".stl":
            bpy.ops.wm.stl_import(filepath=path)
        elif ext == ".usd" or ext in {".usda", ".usdc", ".usdz"}:
            bpy.ops.wm.usd_import(filepath=path)
        else:
            raise ToolError("Cannot import {} files.".format(ext))
    return [ob for ob in bpy.data.objects if ob not in before]


def _union(obs, dg):
    lo = hi = None
    for ob in obs:
        b = world_bounds(ob, dg)
        if b is None:
            continue
        lo = b[0].copy() if lo is None else Vector(map(min, lo, b[0]))
        hi = b[1].copy() if hi is None else Vector(map(max, hi, b[1]))
    if lo is None:
        raise ToolError("Nothing with a size was imported.")
    return lo, hi


def place(new_objects: list, name: str, location=(0, 0, 0), size_m=None, size_axis="height",
          join=True) -> dict:
    """
    Make imported objects one named thing, sized and stood on the ground at ``location``
    (its lowest point at location.z, centred over location.xy).

    join=True merges all meshes into one object (generated models); join=False keeps
    the parts under an empty called ``name`` (multi-part assets).
    """
    meshes = [ob for ob in new_objects if ob.type == 'MESH']
    if not meshes:
        raise ToolError("The import made no mesh.")
    for ob in bpy.context.selected_objects:
        ob.select_set(False)

    if join:
        with bpy.context.temp_override(**ui_override(), active_object=meshes[0], object=meshes[0],
                                       selected_objects=meshes, selected_editable_objects=meshes):
            if len(meshes) > 1:
                bpy.ops.object.join()
        root = meshes[0]
        mw = root.matrix_world.copy()
        root.parent = None
        root.matrix_world = mw
        root.data.transform(root.matrix_world)  # Bake the transform into the mesh.
        root.matrix_world = Matrix.Identity(4)
        for ob in new_objects:
            if ob is not root and ob.name in bpy.data.objects and ob.type != 'MESH':
                bpy.data.objects.remove(ob)
        root.name = name
        root.data.name = name
        parts = [root]
    else:
        # The group gets the clean name; a part that already has it is renamed.
        clash = bpy.data.objects.get(name)
        if clash is not None and clash in new_objects:
            clash.name = name + "_part"
        root = bpy.data.objects.new(name, None)
        root.empty_display_type = 'PLAIN_AXES'
        coll = meshes[0].users_collection[0] if meshes[0].users_collection else bpy.context.scene.collection
        coll.objects.link(root)
        tops = [ob for ob in new_objects if ob.parent is None or ob.parent not in new_objects]
        for ob in tops:
            mw = ob.matrix_world.copy()
            ob.parent = root
            ob.matrix_world = mw
        parts = meshes

    dg = bpy.context.evaluated_depsgraph_get()
    lo, hi = _union(parts, dg)
    size = hi - lo
    factor = 1.0
    if size_m:
        current = size.z if size_axis == "height" else max(size)
        if current > 1e-9:
            factor = float(size_m) / current
    base = Vector(((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, lo.z))
    target = Vector(location)
    if join:
        root.data.transform(Matrix.Translation(-base))
        root.data.transform(Matrix.Scale(factor, 4))
        root.location = target
    else:
        root.location = (0, 0, 0)
        for child in root.children:
            child.matrix_world = Matrix.Translation(-base) @ child.matrix_world
        root.scale = (factor,) * 3
        root.location = target
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    b = _union(parts, dg)
    root.select_set(True)
    bpy.context.view_layer.objects.active = root
    mats = sorted({s.material.name for ob in parts for s in ob.material_slots if s.material})
    return {"object": root.name, "parts": len(parts),
            "faces": sum(len(ob.data.polygons) for ob in parts),
            "materials": mats, "scaled_by": r(factor, 4), "bounds": bounds_dict(b)}
