# SPDX-License-Identifier: GPL-3.0-or-later
"""
Updates: whether a newer PartyMode is out (the latest GitHub release), and installing it.

The check asks GitHub's releases API for the newest PartyMode release, once a day at most (and when the user
asks), only while Blender's Allow Online Access is on; it sends nothing but the request. A private
repository needs a token: GH_TOKEN / GITHUB_TOKEN, or the GitHub CLI's (`gh auth token`) when it
is installed and signed in; the token is only ever sent to api.github.com.

Installing downloads the release's zip into the config folder, checks it is this add-on at the
version offered, and installs it with Blender's own extension installer (it replaces the running
add-on; Blender then reloads it). Never while an agent is working.
"""

import json
import os
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile

# Releases are published to a private downloads-only repository (the code lives in a private
# monorepo, which testers aren't invited to). Its tags are partymode-v<version>; we list releases
# and take the newest of those, so other tags or a media upload there can't be mistaken for one.
REPO = "johnmcclurgdesign/partymode-releases"
TAG = "partymode-v"
API = "https://api.github.com/repos/{}/releases?per_page=100".format(REPO)
CHECK_EVERY_S = 24 * 3600
MAX_ZIP = 60 * 1024 * 1024
_HOSTS = ("api.github.com", "github.com", "objects.githubusercontent.com",
          "release-assets.githubusercontent.com")

_lock = threading.Lock()
U = {"state": "idle", "latest": "", "url": "", "notes": "", "asset": None, "checked": 0.0, "error": "",
     "zip": "", "online": True}


def current():
    from . import tools_look
    return tools_look.addon_build()["version"]


def _ver(v):
    try:
        return tuple(int(x) for x in str(v).lstrip("v").split("."))
    except ValueError:
        return None


def newer(a, b):
    """Is version a newer than b?"""
    va, vb = _ver(a), _ver(b)
    return bool(va and vb and va > vb)


def available():
    """The newer version that is out, or "" (also "" when running from a source folder)."""
    with _lock:
        latest = U["latest"]
    return latest if newer(latest, current()) else ""


def status():
    with _lock:
        return dict(U)


def _folder():
    import bpy
    return bpy.utils.user_resource('CONFIG', path="agent_bridge", create=True)


def _cache():
    return os.path.join(_folder(), "update.json")


def load_cache():
    try:
        with open(_cache(), encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return
    with _lock:
        for k in ("latest", "url", "notes", "asset", "checked"):
            if k in data:
                U[k] = data[k]


def _save_cache():
    with _lock:
        data = {k: U[k] for k in ("latest", "url", "notes", "asset", "checked")}
    try:
        with open(_cache(), "w", encoding="utf-8") as fh:
            json.dump(data, fh)
    except OSError:
        pass


def _token():
    for name in ("GH_TOKEN", "GITHUB_TOKEN"):
        if os.environ.get(name):
            return os.environ[name].strip()
    gh = shutil.which("gh")
    if not gh:
        return ""
    try:
        out = subprocess.run([gh, "auth", "token"], capture_output=True, text=True, timeout=10,
                             creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
    except (OSError, subprocess.SubprocessError):
        return ""
    return out.stdout.strip() if out.returncode == 0 else ""


class _Redirect(urllib.request.HTTPRedirectHandler):
    """Follows GitHub's redirects, keeping the token only while they stay on api.github.com (a renamed
    repository redirects there); a download that moves on to signed storage goes without it."""

    def __init__(self, token):
        super().__init__()
        self.token = token

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is not None and self.token and urllib.parse.urlparse(newurl).hostname == "api.github.com":
            new.add_unredirected_header("Authorization", "Bearer " + self.token)
        return new


def _request(url, accept, token=""):
    host = urllib.parse.urlparse(url).hostname or ""
    if urllib.parse.urlparse(url).scheme != "https" or host not in _HOSTS:
        raise ValueError("not a GitHub address: " + url)
    req = urllib.request.Request(url, headers={"Accept": accept, "User-Agent": "partymode/" + current()})
    token = token if host == "api.github.com" else ""
    if token:
        req.add_unredirected_header("Authorization", "Bearer " + token)
    return urllib.request.build_opener(_Redirect(token)).open(req, timeout=30)


def pick(releases):
    """The newest published PartyMode release in a list from the releases API, or None. Drafts,
    prereleases (such as media uploads) and other projects' releases don't count."""
    ours = [r for r in releases if not r.get("draft") and not r.get("prerelease")
            and r.get("tag_name", "").startswith(TAG) and _ver(r["tag_name"][len(TAG):])]
    return max(ours, key=lambda r: _ver(r["tag_name"][len(TAG):]), default=None)


# Release zips are named PartyMode-<version>.zip (before 0.38.13, agent_bridge-<version>.zip, after
# the add-on's id, which stays agent_bridge so installs update in place).
ZIP_PREFIXES = ("PartyMode-", "agent_bridge-")


def zip_asset(rel):
    """The release's add-on zip (the PartyMode- name first), or None."""
    zips = [a for a in rel.get("assets", []) if a.get("name", "").endswith(".zip")
            and a["name"].startswith(ZIP_PREFIXES)]
    zips.sort(key=lambda a: not a["name"].startswith(ZIP_PREFIXES[0]))
    return zips[0] if zips else None


def _fetch_latest():
    """The latest release, as {"latest", "url", "notes", "asset"}; tries without a token first."""
    token = ""
    for attempt in (0, 1):
        try:
            with _request(API, "application/vnd.github+json", token) as r:
                rel = pick(json.loads(r.read()))
            if rel is None:
                raise RuntimeError("no PartyMode release has been published yet")
            break
        except urllib.error.HTTPError as ex:
            if ex.code == 404 and attempt == 0:
                token = _token()  # a private repository answers 404 without one
                if token:
                    continue
                raise RuntimeError("the release page is private: sign in with the GitHub CLI (gh auth "
                                   "login) or set GH_TOKEN") from None
            raise RuntimeError("GitHub answered {}".format(ex.code)) from None
    a = zip_asset(rel)
    asset = None
    if a:
        asset = {"name": a["name"], "size": a.get("size", 0), "api": a.get("url", ""),
                 "public": a.get("browser_download_url", ""), "private": bool(token)}
    return {"latest": rel["tag_name"][len(TAG):], "url": rel.get("html_url", ""),
            "notes": (rel.get("body") or "")[:4000], "asset": asset}


def _bump():
    from . import chat
    chat.S.revision += 1


def check(force=False):
    """Start a check in the background (at most once a day unless forced). Call on the main thread."""
    import bpy
    online = bool(bpy.app.online_access)
    with _lock:
        U["online"] = online
        if not online or U["state"] in ("checking", "downloading"):
            return False
        if not force and time.time() - (U["checked"] or 0) < CHECK_EVERY_S:
            return False
        U.update(state="checking", error="")
    threading.Thread(target=_check_thread, name="agent-update-check", daemon=True).start()
    return True


def _check_thread():
    try:
        rel = _fetch_latest()
    except Exception as ex:  # offline, rate limited, private: say so in the preferences
        with _lock:
            U.update(state="error", error=str(ex)[:200], checked=time.time())
        _bump()
        return
    with _lock:
        U.update(rel, state="done", checked=time.time())
    _save_cache()
    _bump()


def busy_reason():
    """Why installing now would be a bad idea, or ""."""
    from . import chat, team, tools_generate
    if chat.live():
        return "an agent is answering in the chat"
    if team.busy():
        return "the team is still working"
    if any(j.get("state") not in ("done", "failed", "cancelled") for j in list(tools_generate._jobs.values())):
        return "a render or generation is still running"
    return ""


def download():
    """Fetch the offered zip in the background; install() once U["state"] is "ready"."""
    version = available()
    with _lock:
        asset = U["asset"]
        if U["state"] == "ready" and U["zip"].endswith("PartyMode-{}.zip".format(version)):
            return True  # downloaded already
        if not version or not asset or U["state"] == "downloading":
            return False
        U.update(state="downloading", error="")
    threading.Thread(target=_download_thread, args=(version, asset), name="agent-update-get", daemon=True).start()
    return True


def _download_thread(version, asset):
    try:
        if asset["size"] and asset["size"] > MAX_ZIP:
            raise RuntimeError("the release zip is unexpectedly large")
        if asset.get("private"):
            token = _token()
            src = _request(asset["api"], "application/octet-stream", token)
        else:
            src = _request(asset["public"], "application/octet-stream")
        folder = os.path.join(_folder(), "updates")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, "PartyMode-{}.zip".format(version))
        got = 0
        with src, open(path + ".part", "wb") as fh:
            while True:
                chunk = src.read(1 << 16)
                if not chunk:
                    break
                got += len(chunk)
                if got > MAX_ZIP:
                    raise RuntimeError("the release zip is unexpectedly large")
                fh.write(chunk)
        _verify(path + ".part", version)
        os.replace(path + ".part", path)
    except Exception as ex:
        with _lock:
            U.update(state="error", error="download failed: {}".format(ex)[:200])
        _bump()
        return
    with _lock:
        U.update(state="ready", zip=path)
    _bump()


def _verify(path, version):
    """The zip must be this add-on (id agent_bridge) at exactly the version offered."""
    try:
        with zipfile.ZipFile(path) as z:
            name = next((n for n in z.namelist() if n.rsplit("/", 1)[-1] == "blender_manifest.toml"), None)
            if not name:
                raise RuntimeError("no blender_manifest.toml in it")
            text = z.read(name).decode("utf-8", "replace")
    except zipfile.BadZipFile:
        raise RuntimeError("not a zip file") from None
    fields = {}
    for line in text.splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            k, v = line.split("=", 1)
            fields.setdefault(k.strip(), v.strip().strip('"'))
    if fields.get("id") != "agent_bridge" or fields.get("version") != version:
        raise RuntimeError("it is {} {}, not agent_bridge {}".format(fields.get("id"), fields.get("version"), version))


def install():
    """Install the downloaded zip with Blender's extension installer (main thread). Returns an error or ""."""
    import bpy
    why = busy_reason()
    if why:
        return "Not now: " + why
    with _lock:
        path, version = U["zip"], U["latest"]
    if not path or not os.path.isfile(path):
        return "The update is not downloaded yet"
    try:
        bpy.ops.extensions.package_install_files(filepath=path, repo="user_default", enable_on_install=True,
                                                 overwrite=True)
    except Exception as ex:
        return "Blender could not install it: {}".format(ex)
    with _lock:
        U.update(state="installed")
    print("agent-bridge: installed", version)
    return ""


# ---------------------------------------------------------------------------
# Operators (the preferences' buttons, the chat's notice).

import bpy  # noqa: E402


class AGENT_OT_update_check(bpy.types.Operator):
    bl_idname = "agent.update_check"
    bl_label = "Check for Updates"
    bl_description = "Ask GitHub whether a newer PartyMode is out"

    def execute(self, context):
        if not bpy.app.online_access:
            self.report({'WARNING'}, "Allow Online Access is off (Preferences > System)")
            return {'CANCELLED'}
        check(force=True)
        return {'FINISHED'}


class AGENT_OT_update_install(bpy.types.Operator):
    bl_idname = "agent.update_install"
    bl_label = "Install Update"
    bl_description = "Download the newer PartyMode and install it over this one"

    def invoke(self, context, event):
        version = available()
        if not version:
            self.report({'INFO'}, "PartyMode is up to date")
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(
            self, event, title="Install PartyMode {}?".format(version),
            message="It replaces {} and reloads the add-on. Your chats, Sandbox and settings stay.".format(current()),
            confirm_text="Install")

    def execute(self, context):
        why = busy_reason()
        if why:
            self.report({'WARNING'}, "Not now: " + why)
            return {'CANCELLED'}
        if not download():
            self.report({'WARNING'}, status()["error"] or "Nothing to install")
            return {'CANCELLED'}
        bpy.app.timers.register(_install_when_ready, first_interval=0.5)
        self.report({'INFO'}, "Downloading PartyMode {}".format(available()))
        return {'FINISHED'}


def _install_when_ready():
    state = status()["state"]
    if state == "downloading":
        return 0.5
    if state == "ready":
        err = install()
        if err:
            with _lock:
                U.update(state="error", error=err)
            _bump()
    return None


CLASSES = (AGENT_OT_update_check, AGENT_OT_update_install)


def status_line():
    """The preferences' Add-on row: (icon, text, [(operator, label, icon, url)])."""
    st = status()
    version = current()
    check = [("agent.update_check", "Check for updates", 'FILE_REFRESH', "")]
    if version == "development":
        return 'INFO', "Running from a source folder: update it with git", []
    new = available()
    if st["state"] == "checking":
        return 'TIME', "{} · checking…".format(version), []
    if st["state"] == "downloading":
        return 'IMPORT', "Downloading {}…".format(new), []
    if st["state"] == "installed":
        return 'CHECKMARK', "Installed {}".format(st["latest"]), []
    if new:
        actions = [("agent.update_install", "Install", 'IMPORT', "")]
        if st["url"]:
            actions.append(("wm.url_open", "What's new", 'URL', st["url"]))
        return 'IMPORT', "{} is out (you have {})".format(new, version), actions
    if st["state"] == "error" and st["error"]:
        return 'ERROR', "{} · could not check: {}".format(version, st["error"]), check
    if not bpy.app.online_access:
        return 'INFO', "{} · checks are off (Allow Online Access)".format(version), check
    if st["checked"]:
        ago = time.time() - st["checked"]
        when = "just now" if ago < 90 else "{} min ago".format(round(ago / 60)) if ago < 5400 else \
               "{} h ago".format(round(ago / 3600))
        return 'CHECKMARK', "{} · up to date · checked {}".format(version, when), check
    return 'CHECKMARK', version, check
