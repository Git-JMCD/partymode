# SPDX-License-Identifier: GPL-3.0-or-later
"""
Geometry checks that a screenshot cannot settle: does a part rest on its
support, is it sunk in, floating, touching, or colliding. All measurements
are on evaluated (post-modifier) meshes in world space, in metres.

A failed check is a claim to look at, so it says where: which sample points
failed, which separate piece of the object they belong to, whether the rest of
the object passes, and a close-up to render.
"""

import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

from .registry import ToolError, get_object, r, tool, vec

_MAX_SAMPLES = 20000


class _Surface:
    """World-space triangles of one evaluated object, with a BVH for queries."""

    __slots__ = ("name", "verts", "tris", "tree", "_samples", "_parts")

    def __init__(self, ob, dg):
        ob_eval = ob.evaluated_get(dg)
        try:
            me = ob_eval.to_mesh()
        except RuntimeError:
            me = None
        if me is None or not len(me.vertices):
            if me is not None:
                ob_eval.to_mesh_clear()
            raise ToolError("{!r} has no surface to measure (type {}).".format(ob.name, ob.type))
        try:
            me.calc_loop_triangles()
            n = len(me.vertices)
            co = np.empty(n * 3, dtype=np.float64)
            me.vertices.foreach_get("co", co)
            co = co.reshape(n, 3)
            mw = np.array(ob_eval.matrix_world, dtype=np.float64)
            co = co @ mw[:3, :3].T + mw[:3, 3]
            tris = np.empty(len(me.loop_triangles) * 3, dtype=np.int64)
            me.loop_triangles.foreach_get("vertices", tris)
            tris = tris.reshape(-1, 3)
        finally:
            ob_eval.to_mesh_clear()
        self.name = ob.name
        self.verts = co
        self.tris = tris
        self.tree = BVHTree.FromPolygons(co.tolist(), tris.tolist(), all_triangles=True)
        self._samples = None
        self._parts = None

    def samples(self):
        """(points, vertex each came from): vertices plus triangle centres, capped for speed."""
        if self._samples is None:
            centres = self.verts[self.tris].mean(axis=1) if len(self.tris) else np.empty((0, 3))
            pts = np.concatenate([self.verts, centres])
            owner = np.concatenate([np.arange(len(self.verts)),
                                    self.tris[:, 0] if len(self.tris) else np.empty(0, dtype=np.int64)])
            if len(pts) > _MAX_SAMPLES:
                pick = np.random.default_rng(0).choice(len(pts), _MAX_SAMPLES, replace=False)
                pts, owner = pts[pick], owner[pick]
            self._samples = (pts, owner)
        return self._samples

    def parts(self):
        """(part per vertex, vertex count, surface area per part): loose pieces, part 0 the biggest."""
        if self._parts is None:
            parent = list(range(len(self.verts)))

            def find(x):
                root = x
                while parent[root] != root:
                    root = parent[root]
                while parent[x] != root:
                    parent[x], x = root, parent[x]
                return root

            for a, b, c in self.tris.tolist():
                ra = find(a)
                rb = find(b)
                if rb != ra:
                    parent[rb] = ra
                rc = find(c)
                if rc != ra:
                    parent[rc] = ra
            roots = np.array([find(i) for i in range(len(parent))])
            _uniq, inverse, counts = np.unique(roots, return_inverse=True, return_counts=True)
            # Size a piece by its surface area: vertex counts say little (a big flat block and
            # a small plank can both have 8).
            t = self.verts[self.tris]
            tri_area = 0.5 * np.linalg.norm(np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0]), axis=1)
            area = np.bincount(inverse[self.tris[:, 0]], weights=tri_area, minlength=len(counts))
            order = np.argsort(-area)
            rank = np.empty_like(order)
            rank[order] = np.arange(len(order))
            self._parts = (rank[inverse], counts[order], area[order])
        return self._parts

    def bounds(self):
        return self.verts.min(axis=0), self.verts.max(axis=0)


def _signed_distances(points, surface: _Surface):
    """
    Distance from each point to ``surface``; negative when the point is inside it.

    A point counts as inside only when the nearest spot is on a face (the offset is
    mostly along that face's normal) and on its back side, so points past the edge
    of an open mesh such as a floor plane are not mistaken for buried ones.
    """
    out = np.empty(len(points))
    find_nearest = surface.tree.find_nearest
    for i, p in enumerate(points):
        p = Vector(p)
        loc, normal, _index, dist = find_nearest(p)
        if loc is None:
            out[i] = np.inf
            continue
        d = (p - loc).dot(normal)
        inside = d < 0 and -d >= 0.5 * dist
        out[i] = -dist if inside else dist
    return out


def _measure(src: _Surface, tgt: _Surface):
    s_pts, s_owner = src.samples()
    s_dist = _signed_distances(s_pts, tgt)
    # Also the other way round (the target poking into the source), near the source only.
    s_lo, s_hi = src.bounds()
    t_lo, t_hi = tgt.bounds()
    t_pts = tgt.samples()[0]
    near = np.all((t_pts >= s_lo - 0.05) & (t_pts <= s_hi + 0.05), axis=1)
    t_pts = t_pts[near]
    t_dist = _signed_distances(t_pts, src) if len(t_pts) else np.array([np.inf])

    pen_s = float(max(0.0, -s_dist.min()))
    pen_t = float(max(0.0, -t_dist.min()))
    # Gap both ways: a wide seat on thin legs has no seat sample right above a leg,
    # but the leg's top vertices sit exactly on the seat.
    return {
        "min_distance": float(min(np.abs(s_dist).min(), np.abs(t_dist).min())),
        "penetration": max(pen_s, pen_t),
        "pen_source": pen_s, "pen_target": pen_t,
        "intersecting": bool(src.tree.overlap(tgt.tree)),
        "source_bottom_z": float(s_lo[2]),
        "source_top_z": float(s_hi[2]),
        "target_top_z": float(t_hi[2]),
        "_s": (s_pts, s_owner, s_dist), "_t": (t_pts, t_dist),
    }


def _region(points):
    lo, hi = points.min(axis=0), points.max(axis=0)
    centre = (lo + hi) / 2
    radius = max(float(np.linalg.norm(hi - lo)) * 0.75, 0.15)
    return {"bounds_min": vec(lo, 4), "bounds_max": vec(hi, 4),
            "look": {"tool": "render_view", "focus_point": vec(centre, 3), "focus_radius": r(radius, 3)}}


def _evidence(src: _Surface, tgt: _Surface, m: dict, cause: str, tol: float):
    """Where a failed check failed, in terms an agent can act on."""
    s_pts, s_owner, s_dist = m["_s"]
    t_pts, t_dist = m["_t"]
    ev = {"cause": cause}
    if cause == "target_inside_source":
        bad = t_dist < -tol
        pts = t_pts[bad]
        if len(pts):
            ev.update(where="{} pokes into {}".format(tgt.name, src.name), samples=int(bad.sum()),
                      of=int(len(t_pts)), worst_points=[vec(p, 4) for p in pts[np.argsort(t_dist[bad])][:4]],
                      **_region(pts))
        return ev
    if cause in ("sunk", "colliding"):
        bad = s_dist < -tol
        order = np.argsort(s_dist[bad])
    elif cause == "floating":
        bad = np.zeros(len(s_dist), dtype=bool)
        bad[int(np.argmin(np.abs(s_dist)))] = True     # where the source comes closest
        order = np.arange(1)
    else:  # below_top
        bad = s_pts[:, 2] < m["target_top_z"] - tol
        order = np.argsort(s_pts[bad][:, 2])
    pts = s_pts[bad]
    if not len(pts):
        return ev
    ev.update(samples=int(bad.sum()), of=int(len(s_pts)),
              worst_points=[vec(p, 4) for p in pts[order][:4]], **_region(pts))
    if cause == "floating":
        loc, _n, _i, dist = tgt.tree.find_nearest(Vector(pts[0]))
        if loc is not None:
            ev["nearest_support_point"] = vec(loc, 4)
            ev["gap_m"] = r(dist, 5)
        return ev
    # Which loose pieces of the source the failure comes from, and whether the rest passes.
    part_of, sizes, areas = src.parts()
    if len(sizes) < 2:
        return ev
    ids, hits = np.unique(part_of[s_owner[bad]], return_counts=True)
    total_area = float(areas.sum()) or 1.0
    pieces = []
    for pid, hit in sorted(zip(ids.tolist(), hits.tolist()), key=lambda x: -x[1])[:3]:
        mask = part_of == pid
        pieces.append({"part": int(pid), "vertices": int(sizes[pid]),
                       "share_of_object": r(areas[pid] / total_area, 3),
                       "failing_samples": int(hit), "bounds_min": vec(src.verts[mask].min(axis=0), 3),
                       "bounds_max": vec(src.verts[mask].max(axis=0), 3)})
    ev["object_parts"] = int(len(sizes))
    ev["failing_parts"] = pieces
    rest = ~np.isin(part_of[s_owner], ids)
    if rest.any():
        rd = s_dist[rest]
        rest_pen = float(max(0.0, -rd.min()))
        rest_gap = float(np.abs(rd).min())
        share = 1.0 - float(sum(float(areas[i]) for i in ids.tolist())) / total_area
        if rest_pen <= tol and (cause == "colliding" or rest_gap <= max(tol, 0.01)):
            ev["rest_of_object"] = "passes: the other {:.0%} of {} {} (closest {:.4f} m)".format(
                share, src.name, "is clear of " + tgt.name if cause == "colliding" else "rests on " + tgt.name,
                rest_gap)
            if all(float(areas[i]) / total_area < 0.25 for i in ids.tolist()):
                ev["note"] = ("Decided by {} small separate piece(s) of {} ({}). Check whether that piece "
                              "should meet {} at all (a bridge, a flag, a prop) before moving the whole "
                              "object.".format(len(ids), src.name,
                                               ", ".join("part {}".format(p["part"]) for p in pieces), tgt.name))
        else:
            ev["rest_of_object"] = "also fails: the rest of {} is {} (closest {:.4f} m)".format(
                src.name, "{:.4f} m into {}".format(rest_pen, tgt.name) if rest_pen > tol else "away from " + tgt.name,
                rest_gap)
    return ev


def _verdict(rel: str, m: dict, tol: float):
    """(passed, verdict, cause); cause names what failed, for the evidence."""
    pen, gap = m["penetration"], m["min_distance"]
    sunk_cause = "sunk" if m["pen_source"] >= m["pen_target"] else "target_inside_source"
    if rel == "rests_on":
        if pen > tol:
            return False, "sunk into the support by {:.4f} m".format(pen), sunk_cause
        if gap > tol:
            return False, "floating {:.4f} m above/away from the support".format(gap), "floating"
        if m["source_bottom_z"] < m["target_top_z"] - tol and m["source_top_z"] < m["target_top_z"]:
            return False, "below the top of the support (hanging off its side?)", "below_top"
        return True, "resting on the support", None
    if rel == "contact":
        if gap <= tol or m["intersecting"]:
            return True, "touching" + (" (overlap {:.4f} m)".format(pen) if pen > tol else ""), None
        return False, "not touching: {:.4f} m apart".format(gap), "floating"
    if rel == "clearance":
        if m["intersecting"] or pen > 0:
            cause = "colliding" if m["pen_source"] >= m["pen_target"] else "target_inside_source"
            return False, "colliding (overlap {:.4f} m)".format(pen), cause
        if gap <= tol:
            return False, "only {:.4f} m clearance".format(gap), "floating"
        return True, "clear by {:.4f} m".format(gap), None
    raise ToolError("Unknown relationship {!r}.".format(rel))


HOW_MEASURED = ("min_distance_m and penetration_m are measured at sample points (vertices and face centres), "
                "so they can miss a crossing between samples on large faces; intersecting is an exact "
                "face-crossing test (faces that only touch, flat on each other, do not count as crossing). "
                "decided_by says which of them gave the verdict.")


def _decided(rel, m, tol, ok):
    """Which measurement gave the verdict, in words, flagging when the two disagree."""
    gap, pen, crossing = m["min_distance"], m["penetration"], m["intersecting"]
    near = "the closest sample points are {:.4f} m apart".format(gap)
    if rel == "contact":
        if crossing and gap > tol:
            return ("faces cross (exact test), although " + near +
                    ": the crossing lies between samples, on large faces")
        if gap <= tol:
            return near + (" (within tolerance)" + ("; the samples overlap by about {:.4f} m".format(pen)
                                                    if pen > tol else ""))
        return near + ", and no faces cross"
    if rel == "clearance":
        if crossing:
            return "faces cross (exact test)" + ("" if pen > 0 else ", though no sample point is inside")
        if pen > 0:
            return "a sample point is {:.4f} m inside, though no faces cross (touching flat faces?)".format(pen)
        return near
    # rests_on
    if pen > tol:
        return "sample points are up to {:.4f} m inside the support".format(pen)
    if gap > tol:
        return near + " (a gap)"
    return near + (" and faces cross" if crossing else "") + " (resting)"


@tool("inspect_geometry",
      "Measure how parts sit against each other on evaluated world-space surfaces (1-16 "
      "checks, changes nothing). relationship: rests_on (source sits on target: fails if "
      "sunk in past tolerance, reported as penetration, or floating), contact (touching or "
      "fused; overlap allowed), clearance (must not collide or come within tolerance). "
      "Returns pass/fail per check with distances in metres. A failure includes evidence: where "
      "(sample points, region, a render_view close-up to look at), which separate piece of the "
      "source caused it and whether the rest of the object passes. Treat a failure as a claim to "
      "look at, not a proof. Re-check after every fix.",
      {"checks": {"type": "array", "minItems": 1, "maxItems": 16, "items": {
          "type": "object", "additionalProperties": False,
          "required": ["source", "target", "relationship"],
          "properties": {
              "source": {"type": "string", "description": "Exact object name (a mesh part)."},
              "target": {"type": "string", "description": "Exact supporting or neighbouring object."},
              "relationship": {"type": "string", "enum": ["rests_on", "contact", "clearance"]},
              "tolerance_m": {"type": "number", "minimum": 0.0001, "maximum": 0.1, "default": 0.005},
          }}}},
      required=("checks",))
def inspect_geometry(args):
    dg = bpy.context.evaluated_depsgraph_get()
    cache = {}

    def surface(name):
        if name not in cache:
            cache[name] = _Surface(get_object(name), dg)
        return cache[name]

    results, passed = [], 0
    for chk in args["checks"]:
        rel, tol = chk["relationship"], float(chk.get("tolerance_m", 0.005))
        entry = {"source": chk["source"], "target": chk["target"], "relationship": rel, "tolerance_m": tol}
        try:
            if chk["source"] == chk["target"]:
                raise ToolError("source and target are the same object.")
            src, tgt = surface(chk["source"]), surface(chk["target"])
            m = _measure(src, tgt)
            ok, why, cause = _verdict(rel, m, tol)
            entry.update(passed=ok, verdict=why,
                         min_distance_m=r(m["min_distance"], 5), penetration_m=r(m["penetration"], 5),
                         intersecting=m["intersecting"], decided_by=_decided(rel, m, tol, ok))
            if not ok:
                entry["evidence"] = _evidence(src, tgt, m, cause, tol)
            passed += ok
        except ToolError as ex:
            entry.update(passed=False, verdict="unavailable", error=str(ex))
        results.append(entry)
    data = {"passed": passed, "failed": len(results) - passed, "checks": results, "how_measured": HOW_MEASURED}
    from . import check_marks
    shown = check_marks.note(check_marks.from_geometry(results))
    if shown:
        data["viewport"] = shown
    return {"data": data, "isError": False}
