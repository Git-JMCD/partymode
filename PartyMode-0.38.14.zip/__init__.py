# SPDX-License-Identifier: GPL-3.0-or-later
"""
PartyMode: an MCP server inside Blender, built for AI agents.

Every edit gets a receipt (safe retries), a change report, a named undo step
and a history entry; checking tools measure geometry and render focused views.
"""

bl_info = {
    "name": "PartyMode",
    "author": "agent-blender",
    "version": (0, 1, 0),
    "blender": (5, 3, 0),
    "location": "Preferences > Add-ons > PartyMode",
    "description": "MCP server for AI agents: receipts, change reports, undo steps, geometry checks",
    "category": "Development",
    "support": "OFFICIAL",
}

import os
import time

import bpy

from . import (cancel, changes, chat, check_marks, history, looks, mainthread, runners, server, ui, ui_chat, ui_mark,
               ui_menu, ui_sandbox, ui_select, ui_space)
# Importing the tool modules registers their tools.
from . import (apihints, guide, intercom, renderjob, rules, tools_anim, tools_assets, tools_check, tools_cleanup,  # noqa: F401
               tools_edit, tools_generate, tools_inspect, tools_export, tools_light, tools_look, tools_marks, tools_remesh,
               tools_repair, tools_sandbox, tools_render, tools_safety, tools_shade, tools_sheet, team, feedback)
from . import updates

DEFAULT_PORT = 9900


def chat_choice(prefs):
    """(runner, model, effort) for chat.configure / set_choice; "" means the agent's default."""
    if prefs is None:
        return "claude", "", ""
    runner = prefs.chat_runner
    if runner == "claude":
        model = "" if prefs.chat_model == "DEFAULT" else prefs.chat_model
    elif runner == "codex":
        model = prefs.codex_model.strip()
    else:
        model = prefs.opencode_model.strip()
    return runner, model, _effort(prefs, runner)


def _effort(prefs, runner):
    """The reasoning set for an agent ("" for its own default; OpenCode sets it per model)."""
    value = getattr(prefs, runner + "_effort", "DEFAULT") if runner in ("claude", "codex") else "DEFAULT"
    return "" if value == "DEFAULT" else value


def chat_paths(prefs):
    if prefs is None:
        return {}
    return {"claude": prefs.claude_path, "codex": prefs.codex_path, "opencode": prefs.opencode_path}


def team_sync(prefs):
    """The helpers ticked for a team (team.py), and the model each uses."""
    if prefs is None:
        return
    chat.S.team_helpers = [k for k in ("claude", "codex", "opencode") if getattr(prefs, "team_" + k, False)]
    chat.S.team_models = {"claude": "" if prefs.chat_model == "DEFAULT" else prefs.chat_model,
                          "codex": prefs.codex_model.strip(), "opencode": prefs.opencode_model.strip()}
    chat.S.team_efforts = {k: _effort(prefs, k) for k in ("claude", "codex", "opencode")}
    chat.S.revision += 1


def _chat_choice_changed(self, context):
    chat.set_choice(*chat_choice(self))
    team_sync(self)


def _team_changed(self, context):
    team_sync(self)


def _chat_paths_changed(self, context):
    chat.S.paths = chat_paths(self)
    chat.S.revision += 1


_EXE_DESC = "Path to the program; empty finds it automatically"


def _research_changed(self, context):
    chat.S.research_mode = self.research_mode
    if self.research_mode != "MESSAGE":
        chat.S.research = False
    chat.S.revision += 1


def _ask_changed(self, context):
    from . import approvals
    approvals.ASK["on"] = bool(self.ask_web)
    chat.S.revision += 1


def _look_changed(self, context):
    from . import looks
    looks.switched()


def _marks_changed(self, _context):
    from . import check_marks
    check_marks.SHOW["on"] = bool(self.show_check_marks)
    check_marks._redraw()


_EFFORT_ITEMS = ([("DEFAULT", "Default", "Whatever the agent's own settings say")]
                 + [(e, e.capitalize() if e != "xhigh" else "Extra high", "") for e in chat.EFFORTS])


def _claude_default_label():
    model = chat.model_label(runners.get("claude").defaults().get("model") or "")
    return "Default · " + model if model else "Default"


# The tabs (dynamic items, so Setup can show a warning). Kept in a module list: Blender needs the
# items to stay referenced while it draws them.
_TAB_ITEMS = []


def _setup_problem(prefs):
    """Something on the Setup tab that needs fixing: a missing agent program or a stopped server."""
    return not server.port() or not all(chat.executable(k) for k in ("claude", "codex", "opencode"))


def _tab_items(self, context):
    chat_icon = ui_space.agent_icon() or 0
    setup = 'ERROR' if _setup_problem(self) else 'PREFERENCES'
    _TAB_ITEMS[:] = [
        ("CHAT", "Chat", "The chat's agent, each agent's model and reasoning, and the team",
         chat_icon if chat_icon else 'OUTLINER_DATA_GP_LAYER', 0),
        ("WEB", "Web", "When agents may go online", 'URL', 1),
        ("LOOK", "Look", "How the chat looks, and marks in the viewport", 'COLOR', 2),
        ("SETUP", "Setup", "Agent programs, the server, ComfyUI and updates", setup, 3),
    ]
    return _TAB_ITEMS


class AgentBridgePreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    prefs_tab: bpy.props.EnumProperty(name="Tab", items=_tab_items, options={'HIDDEN'})
    port: bpy.props.IntProperty(name="Port", default=DEFAULT_PORT, min=1024, max=65535,
                                description="Where the server listens (127.0.0.1 only). If another Blender "
                                            "has it, this one takes the next free port")
    ui_look: bpy.props.EnumProperty(
        name="Look", description="How the chat looks (layout and behaviour stay the same)",
        items=looks.ITEMS, default=looks.DEFAULT, update=_look_changed)
    research_mode: bpy.props.EnumProperty(
        name="Agents go online", description="When the chat's agents may use the web",
        items=(("OFF", "Off", "The agents never use the web"),
               ("MESSAGE", "Per message", "Switch Research on in the agent menu for one message; the scene stays "
                                          "read-only that turn"),
               ("AUTO", "Auto", "The agent uses the web when it helps; once it has, it asks once before it "
                                "changes the scene that turn")),
        default="MESSAGE", update=_research_changed)
    ask_web: bpy.props.BoolProperty(
        name="Ask before the agent uses the web",
        description="Show Allow / Deny in the chat before an agent searches the web, reads a page or pulls a "
                    "picture into the Sandbox. Pictures pulled into the Sandbox keep their source and licence",
        default=True, update=_ask_changed)
    show_check_marks: bpy.props.BoolProperty(
        name="Show check results in the viewport",
        description="Mark where an agent's check failed (a part sunk in, a hole) with a box and a label in the "
                    "3D viewport",
        default=True, update=_marks_changed)
    team_claude: bpy.props.BoolProperty(name="Claude", description="Claude helps as a team member when it "
                                        "is not the one leading", default=False, update=_team_changed)
    team_codex: bpy.props.BoolProperty(name="Codex", description="Codex helps as a team member when it is "
                                       "not the one leading", default=False, update=_team_changed)
    team_opencode: bpy.props.BoolProperty(name="OpenCode", description="OpenCode helps as a team member when "
                                          "it is not the one leading", default=False, update=_team_changed)
    autostart: bpy.props.BoolProperty(name="Start with Blender", default=True,
                                      description="Start the agent server when Blender starts")
    update_check: bpy.props.BoolProperty(
        name="Check for updates once a day",
        description="Ask GitHub for the latest PartyMode release when Blender starts (at most once a "
                    "day, and only with Allow Online Access on)",
        default=True)
    comfy_url: bpy.props.StringProperty(name="ComfyUI address", default="http://127.0.0.1:8188",
                                        description="Where ComfyUI runs, for images and 3D models made on this "
                                                    "computer")
    image_workflow: bpy.props.StringProperty(name="Image workflow", default="IMAGE - Flux Schnell txt2img",
                                             description="The ComfyUI workflow that makes images, by its name")
    mesh_workflow: bpy.props.StringProperty(name="Mesh workflow", default="3D - TripoSG image to mesh",
                                            description="The ComfyUI workflow that makes a mesh from an image")
    pbr_workflow: bpy.props.StringProperty(name="PBR model workflow", default="3D - TripoSG image to PBR mesh",
                                           description="The ComfyUI workflow that makes a textured (PBR) mesh")

    chat_runner: bpy.props.EnumProperty(
        name="Agent", description="Which AI agent answers in the chat (and leads a team)",
        items=[(r.key, r.label, r.description) for r in runners.RUNNERS.values()],
        default="claude", update=_chat_choice_changed)
    claude_path: bpy.props.StringProperty(name="Claude Code program", subtype='FILE_PATH', default="",
                                          description=_EXE_DESC, update=_chat_paths_changed)
    codex_path: bpy.props.StringProperty(name="Codex program", subtype='FILE_PATH', default="",
                                         description=_EXE_DESC, update=_chat_paths_changed)
    opencode_path: bpy.props.StringProperty(name="OpenCode program", subtype='FILE_PATH', default="",
                                            description=_EXE_DESC + " (the .exe, not the npm .cmd wrapper)",
                                            update=_chat_paths_changed)
    chat_model: bpy.props.EnumProperty(
        name="Claude model", description="Claude's model (as lead or helper)",
        items=[("DEFAULT", _claude_default_label(), "Whatever Claude Code uses (your Claude Code settings)")]
              + [(key, label, desc) for key, label, desc in chat.MODELS],
        default="DEFAULT", update=_chat_choice_changed)
    codex_model: bpy.props.StringProperty(
        name="Codex model", default="", update=_chat_choice_changed,
        description="Codex's model (as lead or helper), e.g. gpt-6.1-sol. Empty: your Codex settings")
    opencode_model: bpy.props.StringProperty(
        name="OpenCode model", default="", update=_chat_choice_changed,
        description="OpenCode's model (as lead or helper) as provider/model, e.g. ollama/qwen3.8:27b. Empty: "
                    "your OpenCode settings. Local models need Ollama or LM Studio running, and share the GPU "
                    "with ComfyUI")
    claude_effort: bpy.props.EnumProperty(
        name="Claude reasoning", description="How hard Claude thinks (as lead or helper)",
        items=_EFFORT_ITEMS, default="DEFAULT", update=_chat_choice_changed)
    codex_effort: bpy.props.EnumProperty(
        name="Codex reasoning", description="How hard Codex thinks (as lead or helper)",
        items=_EFFORT_ITEMS, default="DEFAULT", update=_chat_choice_changed)
    # Before 0.38 one setting covered Claude and Codex; start() moves it into the two above.
    chat_effort: bpy.props.EnumProperty(name="Reasoning", items=_EFFORT_ITEMS, default="DEFAULT",
                                        options={'HIDDEN'})

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        _draw_status(layout.box(), self)
        row = layout.row()
        row.use_property_split = False
        row.scale_y = 1.4
        row.prop(self, "prefs_tab", expand=True)
        col = layout.column()
        {"CHAT": _draw_chat, "WEB": _draw_web, "LOOK": _draw_look, "SETUP": _draw_setup}.get(
            self.prefs_tab, _draw_chat)(col, self)


# ---------------------------------------------------------------------------
# Drawing helpers.

def _heading(col, text):
    col.separator()
    col.label(text=text)
    col.separator(type='LINE')


def _note(col, text, icon='NONE', alert=False):
    """One short line of explanation in the value column (never wraps: keep it under ~60 characters)."""
    split = col.split(factor=0.4)
    split.label(text="")
    row = split.row()
    if alert:
        row.alert = True
    else:
        row.active = False
    row.label(text=text, icon=icon)


def _status_row(box, icon, key, text, alert=False):
    """A row of the status box: icon and key, the value, then a right-aligned button area."""
    row = box.row()
    row.alert = alert
    key_split = row.split(factor=0.16)
    key_split.label(text=key, icon=icon)
    value_split = key_split.split(factor=0.66)
    value_split.label(text=text)
    buttons = value_split.row(align=True)
    buttons.alignment = 'RIGHT'
    return buttons


def _found_agents():
    return [k for k in ("claude", "codex", "opencode") if chat.executable(k)]


def _and_list(names):
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


def _port_taken(port):
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.2)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def _draw_status(box, prefs):
    box.use_property_split = False
    # Server.
    live = server.port()
    if live:
        b = _status_row(box, 'LINKED', "Server", "Running · 127.0.0.1:{}/mcp".format(live))
        b.operator("agent.copy_text", text="Copy address", icon='COPYDOWN').text = \
            "http://127.0.0.1:{}/mcp".format(live)
    else:
        why = " · port {} is taken".format(prefs.port) if _port_taken(prefs.port) else ""
        b = _status_row(box, 'ERROR', "Server", "Stopped" + why, alert=True)
        b.operator("agent.server_start", text="Start", icon='PLAY')
    # Agents.
    found = _found_agents()
    missing = [runners.get(k).label for k in ("claude", "codex", "opencode") if k not in found]
    if missing:
        b = _status_row(box, 'ERROR', "Agents", "{} not found".format(_and_list(missing)), alert=True)
        b.operator("agent.prefs_setup", text="Set path…", icon='FILEBROWSER')
    else:
        _status_row(box, 'CHECKMARK', "Agents", "{} found".format(_and_list([runners.get(k).label for k in found])))
    # Add-on: its version and updates.
    icon, text, actions = updates.status_line()
    b = _status_row(box, icon, "Add-on", text, alert=icon == 'ERROR')
    for op, label, op_icon, url in actions:
        o = b.operator(op, text=label, icon=op_icon)
        if url:
            o.url = url
    if live and live != prefs.port:
        _note(box, "Port {} was taken, so this Blender uses {}".format(prefs.port, live), 'INFO')


def _cells(row):
    """The agents table's four cells: agent · model · reasoning · team. Blender fills a split left
    to right, so each cell is made before the split that holds the rest."""
    s1 = row.split(factor=0.17)
    agent = s1.row()
    s2 = s1.split(factor=0.60)
    model = s2.row()
    s3 = s2.split(factor=0.55)
    return agent, model, s3.row(), s3.row()


def _draw_chat(col, prefs):
    _heading(col, "Answers in chat")
    col.row().prop(prefs, "chat_runner", expand=True)
    _heading(col, "Agents")
    head = col.row()
    head.active = False
    a, b, c, d = _cells(head)
    a.label(text="Agent")
    b.label(text="Model")
    c.label(text="Reasoning")
    d.label(text="Team")
    lead = prefs.chat_runner
    for key in ("claude", "codex", "opencode"):
        found = bool(chat.executable(key))
        a, b, c, d = _cells(col.row())
        name = a.row()
        name.alert = not found
        name.label(text=runners.get(key).label, icon='CHECKMARK' if found else 'ERROR')
        model = b.row()
        model.use_property_split = False
        if key == "claude":
            model.prop(prefs, "chat_model", text="")
        else:
            # A field that shows the default when empty (type any name), and a list to pick from.
            if key == "opencode":
                ui_space._fetch_opencode_models()
            default = chat.model_label(chat.defaults(key).get("model") or "")
            field = model.row(align=True)
            field.prop(prefs, key + "_model", text="",
                       placeholder="Default · " + default if default else "Default (provider/model)"
                       if key == "opencode" else "Default")
            field.operator("agent.pick_model", text="", icon='DOWNARROW_HLT').agent = key
        effort = c.row()
        effort.use_property_split = False
        if key in ("claude", "codex"):
            effort.prop(prefs, key + "_effort", text="")
        else:
            effort.active = False
            effort.label(text="In OpenCode")
        team = d.row()
        team.use_property_split = False
        if key == lead:
            team.enabled = False
            team.operator("agent.prefs_setup", text="Leads")
        elif found:
            team.prop(prefs, "team_" + key, text="Helps", toggle=True)
        else:
            team.alert = True
            team.operator("agent.prefs_setup", text="Set path…")
    if not chat.executable(lead):
        _note(col, "{} isn't installed, or its path isn't set in Setup.".format(runners.get(lead).label),
              'ERROR', alert=True)
    else:
        _note(col, "Helpers use their own model here; the lead checks their work.", 'INFO')


_RESEARCH_NOTE = {"OFF": "Agents never go online.",
                  "MESSAGE": "Switch Research on per message. That turn can't edit.",
                  "AUTO": "Agents go online when it helps, then ask before editing."}


def _draw_web(col, prefs):
    _heading(col, "Web use")
    col.row().prop(prefs, "research_mode", expand=True)
    _note(col, _RESEARCH_NOTE.get(prefs.research_mode, ""))
    row = col.row(heading="Ask first")
    row.enabled = prefs.research_mode != "OFF"
    row.prop(prefs, "ask_web", text="Before each search, page or picture")


_LOOK_NOTE = {"HALO": "Graphite surfaces, the agent's colour as light.",
              "SIGNAL": "Instrument panel: ink black, hairlines, a step log.",
              "CLASSIC": "The original look, in Blender's own fonts."}


def _draw_look(col, prefs):
    _heading(col, "Chat")
    col.row().prop(prefs, "ui_look", expand=True)
    _note(col, _LOOK_NOTE.get(prefs.ui_look, ""))
    _heading(col, "Viewport")
    col.row(heading="Checks").prop(prefs, "show_check_marks", text="Mark where a check failed")


def _draw_setup(col, prefs):
    _heading(col, "Agent programs")
    for key in ("claude", "codex", "opencode"):
        found = chat.executable(key)
        split = col.split(factor=0.4)
        label = split.row()
        label.alignment = 'RIGHT'
        label.alert = not found
        label.label(text=runners.get(key).label, icon='CHECKMARK' if found else 'ERROR')
        split.prop(prefs, key + "_path", text="", placeholder=found or "not found")
    _note(col, "Leave empty to find each program on its own.")
    _heading(col, "Server")
    col.row(heading="Start").prop(prefs, "autostart", text="With Blender")
    col.prop(prefs, "port")
    live = server.port() or prefs.port
    address = "http://127.0.0.1:{}/mcp".format(live)
    split = col.split(factor=0.4)
    label = split.row()
    label.alignment = 'RIGHT'
    label.label(text="Terminal agents")
    buttons = split.row()
    buttons.operator("agent.copy_text", text="Copy Claude Code command", icon='COPYDOWN').text = \
        "claude mcp add --transport http agent-blender " + address
    buttons.operator("agent.copy_address", text="Copy address", icon='COPYDOWN').text = address
    _heading(col, "Local generation (ComfyUI)")
    col.prop(prefs, "comfy_url", text="Address")
    col.prop(prefs, "image_workflow", text="Image")
    col.prop(prefs, "mesh_workflow", text="Mesh")
    col.prop(prefs, "pbr_workflow", text="Mesh with PBR")
    _heading(col, "Updates")
    col.row(heading="Check").prop(prefs, "update_check", text="Once a day")


class AGENT_OT_copy_text(bpy.types.Operator):
    bl_idname = "agent.copy_text"
    bl_label = "Copy"
    bl_description = "Copy this to the clipboard"
    text: bpy.props.StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        context.window_manager.clipboard = self.text
        self.report({'INFO'}, "Copied")
        return {'FINISHED'}


class AGENT_OT_copy_address(AGENT_OT_copy_text):
    bl_idname = "agent.copy_address"
    bl_label = "Copy Address"
    bl_description = ("Copy the server's address. Codex and OpenCode take it in their own MCP settings "
                      "(as a streamable HTTP server)")


_PICK_ITEMS = []


def _pick_items(self, context):
    """The models an agent offers, for the pick list (Default first)."""
    from . import ui_menu
    _PICK_ITEMS[:] = [(value or "__default__", label if value else "Default · " + note if note else "Default", note)
                      for value, label, note in ui_menu.models(self.agent)]
    return _PICK_ITEMS


class AGENT_OT_pick_model(bpy.types.Operator):
    bl_idname = "agent.pick_model"
    bl_label = "Pick a Model"
    bl_description = "Pick from the models this agent offers (or type any name in the field)"
    bl_property = "model"
    agent: bpy.props.StringProperty(options={'SKIP_SAVE', 'HIDDEN'})
    model: bpy.props.EnumProperty(items=_pick_items)

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        prefs = _prefs()
        if prefs is not None and self.agent in ("codex", "opencode"):
            setattr(prefs, self.agent + "_model", "" if self.model == "__default__" else self.model)
        return {'FINISHED'}


class AGENT_OT_server_start(bpy.types.Operator):
    bl_idname = "agent.server_start"
    bl_label = "Start Server"
    bl_description = "Start the agent server (on the next free port if this one is taken)"

    def execute(self, context):
        try:
            start()
        except OSError as ex:
            self.report({'ERROR'}, "Could not start the server: {}".format(ex))
            return {'CANCELLED'}
        self.report({'INFO'}, "Server running on port {}".format(server.port()))
        return {'FINISHED'}


class AGENT_OT_prefs_setup(bpy.types.Operator):
    bl_idname = "agent.prefs_setup"
    bl_label = "Set Path"
    bl_description = "Open the Setup tab, to set where an agent's program is"

    def execute(self, context):
        prefs = _prefs()
        if prefs is not None:
            prefs.prefs_tab = 'SETUP'
        return {'FINISHED'}


_PREF_CLASSES = (AGENT_OT_copy_text, AGENT_OT_copy_address, AGENT_OT_server_start, AGENT_OT_prefs_setup,
                 AGENT_OT_pick_model)


def _prefs():
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def _history_tick():
    history.poll()
    return 0.5


def _migrate(prefs):
    """Settings from before 0.38: one reasoning setting covered Claude and Codex."""
    if prefs is not None and prefs.chat_effort != "DEFAULT":
        for key in ("claude_effort", "codex_effort"):
            if getattr(prefs, key) == "DEFAULT":
                setattr(prefs, key, prefs.chat_effort)
        prefs.chat_effort = "DEFAULT"


def start(port: int | None = None) -> None:
    prefs = _prefs()
    _migrate(prefs)
    from . import approvals
    approvals.ASK["on"] = bool(getattr(prefs, "ask_web", True)) if prefs else True
    from . import check_marks
    check_marks.SHOW["on"] = bool(getattr(prefs, "show_check_marks", True)) if prefs else True
    team_sync(prefs)
    chat.S.research_mode = getattr(prefs, "research_mode", "MESSAGE") if prefs else "MESSAGE"
    mainthread.start()
    if not bpy.app.timers.is_registered(_history_tick):
        bpy.app.timers.register(_history_tick, first_interval=0.5, persistent=True)
    # AGENT_BRIDGE_PORT runs a second Blender beside the first (tests, stock and fork side by side).
    # A port asked for outright is used or fails; the preference falls back to the next free port,
    # so a second Blender opened beside the first gets its own server.
    asked = port or int(os.environ.get("AGENT_BRIDGE_PORT") or 0)
    port = server.start(asked or (prefs.port if prefs else DEFAULT_PORT), tries=1 if asked else 10)
    cancel.start_watcher()
    from . import registry
    runner, model, effort = chat_choice(prefs)
    chat.configure(bpy.utils.user_resource('CONFIG', path="agent_bridge/chat", create=True), port,
                   chat_paths(prefs), runner, model, effort, tool_names=sorted(registry.TOOLS))
    updates.load_cache()
    if prefs is not None and prefs.update_check and not bpy.app.background:
        updates.check()


def stop() -> None:
    cancel.stop_watcher()
    server.stop()
    if bpy.app.timers.is_registered(_history_tick):
        bpy.app.timers.unregister(_history_tick)
    mainthread.stop()


def serve_blocking(port: int = DEFAULT_PORT) -> None:
    """For `blender -b`: no event loop runs timers there, so pump the main thread here."""
    server.start(port)
    cancel.start_watcher()
    try:
        while True:
            mainthread.pump()
            history.poll()
            time.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()


def _autostart():
    prefs = _prefs()
    if prefs is None or prefs.autostart:
        try:
            start()
        except OSError as ex:
            print("agent-bridge: could not start server:", ex)
    return None


def register():
    bpy.utils.register_class(AgentBridgePreferences)
    for cls in _PREF_CLASSES:
        bpy.utils.register_class(cls)
    for cls in updates.CLASSES:
        bpy.utils.register_class(cls)
    changes.register()
    if not bpy.app.background:
        ui_chat.register()
        ui_space.register()
        ui_mark.register()
        ui_sandbox.register()
        ui_menu.register()
        ui_select.register()
        check_marks.register()
        ui.register()
    if not bpy.app.background:
        # Preferences are not readable during registration; start right after.
        # Persistent: opening a file at launch (blender.exe scene.blend) clears other timers.
        bpy.app.timers.register(_autostart, first_interval=0.1, persistent=True)


def unregister():
    stop()
    if not bpy.app.background:
        ui.unregister()
        check_marks.unregister()
        ui_sandbox.unregister()
        ui_menu.unregister()
        ui_select.unregister()
        ui_mark.unregister()
        ui_space.unregister()
        ui_chat.unregister()
    changes.unregister()
    if not bpy.app.background:
        from . import ui_draw
        ui_draw.unload_fonts()
    for cls in reversed(updates.CLASSES):
        bpy.utils.unregister_class(cls)
    for cls in reversed(_PREF_CLASSES):
        bpy.utils.unregister_class(cls)
    bpy.utils.unregister_class(AgentBridgePreferences)
