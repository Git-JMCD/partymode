# SPDX-License-Identifier: GPL-3.0-or-later
"""
Stop a helper program another add-on started from Blender when it hangs.

Smart Remesh runs Instant Meshes and reads its output line by line; its own time limit is only
checked when a line arrives, so a run that freezes without printing waits forever and holds
Blender's main thread. While a watch is open, a thread looks at this Blender's child programs
whose name matches, and stops one whose CPU time has not moved for `stall_s` seconds (a working
remesher keeps a core busy). No psutil in Blender's Python: Windows uses the Win32 API through
ctypes, macOS and Linux use `ps`.
"""

import os
import signal
import subprocess
import sys
import threading
import time


def _children_windows(name):
    import ctypes
    from ctypes import wintypes

    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                    ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_void_p),
                    ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                    ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
                    ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    snap = k32.CreateToolhelp32Snapshot(0x2, 0)  # TH32CS_SNAPPROCESS
    if snap in (None, wintypes.HANDLE(-1).value):
        return {}
    found, me = {}, os.getpid()
    try:
        entry = PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        ok = k32.Process32FirstW(snap, ctypes.byref(entry))
        while ok:
            if entry.th32ParentProcessID == me and name in entry.szExeFile.lower():
                found[entry.th32ProcessID] = _cpu_windows(k32, entry.th32ProcessID)
            ok = k32.Process32NextW(snap, ctypes.byref(entry))
    finally:
        k32.CloseHandle(snap)
    return {pid: cpu for pid, cpu in found.items() if cpu is not None}


def _cpu_windows(k32, pid):
    import ctypes
    from ctypes import wintypes
    k32.OpenProcess.restype = wintypes.HANDLE
    h = k32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return None
    try:
        times = [wintypes.FILETIME() for _ in range(4)]
        if not k32.GetProcessTimes(h, *[ctypes.byref(t) for t in times]):
            return None
        kernel, user = times[2], times[3]
        return ((kernel.dwHighDateTime << 32 | kernel.dwLowDateTime)
                + (user.dwHighDateTime << 32 | user.dwLowDateTime)) / 1e7
    finally:
        k32.CloseHandle(h)


def _kill_windows(pid):
    import ctypes
    from ctypes import wintypes
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.OpenProcess.restype = wintypes.HANDLE
    h = k32.OpenProcess(0x1, False, pid)  # PROCESS_TERMINATE
    if h:
        k32.TerminateProcess(h, 1)
        k32.CloseHandle(h)


def _children_posix(name):
    try:
        out = subprocess.run(["ps", "-A", "-o", "pid=,ppid=,time=,comm="], capture_output=True,
                             text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return {}
    found, me = {}, os.getpid()
    for line in out.splitlines():
        parts = line.split(None, 3)
        if len(parts) < 4 or not parts[0].isdigit() or int(parts[1]) != me or name not in parts[3].lower():
            continue
        days, _, clock = parts[2].rpartition("-")
        secs = 0.0
        for piece in clock.split(":"):
            secs = secs * 60 + float(piece)
        found[int(parts[0])] = secs + (int(days) * 86400 if days else 0)
    return found


def children(name):
    """{pid: cpu seconds} for this Blender's child programs whose name contains `name`."""
    name = name.lower()
    return _children_windows(name) if sys.platform == "win32" else _children_posix(name)


def kill(pid):
    if sys.platform == "win32":
        _kill_windows(pid)
    else:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass


class watch:
    """with watch("instant meshes") as w: ... ; w.stopped lists the stalled runs that were stopped."""

    def __init__(self, name, stall_s=30.0, every_s=2.0):
        self.name, self.stall_s, self.every_s = name, stall_s, every_s
        self.stopped = []
        self._done = threading.Event()
        self._thread = None

    def _run(self):
        seen = {}  # pid -> (cpu, when it last moved)
        while not self._done.wait(self.every_s):
            now = time.monotonic()
            for pid, cpu in children(self.name).items():
                last = seen.get(pid)
                if last is None or cpu > last[0] + 0.05:
                    seen[pid] = (cpu, now)
                elif now - last[1] > self.stall_s:
                    kill(pid)
                    self.stopped.append({"pid": pid, "cpu_s": round(cpu, 1), "idle_s": round(now - last[1])})
                    seen.pop(pid, None)

    def __enter__(self):
        self._thread = threading.Thread(target=self._run, name="agent-bridge-childwatch", daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._done.set()
        self._thread.join(timeout=5)
        return False
