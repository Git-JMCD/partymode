# SPDX-License-Identifier: GPL-3.0-or-later
"""
The Sandbox: a shared shelf in the .blend where the user and the agent keep references,
logos, notes and renders.

Items live in the file, so they travel with it: images are packed, hidden datablocks named
".scrap_<id>"; SVGs are kept as text, with a raster preview; the index is the hidden text
".agent_scrapbook" (JSON). Thumbnails for the chat are written to a cache folder from the packed
bytes, since the chat draws images from files.
"""

import hashlib
import json
import os
import tempfile
import time

import bpy
import numpy as np

INDEX = ".agent_scrapbook"  # named before the Sandbox was renamed: kept, so saved files keep their items
KINDS = ("image", "svg", "note", "render")
_PALETTE_K = 5
_PREVIEW = 512


# ---------------------------------------------------------------------------
# The index.

def _text(create=False):
    t = bpy.data.texts.get(INDEX)
    if t is None and create:
        t = bpy.data.texts.new(INDEX)
        t.use_fake_user = True
        t.write(json.dumps({"items": [], "next": 1}))
    return t


def _load():
    t = _text()
    if t is None:
        return {"items": [], "next": 1}
    try:
        data = json.loads(t.as_string() or "{}")
    except ValueError:
        data = {}
    data.setdefault("items", [])
    data.setdefault("next", len(data["items"]) + 1)
    return data


def _save(data):
    t = _text(create=True)
    t.clear()
    t.write(json.dumps(data, indent=1))


def items():
    return _load()["items"]


def get(item_id):
    return next((i for i in items() if i["id"] == item_id), None)


def _add(entry):
    data = _load()
    entry["id"] = "s{}".format(data["next"])
    data["next"] += 1
    entry.setdefault("t", time.time())
    data["items"].append(entry)
    _save(data)
    return entry


def update(item_id, **fields):
    data = _load()
    for i in data["items"]:
        if i["id"] == item_id:
            i.update(fields)
            _save(data)
            return i
    return None


def remove(item_id):
    data = _load()
    gone = [i for i in data["items"] if i["id"] == item_id]
    data["items"] = [i for i in data["items"] if i["id"] != item_id]
    _save(data)
    for i in gone:
        for key in ("image", "preview"):
            img = bpy.data.images.get(i.get(key) or "")
            if img is not None:
                bpy.data.images.remove(img)
        txt = bpy.data.texts.get(i.get("svg") or "")
        if txt is not None:
            bpy.data.texts.remove(txt)
    return bool(gone)


# ---------------------------------------------------------------------------
# Pixels.

def _pixels(img, size=None):
    """(h, w, 4) float array of an image, rows bottom-up; scaled down to `size` when given."""
    if size is not None:
        img = img.copy()
        try:
            w, h = img.size
            k = size / max(w, h)
            if k < 1:
                img.scale(max(1, int(w * k)), max(1, int(h * k)))
            w, h = img.size
            px = np.empty(w * h * 4, np.float32)
            img.pixels.foreach_get(px)
        finally:
            bpy.data.images.remove(img)
        return px.reshape(h, w, 4)
    w, h = img.size
    px = np.empty(w * h * 4, np.float32)
    img.pixels.foreach_get(px)
    return px.reshape(h, w, 4)


def palette(img, k=_PALETTE_K):
    """The image's main colours (hex, most common first), by k-means on a small copy."""
    px = _pixels(img, 64).reshape(-1, 4)
    px = px[px[:, 3] > 0.5][:, :3]
    if len(px) == 0:
        return []
    k = min(k, len(px))
    rng = np.random.default_rng(0)
    centres = px[rng.choice(len(px), k, replace=False)]
    for _ in range(10):
        labels = np.argmin(((px[:, None, :] - centres[None]) ** 2).sum(-1), axis=1)
        for j in range(k):
            sel = px[labels == j]
            if len(sel):
                centres[j] = sel.mean(axis=0)
    counts = np.bincount(labels, minlength=k)
    order = np.argsort(-counts)
    out = []
    for j in order:
        if counts[j] / len(px) < 0.02:
            continue
        c = np.clip(centres[j], 0, 1)
        hexc = "#{:02x}{:02x}{:02x}".format(*(int(round(v * 255)) for v in c))
        if hexc not in out:
            out.append(hexc)
    return out


def _pack(img, item_id):
    img.name = ".scrap_" + item_id
    img.use_fake_user = True
    if img.packed_file is None:
        img.pack()
    return img


# ---------------------------------------------------------------------------
# Adding.

def add_image(img, title="", by="you", kind="image", note=""):
    """Keep an image datablock (it is renamed, hidden and packed)."""
    entry = _add({"kind": kind, "title": title or img.name, "by": by, "note": note})
    _pack(img, entry["id"])
    w, h = img.size
    colors = palette(img)
    return update(entry["id"], image=img.name, w=w, h=h, colors=colors)


def add_image_file(path, title="", by="you", kind="image", note=""):
    img = bpy.data.images.load(path, check_existing=False)
    return add_image(img, title or os.path.splitext(os.path.basename(path))[0], by, kind, note)


def add_png(png, title="", by="agent", kind="render", note=""):
    path = os.path.join(_cache_dir(), "incoming_{}.png".format(time.time_ns()))
    with open(path, "wb") as fh:
        fh.write(png)
    try:
        return add_image_file(path, title, by, kind, note)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def add_note(text, title="", by="you"):
    return _add({"kind": "note", "title": title or text.strip().split("\n")[0][:40], "by": by, "note": text})


def looks_like_svg(text):
    head = (text or "").lstrip()[:400].lower()
    return head.startswith("<svg") or (head.startswith("<?xml") and "<svg" in head)


def add_svg(svg, title="", by="you"):
    """Keep an SVG (as text) with a raster preview, so it can be seen and turned into 3D."""
    if not looks_like_svg(svg):
        raise ValueError("That is not SVG text.")
    entry = _add({"kind": "svg", "title": title or "SVG", "by": by})
    txt = bpy.data.texts.new(".scrap_{}.svg".format(entry["id"]))
    txt.use_fake_user = True
    txt.write(svg)
    fields = {"svg": txt.name, "svg_chars": len(svg)}
    try:
        preview, colors, size = _svg_preview(svg)
        img = bpy.data.images.new(".scrap_{}_preview".format(entry["id"]), preview.shape[1], preview.shape[0],
                                  alpha=True)
        img.pixels.foreach_set(preview.ravel())
        img.use_fake_user = True
        img.pack()
        fields.update(preview=img.name, w=preview.shape[1], h=preview.shape[0], colors=colors,
                      svg_size=size)
    except Exception as ex:  # noqa: BLE001 - a preview is a nicety; the SVG itself is kept
        fields["preview_error"] = str(ex)[:200]
    return update(entry["id"], **fields)


# ---------------------------------------------------------------------------
# SVG: import into a scratch scene, fill its shapes, rasterise.

def import_svg(svg, scene, collection=None):
    """Import SVG text into `scene` with Blender's importer; returns the new curve objects."""
    path = os.path.join(_cache_dir(), "import_{}.svg".format(time.time_ns()))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(svg)
    before = set(bpy.data.objects)
    try:
        vl = scene.view_layers[0]
        with bpy.context.temp_override(scene=scene, view_layer=vl, collection=collection or scene.collection):
            bpy.ops.import_curve.svg(filepath=path)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    return [o for o in bpy.data.objects if o not in before]


def _svg_preview(svg):
    scene = bpy.data.scenes.new(".scrap_svg_tmp")
    made = []
    try:
        made = import_svg(svg, scene)
        curves = [o for o in made if o.type == 'CURVE']
        if not curves:
            raise ValueError("no shapes found in the SVG")
        dg = bpy.context.evaluated_depsgraph_get()
        dg.update()
        tris = []
        for ob in curves:
            ev = ob.evaluated_get(dg)
            me = ev.to_mesh()
            try:
                me.calc_loop_triangles()
                mw = ob.matrix_world
                verts = [mw @ v.co for v in me.vertices]
                mats = ev.material_slots
                for lt in me.loop_triangles:
                    mi = me.polygons[lt.polygon_index].material_index
                    col = (0.15, 0.15, 0.15, 1.0)
                    if mi < len(mats) and mats[mi].material is not None:
                        col = tuple(mats[mi].material.diffuse_color)
                    tris.append(([(verts[i].x, verts[i].y) for i in lt.vertices], col))
            finally:
                ev.to_mesh_clear()
        if not tris:
            raise ValueError("the SVG has no filled shapes")
        pts = np.array([p for t, _c in tris for p in t])
        lo, hi = pts.min(axis=0), pts.max(axis=0)
        span = max(hi - lo)
        if span <= 0:
            raise ValueError("the SVG has no size")
        scale = (_PREVIEW - 16) / span
        w = int((hi[0] - lo[0]) * scale) + 16
        h = int((hi[1] - lo[1]) * scale) + 16
        img = np.zeros((h, w, 4), np.float32)
        colors = {}
        for t, col in tris:
            p = (np.array(t) - lo) * scale + 8
            _fill_tri(img, p, tuple(_srgb(v) for v in col[:3]))  # materials are linear; pictures sRGB
            colors[col] = colors.get(col, 0) + 1
        hexes = _svg_fills(svg) or ["#{:02x}{:02x}{:02x}".format(*(int(round(_srgb(v) * 255)) for v in c[:3]))
                                    for c, _n in sorted(colors.items(), key=lambda kv: -kv[1])][:_PALETTE_K]
        return img, hexes, [round(float(x), 5) for x in hi - lo]
    finally:
        for o in made:
            data = o.data
            bpy.data.objects.remove(o)
            if data is not None and getattr(data, "users", 1) == 0:
                if isinstance(data, bpy.types.Curve):
                    bpy.data.curves.remove(data)
        for mat in [m for m in bpy.data.materials if m.users == 0 and m.name.startswith("SVGMat")]:
            bpy.data.materials.remove(mat)
        for coll in [c for c in scene.collection.children if not c.objects and not c.children]:
            bpy.data.collections.remove(coll)
        bpy.data.scenes.remove(scene)


def _srgb(v):
    v = min(1.0, max(0.0, v))
    return v * 12.92 if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055


def _svg_fills(svg):
    """The fill colours written in the SVG, most used first (exact, unlike the importer's materials)."""
    import re
    found = re.findall(r"""fill\s*[:=]\s*["']?\s*(#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b)""", svg)
    counts = {}
    for c in found:
        c = c.lower()
        if len(c) == 4:
            c = "#" + "".join(ch * 2 for ch in c[1:])
        counts[c] = counts.get(c, 0) + 1
    return [c for c, _n in sorted(counts.items(), key=lambda kv: -kv[1])][:_PALETTE_K]


def _fill_tri(img, p, col):
    h, w, _ = img.shape
    x0, y0 = np.floor(p.min(axis=0)).astype(int)
    x1, y1 = np.ceil(p.max(axis=0)).astype(int)
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(w - 1, x1), min(h - 1, y1)
    if x1 < x0 or y1 < y0:
        return
    ys, xs = np.mgrid[y0:y1 + 1, x0:x1 + 1]
    px, py = xs + 0.5, ys + 0.5
    (ax, ay), (bx, by), (cx, cy) = p
    d = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
    if abs(d) < 1e-12:
        return
    l1 = ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / d
    l2 = ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / d
    inside = (l1 >= -1e-6) & (l2 >= -1e-6) & (1 - l1 - l2 >= -1e-6)
    region = img[y0:y1 + 1, x0:x1 + 1]
    region[inside] = (col[0], col[1], col[2], 1.0)


# ---------------------------------------------------------------------------
# Reading back.

def svg_text(item):
    txt = bpy.data.texts.get(item.get("svg") or "")
    return txt.as_string() if txt else ""


def image_of(item):
    """The datablock to show for an item: the image, or an SVG's preview."""
    return bpy.data.images.get(item.get("image") or item.get("preview") or "")


def png(item):
    """PNG bytes for an item (for agents), or None."""
    img = image_of(item)
    if img is None:
        return None
    if img.packed_file is not None and bytes(img.packed_file.data[:4]) == b"\x89PNG":
        return bytes(img.packed_file.data)
    from .tools_inspect import _png
    px = _pixels(img, 1536)
    rgb = (np.clip(px[:, :, :3], 0, 1) * 255 + 0.5).astype(np.uint8)
    return _png(np.ascontiguousarray(np.flipud(rgb)))


_MAGIC = ((b"\x89PNG", ".png"), (b"\xff\xd8\xff", ".jpg"), (b"GIF8", ".gif"), (b"BM", ".bmp"))


def file_of(item):
    """(bytes, extension) to save an item as a file: an image as it came in (full size; a PNG of
    its pixels when it has no file of its own), an SVG as its SVG, a note as text. None if empty."""
    kind = item.get("kind")
    if kind == "note":
        return (item.get("note") or "").encode("utf-8"), ".txt"
    if kind == "svg":
        svg = svg_text(item)
        return (svg.encode("utf-8"), ".svg") if svg else None
    img = image_of(item)
    if img is None:
        return None
    if img.packed_file is not None:
        data = bytes(img.packed_file.data)
        ext = next((e for magic, e in _MAGIC if data.startswith(magic)), None)
        if ext is None and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            ext = ".webp"
        if ext:
            return data, ext
    from .tools_inspect import _png
    px = _pixels(img)
    rgba = (np.clip(px, 0, 1) * 255 + 0.5).astype(np.uint8)
    return _png(np.ascontiguousarray(np.flipud(rgba[:, :, :3]))), ".png"


def file_name(item):
    """A file name for saving an item: its title, made safe."""
    stem = "".join(c if c.isalnum() or c in " -_" else "_" for c in (item.get("title") or "")).strip()
    return (stem or "sandbox_" + item["id"])[:60]


def _cache_dir():
    key = hashlib.sha1((bpy.data.filepath or "unsaved").encode("utf-8")).hexdigest()[:10]
    path = os.path.join(tempfile.gettempdir(), "agent_sandbox", key)
    os.makedirs(path, exist_ok=True)
    return path


def thumb_path(item):
    """A file the chat can draw for an item (written from the packed image once)."""
    img = image_of(item)
    if img is None:
        return None
    # Named by when the item was made too: ids start again in a new file, pictures differ.
    path = os.path.join(_cache_dir(), "{}_{}.png".format(img.name.lstrip("."), int(item.get("t", 0) * 1000)))
    if not os.path.exists(path):
        data = png(item)
        if data is None:
            return None
        with open(path, "wb") as fh:
            fh.write(data)
    return path


def summary(item):
    """One line for prompts and lists."""
    kind = item["kind"]
    bits = ["{} {} '{}'".format(item["id"], kind, item.get("title", ""))]
    if item.get("w"):
        bits.append("{}x{} px".format(item["w"], item["h"]))
    if item.get("colors"):
        bits.append("colours " + " ".join(item["colors"][:5]))
    if kind == "note":
        bits.append('"{}"'.format(item.get("note", "")[:160]))
    if item.get("by") and item["by"] != "you":
        bits.append("added by " + item["by"])
    if item.get("license") or item.get("credit"):
        bits.append("{} by {}".format(item.get("license") or "licence unknown", item.get("credit") or "unknown"))
    if item.get("source"):
        bits.append("from " + item["source"])
    return ", ".join(bits)
