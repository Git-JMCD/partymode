# SPDX-License-Identifier: GPL-3.0-or-later
"""
The Agent editor (agent-blender builds add the editor type in C++): a chat laid out
like a modern agent app, drawn directly on the editor's canvas.

- A centred, readable conversation: your messages in bubbles, the agent's replies as
  formatted text (headings, lists, code, tables), tool steps folded into one line,
  renders as thumbnails (click to enlarge).
- A floating message box: click (or just start typing over the chat) to write; Enter
  sends, Shift+Enter adds a line, Esc or a click elsewhere gives the keyboard back.
- A sessions drawer (header button): past conversations, new chat, delete.
- The header keeps Blender's editor menu, the session title and status, and a meter
  of how full the agent's context is, with "continue in a new chat" (a handoff summary
  carried over). A long chat also shows that offer above the message box.
- The message box shows the model and reasoning level (click to change).

Also the "Agent" workspace (3D viewport beside the chat), opened from the 3D View header.
Shares sessions with `ui_chat` (sidebar) and the browser page.
"""

import math
import os
import re
import subprocess
import sys
import threading
import time
import traceback

import bpy
import bpy.utils.previews
import gpu
import numpy as np

from . import chat, runners, server, ui_chat, ui_mark, ui_sandbox
from . import looks
from . import ui_draw as D
from . import approvals, ui_menu, ui_select

SPACE = 'AGENT'
CHAT_TEXT = "Agent Chat"
# Each agent's accent, so it is always clear who is answering: Claude orange, Codex blue,
# OpenCode (open and local models) green.
AGENT_COLORS = {"claude": (0.851, 0.467, 0.341), "codex": (0.361, 0.612, 0.965), "opencode": (0.333, 0.776, 0.537)}


ICON_PATH = os.path.join(os.path.dirname(__file__), "icons", "agent.png")
LOGO_PATH = os.path.join(os.path.dirname(__file__), "icons", "partymode.png")  # white on clear: drawn tinted
# The welcome logo changes with the agent: Claude has v0.1, Codex v0.2, OpenCode v0.3.
LOGOS = {"claude": LOGO_PATH,
         "codex": os.path.join(os.path.dirname(__file__), "icons", "partymode-0.2.png"),
         "opencode": os.path.join(os.path.dirname(__file__), "icons", "partymode-0.3.png")}


def logo_path(runner=None):
    """The welcome logo for an agent (v0.1 when its own version isn't there)."""
    path = LOGOS.get(runner or chat.S.runner, LOGO_PATH)
    return path if os.path.isfile(path) else LOGO_PATH


_icons = {"previews": None}


def agent_icon(name="agent"):
    """An add-on icon's id for layouts (icons/<name>.png; 0 if it could not be loaded)."""
    pv = _icons["previews"]
    if pv is None:
        try:
            pv = _icons["previews"] = bpy.utils.previews.new()
        except Exception:  # noqa: BLE001
            return 0
    if name not in pv:
        try:
            item = pv.load(name, os.path.join(os.path.dirname(__file__), "icons", name + ".png"), 'IMAGE')
            _fill_icon(item)
        except Exception:  # noqa: BLE001
            return 0
    item = pv.get(name)
    return item.icon_id if item else 0


def _fill_icon(item):
    """The small (icon) size from the full image, at once: Blender makes it later, and a preview
    first loaded while a header draws can stay blank there."""
    w, h = item.image_size
    if not w or not h:
        return
    px = np.array(item.image_pixels_float, dtype=np.float32).reshape(h, w, 4)
    f = max(1, w // 32)
    small = px[:h // f * f, :w // f * f].reshape(h // f, f, w // f, f, 4).mean(axis=(1, 3))
    item.icon_size = (small.shape[1], small.shape[0])
    item.icon_pixels_float = small.ravel()


def agent_color(runner=None, a=1.0):
    """RGBA accent for an agent (default: the one that answers next)."""
    rgb = AGENT_COLORS.get(runner or chat.S.runner) or D.palette()["accent"][:3]
    return tuple(rgb[:3]) + (a,)

# ---------------------------------------------------------------------------
# @mentions: name scene objects in a message ("make @Bucket wetter"); the agent gets a
# short fact sheet on each. Names with spaces are written @"Big Rock".

_MENTION_RE = re.compile(r'(?<!\S)(?:@"([^"\n]+)"|@([A-Za-z0-9_.\-]+))')  # not inside a word or an email
_PLAIN_NAME = re.compile(r"[A-Za-z0-9_.\-]+")


def mention_spans(text):
    """[(start, end, name)] for each @mention in text."""
    return [(m.start(), m.end(), m.group(1) or m.group(2)) for m in _MENTION_RE.finditer(text)]


def format_mention(name):
    return "@" + name if _PLAIN_NAME.fullmatch(name) else '@"' + name + '"'


def mention_query(text, caret):
    """(start of the @, what is typed after it) when the caret ends a partial @mention."""
    j = text.rfind('@"', 0, caret)
    if j >= 0 and '"' not in text[j + 2:caret] and "\n" not in text[j:caret] and (j == 0 or text[j - 1].isspace()):
        return j, text[j + 2:caret]
    i = caret
    while i > 0 and not text[i - 1].isspace() and text[i - 1] != "@":
        i -= 1
    if i > 0 and text[i - 1] == "@" and (i == 1 or text[i - 2].isspace()):
        return i - 1, text[i:caret]
    return None


def mention_candidates(query, limit=8):
    scene = bpy.context.scene
    if scene is None:
        return []
    q = query.lower()
    names = [ob.name for ob in scene.objects]
    first = sorted(n for n in names if n.lower().startswith(q))
    rest = sorted(n for n in names if q in n.lower() and not n.lower().startswith(q))
    return (first + rest)[:limit]


def _fmt(v):
    return "({})".format(", ".join("{:.3g}".format(x) for x in v))


def mention_context(text):
    """A fact sheet on the objects a message mentions (added to the prompt, not shown)."""
    names = list(dict.fromkeys(name for _a, _b, name in mention_spans(text)))
    if not names:
        return ""
    lines = []
    for name in names[:12]:
        ob = bpy.data.objects.get(name)
        if ob is None:
            lines.append("- {}: no object by that name in this file".format(name))
            continue
        bits = [ob.type, "at " + _fmt(ob.matrix_world.translation), "size " + _fmt(ob.dimensions) + " m"]
        mats = [s.material.name for s in getattr(ob, "material_slots", ()) if s.material]
        if mats:
            bits.append("materials " + ", ".join(mats[:4]))
        if ob.parent:
            bits.append("parent " + ob.parent.name)
        if ob.modifiers:
            bits.append("modifiers " + ", ".join(md.type.lower() for md in ob.modifiers[:4]))
        if ob.type == 'MESH':
            bits.append("{} verts".format(len(ob.data.vertices)))
        if not ob.visible_get():
            bits.append("hidden")
        lines.append("- {}: {}".format(ob.name, "; ".join(bits)))
    return "Objects the user mentioned (@name):\n" + "\n".join(lines)


def _text_pieces(text, la, lb):
    """[(start, end, is_mention)] covering text[la:lb]."""
    out, pos = [], la
    for a, b, _name in mention_spans(text):
        if b <= la or a >= lb:
            continue
        a, b = max(a, la), min(b, lb)
        if a > pos:
            out.append((pos, a, False))
        out.append((a, b, True))
        pos = b
    if pos < lb:
        out.append((pos, lb, False))
    return out
   # stock Blender: a Text Editor showing this text hosts the chat


def has_agent_space():
    """This build has the Agent editor type (agent-blender); stock Blender does not."""
    try:
        bpy.types.Panel.bl_rna.properties["bl_space_type"].enum_items[SPACE]
        return hasattr(bpy.types, "SpaceAgent")
    except KeyError:
        return False


def is_host(area):
    """An area showing the chat: the Agent editor, or a Text Editor on the chat text."""
    if area is None:
        return False
    if area.type == SPACE:
        return True
    if area.type == 'TEXT_EDITOR':
        text = area.spaces.active.text
        return text is not None and bool(text.get("agent_chat"))
    return False


def bar_on(area):
    """A 3D viewport with the floating agent bar switched on."""
    return area is not None and area.type == 'VIEW_3D' and area.as_pointer() in _ui["bars"]


def is_canvas(area):
    """An area the chat canvas draws in: a chat area, the Sandbox board's own area, or a
    viewport with the bar."""
    return is_host(area) or ui_sandbox.is_pane(area) or bar_on(area)


def chat_text():
    """The text a stock Text Editor shows to host the chat (made once, marked)."""
    text = next((t for t in bpy.data.texts if t.get("agent_chat")), None)
    if text is None:
        text = bpy.data.texts.new(CHAT_TEXT)
        text["agent_chat"] = True
        text.write("This text shows the Agent chat. Pick another text to edit code here.\n")
    return text


def make_host(area):
    """Turn an area into the chat: the Agent editor here, a Text Editor on the chat text in stock."""
    if has_agent_space():
        area.ui_type = SPACE
        return
    area.type = 'TEXT_EDITOR'
    sp = area.spaces.active
    sp.text = chat_text()
    for flag in ("show_region_footer", "show_region_ui", "show_line_numbers", "show_syntax_highlight"):
        if hasattr(sp, flag):
            setattr(sp, flag, False)
_SUGGESTIONS = (
    ("Build a simple prop", "Build a simple wooden side table at real size, check that it stands on the floor, and show me."),
    ("Check my scene", "Check my scene for problems: floating or sunk objects, broken meshes, wrong sizes. Summarise what you find."),
    ("Sky and lighting", "Add a natural sky (HDRI) and a ground plane so my scene renders nicely, then show me a lit render."),
    ("Export for Unreal", "Export the selected objects for Unreal Engine and verify the export."),
)



def selection_suggestions(context=None, limit=3):
    """(label, message) for what is selected: a few next steps that fit it."""
    context = context or bpy.context
    # From the view layer: in a drawing callback, context.selected_objects can be empty.
    vl = getattr(context, "view_layer", None)
    sel = [o for o in vl.objects if o.select_get()][:6] if vl is not None else []
    if not sel:
        return []
    names = " ".join(format_mention(o.name) for o in sel)
    meshes = [o for o in sel if o.type == 'MESH']
    out = []
    if any(len(o.data.polygons) > 20000 for o in meshes):
        out.append(("Remesh it", "Remesh {} with remesh_asset and show me the result.".format(names)))
    if meshes:
        out.append(("Check it sits right", "Check that {} sits on what is under it (nothing sunk in or floating) "
                                           "and that the mesh is clean.".format(names)))
    if meshes and not any(o.material_slots and any(s.material for s in o.material_slots) for o in meshes):
        out.append(("Give it a material", "Give {} a fitting material and show me a lit render.".format(names)))
    try:
        from . import sandbox
        coloured = [i for i in sandbox.items() if i.get("colors")]
    except Exception:  # noqa: BLE001 - suggestions must never break drawing
        coloured = []
    if coloured and meshes:
        it = coloured[-1]
        out.append(("Sandbox colours", "Tint {} with the colours from Sandbox item {} ({}).".format(
            names, it["id"], it.get("title", ""))))
    out.append(("Export it", "Export {} for Unreal Engine and verify the file.".format(names)))
    return out[:limit]


# ---------------------------------------------------------------------------
# State shared by drawing and the operators.

_ui = {
    "drafts": {},          # session id (or "NEW") -> unsent text
    "edit": None,          # the message box while it has the keyboard
    "hover": None,         # (area pointer, hit id)
    "expanded": set(),     # step groups opened by the user
    "lightbox": None,      # image path shown full size
    "toast": None,         # (text, until, is_error)
    "confirm_delete": None,
    "bars": set(),         # 3D viewports (area pointers) showing the floating bar
    "bar_open": set(),     # ...whose bar shows the whole conversation
    "compare": set(),      # trial cards showing their before
    "diff": set(),         # trial cards showing their diff
}
_areas = {}                # area pointer -> per-area state
_layout_cache = {}
_conv_cache = {"key": None, "items": []}


def _area_state(area):
    key = area.as_pointer()
    st = _areas.get(key)
    if st is None:
        st = _areas[key] = {"scroll": 0.0, "target": 0.0, "last_h": None, "drawer_scroll": 0.0,
                            "hits": [], "composer": None, "drawer_w": 0.0, "drawer_overlay": False,
                            "region": None}
    return st


def _session_key(wm):
    return ui_chat._current_id(wm) or "NEW"


def _toast(text, error=True, seconds=4.0):
    _ui["toast"] = (text, time.time() + seconds, error)
    _redraw_all()


def _redraw_all():
    for area in _agent_areas():
        area.tag_redraw()


def _agent_areas():
    wm = bpy.context.window_manager
    for win in (wm.windows if wm else ()):
        for area in win.screen.areas:
            if is_canvas(area):
                yield area


def _find_area(pointer):
    for area in _agent_areas():
        if area.as_pointer() == pointer:
            return area
    return None


def _main_region(area):
    return next((r for r in area.regions if r.type == 'WINDOW'), None)


# ---------------------------------------------------------------------------
# The conversation as display items.

def _conversation(local_id, live=None):
    """Display items, turn by turn: your message; the agent's turn header (model, steps, time);
    its text, steps and render cards in order; your own chat actions; errors."""
    from . import team
    rows = team.rows() if (team.run() or {}).get("local_id") == local_id else []
    key = (local_id, chat.S.revision, bool(live), (live or {}).get("model"),
           tuple((r["key"], r["status"], r["activity"], r["secs"] // 5) for r in rows))
    if _conv_cache["key"] == key:
        return _conv_cache["items"]
    entries = ui_chat._messages(local_id) if local_id else []
    # Turns start at each of your messages; the meta entry closes one.
    bounds = [i for i, e in enumerate(entries) if e.get("role") == "user"]
    segments = []
    starts = ([0] if not bounds or bounds[0] != 0 else []) + bounds
    for n, a in enumerate(starts):
        b = starts[n + 1] if n + 1 < len(starts) else len(entries)
        segments.append(range(a, b))
    applied = set()
    last_trial = None
    for i, e in enumerate(entries):
        card = e.get("card") or {}
        if card.get("kind") == "trial":
            last_trial = card.get("trial_id")
        elif (card.get("kind") == "applied" or e.get("applied_trial")) and last_trial:
            applied.add(e.get("applied_trial") or last_trial)
    items = []
    for n, seg in enumerate(segments):
        meta = next((entries[i] for i in seg if entries[i].get("role") == "meta"
                     and entries[i].get("duration_s") is not None), None)
        steps_n = sum(1 for i in seg if entries[i].get("role") == "tool" and not entries[i].get("member")
                      and entries[i].get("tool") not in chat._HIDDEN_TOOLS)
        is_last = n == len(segments) - 1
        head_done = False
        group = None
        turn_texts = []
        member = None
        for i in seg:
            e = entries[i]
            role = e.get("role")
            if role == "member_meta":
                continue
            agentish = role in ("assistant", "tool", "tool_result", "system")
            who = e.get("member") if agentish else None
            if who != member and agentish:
                group = None
                if who:  # a helper's block starts
                    done_at = next((entries[j] for j in range(i, len(entries)) if entries[j].get("role") ==
                                    "member_meta" and entries[j].get("member") == who), {})
                    steps_m = 0
                    for j in range(i, len(entries)):
                        if entries[j].get("member") != who or entries[j].get("role") == "member_meta":
                            break
                        steps_m += entries[j].get("role") == "tool"
                    items.append({"kind": "head", "runner": who, "model": done_at.get("model", ""), "effort": "",
                                  "steps": steps_m, "duration": done_at.get("duration_s"), "t": e.get("t"),
                                  "task": done_at.get("title", ""), "live": False})
                elif head_done:  # back to the lead after a helper's block
                    items.append({"kind": "head", "runner": (meta or live or {}).get("runner", "claude"),
                                  "model": "", "effort": "", "steps": 0, "duration": None, "t": e.get("t"),
                                  "live": bool(live) and is_last and meta is None})
                member = who
            if agentish and not head_done and not who:
                head_done = True
                items.append({"kind": "head", "runner": (meta or live or {}).get("runner", "claude"),
                              "model": (meta or {}).get("model") or (live or {}).get("model", ""),
                              "effort": (meta or {}).get("effort", ""), "steps": steps_n,
                              "duration": (meta or {}).get("duration_s"), "t": e.get("t"),
                              "live": bool(live) and is_last and meta is None})
            if role in ("tool", "tool_result"):
                if group is None:
                    group = {"kind": "steps", "key": (local_id, i), "steps": []}
                    items.append(group)
                if role == "tool":
                    group["steps"].append({"tool": e.get("tool", ""), "detail": e.get("detail", ""), "ok": None,
                                           "t": e.get("t")})
                    continue
                for step in group["steps"]:
                    if step["tool"] == e.get("tool") and step["ok"] is None:
                        step["ok"] = bool(e.get("ok"))
                        if step.get("t") and e.get("t"):
                            step["dur"] = max(0.0, e["t"] - step["t"])
                        break
                if e.get("images"):
                    items.append(_card_item(local_id, i, e, applied))
                    group = None
                continue
            group = None
            if role == "user" and e.get("team"):
                items.append({"kind": "action", "text": e.get("text", "")})
            elif role == "user":
                items.append({"kind": "user", "text": e.get("text", "")})
            elif role == "assistant":
                items.append({"kind": "md", "text": e.get("text", "")})
                turn_texts.append(e.get("text", ""))
            elif role == "system":
                items.append({"kind": "error", "text": e.get("text", "")})
            elif role == "note":
                items.append({"kind": "note", "from": e.get("from", ""), "family": e.get("family", ""),
                              "text": e.get("text", "")})
            elif role in ("action", "mark"):
                items.append({"kind": "action", "text": e.get("text", "")})
                if e.get("images"):
                    items.append(_card_item(local_id, i, e, applied))
            elif role == "carry":
                items.append({"kind": "carry", "key": (local_id, i), "text": e.get("text", ""),
                              "from_title": e.get("from_title", ""), "from": e.get("from", ""),
                              "how": e.get("how", "agent")})
            elif role == "meta" and e.get("duration_s") is not None and turn_texts:
                items.append({"kind": "meta", "key": (local_id, i), "copy": "\n\n".join(turn_texts)})
        if not head_done and live and is_last:
            items.append({"kind": "head", "runner": live.get("runner", "claude"), "model": live.get("model", ""),
                          "effort": "", "steps": 0, "duration": None, "live": True})
    for r in rows:  # helpers at work, or just finished, under the conversation
        if r["status"] == "working":
            items.append({"kind": "member", "family": r["key"], "from": r["label"], "title": r["title"],
                          "text": "{}  ·  {}s".format(r["activity"] or "working", r["secs"])})
    # Undo and Keep only make sense on the newest card of the newest turn.
    last_user = max((n for n, it in enumerate(items) if it["kind"] == "user"), default=-1)
    cards = [it for n, it in enumerate(items) if it["kind"] == "card" and n > last_user]
    if cards:
        cards[-1]["latest"] = True
    _conv_cache.update(key=key, items=items)
    return items


def _card_item(local_id, i, e, applied):
    card = dict(e.get("card") or {})
    if not card and e.get("tool") == "render_view":  # chats from before cards: read the stored reply
        view = re.search(r'"view":\s*"(\w+)"', e.get("text", ""))
        look = re.search(r'"look":\s*"(\w+)"', e.get("text", ""))
        card = {"kind": "render", "view": view.group(1) if view else None, "look": look.group(1) if look else None}
    paths = [chat.image_path(local_id, n) for n in e.get("images", [])]
    item = {"kind": "card", "key": (local_id, i), "images": [p for p in paths if p], "card": card,
            "tool": e.get("tool", ""), "latest": False, "user": e.get("role") in ("action", "mark")}
    if card.get("kind") == "trial":
        item["applied"] = card.get("trial_id") in applied
    return item


def _gap(prev, cur, s):
    if prev is None:
        return 0
    if cur == "user":
        return 34 * s if prev in ("meta", "action", "card") else 26 * s
    if cur == "head":
        return 16 * s
    if prev == "head":
        return 8 * s
    if cur == "meta":
        return 6 * s
    if cur in ("action", "note") or prev in ("action", "note"):
        return 14 * s
    if cur == "card" or prev == "card":
        return 12 * s
    if cur == "steps" or prev == "steps":
        return 10 * s
    return 14 * s


# ---------------------------------------------------------------------------
# Item layout (doc space, cached). Returns (ops, height, hits).

def _layout(item, W, m):
    expanded = item.get("key") in _ui["expanded"]
    state = (item.get("key") in _ui["compare"], item.get("key") in _ui["diff"])
    key = (item["kind"], repr(item), round(W), m.s, expanded, state, looks.name())
    hit = _layout_cache.get(key)
    if hit:
        return hit
    fn = {"user": _lay_user, "md": _lay_md, "steps": _lay_steps, "error": _lay_error, "meta": _lay_meta,
          "carry": _lay_carry, "head": _lay_head, "card": _lay_card, "action": _lay_action,
          "note": _lay_note, "member": _lay_member}[item["kind"]]
    result = fn(item, W, m, expanded)
    if len(_layout_cache) > 600:
        _layout_cache.clear()
    _layout_cache[key] = result
    return result


def _plain_lines(text, maxw, size, m, color="text"):
    lines = []
    for para in text.split("\n"):
        lines += D.flow([(para, "n")], maxw, size, m, color=color) if para.strip() else [[]]
    return lines


def _lines_width(lines):
    w = 0.0
    for line in lines:
        if line:
            x, text, _st, fs, fw, font = line[-1][:6]
            w = max(w, x + D.measure(text, fs, fw, font))
    return w


def _lay_user(item, W, m, _expanded):
    s = m.s
    pad_x, pad_y = 14 * s, 9 * s
    maxw = W * 0.8
    lines = []
    for para in item["text"].split("\n"):
        spans = [(para[a:b], "a" if is_m else "n") for a, b, is_m in _text_pieces(para, 0, len(para))]
        lines += D.flow(spans, maxw - 2 * pad_x, m.body, m) if para.strip() else [[]]
    lh = m.line_h(m.body)
    look = looks.get()
    tag = looks.tag("You") if look["brackets"] else ""
    tag_h = 18 * s if tag else 0.0
    bw = min(maxw, max(_lines_width(lines), D.measure(tag, m.tiny, 500, "mono") if tag else 0) + 2 * pad_x)
    h = len(lines) * lh + 2 * pad_y + tag_h
    x0 = W - bw
    r = min(looks.radius("bubble", s, h), h / 2)
    if look["brackets"]:  # Signal: a hairline box with its label
        ops = [("r", x0, 0, W, h, "border", r), ("r", x0 + 1 * s, 1 * s, W - 1 * s, h - 1 * s, "surface", r)]
        ops.append(("t", x0 + pad_x, D.baseline(pad_y - 2 * s, tag_h, m.tiny), tag, m.tiny, 500, "faint", "mono"))
    else:
        ops = [("r", x0, 0, W, h, "surface2", r)]
    D.emit_lines(ops, lines, x0 + pad_x, pad_y + tag_h, m.body, m)
    return ops, h, []


def _lay_md(item, W, m, _expanded):
    ops, h = D.layout_markdown(item["text"], W, m)
    return ops, h, []


def _lay_error(item, W, m, _expanded):
    s = m.s
    pad = 10 * s
    lines = _plain_lines(item["text"], W - 2 * pad - 10 * s, m.small + 1 * s, m)
    lh = m.line_h(m.small + 1 * s)
    h = len(lines) * lh + 2 * pad
    ops = [("r", 0, 0, W, h, D.alpha(D.palette()["error"], 0.12), 10 * s),
           ("r", 0, 0, 3 * s, h, "error", 1.5 * s)]
    D.emit_lines(ops, lines, pad + 8 * s, pad, m.small + 1 * s, m)
    return ops, h, []


def _lay_meta(item, W, m, _expanded):
    s = m.s
    lh = 18 * s
    base = D.baseline(0, lh, m.tiny)
    lab, font = looks.label("Copy"), _chip_font()
    w = D.measure(lab, m.tiny, 500, font)
    ops = [("t", 0, base, lab, m.tiny, 500, "faint", font)]
    return ops, lh, [(("copy", item["key"]), -6 * s, 0, w + 6 * s, lh, 6 * s)]


def _turn_label(item):
    parts = []
    if item.get("runner", "claude") != "claude":
        parts.append(runners.get(item["runner"]).label)
    if item.get("model"):
        parts.append(chat.model_label(item["model"]))
    if not parts:
        parts.append("Agent")
    return "  ·  ".join(parts)


_SHORT = {"claude": "Claude", "codex": "Codex", "opencode": "OpenCode"}


def _clock(t, seconds=False):
    return time.strftime("%H:%M:%S" if seconds else "%H:%M", time.localtime(t)) if t else ""


def _lay_head(item, W, m, _expanded):
    """The start of an agent turn: an accent dot, who answered, and how the turn went."""
    look = looks.get()
    if look["head"] != "classic":
        return _lay_head_look(item, W, m, look)
    s = m.s
    lh = 20 * s
    size = m.small
    base = D.baseline(0, lh, size)
    ops = [("r", 2 * s, lh / 2 - 3 * s, 8 * s, lh / 2 + 3 * s, agent_color(item.get("runner", "claude")), 3 * s)]
    label = _turn_label(item)
    ops.append(("t", 16 * s, base, label, size, 600, "text", "ui"))
    x = 16 * s + D.measure(label, size, 600)
    info = [item["task"]] if item.get("task") else []
    if item.get("live"):
        info.append("working")
    else:
        if item.get("duration") is not None:
            info.append("{:g}s".format(item["duration"]))
        if item.get("effort"):
            info.append(_effort_label(item["effort"]))
    if info:
        ops.append(("t", x, base, D.ellipsize("  ·  " + "  ·  ".join(info), size, W - x), size, 400, "faint", "ui"))
    return ops, lh, []


def _lay_head_look(item, W, m, look):
    """Halo: a glowing orb, the agent's name and the time. Signal: a square LED and [ CODEX ]."""
    s = m.s
    lh = 22 * s
    runner = item.get("runner", "claude")
    color = agent_color(runner)
    size = m.small + 0.5 * s
    base = D.baseline(0, lh, size)
    cy = lh / 2
    ops = []
    if look["head"] == "orb":
        ops.append(("r", 0, cy - 8 * s, 14 * s, cy + 6 * s, D.alpha(color, 0.5), 7 * s, 6 * s))
        ops.append(("r", 3 * s, cy - 4 * s, 11 * s, cy + 4 * s, color, 4 * s))
        name, font, col = _SHORT.get(runner, "Agent"), "ui", "text"
    else:
        ops.append(("r", 2 * s, cy - 3.5 * s, 9 * s, cy + 3.5 * s, color, 1 * s))
        name, font, col = looks.tag(_SHORT.get(runner, "Agent")), "mono", color
    x = 18 * s
    ops.append(("t", x, base, name, size, 600, col, font))
    x += D.measure(name, size, 600, font) + 9 * s
    info = [_clock(item.get("t"))] if item.get("t") else []
    if item.get("task"):
        info.insert(0, item["task"])
    if item.get("live"):
        info.append("working")
    else:
        if item.get("model"):
            info.append(chat.model_label(item["model"]))
        if item.get("duration") is not None:
            info.append("{:g}s".format(item["duration"]))
    if info:
        text = "  ·  ".join(i for i in info if i)
        tsize = m.tiny + 0.5 * s
        ops.append(("t", x, D.baseline(0, lh, tsize), D.ellipsize(looks.label(text), tsize, W - x, 400, "mono"),
                    tsize, 400, "faint", "mono"))
    return ops, lh, []


def _lay_action(item, W, m, _expanded):
    """Something you did from the chat (kept a trial, undid an edit): a quiet line."""
    s = m.s
    lh = 20 * s
    size = m.small
    text = D.ellipsize(item["text"], size, W - 40 * s)
    w = D.measure(text, size) + 22 * s
    x = (W - w) / 2
    cy = lh / 2
    ops = [("l", [(x + 2 * s, cy), (x + 5 * s, cy + 3 * s), (x + 11 * s, cy - 3 * s)], "faint", 1.4 * s),
           ("t", x + 18 * s, D.baseline(0, lh, size), text, size, 400, "muted", "ui")]
    return ops, lh, []


def _lay_note(item, W, m, _expanded):
    """A note another agent left: who, in its colour, and what it says."""
    s = m.s
    pad = 12 * s
    size = m.small
    lines = _plain_lines(item["text"], W - 2 * pad - 6 * s, m.body - 0.5 * s, m)
    lh = m.line_h(m.body - 0.5 * s)
    head_h = 22 * s
    h = pad + head_h + len(lines) * lh + pad - 4 * s
    color = agent_color(item.get("family") or None) if item.get("family") else D.palette()["accent"]
    ops = [("r", 0, 0, W, h, "border", 12 * s), ("r", 1 * s, 1 * s, W - 1 * s, h - 1 * s, "surface", 11 * s),
           ("r", pad, pad + head_h / 2 - 3 * s, pad + 6 * s, pad + head_h / 2 + 3 * s, color, 3 * s)]
    who = "Note from " + (item.get("from") or "another agent")
    ops.append(("t", pad + 14 * s, D.baseline(pad, head_h, size), who, size, 600, "muted", "ui"))
    D.emit_lines(ops, lines, pad, pad + head_h, m.body - 0.5 * s, m)
    return ops, h, []


def _lay_member(item, W, m, _expanded):
    """A helper at work on its task: who (in its colour), the task, and what it is doing now."""
    s = m.s
    pad = 10 * s
    size = m.small
    head_h = 20 * s
    h = pad + head_h + m.line_h(m.tiny) + pad - 2 * s
    color = agent_color(item.get("family"))
    ops = [("r", 0, 0, W, h, D.alpha(color, 0.55), 10 * s), ("r", 1 * s, 1 * s, W - 1 * s, h - 1 * s, "surface", 9 * s),
           ("r", pad, pad + head_h / 2 - 3 * s, pad + 6 * s, pad + head_h / 2 + 3 * s, color, 3 * s)]
    who = item.get("from", "")
    ops.append(("t", pad + 14 * s, D.baseline(pad, head_h, size), who, size, 600, "text", "ui"))
    x = pad + 14 * s + D.measure(who, size, 600) + 8 * s
    ops.append(("t", x, D.baseline(pad, head_h, size), D.ellipsize(item.get("title", ""), size, W - x - pad),
                size, 400, "muted", "ui"))
    tiny = m.tiny
    ops.append(("t", pad + 14 * s, D.baseline(pad + head_h, m.line_h(tiny), tiny),
                D.ellipsize(item.get("text", ""), tiny, W - 2 * pad - 14 * s, 400, "mono"), tiny, 400, "faint", "mono"))
    return ops, h, []


def _chip_font():
    return "mono" if looks.get()["upper"] else "ui"


def _chip_w(label, size, s):
    return D.measure(looks.label(label), size, 500, _chip_font()) + 22 * s


def _chip_ops(ops, hits, x, y, label, hid, primary=False, muted=False, s=1.0, size=11.0):
    """A button at (x, y) top-left, doc space (a pill, or square in Signal). Returns its width."""
    label = looks.label(label)
    font = _chip_font()
    w = D.measure(label, size, 500, font) + 22 * s
    h = 24 * s
    r = looks.radius("button", s, h)
    classic = looks.name() == "CLASSIC"
    lead = ("accent" if classic else "agent")
    line = D.alpha(D.palette()[lead], 0.75) if primary else "border2"
    ops.append(("r", x, y, x + w, y + h, line, r))
    ops.append(("r", x + 1 * s, y + 1 * s, x + w - 1 * s, y + h - 1 * s, "surface", max(0.0, r - 1 * s)))
    color = lead if primary else ("faint" if muted else ("muted" if classic else "text"))
    ops.append(("t", x + 11 * s, D.baseline(y, h, size), label, size, 500, color, font))
    if hid is not None:
        hits.append((hid, x, y, x + w, y + h, r))
    return w


def _card_chips(item):
    """(action, label, primary) for a render card."""
    card = item.get("card") or {}
    chips = []
    if card.get("kind") in ("mark", "scrap"):
        return [("open", "Open", False)]
    if card.get("kind") == "trial":
        if item.get("applied"):
            chips.append(("", "Kept", False))
        elif item.get("latest"):
            chips.append(("keep", "Keep", True))
        if any(lbl.startswith("before") for lbl in card.get("labels", [])):
            chips.append(("compare", "After" if item["key"] in _ui["compare"] else "Before", False))
        if any(lbl.startswith("diff") for lbl in card.get("labels", [])):
            chips.append(("diff", "Hide diff" if item["key"] in _ui["diff"] else "Diff", False))
    else:
        look = card.get("look")
        chips.append(("lit", "Lit render", False) if look != "lit" else ("solid", "Solid view", False))
        if item.get("latest") and not item.get("user"):
            chips.append(("undo", "Undo last edit", False))
    chips.append(("open", "Open", False))
    return chips


def _card_images(item):
    """The images to show now: a trial shows its after (before or diff when toggled)."""
    card = item.get("card") or {}
    images = item["images"]
    labels = card.get("labels") or []
    if card.get("kind") == "trial" and len(labels) == len(images):
        want = "diff" if item["key"] in _ui["diff"] else ("before" if item["key"] in _ui["compare"] else "after")
        picked = [p for p, lbl in zip(images, labels) if lbl.startswith(want)]
        return picked or images
    return images


def _card_caption(item, shown):
    card = item.get("card") or {}
    if card.get("kind") == "mark":
        return "mark {}  ·  {}  ·  you marked it".format(card.get("n", ""), card.get("editor", ""))
    if card.get("kind") == "scrap":
        return "from the Sandbox  ·  " + ", ".join(card.get("titles", [])[:3])
    if card.get("kind") == "trial":
        state = "diff" if item["key"] in _ui["diff"] else ("before" if item["key"] in _ui["compare"] else "after")
        parts = ["Trial", state]
        measured = card.get("measured") or {}
        m0 = next(iter(measured.values()), None)
        if m0:
            if m0.get("verdict") == "no visible change":
                parts.append("no visible change")
            else:
                if m0.get("changed_share") is not None:
                    parts.append("changed {:.0%} of the frame".format(m0["changed_share"]).replace(" 0% ", " <1% "))
                b = m0.get("brightness")
                if b is not None and abs(b) > 0.01:
                    parts.append("darker" if b < 0 else "lighter")
        return "  ·  ".join(parts)
    bits = [b for b in (card.get("view"), card.get("look")) if b]
    if item.get("user"):
        bits.append("from the chat")
    if len(shown) > 1:
        bits.append("{} views".format(len(shown)))
    return "  ·  ".join(bits) or item.get("tool", "")


def _lay_card(item, W, m, _expanded):
    """A render on stage: the image large and framed, a caption, and actions under it."""
    s = m.s
    pad = 8 * s
    inner = W - 2 * pad
    ops, hits = [], []
    shown = _card_images(item)
    y = pad
    if shown:
        cols = 1 if len(shown) == 1 else 2
        gap = 6 * s
        cw = (inner - gap * (cols - 1)) / cols
        iw, ih = D.image_size(shown[0])
        aspect = iw / max(ih, 1)
        # Big but not overwhelming: capped in height, proportions kept, centred.
        ch = min(cw / aspect, (380 if cols == 1 else 200) * s)
        iw_draw = min(cw, ch * aspect)
        x_in = (cw - iw_draw) / 2
        for n, path in enumerate(shown[:6]):
            cx = pad + (n % cols) * (cw + gap) + x_in
            cy = y + (n // cols) * (ch + gap)
            ir = min(10 * s, looks.radius("card", s, ch))
            ops.append(("i", path, cx, cy, cx + iw_draw, cy + ch, ir))
            hits.append((("img", path), cx, cy, cx + iw_draw, cy + ch, ir))
        rows = (min(len(shown), 6) + cols - 1) // cols
        y += rows * ch + (rows - 1) * gap
    y += 9 * s
    size = m.small
    caption = _card_caption(item, shown)
    cfont = "ui"
    if looks.get()["brackets"]:
        caption, cfont = "[ {} ]".format(looks.label(caption)), "mono"
    caption = D.ellipsize(caption, size, inner - 4 * s, 400, cfont)
    ops.append(("t", pad + 2 * s, D.baseline(y, 16 * s, size), caption, size, 400, "faint", cfont))
    y += 16 * s + 8 * s
    x = pad
    for action, label, primary in _card_chips(item):
        w = _chip_w(label, size - 0.5 * s, s)
        if x > pad and x + w > W - pad:
            x = pad
            y += 24 * s + 6 * s
        hid = ("chip", item["key"], action) if action else None
        _chip_ops(ops, hits, x, y, label, hid, primary=primary, muted=not action, s=s, size=size - 0.5 * s)
        x += w + 6 * s
    y += 24 * s + pad
    r = looks.radius("card", s, y)
    frame = [("r", 0, 0, W, y, "border", r), ("r", 1 * s, 1 * s, W - 1 * s, y - 1 * s, "surface", max(0.0, r - 1 * s))]
    return frame + ops, y, hits


def _shift(ops, dx, dy):
    out = []
    for op in ops:
        kind = op[0]
        if kind == "t":
            out.append((kind, op[1] + dx, op[2] + dy) + tuple(op[3:]))
        elif kind == "r":
            out.append((kind, op[1] + dx, op[2] + dy, op[3] + dx, op[4] + dy) + tuple(op[5:]))
        elif kind == "l":
            out.append((kind, [(x + dx, y + dy) for x, y in op[1]]) + tuple(op[2:]))
        elif kind == "i":
            out.append((kind, op[1], op[2] + dx, op[3] + dy, op[4] + dx, op[5] + dy) + tuple(op[6:]))
    return out


def _lay_carry(item, W, m, expanded):
    """'Continued from …' card; the handoff summary shows when opened."""
    s = m.s
    pad = 14 * s
    row_h = 34 * s
    size = m.small
    base = D.baseline(0, row_h, size)
    lead = "Continued from "
    title = item["from_title"] or "an earlier chat"
    toggle = "Hide summary" if expanded else "Show summary"
    tw = D.measure(toggle, size, 500)
    lead_w = D.measure(lead, size)
    title = D.ellipsize(title, size, max(40 * s, W - 2 * pad - lead_w - tw - 40 * s), 600)
    ops = [("t", pad + 14 * s, base, lead, size, 400, "muted", "ui"),
           ("t", pad + 14 * s + lead_w, base, title, size, 600, "text", "ui")]
    cx, cy = pad + 4 * s, row_h / 2  # a small "carried over" arrow
    ops.append(("l", [(cx - 4 * s, cy), (cx + 4 * s, cy)], "accent", 1.5 * s))
    ops.append(("l", [(cx + 1 * s, cy - 3 * s), (cx + 4 * s, cy), (cx + 1 * s, cy + 3 * s)], "accent", 1.5 * s))
    ops.append(("t", W - pad - tw, base, toggle, size, 500, "accent", "ui"))
    hits = [(("steps", item["key"]), W - pad - tw - 8 * s, 4 * s, W - pad + 8 * s, row_h - 4 * s, 8 * s)]
    h = row_h
    if expanded:
        note = ("Written by the agent from its full memory of that chat." if item["how"] == "agent"
                else "Built from that chat's messages (the agent could not write one).")
        body, bh = D.layout_markdown(item["text"] or "(empty)", W - 2 * pad, m)
        ops += _shift(body, pad, h)
        h += bh + 8 * s
        ops.append(("t", pad, D.baseline(h, 18 * s, m.tiny), note, m.tiny, 400, "faint", "ui"))
        h += 18 * s + 8 * s
    card = [("r", 0, 0, W, h, "surface", 12 * s), ("r", 0, 0, 3 * s, h, "accent", 1.5 * s)]
    return card + ops, h, hits


def _lay_steps(item, W, m, expanded):
    s = m.s
    steps = item["steps"]
    ops, hits = [], []
    if not steps:
        return ops, 0, hits
    style = looks.get()["steps"]
    if style == "pill":
        return _lay_steps_pill(item, W, m, expanded)
    if style == "log":
        return _lay_steps_log(item, W, m, expanded)
    names = []
    for st in steps:
        if st["tool"] not in names:
            names.append(st["tool"])
    failed = sum(1 for st in steps if st["ok"] is False)
    head = "{} step{}".format(len(steps), "" if len(steps) == 1 else "s")
    row_h = 24 * s
    size = m.small
    tx = 18 * s
    base = D.baseline(0, row_h, size)
    head_w = D.measure(head, size, 600)
    fail_label = "  ·  {} failed".format(failed) if failed else ""
    fail_w = D.measure(fail_label, size, 500) if failed else 0
    detail = D.ellipsize("  ·  " + ", ".join(names), size, max(0.0, W - tx - head_w - fail_w - 10 * s))
    ops.append(("t", tx, base, head, size, 600, "muted", "ui"))
    ops.append(("t", tx + head_w, base, detail, size, 400, "faint", "ui"))
    end_x = tx + head_w + D.measure(detail, size)
    if failed:
        ops.append(("t", end_x, base, fail_label, size, 500, "error", "ui"))
        end_x += fail_w
    cx, cy = 7 * s, row_h / 2
    if expanded:
        ops.append(("l", [(cx - 3.5 * s, cy - 1.5 * s), (cx, cy + 2 * s), (cx + 3.5 * s, cy - 1.5 * s)], "faint", 1.5 * s))
    else:
        ops.append(("l", [(cx - 1.5 * s, cy - 3.5 * s), (cx + 2 * s, cy), (cx - 1.5 * s, cy + 3.5 * s)], "faint", 1.5 * s))
    hits.append((("steps", item["key"]), -4 * s, 0, min(W, end_x + 10 * s), row_h, 8 * s))
    y = row_h
    if expanded:
        lh = 21 * s
        top = y + 2 * s
        ops.append(("r", cx - 0.5 * s, top, cx + 0.5 * s, top + lh * len(steps) - lh / 2, "border2", 0))
        for n, st in enumerate(steps):
            yy = top + n * lh
            b = D.baseline(yy, lh, size)
            color = "error" if st["ok"] is False else ("accent" if st["ok"] else "faint")
            ops.append(("r", cx - 3 * s, yy + lh / 2 - 3 * s, cx + 3 * s, yy + lh / 2 + 3 * s, "bg", 3 * s))
            ops.append(("r", cx - 2.2 * s, yy + lh / 2 - 2.2 * s, cx + 2.2 * s, yy + lh / 2 + 2.2 * s, color, 2.2 * s))
            name_w = D.measure(st["tool"], size, 500)
            ops.append(("t", tx, b, st["tool"], size, 500, "muted", "ui"))
            if st["detail"]:
                d = D.ellipsize("  " + st["detail"], size, W - tx - name_w - 6 * s)
                ops.append(("t", tx + name_w, b, d, size, 400, "faint", "ui"))
        y = top + lh * len(steps)
    return ops, y, hits


def _step_color(st):
    return "error" if st["ok"] is False else ("ok" if st["ok"] else "agent")


def _lay_steps_pill(item, W, m, expanded):
    """Halo: one pill, a check (a cross if one failed), the count, the tools in mono; opened, a
    row each."""
    s = m.s
    steps = item["steps"]
    ops, hits = [], []
    names = []
    for st in steps:
        if st["tool"] not in names:
            names.append(st["tool"])
    failed = sum(1 for st in steps if st["ok"] is False)
    running = any(st["ok"] is None for st in steps)
    h = 28 * s
    size = m.small
    msize = m.tiny + 0.5 * s
    head = "{} step{}".format(len(steps), "" if len(steps) == 1 else "s")
    x = 34 * s
    texts = [("t", x, D.baseline(0, h, size), head, size, 600, "text", "ui")]
    x += D.measure(head, size, 600) + 10 * s
    shown = names[:2]
    tail = ["+{}".format(len(names) - 2)] if len(names) > 2 else []
    if failed:
        tail.append("{} failed".format(failed))
    room = W - x - 40 * s
    detail = D.ellipsize("  ·  ".join(shown + tail), msize, max(0.0, room), 400, "mono")
    texts.append(("t", x, D.baseline(0, h, msize), detail, msize, 400, "error" if failed else "faint", "mono"))
    x += D.measure(detail, msize, 400, "mono") + 12 * s
    cx, cy = x + 4 * s, h / 2
    d = -1 if expanded else 1
    texts.append(("l", [(cx - 3.5 * s, cy - d * 1.5 * s), (cx, cy + d * 2 * s), (cx + 3.5 * s, cy - d * 1.5 * s)],
                  "muted", 1.4 * s))
    w = cx + 14 * s
    ops.append(("r", 0, 0, w, h, "border", h / 2))
    ops.append(("r", 1 * s, 1 * s, w - 1 * s, h - 1 * s, "surface", h / 2 - 1 * s))
    ccol = "error" if failed else ("agent" if running else "agent")
    ops.append(("r", 6 * s, 5 * s, 24 * s, 23 * s, D.alpha(D.palette()[ccol], 0.18), 9 * s))
    ix, iy = 15 * s, 14 * s
    if failed:
        k = 3.2 * s
        ops.append(("l", [(ix - k, iy - k), (ix + k, iy + k)], "error", 1.5 * s))
        ops.append(("l", [(ix - k, iy + k), (ix + k, iy - k)], "error", 1.5 * s))
    else:
        ops.append(("l", [(ix - 3.5 * s, iy), (ix - 1 * s, iy + 2.6 * s), (ix + 3.8 * s, iy - 2.8 * s)], "agent", 1.6 * s))
    ops += texts
    hits.append((("steps", item["key"]), 0, 0, w, h, h / 2))
    y = h
    if expanded:
        y += 6 * s
        lh = 21 * s
        for st in steps:
            b = D.baseline(y, lh, msize)
            ops.append(("r", 14 * s, y + lh / 2 - 2.5 * s, 19 * s, y + lh / 2 + 2.5 * s, _step_color(st), 2.5 * s))
            nw = D.measure(st["tool"], msize, 500, "mono")
            ops.append(("t", 30 * s, b, st["tool"], msize, 500, "muted", "mono"))
            if st["detail"]:
                ops.append(("t", 30 * s + nw, b, D.ellipsize("  " + st["detail"], msize, W - 36 * s - nw, 400, "mono"),
                            msize, 400, "faint", "mono"))
            y += lh
    return ops, y, hits


_LOG_ROWS = 5


def _lay_steps_log(item, W, m, expanded):
    """Signal: a timestamped log on a rail: the time, an LED, the tool, what it did, how long."""
    s = m.s
    steps = item["steps"]
    ops, hits = [], []
    size = m.tiny + 0.5 * s
    lh = 19 * s
    rows = steps
    hidden = 0
    if not expanded and len(steps) > _LOG_ROWS:
        hidden = len(steps) - _LOG_ROWS
        rows = steps[-_LOG_ROWS:]
    y = 0.0
    tx = 14 * s
    if hidden:
        lab = "+{} earlier step{}".format(hidden, "" if hidden == 1 else "s")
        ops.append(("t", tx, D.baseline(y, lh, size), looks.label(lab), size, 500, "faint", "mono"))
        hits.append((("steps", item["key"]), 0, y, tx + D.measure(looks.label(lab), size, 500, "mono") + 8 * s, y + lh, 2 * s))
        y += lh
    tw = D.measure("00:00:00", size, 400, "mono") + 12 * s
    for st in rows:
        b = D.baseline(y, lh, size)
        x = tx
        if st.get("t"):
            ops.append(("t", x, b, _clock(st["t"], True), size, 400, "faint", "mono"))
        x += tw
        ops.append(("r", x, y + lh / 2 - 2.5 * s, x + 5 * s, y + lh / 2 + 2.5 * s, _step_color(st), 0.6 * s))
        x += 14 * s
        nw = D.measure(st["tool"], size, 600, "mono")
        ops.append(("t", x, b, st["tool"], size, 600, "text", "mono"))
        x += nw + 10 * s
        dur = "{:.1f}s".format(st["dur"]) if st.get("dur") is not None else ""
        dw = D.measure(dur, size, 400, "mono") + 10 * s if dur else 0.0
        if st["detail"]:
            d = D.ellipsize(st["detail"], size, max(0.0, W - x - dw - 4 * s), 400, "mono")
            ops.append(("t", x, b, d, size, 400, "muted", "mono"))
            x += D.measure(d, size, 400, "mono") + 10 * s
        if dur:
            ops.append(("t", x, b, dur, size, 400, "faint", "mono"))
        y += lh
    ops.insert(0, ("r", 0, 2 * s, 1 * s, y - 2 * s, "border2", 0))
    if expanded and len(steps) > _LOG_ROWS:
        lab = looks.label("fewer")
        ops.append(("t", tx, D.baseline(y, lh, size), lab, size, 500, "faint", "mono"))
        hits.append((("steps", item["key"]), 0, y, tx + D.measure(lab, size, 500, "mono") + 8 * s, y + lh, 2 * s))
        y += lh
    return ops, y, hits


# ---------------------------------------------------------------------------
# Message box geometry: wrapping that keeps text indices (for the caret).

def _wrap_plain(text, maxw, size):
    """[(start, end)] index ranges of the visual lines of `text`."""
    out = []
    start = 0
    for para in text.split("\n"):
        end = start + len(para)
        ls = start
        i = start
        while i < end:
            j = i
            while j < end and text[j] != " ":
                j += 1
            while j < end and text[j] == " ":
                j += 1
            if D.measure(text[ls:j].rstrip(), size) > maxw and i > ls:
                out.append((ls, i))
                ls = i
            if D.measure(text[ls:j].rstrip(), size) > maxw:
                # One word wider than the box: break it by characters.
                k = ls + 1
                while k < j and D.measure(text[ls:k + 1], size) <= maxw:
                    k += 1
                out.append((ls, k))
                ls = i = k
                continue
            i = j
        out.append((ls, end))
        start = end + 1
    return out


def _caret_line(lines, caret):
    for n, (a, b) in enumerate(lines):
        if a <= caret <= b and (caret < b or n == len(lines) - 1 or lines[n + 1][0] > caret):
            return n
    return len(lines) - 1


def _index_at(text, lines, line_no, x, size):
    a, b = lines[max(0, min(line_no, len(lines) - 1))]
    best, best_d = a, abs(x)
    for k in range(a, b + 1):
        d = abs(D.measure(text[a:k], size) - x)
        if d < best_d:
            best, best_d = k, d
    return best


# ---------------------------------------------------------------------------
# Drawing.

def _draw():
    context = bpy.context
    area, region = context.area, context.region
    if region is None:
        return
    pane = ui_sandbox.is_pane(area)
    if not pane and not is_host(area):
        return
    D.AGENT["color"] = agent_color()
    cv = D.Canvas(region)
    try:
        if pane:
            ui_sandbox.draw_area(context, cv, area, region)
        else:
            _draw_area(context, cv, area, region)
    except Exception:  # noqa: BLE001 - a drawing bug must not take the editor down
        if not _ui.get("draw_error_shown"):
            traceback.print_exc()
            _ui["draw_error_shown"] = True
    finally:
        cv.finish()


def _hovered(area, hit_id):
    return _ui["hover"] == (area.as_pointer(), hit_id)


def _draw_area(context, cv, area, region):
    wm = context.window_manager
    st = _area_state(area)
    st["region"] = (region.x, region.y, region.width, region.height)
    s = cv.s
    m = D.Metrics(s)
    hits = []
    st["hits"] = hits
    cv.rect(0, 0, cv.w, cv.h, "bg")
    _draw_backdrop(cv, m, (0, 0, cv.w, cv.h))

    # Sessions drawer: beside the chat when there is room, over it otherwise.
    drawer_w = min(268 * s, cv.w * 0.85) if wm.agent_ui_drawer else 0.0
    min_col = 380 * s
    overlay = bool(drawer_w) and cv.w - drawer_w < min_col + 48 * s
    left = 0.0 if overlay else drawer_w
    st["drawer_w"], st["drawer_overlay"] = drawer_w, overlay
    scrap_w = ui_sandbox.width(cv, getattr(wm, "agent_ui_sandbox", False))
    scrap_overlay = bool(scrap_w) and cv.w - left - scrap_w < min_col + 48 * s
    st["scrap_w"], st["scrap_overlay"] = scrap_w, scrap_overlay
    avail = cv.w - left - (0.0 if scrap_overlay else scrap_w)
    margin = 28 * s if avail > 520 * s else 14 * s
    W = max(120 * s, min(avail - 2 * margin, 760 * s))
    col_x = left + (avail - W) / 2

    local_id = ui_chat._current_id(wm)
    key = _session_key(wm)
    turn = chat.live()
    busy = turn is not None or _team_busy()
    live_here = turn is not None and turn["local_id"] == local_id
    items = _conversation(local_id, turn if live_here else None)
    running = server.is_running()

    if not running:
        _draw_center_note(cv, m, col_x, W, "The agent server is stopped",
                          "Start it from the PartyMode preferences, or restart Blender.")
    elif not items and not live_here:
        _draw_empty(cv, m, area, st, hits, col_x, W, key, busy)
        asks = approvals.pending()  # an agent elsewhere (a terminal) may ask while the chat is empty
        if asks and st.get("composer"):
            _draw_ask(cv, m, area, hits, col_x, W, st["composer"]["top"] + 10 * s, asks)
    else:
        comp = _composer_geom(m, col_x, W, _ui["drafts"].get(key, ""), 16 * s, area)
        offer = not busy and local_id and chat.is_long(local_id)
        quick = not busy and bool(items)
        asks = approvals.pending()
        st["offer_h"] = (40 * s if offer else 0.0) + (34 * s if quick else 0.0) + (_ASK_H * s + 8 * s if asks else 0.0)
        _draw_conversation(cv, m, area, st, hits, items, turn if live_here else None, col_x, W,
                           comp["top"] + 14 * s + st["offer_h"])
        _draw_composer(cv, m, area, st, hits, comp, key, busy)
        y = comp["top"] + 8 * s
        if quick:
            _draw_quick(cv, m, area, hits, col_x, W, y)
            y += 34 * s
        if offer:
            _draw_offer(cv, m, area, hits, col_x, W, y, chat.context(local_id))
            y += 40 * s
        if asks:
            _draw_ask(cv, m, area, hits, col_x, W, y, asks)

    _draw_toast(cv, m, st, col_x, W)
    if scrap_w:
        ui_sandbox.draw(cv, m, area, st, hits, lambda hid: _hovered(area, hid), key)
    if running:
        ui_sandbox.draw_tab(cv, m, area, st, hits, lambda hid: _hovered(area, hid))
    if drawer_w:
        _draw_drawer(cv, m, area, st, hits, drawer_w, overlay, local_id, turn)
    ui_menu.draw(cv, m, area, st, hits, lambda hid: _hovered(area, hid))
    if _ui["lightbox"]:
        _draw_lightbox(cv, m, hits)


def _draw_backdrop(cv, m, rect, ticks_all=False, wash=True):
    """The answering agent's faint texture behind the chat, fading toward the message box; Halo
    washes its colour down from the top, Signal marks the corners."""
    look = looks.get()
    s = m.s
    x0, y0, x1, y1 = rect
    tex = look["texture"].get(chat.S.runner)
    color = agent_color()
    if tex:
        kind, step, strength = tex
        cv.pattern(kind, rect, step, color, strength * (0.55 if cv.pal.get("light") else 1.0),
                   y1 - (y1 - y0) * 0.6)
    if look["wash"] and wash:
        cv.rect(x0, y1 - (y1 - y0) * 0.45, x1, y1, D.alpha(color, 0.0), 0, top=D.alpha(color, look["wash"]))
    if look["ticks"]:
        k, w, i = 12 * s, 1.5 * s, 6 * s
        corners = [(x0 + i, y1 - i, 1, -1), (x1 - i, y1 - i, -1, -1)]
        if ticks_all:
            corners += [(x0 + i, y0 + i, 1, 1), (x1 - i, y0 + i, -1, 1)]
        for cx, cy, dx, dy in corners:
            cv.line([(cx, cy + dy * k), (cx, cy), (cx + dx * k, cy)], D.alpha(color, 0.9), w)


def _draw_center_note(cv, m, col_x, W, title, sub):
    y = cv.h * 0.55
    tw = D.measure(title, m.h[2], 600)
    cv.text(col_x + (W - tw) / 2, y, title, m.h[2], "text", 600)
    sw = D.measure(sub, m.body)
    cv.text(col_x + (W - sw) / 2, y - 28 * m.s, sub, m.body, "muted")


def _draw_empty(cv, m, area, st, hits, col_x, W, key, busy):
    s = m.s
    title = "Let’s do this!"
    sub = "Build, check, fix or export. Every edit is one undo step."
    comp = _composer_geom(m, col_x, W, _ui["drafts"].get(key, ""), 0, area)
    logo_h = 96 * s
    group_h = logo_h + 26 * s + 22 * s + comp["h"] + 18 * s + 34 * s
    top = cv.h * 0.5 + group_h * 0.5 + 20 * s
    size = 24 * s
    tex = D.texture(logo_path(), max_w=256)
    if tex:
        lw = logo_h * tex[1] / tex[2]
        ix = col_x + (W - lw) / 2
        cv.image(tex[0], ix, top + 4 * s, ix + lw, top + 4 * s + logo_h, 0, tint="text")
    if looks.get()["upper"]:
        title, size = title.upper(), 17 * s
    tw = D.measure(title, size, 650, "head")
    cv.text(col_x + (W - tw) / 2, top - 30 * s, title, size, "text", 650, "head")
    sw = D.measure(sub, m.body)
    cv.text(col_x + (W - sw) / 2, top - 62 * s, sub, m.body, "muted")
    comp = _composer_geom(m, col_x, W, _ui["drafts"].get(key, ""), top - 84 * s - comp["h"], area)
    _draw_composer(cv, m, area, st, hits, comp, key, busy)
    _draw_update_pill(cv, m, area, hits, col_x, W, top + 16 * s + logo_h)
    # Suggestions: pills that wrap, centred under the box.
    size = m.small + 0.5 * s
    pad = 12 * s
    ph = 30 * s
    gap = 8 * s
    rows, row, row_w = [], [], 0.0
    _ui["suggest_list"] = selection_suggestions() or list(_SUGGESTIONS)
    for i, (label, _text) in enumerate(_ui["suggest_list"]):
        w = D.measure(label, size, 500) + 2 * pad
        if row and row_w + gap + w > W:
            rows.append((row, row_w))
            row, row_w = [], 0.0
        row.append((i, label, w))
        row_w += (gap if len(row) > 1 else 0) + w
    if row:
        rows.append((row, row_w))
    y = comp["y0"] - 18 * s
    for row, row_w in rows:
        x = col_x + (W - row_w) / 2
        for i, label, w in row:
            hid = ("suggest", i)
            hov = _hovered(area, hid)
            cv.rect(x, y - ph, x + w, y, "surface2" if hov else "surface", ph / 2, line="border", width=1 * s)
            cv.text(x + pad, y - ph / 2 - size * 0.36, label, size, "text" if hov else "muted", 500)
            hits.append((hid, x, y - ph, x + w, y))
            x += w + gap
        y -= ph + gap


def _draw_update_pill(cv, m, area, hits, col_x, W, y):
    """A newer PartyMode is out: a quiet pill above the welcome; a click offers to install it."""
    from . import updates
    new = updates.available()
    if not new or updates.status()["state"] == "installed":
        return
    s = m.s
    busy = updates.status()["state"] == "downloading"
    label = "Downloading PartyMode {}…".format(new) if busy else "PartyMode {} is out  ·  Install".format(new)
    size = m.small
    pad, ph = 12 * s, 26 * s
    w = min(W, D.measure(label, size, 500) + 2 * pad)
    x = col_x + (W - w) / 2
    hid = ("update",)
    hov = _hovered(area, hid)
    cv.rect(x, y, x + w, y + ph, "surface2" if hov else "surface", ph / 2, line="border", width=1 * s)
    cv.text(x + pad, y + ph / 2 - size * 0.36, D.ellipsize(label, size, w - 2 * pad, 500), size,
            "text" if hov else "muted", 500)
    hits.append((hid, x, y, x + w, y + ph))


def _draw_conversation(cv, m, area, st, hits, items, turn, col_x, W, view_bottom, view_top=None, panel=False,
                       pin=None):
    """pin: the index of an item to show at the top when the view first lands on it (the folded
    bar's last picture, when it and the reply after it are too tall to fit)."""
    s = m.s
    view_top = cv.h - 18 * s if view_top is None else view_top
    blocks = []
    y = 0.0
    prev = None
    for item in items:
        ops, h, ihits = _layout(item, W, m)
        y += _gap(prev, item["kind"], s)
        blocks.append((y, ops, h, ihits))
        y += h
        prev = item["kind"]
    live_block = None
    if turn is not None:
        if turn["text"].strip():
            ops, h = D.layout_markdown(turn["text"], W, m)
            y += _gap(prev, "md", s)
            blocks.append((y, ops, h, []))
            y += h
            prev = "md"
        y += _gap(prev, "steps", s)
        live_block = y
        y += 26 * s
    doc_h = y + 8 * s
    V = max(1.0, view_top - view_bottom)
    max_scroll = max(0.0, doc_h - V)

    # Stay at the newest message, or keep the view still while scrolled up.
    if st["last_h"] is not None and st["target"] > 0.5 and doc_h != st["last_h"]:
        st["target"] += doc_h - st["last_h"]
        st["scroll"] += doc_h - st["last_h"]
    st["last_h"] = doc_h
    if pin is not None and pin < len(blocks):
        key = (len(items), round(blocks[pin][0]))
        if st.get("pinned") != key:  # once per new picture: after that the user scrolls as they like
            st["pinned"] = key
            st["target"] = st["scroll"] = doc_h - blocks[pin][0] - V + 4 * s
    st["target"] = min(max(st["target"], 0.0), max_scroll)
    if abs(st["target"] - st["scroll"]) > 0.5:
        st["scroll"] += (st["target"] - st["scroll"]) * 0.35
        _anim["until"] = time.time() + 0.3
    else:
        st["scroll"] = st["target"]
    st["scroll"] = min(max(st["scroll"], 0.0), max_scroll)
    st["max_scroll"] = max_scroll
    st["page"] = V * 0.85

    oy = view_top if doc_h <= V else view_bottom + doc_h - st["scroll"]
    for by, ops, h, ihits in blocks:
        top = oy - by
        if top - h > view_top + 40 * s or top < view_bottom - 40 * s:
            continue
        D.draw_ops(cv, ops, col_x, top, clip_top=view_top + 30 * s, clip_bottom=view_bottom - 30 * s)
        for hid, x0, y0, x1, y1, *rad in ihits:
            if _hovered(area, hid) and hid[0] != "img":
                cv.rect(col_x + x0, top - y1, col_x + x1, top - y0, D.alpha(cv.pal["text"], 0.07),
                        rad[0] if rad else 6 * s)
        for hid, x0, y0, x1, y1, *_r in ihits:
            if top - y0 > view_bottom and top - y1 < view_top:
                hits.append((hid, col_x + x0, max(view_bottom, top - y1), col_x + x1, min(view_top, top - y0)))
    ui_select.capture(st, blocks, col_x, oy, view_bottom, view_top)
    ui_select.draw_highlight(cv, st, agent_color(None, 0.3))
    if live_block is not None:
        _draw_status(cv, m, col_x, oy - live_block, turn)

    # Fade under the message box and at the top edge (a panel is clipped instead).
    if not panel:
        cv.rect(0, 0, cv.w, view_bottom - 10 * s, "bg")
        cv.rect(0, view_bottom - 10 * s, cv.w, view_bottom + 26 * s, "bg", top=D.alpha(cv.pal["bg"], 0.0))
        cv.rect(0, view_top - 6 * s, cv.w, cv.h, D.alpha(cv.pal["bg"], 0.0), top="bg")

    if max_scroll > 0:
        track_h = V
        thumb_h = max(28 * s, track_h * V / doc_h)
        frac = 1.0 - st["scroll"] / max_scroll
        y0 = view_bottom + (track_h - thumb_h) * frac
        sx = col_x + W + 8 * s if panel else cv.w - 7 * s
        cv.rect(sx, y0, sx + 4 * s, y0 + thumb_h, D.alpha(cv.pal["text"], 0.18), 2 * s)
    if st["scroll"] > 60 * s:
        label = "Jump to latest"
        size = m.small
        w = D.measure(label, size, 500) + 34 * s
        h = 28 * s
        x = col_x + (W - w) / 2
        y = view_bottom + 8 * s
        hov = _hovered(area, ("bottom",))
        cv.rect(x, y - 2 * s, x + w, y + h - 2 * s, "shadow", h / 2, soft=8 * s)
        cv.rect(x, y, x + w, y + h, "surface2" if hov else "surface", h / 2, line="border2", width=1 * s)
        cx, cy = x + 15 * s, y + h / 2
        cv.line([(cx, cy + 4 * s), (cx, cy - 4 * s)], "muted", 1.5 * s)
        cv.line([(cx - 3.5 * s, cy - 0.5 * s), (cx, cy - 4 * s), (cx + 3.5 * s, cy - 0.5 * s)], "muted", 1.5 * s)
        cv.text(x + 25 * s, y + h / 2 - size * 0.36, label, size, "text", 500)
        hits.append((("bottom",), x, y, x + w, y + h))


def _tokens(n):
    return "{:.1f}M".format(n / 1e6) if n >= 1e6 else "{}k".format(max(1, round(n / 1000)))


def _context_text(c):
    if c["fraction"] is not None:
        return "{}% of context used".format(round(c["fraction"] * 100))
    return "{} tokens of context".format(_tokens(c["tokens"]))


QUICK = (("check", "Check scene"), ("lit", "Lit render"), ("checkpoint", "Checkpoint"), ("undo", "Undo"))


def _icon(cv, kind, cx, cy, s, color):
    """Small line icons for Halo's quick actions."""
    if kind == "check":
        cv.rect(cx - 5.5 * s, cy - 5.5 * s, cx + 5.5 * s, cy + 5.5 * s, D.alpha(cv.color(color), 0.0), 5.5 * s,
                line=color, width=1.2 * s)
        cv.line([(cx - 2.6 * s, cy), (cx - 0.6 * s, cy - 2 * s), (cx + 2.8 * s, cy + 2 * s)], color, 1.3 * s)
    elif kind == "lit":  # a camera
        cv.rect(cx - 6 * s, cy - 4.5 * s, cx + 6 * s, cy + 3.5 * s, D.alpha(cv.color(color), 0.0), 2 * s,
                line=color, width=1.2 * s)
        cv.rect(cx - 2.3 * s, cy - 2.8 * s, cx + 2.3 * s, cy + 1.8 * s, D.alpha(cv.color(color), 0.0), 2.3 * s,
                line=color, width=1.2 * s)
        cv.line([(cx - 2.5 * s, cy + 3.5 * s), (cx - 1.5 * s, cy + 5 * s), (cx + 1.5 * s, cy + 5 * s),
                 (cx + 2.5 * s, cy + 3.5 * s)], color, 1.2 * s)
    elif kind == "checkpoint":  # a flag
        cv.line([(cx - 4 * s, cy - 6 * s), (cx - 4 * s, cy + 5.5 * s)], color, 1.3 * s)
        cv.line([(cx - 4 * s, cy + 5.5 * s), (cx + 4.5 * s, cy + 3.5 * s), (cx - 4 * s, cy + 0.5 * s)], color, 1.3 * s)
    elif kind == "undo":
        pts = [(cx + 5 * s * math.cos(a), cy - 1 * s + 4.5 * s * math.sin(a))
               for a in [math.pi * (0.95 - i / 10 * 1.45) for i in range(11)]]
        cv.line(pts, color, 1.3 * s)
        hx, hy = pts[0]
        cv.line([(hx + 1.2 * s, hy + 3.2 * s), (hx, hy), (hx + 3.2 * s, hy - 1.2 * s)], color, 1.3 * s)
    elif kind == "spark":  # a four-point star
        k, q = 5 * s, 1.4 * s
        cv.line([(cx, cy + k), (cx + q, cy + q), (cx + k, cy), (cx + q, cy - q), (cx, cy - k), (cx - q, cy - q),
                 (cx - k, cy), (cx - q, cy + q), (cx, cy + k)], color, 1.2 * s)


def _draw_quick(cv, m, area, hits, col_x, W, y):
    """Quick actions above the message box: one click, no typing."""
    s = m.s
    look = looks.get()
    font = "mono" if look["upper"] else "ui"
    size = (m.tiny + 0.5 * s) if look["upper"] else m.small - 0.5 * s
    icons = looks.name() == "HALO"
    h = 24 * s
    r = looks.radius("button", s, h)
    x = col_x + 4 * s
    for action, label in QUICK:
        label = looks.label(label)
        lead = 18 * s if icons else 0.0
        w = D.measure(label, size, 500, font) + 22 * s + lead
        if x + w > col_x + W:
            break
        hid = ("quick", action)
        hov = _hovered(area, hid)
        cv.rect(x, y, x + w, y + h, "border2" if hov else "border", r)
        cv.rect(x + 1 * s, y + 1 * s, x + w - 1 * s, y + h - 1 * s, "surface2" if hov else "bg", max(0.0, r - 1 * s))
        if icons:
            _icon(cv, action, x + 17 * s, y + h / 2, s, "text" if hov else "muted")
        cv.text(x + 11 * s + lead, y + h / 2 - size * 0.36, label, size, "text" if hov else "muted", 500, font)
        hits.append((hid, x, y, x + w, y + h))
        x += w + 6 * s
    sugg = selection_suggestions()
    _ui["sel_suggest_list"] = sugg
    if sugg and x + 30 * s < col_x + W:
        cv.rect(x + 2 * s, y + 6 * s, x + 3 * s, y + h - 6 * s, "border")
        x += 10 * s
    spark = looks.name() != "CLASSIC"
    for i, (label, _text) in enumerate(sugg):
        label = looks.label(label)
        lead = 16 * s if spark else 0.0
        w = D.measure(label, size, 500, font) + 22 * s + lead
        if x + w > col_x + W:
            break
        hid = ("sel_suggest", i)
        hov = _hovered(area, hid)
        acc = agent_color(None, 1.0)
        cv.rect(x, y, x + w, y + h, D.alpha(acc, 0.85 if hov else (0.65 if spark else 0.35)), r)
        cv.rect(x + 1 * s, y + 1 * s, x + w - 1 * s, y + h - 1 * s,
                D.alpha(acc, 0.14) if spark else ("surface2" if hov else "bg"), max(0.0, r - 1 * s))
        if spark:
            _icon(cv, "spark", x + 16 * s, y + h / 2, s, acc)
        cv.text(x + 11 * s + lead, y + h / 2 - size * 0.36, label, size, "text", 500, font)
        hits.append((hid, x, y, x + w, y + h))
        x += w + 6 * s


def _draw_offer(cv, m, area, hits, col_x, W, y, c):
    """Above the message box once a chat is long: move on with a summary."""
    s = m.s
    size = m.small
    lead = "This chat is getting long ({}). ".format(_context_text(c))
    action = "Continue in a new chat"
    lw, aw = D.measure(lead, size), D.measure(action, size, 600)
    w = min(W, lw + aw + 46 * s)
    h = 30 * s
    x = col_x + (W - w) / 2
    hid = ("continue",)
    hov = _hovered(area, hid)
    warn = c["fraction"] is not None and c["fraction"] >= 0.85
    cv.rect(x, y, x + w, y + h, "surface2" if hov else "surface", h / 2,
            line=("error" if warn else "border2"), width=1 * s)
    tx = x + 16 * s
    lead = D.ellipsize(lead, size, max(0.0, w - aw - 46 * s))
    cv.text(tx, y + h / 2 - size * 0.36, lead, size, "muted")
    ax = tx + D.measure(lead, size)
    cv.text(ax, y + h / 2 - size * 0.36, action, size, "accent", 600)
    cx, cy = ax + aw + 9 * s, y + h / 2
    cv.line([(cx - 3 * s, cy), (cx + 3 * s, cy)], "accent", 1.4 * s)
    cv.line([(cx, cy - 3 * s), (cx + 3 * s, cy), (cx, cy + 3 * s)], "accent", 1.4 * s)
    hits.append((hid, x, y, x + w, y + h))


_ASK_H = 66.0


def _draw_ask(cv, m, area, hits, col_x, W, y, asks):
    """An agent asking before it reaches the web: what, where, and Allow / Allow for this chat / Deny."""
    s = m.s
    req = asks[0]
    h = _ASK_H * s
    look = looks.get()
    acc = agent_color()
    r = min(looks.radius("card", s, h), 14 * s)
    font = "mono" if look["upper"] else "ui"
    cv.rect(col_x, y - 3 * s, col_x + W, y + h - 3 * s, "shadow", r, soft=12 * s)
    cv.rect(col_x, y, col_x + W, y + h, "surface2", r, line=D._mix(cv.pal["border2"][:3], acc[:3], 0.6), width=1.2 * s)
    pad = 14 * s
    cv.rect(col_x + pad, y + h - 22 * s, col_x + pad + 8 * s, y + h - 14 * s, acc, 1 * s if look["upper"] else 4 * s)
    size = m.small + 0.5 * s
    text = "{} wants to {}".format(req["who"], req["text"])
    cv.text(col_x + pad + 16 * s, y + h - 18 * s - size * 0.36, D.ellipsize(text, size, W - 2 * pad - 16 * s, 600),
            size, "text", 600)
    # Buttons on the bottom row, right; what it is (and how many more wait) on the left.
    bh = 24 * s
    by = y + 10 * s
    x = col_x + W - pad
    for choice, label, primary in (("allow", "Allow", True), ("chat", "Allow for this chat", False),
                                   ("deny", "Deny", False)):
        label = looks.label(label)
        w = D.measure(label, m.tiny + 0.5 * s, 600, font) + 22 * s
        x -= w
        hid = ("approve", req["id"], choice)
        hov = _hovered(area, hid)
        br = looks.radius("button", s, bh)
        if primary:
            fill = D._mix(acc[:3], (1, 1, 1), 0.12) if hov else acc
            cv.rect(x, by, x + w, by + bh, fill, br)
            col = "accent_text"
        else:
            cv.rect(x, by, x + w, by + bh, "border2" if hov else "surface", br, line="border2", width=1 * s)
            col = "text"
        cv.text(x + 11 * s, by + bh / 2 - (m.tiny + 0.5 * s) * 0.36, label, m.tiny + 0.5 * s, col, 600, font)
        hits.append((hid, x, by, x + w, by + bh))
        x -= 6 * s
    detail = req.get("detail") or ""
    if len(asks) > 1:
        detail = "{}  ·  +{} more waiting".format(detail, len(asks) - 1) if detail else "+{} more waiting".format(len(asks) - 1)
    room = x - (col_x + pad) - 8 * s
    if detail and room > 40 * s:
        cv.text(col_x + pad, by + bh / 2 - m.tiny * 0.36, D.ellipsize(detail, m.tiny, room, 400, "mono"), m.tiny,
                "muted", 400, "mono")


def _draw_status(cv, m, col_x, top, turn):
    s = m.s
    t = time.time()
    cy = top - 13 * s
    square = looks.get()["upper"]
    for i in range(3):
        a = 0.35 + 0.65 * max(0.0, math.sin(t * 5.0 - i * 0.7))
        x = col_x + 6 * s + i * 9 * s
        cv.rect(x - 3 * s, cy - 3 * s, x + 3 * s, cy + 3 * s, agent_color(turn.get("runner"), a),
                0.6 * s if square else 3 * s)
    activity = (turn.get("activity") or "thinking").strip()
    activity = activity[:1].upper() + activity[1:]
    font = "mono" if square else "ui"
    size = m.tiny + 0.5 * s if square else m.small
    text = D.ellipsize(looks.label(activity + "…"), size, 600 * s, 400, font)
    cv.text(col_x + 36 * s, cy - size * 0.36, text, size, "muted", 400, font)


def _composer_geom(m, col_x, W, text, y0, area):
    s = m.s
    pad = 16 * s
    inner = W - 2 * pad
    lines = _wrap_plain(text, inner, m.body) if text else [(0, 0)]
    lh = m.line_h(m.body)
    edit = _ui["edit"]
    focused = edit is not None and edit["area"] == area.as_pointer()
    nvis = min(len(lines), 8)
    first = 0
    if len(lines) > nvis:
        first = len(lines) - nvis
        if focused:
            cl = _caret_line(lines, edit["caret"])
            first = max(0, min(cl - nvis + 1, len(lines) - nvis))
            first = min(first, cl)
    h = 14 * s + nvis * lh + 6 * s + 32 * s + 8 * s
    return {"x0": col_x, "x1": col_x + W, "y0": y0, "top": y0 + h, "h": h, "pad": pad, "inner": inner,
            "lines": lines, "first": first, "nvis": nvis, "lh": lh, "text_top": y0 + h - 14 * s,
            "focused": focused}


def _draw_mark_chips(cv, m, area, hits, key, hx, by, limit, size):
    """Sandbox items and marks waiting to go with this message (click one to drop it), then the
    Mark button."""
    s = m.s
    cr = looks.radius("chip", s, 24 * s)
    from . import sandbox
    attached = [sandbox.get(sid) for sid in ui_sandbox.attached(key)]
    attached = [it for it in attached if it is not None]
    labels = [D.ellipsize(it.get("title") or it["id"], size, 110 * s, 500) for it in attached]
    need = sum(D.measure(lab, size, 500) + 46 * s for lab in labels)
    if attached and hx + need > limit - 70 * s:
        # Not enough room for a chip each: one that says how many, and opens the Sandbox.
        lab = "{} attached".format(len(attached))
        w = D.measure(lab, size, 500) + 34 * s
        hid = ("scrap_open",)
        hov = _hovered(area, hid)
        acc = agent_color(None, 1.0)
        cv.rect(hx, by - 12 * s, hx + w, by + 12 * s, D.alpha(acc, 0.16 if hov else 0.08), cr,
                line=D.alpha(acc, 0.7), width=1 * s)
        cv.rect(hx + 10 * s, by - 4 * s, hx + 18 * s, by + 4 * s, D.alpha(acc, 0.5), 2 * s)
        cv.text(hx + 24 * s, by - size * 0.36, lab, size, "text", 500)
        hits.append((hid, hx, by - 12 * s, hx + w, by + 12 * s))
        hx += w + 6 * s
        attached = []
    for it, lab in zip(attached, labels):
        sid = it["id"]
        w = D.measure(lab, size, 500) + 40 * s
        hid = ("scrap_chip", sid)
        hov = _hovered(area, hid)
        acc = agent_color(None, 1.0)
        cv.rect(hx, by - 12 * s, hx + w, by + 12 * s, D.alpha(acc, 0.16 if hov else 0.08), cr,
                line=D.alpha(acc, 0.7), width=1 * s)
        cv.rect(hx + 10 * s, by - 4 * s, hx + 18 * s, by + 4 * s, D.alpha(acc, 0.5), 2 * s)
        cv.text(hx + 24 * s, by - size * 0.36, lab, size, "text", 500)
        k = 3 * s
        xx = hx + w - 12 * s
        cv.line([(xx - k, by - k), (xx + k, by + k)], "muted" if not hov else "text", 1.2 * s)
        cv.line([(xx - k, by + k), (xx + k, by - k)], "muted" if not hov else "text", 1.2 * s)
        hits.append((hid, hx, by - 12 * s, hx + w, by + 12 * s))
        hx += w + 6 * s
    for mk in ui_mark.pending(key):
        lab = D.ellipsize("{}  {}".format(mk["n"], ui_mark.label(mk)), size, 120 * s, 500)
        w = D.measure(lab, size, 500) + 40 * s
        if hx + w > limit - 70 * s:
            break
        hid = ("mark_del", mk["id"])
        hov = _hovered(area, hid)
        red = (0.94, 0.23, 0.2, 1.0)
        cv.rect(hx, by - 12 * s, hx + w, by + 12 * s, D.alpha(red, 0.16 if hov else 0.08), cr,
                line=D.alpha(red, 0.7), width=1 * s)
        cv.rect(hx + 10 * s, by - 4 * s, hx + 18 * s, by + 4 * s, D.alpha(red, 0.0), 1.5 * s, line=red, width=1.3 * s)
        cv.text(hx + 24 * s, by - size * 0.36, lab, size, "text", 500)
        k = 3 * s
        xx = hx + w - 12 * s
        cv.line([(xx - k, by - k), (xx + k, by + k)], "muted" if not hov else "text", 1.2 * s)
        cv.line([(xx - k, by + k), (xx + k, by - k)], "muted" if not hov else "text", 1.2 * s)
        hits.append((hid, hx, by - 12 * s, hx + w, by + 12 * s))
        hx += w + 6 * s
    if hx + 70 * s <= limit:
        hid = ("mark_new",)
        hov = _hovered(area, hid)
        lab, mfont = looks.label("Mark"), _chip_font()
        w = D.measure(lab, size, 500, mfont) + 34 * s
        cv.rect(hx, by - 12 * s, hx + w, by + 12 * s, "surface2" if hov else D.alpha(cv.pal["surface2"], 0.0),
                cr, line="border", width=1 * s)
        cv.rect(hx + 10 * s, by - 4 * s, hx + 18 * s, by + 4 * s, D.alpha(cv.pal["text"], 0.0), 1.5 * s,
                line="muted", width=1.3 * s)
        cv.text(hx + 23 * s, by - size * 0.36, lab, size, "text" if hov else "muted", 500, mfont)
        hits.append((hid, hx, by - 12 * s, hx + w, by + 12 * s))
        hx += w + 8 * s
    return hx


def next_hint(key):
    """The agent's suggested next message for the chat `key` (a session id), or None."""
    return chat.next_suggestion(key) if key and key != "NEW" else None


def _draw_composer(cv, m, area, st, hits, g, key, busy):
    s = m.s
    text = _ui["drafts"].get(key, "")
    edit = _ui["edit"] if g["focused"] else None
    x0, x1, y0, y1 = g["x0"], g["x1"], g["y0"], g["top"]
    look = looks.get()
    radius = looks.radius("composer", s, y1 - y0)
    radius = min(radius, 20 * s)
    cv.rect(x0, y0 - 4 * s, x1, y1 - 4 * s, "shadow", radius, soft=18 * s)
    if edit and look["glow"]:  # Halo: a lit focus ring
        cv.rect(x0 - 3 * s, y0 - 3 * s, x1 + 3 * s, y1 + 3 * s, agent_color(None, 0.32), radius + 3 * s, soft=16 * s)
    border = agent_color(None, 0.85) if edit else ("border2" if _hovered(area, ("composer",)) else "border")
    cv.rect(x0, y0, x1, y1, "surface", radius, line=border, width=1.2 * s)
    tx = x0 + g["pad"]
    size = m.body
    lh = g["lh"]
    if look["prompt"]:  # Signal: a prompt mark in the padding, before the first line
        cv.text(x0 + 5 * s, D_base(g["text_top"], lh, size), look["prompt"], size, agent_color(), 600)
    if not text:
        ghost = None if busy else next_hint(key)
        if ghost:
            # The agent's guess at the next message: Tab (or the right arrow) takes it.
            tab = "Tab"
            tw = D.measure(tab, m.tiny, 600) + 12 * s
            room = g["inner"] - tw - 10 * s
            shown = D.ellipsize(ghost, size, room)
            gx = tx + D.measure(shown, size) + 10 * s
            base = D_base(g["text_top"], lh, size)
            cv.text(tx, base, shown, size, "faint")
            cv.rect(gx, base - 4 * s, gx + tw, base + m.tiny + 3 * s, "surface2", 5 * s, line="border", width=1 * s)
            cv.text(gx + 6 * s, base, tab, m.tiny, "muted", 600)
        else:
            hint = "Ask the agent to build, check or change something…"
            cv.text(tx, D_base(g["text_top"], lh, size), D.ellipsize(hint, size, g["inner"]), size, "faint")
    if edit and edit["caret"] != edit["anchor"]:
        a, b = sorted((edit["caret"], edit["anchor"]))
        for n in range(g["first"], g["first"] + g["nvis"]):
            la, lb = g["lines"][n]
            sa, sb = max(a, la), min(b, lb)
            if sa < sb or (a <= la and b > lb):
                xa = tx + D.measure(text[la:sa], size)
                xb = tx + D.measure(text[la:max(sa, sb)], size) + (4 * s if b > lb else 0)
                top = g["text_top"] - (n - g["first"]) * lh
                cv.rect(xa, top - lh, xb, top, agent_color(None, 0.35), 2 * s)
    for n in range(g["first"], g["first"] + g["nvis"]):
        la, lb = g["lines"][n]
        if lb > la:
            top = g["text_top"] - (n - g["first"]) * lh
            x = tx
            for a, b, is_mention in _text_pieces(text, la, lb):
                cv.text(x, D_base(top, lh, size), text[a:b], size, "accent" if is_mention else "text")
                x += D.measure(text[a:b], size)
    if edit and int((time.time() - edit["t"]) / 0.53) % 2 == 0:
        n = _caret_line(g["lines"], edit["caret"])
        if g["first"] <= n < g["first"] + g["nvis"]:
            la, _lb = g["lines"][n]
            cx = tx + D.measure(text[la:edit["caret"]], size)
            top = g["text_top"] - (n - g["first"]) * lh
            cv.rect(cx - 0.75 * s, top - lh + 4 * s, cx + 0.75 * s, top - 4 * s, agent_color())
    hits.append((("composer",), x0, y0, x1, y1))
    st["composer"] = g
    mention = _ui.get("mention") if edit else None
    if mention and mention["items"]:
        n = _caret_line(g["lines"], edit["caret"])
        la = g["lines"][min(n, len(g["lines"]) - 1)][0]
        cx = tx + D.measure(text[la:mention["at"]], size)
        rows = mention["items"]
        rh = 26 * s
        pw = min(300 * s, x1 - x0)
        px = min(max(x0, cx - 12 * s), x1 - pw)
        py = y1 + 8 * s
        ph = rh * len(rows) + 8 * s
        cv.rect(px, py - 3 * s, px + pw, py + ph - 3 * s, "shadow", 12 * s, soft=12 * s)
        cv.rect(px, py, px + pw, py + ph, "surface2", 12 * s, line="border2", width=1 * s)
        for i, name in enumerate(rows):
            ry = py + 4 * s + i * rh  # the first match sits nearest the message box
            hid = ("mention", i)
            if i == mention["sel"] or _hovered(area, hid):
                cv.rect(px + 4 * s, ry + 1 * s, px + pw - 4 * s, ry + rh - 1 * s,
                        D.alpha(cv.pal["accent"], 0.18 if i == mention["sel"] else 0.08), 8 * s)
            ob = bpy.data.objects.get(name)
            kind = ob.type.lower() if ob else ""
            fs = m.small
            cv.text(px + 14 * s, ry + rh / 2 - fs * 0.36, "@" + D.ellipsize(name, fs, pw - 90 * s), fs, "text", 500)
            kw = D.measure(kind, m.tiny)
            cv.text(px + pw - 12 * s - kw, ry + rh / 2 - m.tiny * 0.36, kind, m.tiny, "faint")
            hits.append((hid, px, ry, px + pw, ry + rh))

    # Toolbar: model chip and hint on the left, send or stop on the right.
    by = y0 + 8 * s + 16 * s
    size = m.tiny + 0.5 * s
    cx0 = tx - 6 * s
    chip = ("model",)
    hov = _hovered(area, chip)
    cw = _agent_chip(cv, m, cx0, by, hov or ui_menu.is_open(area))
    hits.append((chip, cx0, by - 12 * s, cx0 + cw, by + 12 * s))
    st["chip_rect"] = (cx0, by - 12 * s, cx0 + cw, by + 12 * s)
    sel = [o for o in (bpy.context.selected_objects or ())][:6]
    hx = cx0 + cw + 8 * s
    if chat.S.research and not busy:
        hx += _research_pill(cv, m, area, hits, hx, by) + 8 * s
    if sel and g["inner"] - cw > 200 * s:
        lab = "@ " + (sel[0].name if len(sel) == 1 else "{} selected".format(len(sel)))
        lab = D.ellipsize(lab, size, 150 * s, 500)
        sw = D.measure(lab, size, 500) + 20 * s
        sid = ("mention_sel",)
        shov = _hovered(area, sid)
        classic = looks.name() == "CLASSIC"
        acc = agent_color()
        cv.rect(hx, by - 12 * s, hx + sw, by + 12 * s,
                ("surface2" if shov else D.alpha(cv.pal["surface2"], 0.0)) if classic else D.alpha(acc, 0.2 if shov else 0.1),
                looks.radius("chip", s, 24 * s), line="border" if classic else D.alpha(acc, 0.6), width=1 * s)
        cv.text(hx + 10 * s, by - size * 0.36, lab, size, "accent" if classic else acc, 500)
        hits.append((sid, hx, by - 12 * s, hx + sw, by + 12 * s))
        hx += sw + 8 * s
    hx = _draw_mark_chips(cv, m, area, hits, key, hx, by, x1 - g["pad"] - 40 * s, size)
    if look["upper"]:
        hint, hfont = ("WORKING  ·  ↵↵ SEND NOW" if busy else "↵ SEND  ·  @ OBJECT"), "mono"
    else:
        hint, hfont = ("Working…  ·  Enter twice sends now" if busy else "Enter to send  ·  @ names an object"), "ui"
    room = x1 - g["pad"] - 40 * s - hx
    if room > 60 * s:
        cv.text(hx + 2 * s, by - m.tiny * 0.36, D.ellipsize(hint, m.tiny, room, 400, hfont), m.tiny, "faint", 400, hfont)
    r = 15 * s
    cr = r if look["radius"]["button"] >= 999 else 3 * s  # a round key, or Signal's square one
    cx, cy = x1 - g["pad"] + 2 * s - r, by
    hid = ("send",)
    hov = _hovered(area, hid)
    if busy:
        cv.rect(cx - r, cy - r, cx + r, cy + r, "surface2" if not hov else "border2", cr,
                line=agent_color(None, 0.8) if look["upper"] else "border2", width=1 * s)
        k = 4.5 * s
        cv.rect(cx - k, cy - k, cx + k, cy + k, agent_color() if look["upper"] else "text", 1 * s if look["upper"] else 2 * s)
    else:
        ready = bool(text.strip())
        fill = agent_color() if ready else "surface2"
        if ready and hov:
            fill = D._mix(agent_color()[:3], (1, 1, 1), 0.12)
        if ready and look["glow"]:  # Halo: the send key glows
            cv.rect(cx - r - 2 * s, cy - r - 4 * s, cx + r + 2 * s, cy + r, agent_color(None, 0.55), r + 2 * s, soft=12 * s)
        cv.rect(cx - r, cy - r, cx + r, cy + r, fill, cr)
        col = "accent_text" if ready else "faint"
        cv.line([(cx, cy - 5.5 * s), (cx, cy + 5.5 * s)], col, 2 * s)
        cv.line([(cx - 5 * s, cy + 0.5 * s), (cx, cy + 5.5 * s), (cx + 5 * s, cy + 0.5 * s)], col, 2 * s)
    hits.append((hid, cx - r - 3 * s, cy - r - 3 * s, cx + r + 3 * s, cy + r + 3 * s))


def _globe(cv, cx, cy, r, s, color):
    """A small globe: a circle, the equator and a meridian."""
    import math as _m
    ring = [(cx + r * _m.cos(a / 16 * 2 * _m.pi), cy + r * _m.sin(a / 16 * 2 * _m.pi)) for a in range(17)]
    cv.line(ring, color, 1.2 * s)
    cv.line([(cx - r, cy), (cx + r, cy)], color, 1.0 * s)
    mer = [(cx + r * 0.45 * _m.cos(a / 16 * 2 * _m.pi), cy + r * _m.sin(a / 16 * 2 * _m.pi)) for a in range(17)]
    cv.line(mer, color, 1.0 * s)


def _research_pill(cv, m, area, hits, x, by):
    """'Research' in the message box: the next message may use the web. A click turns it off."""
    s = m.s
    look = looks.get()
    font = "mono" if look["upper"] else "ui"
    size = m.tiny + 0.5 * s
    label = looks.label("Research")
    w = D.measure(label, size, 600, font) + 40 * s
    hid = ("research_off",)
    hov = _hovered(area, hid)
    acc = agent_color()
    cv.rect(x, by - 12 * s, x + w, by + 12 * s, D.alpha(acc, 0.26 if hov else 0.16), looks.radius("chip", s, 24 * s),
            line=D.alpha(acc, 0.8), width=1 * s)
    _globe(cv, x + 15 * s, by, 5.5 * s, s, acc)
    cv.text(x + 26 * s, by - size * 0.36, label, size, "text", 600, font)
    hits.append((hid, x, by - 12 * s, x + w, by + 12 * s))
    return w


def _agent_chip(cv, m, x0, by, hov=False):
    """Who answers next: the agent's mark and its name (the model and reasoning are in the menu it
    opens); returns the width. Signal writes the name in mono capitals."""
    s = m.s
    look = looks.get()
    size = m.tiny + 0.5 * s
    acc = agent_color()
    if looks.name() == "CLASSIC":
        label = runners.get(chat.S.runner).label
        cw = D.measure(label, size, 500) + 42 * s
        cv.rect(x0, by - 12 * s, x0 + cw, by + 12 * s, "surface2" if hov else D.alpha(cv.pal["surface2"], 0.0),
                12 * s, line="border", width=1 * s)
        cv.rect(x0 + 10 * s, by - 3.5 * s, x0 + 17 * s, by + 3.5 * s, acc, 3.5 * s)
        cv.text(x0 + 22 * s, by - size * 0.36, label, size, "text" if hov else "muted", 500)
    else:
        runner = runners.get(chat.S.runner)
        name = runner.label
        font = "mono" if look["upper"] else "ui"
        if look["upper"]:
            name = name.upper()
        nw = D.measure(name, size, 600, font)
        cw = 22 * s + nw + 22 * s
        r = looks.radius("chip", s, 24 * s)
        cv.rect(x0, by - 12 * s, x0 + cw, by + 12 * s, "surface2" if hov else D.alpha(cv.pal["surface2"], 0.6), r,
                line="border2" if hov else "border", width=1 * s)
        if look["glow"]:
            cv.rect(x0 + 8 * s, by - 5.5 * s, x0 + 19 * s, by + 5.5 * s, D.alpha(acc, 0.45), 5.5 * s, soft=5 * s)
        cv.rect(x0 + 10 * s, by - 3.5 * s, x0 + 17 * s, by + 3.5 * s, acc, 0.8 * s if look["upper"] else 3.5 * s)
        cv.text(x0 + 22 * s, by - size * 0.36, name, size, acc if look["upper"] else "text", 600, font)
    ax = x0 + cw - 13 * s
    cv.line([(ax - 3 * s, by + 1.5 * s), (ax, by - 1.5 * s), (ax + 3 * s, by + 1.5 * s)], "muted", 1.3 * s)
    return cw


def _effort_label(effort):
    return {"xhigh": "Extra high"}.get(effort, effort.capitalize())


def D_base(line_top_region, lh, size):
    """Region-space baseline for a line whose top is at `line_top_region` (y up)."""
    return line_top_region - lh * 0.5 - size * 0.36


def _draw_toast(cv, m, st, col_x, W):
    toast = _ui["toast"]
    if not toast:
        return
    text, until, error = toast
    if time.time() > until:
        _ui["toast"] = None
        return
    s = m.s
    size = m.small
    g = st.get("composer")
    y = (g["top"] if g else 80 * s) + 12 * s + st.get("offer_h", 0.0)
    w = min(W, D.measure(text, size, 500) + 28 * s)
    x = col_x + (W - w) / 2
    h = 30 * s
    cv.rect(x, y - 2 * s, x + w, y + h - 2 * s, "shadow", 10 * s, soft=10 * s)
    cv.rect(x, y, x + w, y + h, "surface2", 10 * s, line=("error" if error else "border2"), width=1 * s)
    cv.text(x + 14 * s, y + h / 2 - size * 0.36, D.ellipsize(text, size, w - 28 * s, 500), size,
            "text", 500)


def _ago(t):
    d = time.time() - t
    if d < 60:
        return "just now"
    if d < 3600:
        return "{}m ago".format(int(d // 60))
    if d < 86400:
        return "{}h ago".format(int(d // 3600))
    if d < 7 * 86400:
        return "{}d ago".format(int(d // 86400))
    return time.strftime("%b %d", time.localtime(t))


def _draw_drawer(cv, m, area, st, hits, dw, overlay, current, turn):
    s = m.s
    if overlay:
        cv.rect(dw, 0, cv.w, cv.h, "scrim")
        hits.append((("scrim",), dw, 0, cv.w, cv.h))
    cv.rect(0, 0, dw, cv.h, "drawer")
    cv.rect(dw - max(1.0, s), 0, dw, cv.h, "border")
    hits.append((("drawer",), 0, 0, dw, cv.h))
    pad = 12 * s
    y = cv.h - 14 * s
    # New chat button.
    bh = 34 * s
    hov = _hovered(area, ("new",))
    cv.rect(pad, y - bh, dw - pad, y, "surface2" if hov else "surface", 10 * s, line="border", width=1 * s)
    px, py = pad + 18 * s, y - bh / 2
    cv.line([(px - 5 * s, py), (px + 5 * s, py)], "text", 1.6 * s)
    cv.line([(px, py - 5 * s), (px, py + 5 * s)], "text", 1.6 * s)
    cv.text(pad + 32 * s, py - m.body * 0.36, "New chat", m.body, "text", 500)
    hits.append((("new",), pad, y - bh, dw - pad, y))
    y -= bh + 20 * s
    cv.text(pad + 4 * s, y, "RECENT", m.tiny, "faint", 600)
    y -= 12 * s
    list_top = y
    ih = 50 * s
    sessions = chat.list_sessions()
    busy = (turn or {}).get("local_id")
    max_scroll = max(0.0, len(sessions) * (ih + 2 * s) - (list_top - 8 * s))
    st["drawer_scroll"] = min(max(st["drawer_scroll"], 0.0), max_scroll)
    y = list_top + st["drawer_scroll"]
    if not sessions:
        cv.text(pad + 4 * s, y - 20 * s, "No conversations yet", m.small, "muted")
    for sess in sessions:
        top, bottom = y, y - ih
        y -= ih + 2 * s
        if bottom > list_top or top < 0:
            continue
        sid = sess["id"]
        hid = ("session", sid)
        hov = _hovered(area, hid) or _hovered(area, ("delete", sid))
        active = sid == current
        if active or hov:
            cv.rect(pad - 4 * s, bottom, dw - pad + 4 * s, top, "surface2" if active else "surface", 10 * s)
        right = dw - pad - (30 * s if hov or _ui["confirm_delete"] == sid else 6 * s)
        dot = agent_color(sess.get("runner") or "claude", 0.9)
        cv.rect(pad + 6 * s, top - 19.5 * s, pad + 12 * s, top - 13.5 * s, dot, 3 * s)
        title = D.ellipsize(sess["title"] or "Untitled", m.body - 0.5 * s, right - pad - 22 * s, 500 if active else 400)
        cv.text(pad + 18 * s, top - 21 * s, title, m.body - 0.5 * s, "text", 500 if active else 400)
        if sid == busy:
            sub = "answering…"
            cv.rect(right - 2 * s, top - 18 * s, right + 4 * s, top - 12 * s, agent_color(turn.get("runner")), 3 * s)
        else:
            sub = "{}  ·  {} turn{}".format(_ago(sess.get("updated", 0)), sess.get("turns", 0),
                                          "" if sess.get("turns", 0) == 1 else "s")
        cv.text(pad + 18 * s, top - 39 * s, D.ellipsize(sub, m.tiny, right - pad - 22 * s), m.tiny, "faint")
        hits.append((hid, pad - 4 * s, max(bottom, 0), dw - pad + 4 * s, min(top, list_top)))
        if hov or _ui["confirm_delete"] == sid:
            did = ("delete", sid)
            cx, cy = dw - pad - 10 * s, top - ih / 2
            if _ui["confirm_delete"] == sid:
                label = "Delete"
                w = D.measure(label, m.tiny, 600) + 16 * s
                cv.rect(cx + 8 * s - w, cy - 11 * s, cx + 8 * s, cy + 11 * s, "error", 11 * s)
                cv.text(cx + 16 * s - w, cy - m.tiny * 0.36, label, m.tiny, (1, 1, 1, 1), 600)
                hits.append((did, cx + 8 * s - w, cy - 11 * s, cx + 8 * s, cy + 11 * s))
            else:
                dh = _hovered(area, did)
                if dh:
                    cv.rect(cx - 10 * s, cy - 10 * s, cx + 10 * s, cy + 10 * s, "border2", 10 * s)
                k = 3.5 * s
                cv.line([(cx - k, cy - k), (cx + k, cy + k)], "muted", 1.4 * s)
                cv.line([(cx - k, cy + k), (cx + k, cy - k)], "muted", 1.4 * s)
                hits.append((did, cx - 11 * s, cy - 11 * s, cx + 11 * s, cy + 11 * s))
    # Fade the list under the header row.
    cv.rect(0, list_top, dw - max(1.0, s), list_top + 10 * s, "drawer", top=D.alpha(cv.pal["drawer"], 0.0))


def _draw_lightbox(cv, m, hits):
    s = m.s
    cv.rect(0, 0, cv.w, cv.h, (0, 0, 0, 0.82))
    t = D.texture(_ui["lightbox"], max_w=2048)
    if t:
        tex, iw, ih = t
        k = min((cv.w - 48 * s) / iw, (cv.h - 80 * s) / ih, 1.5)
        w, h = iw * k, ih * k
        x, y = (cv.w - w) / 2, (cv.h - h) / 2 + 12 * s
        cv.image(tex, x, y, x + w, y + h, 10 * s)
    note = "Click anywhere or press Esc to close"
    nw = D.measure(note, m.small)
    cv.text((cv.w - nw) / 2, 22 * s, note, m.small, (1, 1, 1, 0.6))
    hits.append((("lightbox",), 0, 0, cv.w, cv.h))


# ---------------------------------------------------------------------------
# Input.

def _hit(st, x, y):
    for h in reversed(st["hits"]):
        hid, x0, y0, x1, y1 = h[:5]
        if x0 <= x <= x1 and y0 <= y <= y1:
            return hid
    return None


def _start_marking(context):
    """Mark mode: the next drag over any editor makes a mark for this message."""
    if ui_mark._M["active"]:
        return
    try:
        with context.temp_override(window=context.window, screen=context.window.screen):
            bpy.ops.agent.mark_area('INVOKE_DEFAULT')
    except RuntimeError as ex:
        _toast(str(ex))


def _send(context, text):
    wm = context.window_manager
    text = text.strip()
    old_key = _session_key(wm)
    marks = ui_mark.pending(old_key)
    from . import sandbox
    scraps = [sandbox.get(i) for i in ui_sandbox.attached(old_key) if sandbox.get(i)]
    if not text and marks:
        text = "Look at the area I marked." if len(marks) == 1 else "Look at the areas I marked."
    if not text and scraps:
        text = "Have a look at what I attached from the Sandbox."
    if not text:
        return False
    if chat.live() or _team_busy():
        # Enter again soon after: send now (stop this answer, then send). Once: say how.
        now = time.time()
        if now - _ui.get("busy_enter", 0.0) < SEND_NOW_S:
            _ui["busy_enter"] = 0.0
            return _send_now(text)
        _ui["busy_enter"] = now
        _toast("Still working. Press Enter again to send now (stops this answer).", error=False,
               seconds=SEND_NOW_S + 1.0)
        return False
    extra = "\n\n".join(x for x in (mention_context(text), ui_mark.context_text(marks),
                                    ui_sandbox.context_text(scraps)) if x)
    try:
        local_id = chat.send(text, ui_chat._current_id(wm), bpy.data.filepath, extra=extra)
    except (RuntimeError, ValueError) as ex:
        _toast(str(ex))
        return False
    if marks:
        chat.add_marks(local_id, ui_mark.take(old_key))
    if scraps:
        chat.add_scraps(local_id, ui_sandbox.take(old_key))
    _ui["drafts"].pop(old_key, None)
    if wm.agent_chat_session != local_id:
        ui_chat._sessions_enum(None, context)
        wm.agent_chat_session = local_id
    edit = _ui["edit"]
    if edit:
        edit.update(key=local_id, caret=0, anchor=0, undo=[], redo=[])
    for st in _areas.values():
        st["target"] = st["scroll"] = 0.0
    _redraw_all()
    return True


SEND_NOW_S = 1.5  # a second Enter within this sends now


def _send_now(text):
    """Stop the answer (and any helpers), then send `text` as soon as the agent has stopped."""
    from . import cancel
    chat.stop()
    cancel.stop("the user sent a new message")
    _toast("Stopping, then sending…", error=False, seconds=3.0)
    deadline = time.time() + 30.0

    def later():
        if chat.live() or _team_busy():
            if time.time() < deadline:
                return 0.1
            _toast("The agent did not stop; your message is still in the box.")
            return None
        _send(bpy.context, text)
        return None
    bpy.app.timers.register(later, first_interval=0.1)
    return True


def _run_tool(name, args, label):
    """Run a tool for a chat button, as the agent would (receipt, change report, undo step)."""
    from . import receipts, registry
    from . import server as srv
    tool = registry.TOOLS[name]
    if tool.mutating:
        # Named as the user's: history shows it as yours; its id is not an agent's call_status receipt.
        return srv._run_mutating(tool, dict(args, _label=label), receipts.new_id(), label, client="ui")
    try:
        return tool.fn(dict(args))
    except Exception as ex:  # noqa: BLE001
        return {"data": {"error": str(ex)}, "isError": True}


def _team_busy():
    from . import team
    return team.busy()


def _chat_busy():
    if chat.live() or _team_busy():
        _toast("Wait for the agent to finish (or press Stop).")
        return True
    return False


def _render_into_chat(sid, view, look):
    res = _run_tool("render_view", {"view": view or "hero", "look": look}, "render")
    if res.get("isError") or not res.get("images"):
        _toast("Render failed: {}".format((res.get("data") or {}).get("error", "unknown error")))
        return
    chat.user_action(sid, "Rendered the {} view ({}) from the chat.".format(view or "hero", look),
                     res["images"][0], card={"kind": "render", "view": view or "hero", "look": look})


def _undo_last(sid):
    res = _run_tool("undo", {"steps": 1}, "undo (chat)")
    if res.get("isError"):
        _toast((res.get("data") or {}).get("error", "Could not undo."))
        return
    undone = ((res.get("data") or {}).get("undone") or [""])
    chat.user_action(sid, "Undid the last step{} from the chat.".format(
        " ({})".format(undone[0]) if undone and undone[0] else ""))


def _card_action(context, key, action):
    sid = key[0]
    item = next((i for i in _conversation(sid) if i.get("key") == key and i["kind"] == "card"), None)
    if item is None:
        return
    card = item.get("card") or {}
    if action == "open":
        shown = _card_images(item)
        if shown:
            _ui["lightbox"] = shown[0]
    elif action == "compare":
        _ui["diff"].discard(key)
        _ui["compare"] ^= {key}
    elif action == "diff":
        _ui["compare"].discard(key)
        _ui["diff"] ^= {key}
    elif _chat_busy():
        return
    elif action == "keep":
        res = _run_tool("apply_trial", {"trial_id": card.get("trial_id", "")}, "keep trial (chat)")
        if res.get("isError"):
            _toast((res.get("data") or {}).get("error", "Could not keep it."))
            return
        chat.user_action(sid, "Kept the trial from the chat (it is now in the scene).",
                         applied_trial=card.get("trial_id"))
    elif action in ("lit", "solid"):
        _render_into_chat(sid, card.get("view"), "lit" if action == "lit" else "solid")
    elif action == "undo":
        _undo_last(sid)


def _quick_action(context, action):
    wm = context.window_manager
    sid = ui_chat._current_id(wm)
    if action == "check":
        _send(context, "Check my scene for problems: floating or sunk objects, broken meshes, wrong sizes. "
                       "Summarise what you find.")
        return
    if sid is None or _chat_busy():
        return
    if action == "lit":
        _render_into_chat(sid, "hero", "lit")
    elif action == "checkpoint":
        name = "chat " + time.strftime("%H:%M:%S")
        res = _run_tool("checkpoint", {"name": name}, "checkpoint (chat)")
        if res.get("isError"):
            _toast((res.get("data") or {}).get("error", "Could not make a checkpoint."))
            return
        chat.user_action(sid, "Made a checkpoint, '{}', from the chat.".format(name))
        _toast("Checkpoint '{}' saved".format(name), error=False, seconds=2.0)
    elif action == "undo":
        _undo_last(sid)


def _select_session(context, sid):
    wm = context.window_manager
    ui_chat._sessions_enum(None, context)
    try:
        wm.agent_chat_session = sid
    except TypeError:
        _toast("That conversation could not be opened.")
        return
    for st in _areas.values():
        st["target"] = st["scroll"] = 0.0
        st["last_h"] = None
    if _areas_any_overlay():
        wm.agent_ui_drawer = False


def _areas_any_overlay():
    return any(st["drawer_overlay"] for st in _areas.values())


def _activate(context, area, hid):
    wm = context.window_manager
    kind = hid[0]
    _ui["confirm_delete"] = hid[1] if kind == "delete" and _ui["confirm_delete"] != hid[1] else None
    if kind == "composer":
        return bpy.ops.agent.ui_compose('INVOKE_DEFAULT')
    if kind == "model" or kind.startswith("menu_"):
        ui_menu.activate(context, area, hid)
        return {'FINISHED'}
    if kind == "update":
        return bpy.ops.agent.update_install('INVOKE_DEFAULT')
    if kind == "approve":
        approvals.answer(hid[1], hid[2])
        _redraw_all()
        return {'FINISHED'}
    if kind == "research_off":
        chat.set_research(False)
        _redraw_all()
        return {'FINISHED'}
    if kind == "send":
        if chat.live() or _team_busy():
            bpy.ops.agent.chat_stop()
        else:
            _send(context, _ui["drafts"].get(_session_key(wm), ""))
    elif kind == "steps":
        _ui["expanded"] ^= {hid[1]}
    elif kind == "img":
        _ui["lightbox"] = hid[1]
    elif kind == "lightbox":
        _ui["lightbox"] = None
    elif kind == "copy":
        item = next((i for i in _conversation(ui_chat._current_id(wm)) if i.get("key") == hid[1]), None)
        if item:
            wm.clipboard = item["copy"]
            _toast("Copied the reply", error=False, seconds=1.6)
    elif kind == "suggest":
        listed = _ui.get("suggest_list") or list(_SUGGESTIONS)
        if hid[1] < len(listed):
            label, text = listed[hid[1]]
            if any(label == lab for lab, _t in _SUGGESTIONS):
                _send(context, text)
            else:  # for the selection: into the message box, to adjust before sending
                _ui["drafts"][_session_key(wm)] = text
    elif kind == "sel_suggest":
        listed = _ui.get("sel_suggest_list") or []
        if hid[1] < len(listed):
            _ui["drafts"][_session_key(wm)] = listed[hid[1]][1]
    elif kind == "session":
        _select_session(context, hid[1])
    elif kind == "delete":
        if _ui["confirm_delete"] is None:  # second click: confirmed
            try:
                chat.delete(hid[1])
            except RuntimeError as ex:
                _toast(str(ex))
            else:
                if ui_chat._current_id(wm) == hid[1]:
                    wm.agent_chat_session = "NEW"
    elif kind == "new":
        wm.agent_chat_session = "NEW"
        if _areas_any_overlay():
            wm.agent_ui_drawer = False
    elif kind == "mention_sel":
        key = _session_key(wm)
        draft = _ui["drafts"].get(key, "")
        add = " ".join(format_mention(o.name) for o in list(context.selected_objects)[:6])
        _ui["drafts"][key] = (draft.rstrip() + " " if draft.strip() else "") + add + " "
    elif kind.startswith("scrap_"):
        ui_sandbox.activate(context, area, hid, _session_key(wm))
    elif kind == "mark_new":
        _start_marking(context)
    elif kind == "mark_del":
        ui_mark.remove(hid[1])
    elif kind == "continue":
        bpy.ops.agent.chat_continue()
    elif kind == "chip":
        _card_action(context, hid[1], hid[2])
    elif kind == "quick":
        _quick_action(context, hid[1])
    elif kind == "bottom":
        _area_state(area)["target"] = 0.0
    elif kind == "scrim":
        wm.agent_ui_drawer = False
    _redraw_all()
    return {'FINISHED'}


class AGENT_OT_ui_mouse(bpy.types.Operator):
    bl_idname = "agent.ui_mouse"
    bl_label = "Agent Editor Mouse"
    bl_options = {'INTERNAL'}

    action: bpy.props.EnumProperty(items=(('MOVE', "Move", ""), ('CLICK', "Click", ""), ('RELEASE', "Release", ""),
                                          ('MIDDLE', "Middle", ""), ('DOUBLE', "Double-click", "")))

    def invoke(self, context, event):
        area, region = context.area, context.region
        if not is_canvas(area) or region is None or region.type != 'WINDOW':
            return {'PASS_THROUGH'}
        st = _area_state(area)
        hid = _hit(st, event.mouse_region_x, event.mouse_region_y)
        if self.action == 'DOUBLE':  # a word of the conversation
            mx, my = event.mouse_region_x, event.mouse_region_y
            if hid in (None, ("bar_panel",)) and ui_select.in_view(st, mx, my) and ui_select.select_word(st, mx, my):
                area.tag_redraw()
                return {'FINISHED'}
            return {'PASS_THROUGH'}
        if self.action == 'MIDDLE':  # middle-drag pans the Sandbox board
            if not ui_sandbox.in_board(st, event.mouse_region_x, event.mouse_region_y):
                return {'PASS_THROUGH'}
            bpy.ops.agent.sandbox_drag('INVOKE_DEFAULT', mode='PAN', button='MIDDLEMOUSE')
            return {'FINISHED'}
        if not is_host(area) and not ui_sandbox.is_pane(area):
            # A viewport: everything off the bar is the viewport's.
            if self.action == 'MOVE':
                hover = (area.as_pointer(), hid)
                if hover != _ui["hover"]:
                    _ui["hover"] = hover
                    area.tag_redraw()
                if hid is not None:
                    context.window.cursor_set('TEXT' if hid == ("composer",) else 'DEFAULT')
                return {'PASS_THROUGH'}
            if self.action == 'CLICK' and hid == ("bar_panel",) and \
                    ui_select.in_view(st, event.mouse_region_x, event.mouse_region_y):
                bpy.ops.agent.select_text('INVOKE_DEFAULT')
                return {'FINISHED'}
            if hid is None or hid == ("bar_panel",):
                return {'PASS_THROUGH'} if hid is None else {'FINISHED'}
            if self.action == 'CLICK' and hid[0] == "bar":
                _bar_action(context, area, hid[1])
                return {'FINISHED'}
        if self.action == 'RELEASE':
            return {'PASS_THROUGH'}
        if self.action == 'MOVE':
            hover = (area.as_pointer(), hid)
            if hover != _ui["hover"]:
                _ui["hover"] = hover
                area.tag_redraw()
            context.window.cursor_set('TEXT' if hid == ("composer",) else (ui_sandbox.cursor(hid) or 'DEFAULT'))
            return {'PASS_THROUGH'}
        if hid is None:
            if _ui["confirm_delete"]:
                _ui["confirm_delete"] = None
                area.tag_redraw()
            if is_host(area) and ui_select.in_view(st, event.mouse_region_x, event.mouse_region_y):
                bpy.ops.agent.select_text('INVOKE_DEFAULT')  # drag to select the conversation's text
                return {'FINISHED'}
            return {'PASS_THROUGH'}
        ui_select.clear(st)
        return _activate(context, area, hid)


class AGENT_OT_ui_scroll(bpy.types.Operator):
    bl_idname = "agent.ui_scroll"
    bl_label = "Scroll the Agent Chat"
    bl_options = {'INTERNAL'}

    lines: bpy.props.FloatProperty()

    def invoke(self, context, event):
        area = context.area
        if not is_canvas(area):
            return {'PASS_THROUGH'}
        st = _area_state(area)
        if not is_host(area) and _hit(st, event.mouse_region_x, event.mouse_region_y) is None:
            return {'PASS_THROUGH'}  # the viewport zooms; the bar scrolls only under the pointer
        s = context.preferences.system.ui_scale
        mx, my = event.mouse_region_x, event.mouse_region_y
        if ui_menu.is_open(area):
            ui_menu.scroll(area, st, mx, my, self.lines or (event.mouse_y - event.mouse_prev_y))
            return {'FINISHED'}
        if ui_sandbox.in_board(st, mx, my) and not (st["drawer_w"] and mx < st["drawer_w"]):
            if event.type == 'TRACKPADZOOM' or (event.type == 'TRACKPADPAN' and event.ctrl):
                ui_sandbox.zoom(area, st, mx, my, 1.0 + (event.mouse_x - event.mouse_prev_x) * 0.01)
            elif event.type == 'TRACKPADPAN':
                ui_sandbox.pan(area, st, event.mouse_x - event.mouse_prev_x, event.mouse_y - event.mouse_prev_y)
            else:
                ui_sandbox.zoom(area, st, mx, my, 1.15 if self.lines > 0 else 1 / 1.15)
            return {'FINISHED'}
        delta = self.lines * 22 * s if self.lines else (event.mouse_y - event.mouse_prev_y)
        if st["drawer_w"] and event.mouse_region_x < st["drawer_w"]:
            st["drawer_scroll"] = max(0.0, st["drawer_scroll"] - delta)
        else:
            st["target"] = min(max(st["target"] + delta, 0.0), st.get("max_scroll", 0.0))
        area.tag_redraw()
        return {'FINISHED'}


class AGENT_OT_ui_key(bpy.types.Operator):
    bl_idname = "agent.ui_key"
    bl_label = "Agent Chat Key"
    bl_options = {'INTERNAL'}

    action: bpy.props.EnumProperty(items=(('ESC', "Esc", ""), ('PAGE_UP', "Page Up", ""),
                                          ('PAGE_DOWN', "Page Down", ""), ('TOP', "Top", ""),
                                          ('BOTTOM', "Bottom", ""), ('COPY', "Copy", "")))

    def invoke(self, context, event):
        area = context.area
        if not is_canvas(area):
            return {'PASS_THROUGH'}
        st = _area_state(area)
        if self.action == 'COPY':
            if not ui_select.has_selection(st):
                return {'PASS_THROUGH'}
            text = ui_select.text_of(st)
            context.window_manager.clipboard = text
            _toast("Copied {} character{}".format(len(text), "" if len(text) == 1 else "s"), error=False, seconds=2.0)
            area.tag_redraw()
            return {'FINISHED'}
        if self.action == 'ESC' and ui_select.has_selection(st):
            ui_select.clear(st)
            area.tag_redraw()
            return {'FINISHED'}
        if not is_host(area) and not _ui["lightbox"] and \
                _hit(st, event.mouse_region_x, event.mouse_region_y) is None:
            return {'PASS_THROUGH'}  # Home, Page Up... belong to the viewport off the bar
        if self.action == 'TOP' and ui_sandbox.in_board(st, event.mouse_region_x, event.mouse_region_y):
            ui_sandbox.fit(area, st)
            return {'FINISHED'}
        if ui_sandbox.is_pane(area) and self.action != 'ESC':
            return {'FINISHED'}
        if self.action == 'ESC':
            if _ui["lightbox"]:
                _ui["lightbox"] = None
            elif context.window_manager.agent_ui_drawer and st["drawer_overlay"]:
                context.window_manager.agent_ui_drawer = False
            elif getattr(context.window_manager, "agent_ui_sandbox", False) and st.get("scrap_overlay"):
                context.window_manager.agent_ui_sandbox = False
            else:
                return {'PASS_THROUGH'}
        elif self.action == 'PAGE_UP':
            st["target"] = min(st["target"] + st.get("page", 300), st.get("max_scroll", 0.0))
        elif self.action == 'PAGE_DOWN':
            st["target"] = max(st["target"] - st.get("page", 300), 0.0)
        elif self.action == 'TOP':
            st["target"] = st.get("max_scroll", 0.0)
        else:
            st["target"] = 0.0
        area.tag_redraw()
        return {'FINISHED'}


def _word_left(text, i):
    while i > 0 and text[i - 1].isspace():
        i -= 1
    if i > 0 and (text[i - 1].isalnum() or text[i - 1] == "_"):
        while i > 0 and (text[i - 1].isalnum() or text[i - 1] == "_"):
            i -= 1
    elif i > 0:
        i -= 1
    return i


def _word_right(text, i):
    n = len(text)
    if i < n and (text[i].isalnum() or text[i] == "_"):
        while i < n and (text[i].isalnum() or text[i] == "_"):
            i += 1
    elif i < n:
        i += 1
    while i < n and text[i].isspace():
        i += 1
    return i


class AGENT_OT_ui_compose(bpy.types.Operator):
    """Type in the Agent editor's message box"""
    bl_idname = "agent.ui_compose"
    bl_label = "Write a Message"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        area = context.area
        if not is_canvas(area) or _ui["edit"] is not None:
            return {'PASS_THROUGH'}
        if ui_sandbox.is_pane(area):
            if event.type == 'V' and event.ctrl:
                if ui_sandbox.paste(context, context.window_manager.clipboard, None, area) is None:
                    _toast("Nothing to paste: copy an image or SVG first.")
            return {'FINISHED'}
        if not is_host(area) and _hit(_area_state(area), event.mouse_region_x,
                                      event.mouse_region_y) != ("composer",):
            return {'PASS_THROUGH'}  # in a viewport, typing starts only by clicking the box
        if not server.is_running():
            return {'PASS_THROUGH'}
        st = _area_state(area)
        if event.type == 'V' and event.ctrl and st.get("scrap_w") and \
                event.mouse_region_x > context.region.width - st["scrap_w"]:
            # Over the Sandbox: paste into it, without attaching to a message.
            if ui_sandbox.paste(context, context.window_manager.clipboard, None, area) is None:
                _toast("Nothing to paste: copy an image or SVG first.")
            return {'FINISHED'}
        key = _session_key(context.window_manager)
        text = _ui["drafts"].get(key, "")
        _ui["edit"] = {"area": area.as_pointer(), "key": key, "caret": len(text), "anchor": len(text),
                       "undo": [], "redo": [], "t": time.time(), "last_push": 0.0, "drag": False}
        if event.type == 'LEFTMOUSE':
            self._place(context, event, extend=False)
            _ui["edit"]["drag"] = True
        elif event.type == 'V' and event.ctrl:
            self._paste(context)
        elif event.type == 'TAB':
            if not text and next_hint(key):
                self._set(context, next_hint(key), len(next_hint(key)))
        elif event.unicode and event.type not in {'RET', 'NUMPAD_ENTER', 'TAB'}:
            self._insert(context, event.unicode)
        self._update_mention(context)
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        _redraw_all()
        return {'RUNNING_MODAL'}

    # -- text helpers -------------------------------------------------------
    def _text(self, context):
        return _ui["drafts"].get(_ui["edit"]["key"], "")

    def _set(self, context, text, caret, anchor=None, push=True, typing=False):
        e = _ui["edit"]
        old = self._text(context)
        if push and text != old:
            now = time.time()
            # Plain typing within a short burst is one undo step; anything else is its own.
            burst = typing and e.get("typing") and now - e["last_push"] < 0.8 and e["undo"]
            if not burst:
                e["undo"].append((old, e["caret"], e["anchor"]))
                del e["undo"][:-100]
            e["last_push"] = now
            e["redo"].clear()
        e["typing"] = typing
        _ui["drafts"][e["key"]] = text
        e["caret"] = max(0, min(caret, len(text)))
        e["anchor"] = e["caret"] if anchor is None else max(0, min(anchor, len(text)))
        e["t"] = time.time()

    def _selection(self):
        e = _ui["edit"]
        return min(e["caret"], e["anchor"]), max(e["caret"], e["anchor"])

    def _paste(self, context):
        """Ctrl+V: an image or SVG on the clipboard goes into the Sandbox, attached to this
        message; text is typed as usual."""
        text = context.window_manager.clipboard
        e = _ui["edit"]
        area = next((a for w in context.window_manager.windows for a in w.screen.areas
                     if e and a.as_pointer() == e["area"]), context.area)
        item = ui_sandbox.paste(context, text, e["key"] if e else _session_key(context.window_manager), area)
        if item is not None:
            _toast("Added to the Sandbox and attached: {}".format(item.get("title") or item["id"]))
            return
        self._insert(context, text)

    def _insert(self, context, s):
        s = s.replace("\r\n", "\n").replace("\r", "\n").replace("\t", "    ")
        s = "".join(ch for ch in s if ch == "\n" or ch >= " ")
        if not s:
            return
        text = self._text(context)
        a, b = self._selection()
        self._set(context, text[:a] + s + text[b:], a + len(s), typing=len(s) == 1 and a == b)

    def _move(self, context, caret, extend):
        e = _ui["edit"]
        e["typing"] = False
        e["caret"] = max(0, min(caret, len(self._text(context))))
        if not extend:
            e["anchor"] = e["caret"]
        e["t"] = time.time()

    def _geom(self):
        area = _find_area(_ui["edit"]["area"])
        return (_area_state(area).get("composer") if area else None), area

    def _place(self, context, event, extend):
        g, area = self._geom()
        region = _main_region(area) if area else None
        if not g or region is None:
            return
        text = self._text(context)
        lines = _wrap_plain(text, g["inner"], D.Metrics(context.preferences.system.ui_scale).body) if text else [(0, 0)]
        x = event.mouse_x - region.x - (g["x0"] + g["pad"])
        y = event.mouse_y - region.y
        n = g["first"] + int((g["text_top"] - y) // g["lh"])
        n = max(0, min(n, len(lines) - 1))
        size = D.Metrics(context.preferences.system.ui_scale).body
        self._move(context, _index_at(text, lines, n, x, size), extend)
        D.restore_fonts()

    def _vertical(self, context, direction, extend):
        g, _area = self._geom()
        e = _ui["edit"]
        text = self._text(context)
        if not g or not text:
            return
        size = D.Metrics(context.preferences.system.ui_scale).body
        lines = _wrap_plain(text, g["inner"], size)
        n = _caret_line(lines, e["caret"])
        target = n + direction
        if target < 0:
            self._move(context, 0, extend)
        elif target >= len(lines):
            self._move(context, len(text), extend)
        else:
            x = D.measure(text[lines[n][0]:e["caret"]], size)
            self._move(context, _index_at(text, lines, target, x, size), extend)
        D.restore_fonts()

    def _finish(self, context):
        _ui["edit"] = None
        _ui["mention"] = None
        if getattr(self, "_timer", None):
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        _redraw_all()

    # -- events -------------------------------------------------------------
    def modal(self, context, event):
        e = _ui["edit"]
        if e is None:
            self._finish(context)
            return {'FINISHED'}
        area = _find_area(e["area"])
        if area is None or _session_key(context.window_manager) != e["key"]:
            self._finish(context)
            return {'FINISHED', 'PASS_THROUGH'}
        t, v = event.type, event.value
        if t == 'TIMER':
            area.tag_redraw()
            return {'PASS_THROUGH'}
        if t in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            if e["drag"]:
                self._place(context, event, extend=True)
                area.tag_redraw()
            return {'PASS_THROUGH'}
        if t == 'LEFTMOUSE' and v == 'RELEASE':
            e["drag"] = False
            return {'PASS_THROUGH'}
        if t in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'} and v == 'PRESS':
            region = _main_region(area)
            hid = None
            if region and region.x <= event.mouse_x < region.x + region.width \
                    and region.y <= event.mouse_y < region.y + region.height:
                hid = _hit(_area_state(area), event.mouse_x - region.x, event.mouse_y - region.y)
            if t == 'LEFTMOUSE' and hid == ("composer",):
                self._place(context, event, extend=event.shift)
                e["drag"] = True
                area.tag_redraw()
                return {'RUNNING_MODAL'}
            if t == 'LEFTMOUSE' and hid == ("send",):
                _activate(context, area, hid)
                return {'RUNNING_MODAL'}
            if t == 'LEFTMOUSE' and hid and hid[0] == "mention":
                self._accept_mention(context, hid[1])
                area.tag_redraw()
                return {'RUNNING_MODAL'}
            if t == 'LEFTMOUSE' and hid and (hid[0] in ("mark_new", "mark_del") or hid[0].startswith("scrap_")):
                self._finish(context)
                _activate(context, area, hid)
                return {'FINISHED'}
            if t == 'LEFTMOUSE' and hid == ("mention_sel",):
                self._insert(context, " ".join(format_mention(o.name) for o in list(context.selected_objects)[:6]) + " ")
                area.tag_redraw()
                return {'RUNNING_MODAL'}
            self._finish(context)
            return {'FINISHED', 'PASS_THROUGH'}
        if v not in {'PRESS'}:
            return {'PASS_THROUGH'} if t.startswith('WHEEL') or t.startswith('TRACKPAD') else {'RUNNING_MODAL'}
        ctrl = event.ctrl or event.oskey
        text = self._text(context)
        a, b = self._selection()
        mention = _ui.get("mention")
        if mention and mention["items"]:
            if t in {'UP_ARROW', 'DOWN_ARROW'}:
                step = 1 if t == 'UP_ARROW' else -1  # the list grows upward, nearest first
                mention["sel"] = (mention["sel"] + step) % len(mention["items"])
                area.tag_redraw()
                return {'RUNNING_MODAL'}
            if t in {'TAB', 'RET', 'NUMPAD_ENTER'} and not event.shift:
                self._accept_mention(context, mention["sel"])
                area.tag_redraw()
                return {'RUNNING_MODAL'}
            if t == 'ESC':
                _ui["mention"] = None
                area.tag_redraw()
                return {'RUNNING_MODAL'}
        if t == 'ESC':
            self._finish(context)
            return {'FINISHED'}
        if t in {'RET', 'NUMPAD_ENTER'}:
            if event.shift:
                self._insert(context, "\n")
            elif text.strip():
                _send(context, text)  # while the agent works: Enter twice sends now
        elif t == 'BACK_SPACE':
            if a != b:
                self._set(context, text[:a] + text[b:], a)
            elif a > 0:
                k = _word_left(text, a) if ctrl else a - 1
                self._set(context, text[:k] + text[a:], k, typing=not ctrl)
        elif t == 'DEL':
            if a != b:
                self._set(context, text[:a] + text[b:], a)
            elif a < len(text):
                k = _word_right(text, a) if ctrl else a + 1
                self._set(context, text[:a] + text[k:], a)
        elif t == 'LEFT_ARROW':
            if a != b and not event.shift:
                self._move(context, a, False)
            else:
                self._move(context, _word_left(text, e["caret"]) if ctrl else e["caret"] - 1, event.shift)
        elif t == 'RIGHT_ARROW' and not text and next_hint(e["key"]):
            self._set(context, next_hint(e["key"]), len(next_hint(e["key"])))
        elif t == 'RIGHT_ARROW':
            if a != b and not event.shift:
                self._move(context, b, False)
            else:
                self._move(context, _word_right(text, e["caret"]) if ctrl else e["caret"] + 1, event.shift)
        elif t in {'UP_ARROW', 'DOWN_ARROW'}:
            self._vertical(context, -1 if t == 'UP_ARROW' else 1, event.shift)
        elif t == 'HOME':
            self._move(context, 0 if ctrl else text.rfind("\n", 0, e["caret"]) + 1, event.shift)
        elif t == 'END':
            nl = text.find("\n", e["caret"])
            self._move(context, len(text) if ctrl or nl < 0 else nl, event.shift)
        elif ctrl and t == 'A':
            self._set(context, text, len(text), anchor=0, push=False)
        elif ctrl and t in {'C', 'X'}:
            if a != b:
                context.window_manager.clipboard = text[a:b]
                if t == 'X':
                    self._set(context, text[:a] + text[b:], a)
        elif ctrl and t == 'V':
            self._paste(context)
        elif ctrl and (t == 'Z' or t == 'Y'):
            redo = t == 'Y' or event.shift
            src, dst = (e["redo"], e["undo"]) if redo else (e["undo"], e["redo"])
            if src:
                dst.append((text, e["caret"], e["anchor"]))
                old, caret, anchor = src.pop()
                _ui["drafts"][e["key"]] = old
                e["caret"], e["anchor"], e["t"] = caret, anchor, time.time()
        elif t == 'TAB':
            if not text and next_hint(e["key"]):  # take the suggested next message
                self._set(context, next_hint(e["key"]), len(next_hint(e["key"])))
        elif event.unicode and (not ctrl or event.alt):
            self._insert(context, event.unicode)
        elif ctrl or (t.startswith('F') and t[1:].isdigit()) or t.startswith('NDOF'):
            return {'PASS_THROUGH'}
        self._update_mention(context)
        area.tag_redraw()
        return {'RUNNING_MODAL'}

    def _update_mention(self, context):
        e = _ui["edit"]
        found = mention_query(self._text(context), e["caret"]) if e and e["caret"] == e["anchor"] else None
        if found is None:
            _ui["mention"] = None
            return
        at, query = found
        items = mention_candidates(query)
        old = _ui.get("mention") or {}
        sel = old.get("sel", 0) if old.get("at") == at else 0
        _ui["mention"] = {"at": at, "query": query, "items": items, "sel": min(sel, max(0, len(items) - 1))}

    def _accept_mention(self, context, index):
        mention = _ui.get("mention")
        if not mention or index >= len(mention["items"]):
            return
        text = self._text(context)
        e = _ui["edit"]
        token = format_mention(mention["items"][index]) + " "
        end = e["caret"]
        self._set(context, text[:mention["at"]] + token + text[end:], mention["at"] + len(token))
        _ui["mention"] = None

    def cancel(self, context):
        self._finish(context)


# ---------------------------------------------------------------------------
# Header and workspace.

# ---------------------------------------------------------------------------
# OpenCode's model list (for searching in the picker), fetched once in the background.

class AgentModelItem(bpy.types.PropertyGroup):
    pass


_oc_models = {"state": "idle", "items": []}


def _fetch_opencode_models():
    if _oc_models["state"] != "idle":
        return
    exe = chat.executable("opencode")
    if not exe:
        return
    _oc_models["state"] = "fetching"

    def work():
        items = []
        # OpenCode asks its background service, which can answer with nothing while it starts up.
        for attempt in range(3):
            try:
                out = subprocess.run([exe, "models"], capture_output=True, timeout=120,
                                     env=chat._child_env(chat.S.root or "."),
                                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                lines = out.stdout.decode("utf-8", "replace").splitlines()
                items = [ln.strip() for ln in lines if "/" in ln and " " not in ln.strip()]
            except (OSError, subprocess.SubprocessError):
                items = []
            if items:
                break
            time.sleep(2.0)
        _oc_models["items"] = items
        # Still nothing: try again the next time the list is wanted.
        _oc_models["state"] = "fetched" if items else "idle"

    threading.Thread(target=work, name="agent-opencode-models", daemon=True).start()


def _fill_opencode_models():
    """Timer: copy a fetched model list into the WindowManager collection (main thread)."""
    if _oc_models["state"] == "fetched":
        wm = bpy.context.window_manager
        if wm is not None and hasattr(wm, "agent_opencode_models"):
            wm.agent_opencode_models.clear()
            for name in _oc_models["items"]:
                wm.agent_opencode_models.add().name = name
        _oc_models["state"] = "done"
    return None if _oc_models["state"] == "done" else 1.0


def _fill_codex_models():
    """Timer: the models Codex offers (its own cached list) into the WindowManager collection, for
    the preferences' Model field (main thread; once at start)."""
    from . import runners
    wm = bpy.context.window_manager
    if wm is not None and hasattr(wm, "agent_codex_models"):
        wm.agent_codex_models.clear()
        for slug, _name, _desc in runners.get("codex").models():
            wm.agent_codex_models.add().name = slug
    return None


def draw_header(layout, context):
    """The chat's header row: sessions, title, status, context meter, new chat, browser."""
    wm = context.window_manager
    icon = agent_icon()
    if icon and context.area is not None:
        layout.prop(context.area, "ui_type", text="", icon_value=icon, icon_only=True)
    else:
        layout.template_header()
    layout.prop(wm, "agent_ui_drawer", text="", icon='COLLAPSEMENU')
    if hasattr(wm, "agent_ui_sandbox"):
        sicon = agent_icon("sandbox")
        if sicon:
            layout.prop(wm, "agent_ui_sandbox", text="", icon_value=sicon)
        else:
            layout.prop(wm, "agent_ui_sandbox", text="", icon='IMAGE_REFERENCE')
    sid = ui_chat._current_id(wm)
    meta = next((m for m in chat.list_sessions() if m["id"] == sid), None) if sid else None
    title = (meta["title"] if meta else "New chat") or "Untitled"
    layout.label(text=title if len(title) <= 48 else title[:47] + "…")
    layout.separator_spacer()
    turn = chat.live()
    if turn:
        activity = turn["activity"][:1].upper() + turn["activity"][1:48]
        layout.label(text=activity + "…", icon='SORTTIME')
    elif not server.is_running():
        layout.label(text="Agent server stopped", icon='UNLINKED')
    c = chat.context(sid) if sid else None
    if sid and c is None:
        chat.measure(sid)
    if c:
        row = layout.row(align=True)
        row.alert = c["fraction"] is not None and c["fraction"] >= 0.85
        if c["fraction"] is not None:
            bar = row.row(align=True)
            bar.ui_units_x = 7
            bar.progress(factor=min(1.0, c["fraction"]), type='BAR',
                         text="{}% of {} context".format(round(c["fraction"] * 100), _tokens(c["window"])))
        else:
            row.label(text=_tokens(c["tokens"]) + " context")
        row.operator(AGENT_OT_chat_continue.bl_idname, text="", icon='FORWARD')
    layout.operator(ui_chat.AGENT_OT_chat_new.bl_idname, text="", icon='ADD')
    if len(context.screen.areas) > 1:
        layout.operator(AGENT_OT_open_window.bl_idname, text="", icon='WINDOW')
    layout.operator(ui_chat.AGENT_OT_chat_open_browser.bl_idname, text="", icon='URL')


class AGENT_HT_header(bpy.types.Header):
    bl_space_type = SPACE

    def draw(self, context):
        draw_header(self.layout, context)


# Stock Blender: the Text Editor's header shows the chat header in the chat's area only.
_text_header = {"draw": None}


def _text_header_draw(self, context):
    if is_host(context.area):
        draw_header(self.layout, context)
    elif ui_sandbox.is_pane(context.area):
        ui_sandbox.draw_pane_header(self.layout, context)
    else:
        _text_header["draw"](self, context)


class AGENT_OT_chat_continue(bpy.types.Operator):
    bl_idname = "agent.chat_continue"
    bl_label = "Continue in a New Chat"
    bl_description = ("Start a new chat that carries a summary of this one over (the agent writes "
                      "it from its full memory), so the context starts fresh")

    @classmethod
    def poll(cls, context):
        sid = ui_chat._current_id(context.window_manager)
        meta = chat.S.sessions.get(sid) if sid else None
        return bool(meta and meta.get("turns")) and chat.live() is None

    @classmethod
    def description(cls, context, properties):
        sid = ui_chat._current_id(context.window_manager)
        c = chat.context(sid) if sid else None
        if not c:
            return cls.bl_description
        if c["fraction"] is not None:
            used = "This chat uses {} of {} tokens of context ({}%).".format(
                _tokens(c["tokens"]), _tokens(c["window"]), round(c["fraction"] * 100))
        else:
            used = "This chat uses {} tokens of context.".format(_tokens(c["tokens"]))
        return used + " " + cls.bl_description + "."

    def execute(self, context):
        wm = context.window_manager
        try:
            new_id = chat.continue_in_new(ui_chat._current_id(wm))
        except RuntimeError as ex:
            self.report({'WARNING'}, str(ex))
            return {'CANCELLED'}
        _select_session(context, new_id)
        _redraw_all()
        return {'FINISHED'}


class AGENT_OT_open_workspace(bpy.types.Operator):
    bl_idname = "agent.open_workspace"
    bl_label = "Agent Workspace"
    bl_description = "Open the Agent workspace: the chat beside a 3D viewport"

    def execute(self, context):
        window = context.window
        ws = bpy.data.workspaces.get("Agent")
        if ws is None:
            # Duplicating also switches to the copy, but only after this operator returns,
            # so the chat area is added by a timer once the switch has happened.
            before = set(bpy.data.workspaces)
            bpy.ops.workspace.duplicate()
            new = [w for w in bpy.data.workspaces if w not in before]
            if not new:
                self.report({'WARNING'}, "Could not create the Agent workspace")
                return {'CANCELLED'}
            ws = new[0]
            ws.name = "Agent"
            _pending_layout[window.as_pointer()] = 0
            bpy.app.timers.register(lambda: _finish_layout(window), first_interval=0.05)
        else:
            window.workspace = ws
            # A file saved by the fork, opened in stock Blender: its chat area shows up as
            # another editor, so put the chat back (once the switch has happened).
            bpy.app.timers.register(lambda: _ensure_host(window), first_interval=0.05)
        return {'FINISHED'}


_pending_layout = {}


def _finish_layout(window):
    """Split the Agent workspace's biggest editor and give the right part to the chat."""
    key = window.as_pointer()
    tries = _pending_layout.get(key)
    if tries is None:
        return None
    if window.workspace.name != "Agent":
        if tries > 40:
            _pending_layout.pop(key, None)
            return None
        _pending_layout[key] = tries + 1
        return 0.05
    _pending_layout.pop(key, None)
    screen = window.screen
    if any(is_host(a) for a in screen.areas):
        return None
    area = max(screen.areas, key=lambda a: a.width * a.height)
    before = set(screen.areas[:])
    with bpy.context.temp_override(window=window, screen=screen, area=area):
        bpy.ops.screen.area_split(direction='VERTICAL', factor=0.68)
    new = [a for a in screen.areas if a not in before]
    target = new[0] if new else None
    if target is not None:
        # The areas' positions update on the next redraw: pick the right-hand one then.
        bpy.app.timers.register(lambda: _host_right(window, (area, target)), first_interval=0.05)
    return None


def _ensure_host(window):
    try:
        screen = window.screen
    except ReferenceError:
        return None
    if window.workspace.name != "Agent" or any(is_host(a) for a in screen.areas):
        return None
    # The fork's Agent editor reads as Info in stock Blender; else the rightmost small area.
    area = next((a for a in screen.areas if a.type == 'INFO'), None)
    if area is None:
        area = max((a for a in screen.areas if a.type not in ('VIEW_3D', 'PROPERTIES', 'OUTLINER')),
                   key=lambda a: a.x, default=None)
    if area is not None:
        make_host(area)
    return None


def _host_right(window, pair, hide_sidebar=True):
    area, other = pair
    try:
        right = max(pair, key=lambda a: a.x)
        left = other if right is area else area
    except ReferenceError:
        return None
    make_host(right)
    if hide_sidebar and left.type == 'VIEW_3D':
        left.spaces.active.show_region_ui = False
    _redraw_all()
    return None


class AGENT_OT_open_window(bpy.types.Operator):
    bl_idname = "agent.open_window"
    bl_label = "Agent Window"
    bl_description = "Open the Agent chat in its own window"

    def execute(self, context):
        wm = context.window_manager
        before = set(wm.windows[:])
        host = context.area if is_host(context.area) else next(
            (a for a in context.window.screen.areas if is_host(a)), None)
        if host is not None:
            # Noted first: once the new window opens it becomes the context's window.
            window, screen = context.window, context.window.screen
            # A window holding just the chat, at the size it has here.
            with context.temp_override(window=window, screen=screen, area=host):
                bpy.ops.screen.area_dupli('INVOKE_DEFAULT')
            # The chat moves: once the new window exists, its old area closes and gives the space back.
            if len(screen.areas) > 1:
                bpy.app.timers.register(lambda: _close_moved_chat(window, len(before)), first_interval=0.15)
        else:
            bpy.ops.wm.window_new()
        for win in wm.windows:
            if win not in before:
                area = win.screen.areas[0]
                if not is_host(area):
                    make_host(area)
                for a in win.screen.areas:
                    if is_host(a):
                        a.tag_redraw()
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# The floating agent bar: the chat at the bottom of a 3D viewport (after Higgsfield's bar).
# Same sessions and drafts as the chat; it takes only clicks on itself, and typing only once
# you click into it, so the viewport's keys and navigation keep working.

def _free_span(area, region, cv, s):
    """x range of the viewport not covered by an overlapping toolbar or sidebar."""
    x0, x1 = 0.0, float(cv.w)
    for r in area.regions:
        if r.type in {'TOOLS', 'UI'} and r.width > 1 and r.height > 1:
            if r.x <= region.x + 2:
                x0 = max(x0, r.x + r.width - region.x)
            elif r.x + r.width >= region.x + region.width - 2:
                x1 = min(x1, r.x - region.x)
    return x0, x1


def _draw_bar():
    context = bpy.context
    area, region = context.area, context.region
    if region is None or not bar_on(area) or region.type != 'WINDOW':
        return
    D.AGENT["color"] = agent_color()
    cv = D.Canvas(region, linear=True)
    try:
        _draw_bar_area(context, cv, area, region)
    except Exception:  # noqa: BLE001 - a drawing bug must not take the viewport down
        if not _ui.get("bar_error_shown"):
            traceback.print_exc()
            _ui["bar_error_shown"] = True
    finally:
        cv.finish()


def _bar_items(items, open_):
    """Collapsed: the latest turn only (from your last message on). Open: everything."""
    if open_ or not items:
        return items
    last_user = max((n for n, it in enumerate(items) if it["kind"] == "user"), default=0)
    return items[last_user:]


def _draw_bar_area(context, cv, area, region):
    wm = context.window_manager
    st = _area_state(area)
    st["region"] = (region.x, region.y, region.width, region.height)
    s = cv.s
    m = D.Metrics(s)
    hits = []
    st["hits"] = hits
    x0, x1 = _free_span(area, region, cv, s)
    W = max(220 * s, min(x1 - x0 - 32 * s, 640 * s))
    col_x = x0 + (x1 - x0 - W) / 2
    key = _session_key(wm)
    local_id = ui_chat._current_id(wm)
    turn = chat.live()
    busy = turn is not None or _team_busy()
    live_here = turn is not None and turn["local_id"] == local_id
    open_ = area.as_pointer() in _ui["bar_open"]
    items = _bar_items(_conversation(local_id, turn if live_here else None), open_)

    comp = _composer_geom(m, col_x, W, _ui["drafts"].get(key, ""), 18 * s, area)
    if items or live_here:
        pad = 10 * s
        # As tall as its content, up to a third of the viewport (half when opened).
        content = _doc_height(items, W - 8 * s, m) + (40 * s if live_here else 0) + 24 * s
        limit = cv.h * (0.5 if open_ else 0.34)
        pin = None
        if not open_:
            # Folded, it scrolls to the end: grow so the last picture and what follows it fit whole,
            # rather than showing a render card's buttons under an image scrolled out of sight.
            pics = [n for n, it in enumerate(items) if it["kind"] in ("render", "card")]
            if pics:
                tail = _doc_height(items[pics[-1]:], W - 8 * s, m) + (40 * s if live_here else 0) + 52 * s
                # At most the card and a few lines of what follows; longer, it shows the card whole
                # with the start of the reply under it (and Jump to latest for the rest).
                need = min(tail, _doc_height(items[pics[-1]:pics[-1] + 1], W - 8 * s, m) + 52 * s + 110 * s)
                limit = max(limit, need)
        top = comp["top"] + 10 * s + max(90 * s, min(content, limit))
        top = min(top, cv.h - 56 * s)
        if not open_ and pics and tail > top - comp["top"] - 10 * s:
            pin = pics[-1]
        px0, px1 = col_x - pad, col_x + W + pad
        py0 = comp["top"] + 8 * s
        if top > py0 + 60 * s:
            pr = min(looks.radius("card", s, 32 * s), 16 * s)
            cv.rect(px0, py0 - 2 * s, px1, top + 30 * s - 2 * s, "shadow", pr, soft=16 * s)
            cv.rect(px0, py0, px1, top + 30 * s, D.alpha(cv.pal["bg"], 0.97), pr, line="border", width=1 * s)
            _draw_backdrop(cv, m, (px0 + 2 * s, py0 + 2 * s, px1 - 2 * s, top + 28 * s), ticks_all=True, wash=False)
            _bar_controls(cv, m, area, hits, px0, px1, top, open_)
            gpu.state.scissor_test_set(True)
            gpu.state.scissor_set(int(px0), int(py0 + 4 * s), int(px1 - px0), int(top - py0 - 2 * s))
            try:
                _draw_conversation(cv, m, area, st, hits, items, turn if live_here else None, col_x + 4 * s,
                                   W - 8 * s, py0 + 12 * s, view_top=top - 8 * s, panel=True, pin=pin)
            finally:
                gpu.state.scissor_test_set(False)
            # The panel's own catch-all goes first, under its buttons and cards, which take priority.
            hits.insert(0, (("bar_panel",), px0, py0, px1, top + 30 * s))
            # Hits scrolled above or below the panel's window are clipped away.
            st["hits"] = [h for h in hits if h[0][0] in ("bar", "bar_panel") or
                          (h[2] < top - 8 * s and h[4] > py0 + 4 * s)]
            hits = st["hits"]
    _draw_composer(cv, m, area, st, hits, comp, key, busy)
    asks = approvals.pending()
    if asks:
        _draw_ask(cv, m, area, hits, col_x, W, comp["top"] + 8 * s, asks)
    ui_menu.draw(cv, m, area, st, hits, lambda hid: _hovered(area, hid))
    _draw_toast(cv, m, st, col_x, W)
    if _ui["lightbox"]:
        _draw_lightbox(cv, m, hits)


def _doc_height(items, W, m):
    y, prev = 0.0, None
    for item in items:
        _ops, h, _hits = _layout(item, W, m)
        y += _gap(prev, item["kind"], m.s) + h
        prev = item["kind"]
    return y


def _bar_controls(cv, m, area, hits, px0, px1, top, open_):
    """The panel's top row: who is answering, open or fold the history, the chat window, close."""
    s = m.s
    cy = top + 15 * s
    if looks.name() == "CLASSIC":
        label = runners.get(chat.S.runner).label
        cv.rect(px0 + 14 * s, cy - 3 * s, px0 + 20 * s, cy + 3 * s, agent_color(), 3 * s)
        cv.text(px0 + 28 * s, cy - m.tiny * 0.36, D.ellipsize(label, m.tiny, px1 - px0 - 130 * s), m.tiny, "muted", 500)
    else:
        _agent_chip(cv, m, px0 + 10 * s, cy)
    x = px1 - 14 * s
    for action, glyph in (("close", "x"), ("window", "w"), ("open", "fold" if open_ else "unfold")):
        hid = ("bar", action)
        r = 11 * s
        cx = x - r
        if _hovered(area, hid):
            cv.rect(cx - r, cy - r, cx + r, cy + r, D.alpha(cv.pal["text"], 0.08), r)
        k = 3.5 * s
        if glyph == "x":
            cv.line([(cx - k, cy - k), (cx + k, cy + k)], "muted", 1.4 * s)
            cv.line([(cx - k, cy + k), (cx + k, cy - k)], "muted", 1.4 * s)
        elif glyph == "w":
            cv.rect(cx - 5 * s, cy - 4 * s, cx + 5 * s, cy + 4 * s, D.alpha(cv.pal["text"], 0.0), 1.5 * s,
                    line="muted", width=1.3 * s)
            cv.line([(cx - 5 * s, cy + 1.5 * s), (cx + 5 * s, cy + 1.5 * s)], "muted", 1.3 * s)
        else:
            d = -1 if glyph == "fold" else 1
            cv.line([(cx - k, cy - d * 2 * s), (cx, cy + d * 2 * s), (cx + k, cy - d * 2 * s)], "muted", 1.5 * s)
        hits.append((hid, cx - r, cy - r, cx + r, cy + r))
        x -= 2 * r + 4 * s


class AGENT_OT_toggle_bar(bpy.types.Operator):
    bl_idname = "agent.toggle_bar"
    bl_label = "Agent Bar"
    bl_description = "Show the agent's chat as a floating bar at the bottom of this 3D viewport"

    def execute(self, context):
        area = context.area
        if area is None or area.type != 'VIEW_3D':
            return {'CANCELLED'}
        _ui["bars"] ^= {area.as_pointer()}
        _ui["bar_open"].discard(area.as_pointer())
        if not server.is_running():
            self.report({'WARNING'}, "The agent server is not running")
        area.tag_redraw()
        return {'FINISHED'}


_CHAT_W = {"px": None}  # the chat's width when it was last closed from a viewport


class AGENT_OT_toggle_chat(bpy.types.Operator):
    bl_idname = "agent.toggle_chat"
    bl_label = "PartyMode"
    bl_description = "Show or hide the PartyMode chat beside this editor (it opens at the width it last had)"

    def execute(self, context):
        screen = context.window.screen
        hosts = [a for a in screen.areas if is_host(a)]
        if hosts:
            _CHAT_W["px"] = hosts[0].width
            for a in hosts:
                with context.temp_override(window=context.window, screen=screen, area=a):
                    bpy.ops.screen.area_close()
            return {'FINISHED'}
        area = context.area
        if area is None or area.type in ('TOPBAR', 'STATUSBAR'):
            area = max(screen.areas, key=lambda a: a.width * a.height)
        want = _CHAT_W["px"] or 440 * context.preferences.system.ui_scale
        share = min(0.6, max(0.2, want / max(1, area.width)))
        if area.width * share < 240 * context.preferences.system.ui_scale:
            self.report({'WARNING'}, "This editor is too narrow to show the chat beside it")
            return {'CANCELLED'}
        before = set(a.as_pointer() for a in screen.areas)
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        with context.temp_override(window=context.window, screen=screen, area=area, region=region):
            bpy.ops.screen.area_split(direction='VERTICAL', factor=1.0 - share)
        new = next((a for a in screen.areas if a.as_pointer() not in before), None)
        if new is None:
            self.report({'WARNING'}, "No room to split this editor")
            return {'CANCELLED'}
        # Which side the new area takes shows only after a redraw: the right-hand one becomes the chat.
        window = context.window
        bpy.app.timers.register(lambda: _host_right(window, (area, new), hide_sidebar=False), first_interval=0.05)
        return {'FINISHED'}


def _bar_action(context, area, action):
    if action == "close":
        _ui["bars"].discard(area.as_pointer())
        _ui["bar_open"].discard(area.as_pointer())
    elif action == "open":
        _ui["bar_open"] ^= {area.as_pointer()}
        st = _area_state(area)
        st["target"] = st["scroll"] = 0.0
        st["last_h"] = None
    elif action == "window":
        bpy.ops.agent.open_workspace()
    area.tag_redraw()


def _close_moved_chat(window, windows_before, tries=0):
    if len(bpy.context.window_manager.windows) <= windows_before:
        if tries < 30:  # wait for the new window (up to 3 s)
            bpy.app.timers.register(lambda: _close_moved_chat(window, windows_before, tries + 1),
                                    first_interval=0.1)
        return None
    try:
        screen = window.screen
    except ReferenceError:
        return None
    host = next((a for a in screen.areas if is_host(a)), None)
    if host is not None and len(screen.areas) > 1:
        with bpy.context.temp_override(window=window, screen=screen, area=host):
            bpy.ops.screen.area_close()
    return None


def _view3d_header_button(self, context):
    if context.region.alignment == 'RIGHT':
        return
    icon = agent_icon()
    row = self.layout.row(align=True)
    shown = any(is_host(a) for a in context.screen.areas)
    if icon:
        row.operator(AGENT_OT_toggle_chat.bl_idname, text="PartyMode", icon_value=icon, depress=shown)
    else:
        row.operator(AGENT_OT_toggle_chat.bl_idname, text="PartyMode", icon='LIGHT', depress=shown)
    row.operator(AGENT_OT_toggle_bar.bl_idname, text="", icon='STATUSBAR', depress=bar_on(context.area))
    row.operator("agent.mark_area", text="", icon='SELECT_SET')


# ---------------------------------------------------------------------------
# Redraws: new content, the live turn's animation, the caret, smooth scrolling.

_last = {"rev": -1, "t": 0.0}
_anim = {"until": 0.0}


def _tick():
    wm = bpy.context.window_manager
    rev = (chat.S.revision, wm.agent_chat_session if wm else None)
    now = time.time()
    lively = chat.live() is not None or _team_busy() or _ui["edit"] is not None or now < _anim["until"] or _ui["toast"]
    if rev != _last["rev"] or (lively and now - _last["t"] > 0.05):
        _last["rev"] = rev
        _last["t"] = now
        _redraw_all()
    return 0.016 if now < _anim["until"] else (0.05 if lively else 0.25)


def _drawer_toggled(self, context):
    _redraw_all()


# ---------------------------------------------------------------------------

_classes = (AgentModelItem, AGENT_OT_ui_mouse, AGENT_OT_ui_scroll, AGENT_OT_ui_key, AGENT_OT_ui_compose,
            AGENT_OT_chat_continue, AGENT_OT_open_workspace, AGENT_OT_open_window, AGENT_OT_toggle_bar,
            AGENT_OT_toggle_chat)
_registered = []
_handles = []
_keymaps = []


def _register_keymap():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc is None:
        return
    # The Agent editor's own keymap, and in the Text Editor's (add-on items come first
    # there; each operator passes the event on unless the area is the chat).
    if has_agent_space():
        _fill_keymap(kc.keymaps.new(name="Agent", space_type=SPACE, region_type='WINDOW'))
    _fill_keymap(kc.keymaps.new(name="Text", space_type='TEXT_EDITOR', region_type='WINDOW'))
    # The viewport bar: mouse and keys over it only (each operator passes the rest on).
    _fill_keymap(kc.keymaps.new(name="3D View", space_type='VIEW_3D', region_type='WINDOW'), typing=False)


def _fill_keymap(km, typing=True):
    add = km.keymap_items.new
    items = [
        add("agent.ui_mouse", 'MOUSEMOVE', 'ANY'),
        add("agent.ui_mouse", 'LEFTMOUSE', 'PRESS'),
        add("agent.ui_mouse", 'LEFTMOUSE', 'RELEASE'),
        add("agent.ui_scroll", 'WHEELUPMOUSE', 'PRESS'),
        add("agent.ui_scroll", 'WHEELDOWNMOUSE', 'PRESS'),
        add("agent.ui_scroll", 'TRACKPADPAN', 'ANY'),
        add("agent.ui_scroll", 'TRACKPADZOOM', 'ANY'),
        add("agent.ui_mouse", 'MIDDLEMOUSE', 'PRESS'),
    ]
    items[0].properties.action = 'MOVE'
    items[1].properties.action = 'CLICK'
    items[2].properties.action = 'RELEASE'
    items[3].properties.lines = 3
    items[4].properties.lines = -3
    items[7].properties.action = 'MIDDLE'
    for key, action in (('ESC', 'ESC'), ('PAGE_UP', 'PAGE_UP'), ('PAGE_DOWN', 'PAGE_DOWN'),
                        ('HOME', 'TOP'), ('END', 'BOTTOM')):
        add("agent.ui_key", key, 'PRESS').properties.action = action
    add("agent.ui_key", 'C', 'PRESS', ctrl=True).properties.action = 'COPY'
    add("agent.ui_mouse", 'LEFTMOUSE', 'DOUBLE_CLICK').properties.action = 'DOUBLE'
    if typing:  # a viewport's keys are its shortcuts: there the box is entered by clicking it
        add("agent.ui_compose", 'TEXTINPUT', 'ANY')
        add("agent.ui_compose", 'V', 'PRESS', ctrl=True)
        add("agent.ui_compose", 'RET', 'PRESS')
        add("agent.ui_compose", 'TAB', 'PRESS')
    _keymaps.append(km)


@bpy.app.handlers.persistent
def _after_load(*_args):
    D.recover_fonts()  # a file opened: fonts by role start fresh (cheap; they load when drawn)


def register():
    fork = has_agent_space()
    bpy.types.WindowManager.agent_ui_drawer = bpy.props.BoolProperty(
        name="Sessions", description="Show past conversations", default=False, update=_drawer_toggled)
    for cls in _classes + ((AGENT_HT_header,) if fork else ()):
        bpy.utils.register_class(cls)
        _registered.append(cls)
    bpy.types.WindowManager.agent_opencode_models = bpy.props.CollectionProperty(type=AgentModelItem)
    bpy.types.WindowManager.agent_codex_models = bpy.props.CollectionProperty(type=AgentModelItem)
    bpy.app.timers.register(_fill_opencode_models, first_interval=1.0, persistent=True)
    bpy.app.timers.register(_fill_codex_models, first_interval=1.0, persistent=True)
    if fork:
        _handles.append((bpy.types.SpaceAgent, bpy.types.SpaceAgent.draw_handler_add(_draw, (), 'WINDOW', 'POST_PIXEL')))
    _handles.append((bpy.types.SpaceTextEditor,
                     bpy.types.SpaceTextEditor.draw_handler_add(_draw, (), 'WINDOW', 'POST_PIXEL')))
    _handles.append((bpy.types.SpaceView3D,
                     bpy.types.SpaceView3D.draw_handler_add(_draw_bar, (), 'WINDOW', 'POST_PIXEL')))
    header = getattr(bpy.types, "TEXT_HT_header", None)
    if header is not None and _text_header["draw"] is None:
        _text_header["draw"] = header.draw
        header.draw = _text_header_draw
    _register_keymap()
    if _after_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_after_load)
    for name in ("agent", "sandbox"):  # loaded now, not first inside a header's draw
        agent_icon(name)
    bpy.types.VIEW3D_HT_header.append(_view3d_header_button)
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.3, persistent=True)


def unregister():
    if not _registered:
        return
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    bpy.types.VIEW3D_HT_header.remove(_view3d_header_button)
    if _after_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_after_load)
    kc = bpy.context.window_manager.keyconfigs.addon
    for km in _keymaps:
        if kc:
            kc.keymaps.remove(km)
    _keymaps.clear()
    for space, h in _handles:
        space.draw_handler_remove(h, 'WINDOW')
    _handles.clear()
    header = getattr(bpy.types, "TEXT_HT_header", None)
    if header is not None and _text_header["draw"] is not None:
        header.draw = _text_header["draw"]
        _text_header["draw"] = None
    for cls in reversed(_registered):
        bpy.utils.unregister_class(cls)
    _registered.clear()
    del bpy.types.WindowManager.agent_ui_drawer
    del bpy.types.WindowManager.agent_opencode_models
    del bpy.types.WindowManager.agent_codex_models
    if bpy.app.timers.is_registered(_fill_opencode_models):
        bpy.app.timers.unregister(_fill_opencode_models)
    _ui["edit"] = None
    if _icons["previews"] is not None:
        bpy.utils.previews.remove(_icons["previews"])
        _icons["previews"] = None
