# SPDX-License-Identifier: GPL-3.0-or-later
"""
MCP over Streamable HTTP, served from inside Blender.

POST /mcp carries JSON-RPC; replies are plain JSON (no SSE stream is needed
because every tool answers within the request). The HTTP server runs on a
worker thread; all scene work goes through `mainthread`.
"""

import base64
import json
import socket
import sys
import threading
import time
import traceback
import urllib.parse
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import bpy

from . import cancel, changes, guide, history, intercom, mainthread, receipts, undo
from .registry import TOOLS, ToolError

SERVER_NAME = "partymode"
SERVER_VERSION = "0.1.0"
_PROTOCOLS = ("2025-11-25", "2025-06-18", "2025-03-26")
_MAX_BODY = 16 * 1024 * 1024
_CALL_TIMEOUT = 120.0

# When a tool last ran, from any agent (test windows quit after a long idle stretch).
last_activity = time.time()

_httpd: ThreadingHTTPServer | None = None
_thread: threading.Thread | None = None


# ---------------------------------------------------------------------------
# Tool execution.

def _error_result(ex: BaseException) -> dict:
    if isinstance(ex, ToolError):
        return {"data": {"error": str(ex)}, "isError": True}
    tb = getattr(ex, "agent_traceback", None) or traceback.format_exc()
    return {"data": {"error": "{}: {}".format(type(ex).__name__, ex), "traceback": tb[-4000:]},
            "isError": True}


_status = {"text": ""}


def status() -> str:
    """The last status shown (also where the window title can't show it, in stock Blender)."""
    return _status["text"]


def set_status(text: str) -> None:
    """Show agent activity in the window title (native PartyMode builds only)."""
    _status["text"] = text
    agent = getattr(bpy.app, "agent", None)
    if agent is not None:
        try:
            agent.set_status(text)
        except Exception:
            pass


IDLE_STATUS = "connected"


def _run_mutating(tool, args: dict, call_id: str, label: str, client: str = "agent") -> dict:
    """Main-thread body of an edit: change tracking, undo step and history around the handler,
    named after the client that asked for it."""
    history.poll()  # Log manual edits made before this call as the user's.
    set_status(label + "…")
    history.agent_depth += 1
    before = changes.begin()
    try:
        try:
            result = tool.fn(args)
        except BaseException as ex:
            result = _error_result(ex)
        report = changes.end(before)
    finally:
        history.agent_depth -= 1
        set_status(IDLE_STATUS)
    undo_step = None
    if tool.push_undo and report["changed"]:
        name = history.step_name(label, client)
        undo_step = name if undo.push_marked(name) else None
    touched = list(report.get("created_objects", ())) + list(report.get("modified_objects", {}))
    warn = intercom.heads_up(client, touched)
    intercom.renew(client, touched + sorted(intercom.names_in(args)))
    history.mark_seen()
    history.record_agent(call_id, tool.name, label,
                         "failed" if result.get("isError") else "succeeded", report, client=client)
    result["changes"] = report
    result["undo_step"] = undo_step
    if warn:
        result["heads_up"] = warn
    return result


RESEARCH_OK = {"sandbox_add", "sandbox_arrange"}  # what a research turn may still change


def _research_turn(client: str):
    """The chat's own agent's turn with the web: "message" (scene read-only), "auto" or None."""
    if not (client or "").startswith("chat-"):
        return None
    from . import chat
    live = chat.live()
    mode = live.get("research") if live else None
    return "message" if mode is True else mode


def _edit_after_web(client: str):
    """An auto research turn that has read the web asks once before it changes the scene.
    Returns an error result, or None to go on."""
    from . import approvals, chat
    live = chat.live() or {}
    if not live.get("web_used") or live.get("edits_ok"):
        return None
    ok, why = approvals.ask("edit", "change the scene after reading the web this turn",
                            "one OK covers the rest of this turn", client)
    if ok:
        chat._set_live(edits_ok=True)
        return None
    return {"data": {"error": "Not changed: " + why + " Put what you found in the Sandbox instead."}, "isError": True}


def _call_tool(name: str, arguments: dict, meta: dict, client: str = "agent") -> dict:
    result = _call_tool_inner(name, dict(arguments, _client=client), meta, client)
    n = intercom.waiting(client)
    if n and name not in ("read_notes", "post_note", "web_permission"):
        result["notes_waiting"] = "{} note(s) from other agents: read_notes".format(n)
    return result


def _call_tool_inner(name: str, arguments: dict, meta: dict, client: str) -> dict:
    tool = TOOLS.get(name)
    if tool is None:
        raise _RpcError(-32602, "Unknown tool: {}".format(name))
    if not tool.on_main:
        try:
            return tool.fn(dict(arguments))
        except BaseException as ex:
            return _error_result(ex)

    research = _research_turn(client) if tool.mutating and name not in RESEARCH_OK else None
    if research == "message":
        return {"data": {"error": "This is a research turn: the scene is read-only. Put what you find in the "
                                  "Sandbox (sandbox_add with a note, url or image_path; sandbox_arrange to "
                                  "group it); the user attaches what they want to the next message."},
                "isError": True}
    if research == "auto":
        refused = _edit_after_web(client)
        if refused is not None:
            return refused

    if tool.mutating:
        refused = intercom.stop_for_claims(client, name, arguments)
        if refused is not None:
            return refused

    # An edit's `prepare` runs inside its receipt (below), so a retry doesn't redo it.
    if tool.prepare is not None and not tool.mutating:
        try:
            arguments = tool.prepare(dict(arguments))
        except BaseException as ex:
            return _error_result(ex)

    if not tool.mutating:
        args = dict(arguments)
        def read():
            history.poll()
            if name == "render_view":
                set_status("rendering a check view…")
            try:
                return tool.fn(args)
            except BaseException as ex:
                return _error_result(ex)
            finally:
                if name == "render_view":
                    set_status(IDLE_STATUS)
        try:
            return mainthread.run_on_main(read, _CALL_TIMEOUT)
        except mainthread.MainThreadTimeout as ex:
            data = {"error": str(ex)}
            blocked = cancel.busy_report()
            if blocked:
                data["blender_busy"] = blocked
            return {"data": data, "isError": True}

    call_id = str(arguments.get("call_id") or meta.get("agent/call-id") or receipts.new_id())
    label = str(arguments.get("label") or name)[:80]

    def edit(arguments):
        args = {k: v for k, v in arguments.items() if k not in {"call_id", "label"}}
        args["_label"] = label
        return lambda: _run_mutating(tool, args, call_id, label, client)

    def before():
        # Off the main thread: a download, a remesh in a child Blender. Its failure is the edit's.
        try:
            prepared = tool.prepare(dict(arguments))
        except BaseException as ex:
            failed = _error_result(ex)
            return lambda: failed
        return edit(prepared)

    receipt = receipts.run_once(call_id, name, edit(arguments), _CALL_TIMEOUT,
                                before=before if tool.prepare is not None else None)
    if receipt["status"] == "running":
        data = {"call_id": call_id, "status": "running",
                "note": "Still running in Blender. Check call_status with this call_id; "
                        "do not send a new edit."}
        blocked = cancel.busy_report()
        if blocked:
            data["blender_busy"] = blocked
            if blocked.get("stuck"):
                data["note"] = blocked["advice"]
        return {"data": data}
    result = dict(receipt["result"])
    result["receipt"] = {"call_id": call_id, "status": receipt["status"], "replayed": receipt["replayed"]}
    return result


def _to_mcp(result: dict) -> dict:
    payload = dict(result.get("data") or {})
    for key in ("receipt", "changes", "undo_step", "heads_up", "notes_waiting"):
        if key in result and result[key] is not None:
            payload[key] = result[key]
    content = [{"type": "text", "text": json.dumps(payload, ensure_ascii=False, default=str)}]
    for img in result.get("images") or ():
        data, mime = img if isinstance(img, tuple) else (img, "image/png")
        content.append({"type": "image", "mimeType": mime, "data": base64.b64encode(data).decode("ascii")})
    return {"content": content, "isError": bool(result.get("isError"))}


# ---------------------------------------------------------------------------
# JSON-RPC.

class _RpcError(Exception):
    def __init__(self, code: int, message: str):
        super().__init__(message)
        self.code = code


def _tools_list() -> dict:
    tools = []
    for t in TOOLS.values():
        tools.append({
            "name": t.name, "description": t.description, "inputSchema": t.schema,
            "annotations": {"readOnlyHint": not t.mutating, "destructiveHint": t.mutating,
                            "idempotentHint": t.mutating, "openWorldHint": False},
        })
    return {"tools": tools}


def _handle(msg: dict, client: str = "agent"):
    method = msg.get("method")
    params = msg.get("params") or {}
    if method == "initialize":
        asked = params.get("protocolVersion")
        return {
            "protocolVersion": asked if asked in _PROTOCOLS else _PROTOCOLS[0],
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            "instructions": guide.INSTRUCTIONS,
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return _tools_list()
    if method == "tools/call":
        global last_activity
        last_activity = time.time()
        return _to_mcp(_call_tool(params.get("name", ""), params.get("arguments") or {},
                                  params.get("_meta") or {}, client))
    raise _RpcError(-32601, "Method not found: {}".format(method))


def _respond(msg, client="agent"):
    if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0":
        return {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request"}}
    if "id" not in msg:
        return None  # Notification.
    try:
        return {"jsonrpc": "2.0", "id": msg["id"], "result": _handle(msg, client)}
    except _RpcError as ex:
        return {"jsonrpc": "2.0", "id": msg["id"], "error": {"code": ex.code, "message": str(ex)}}
    except Exception as ex:
        traceback.print_exc()
        return {"jsonrpc": "2.0", "id": msg["id"],
                "error": {"code": -32603, "message": "{}: {}".format(type(ex).__name__, ex)}}


# ---------------------------------------------------------------------------
# HTTP.

def _blend_file() -> str:
    try:
        return mainthread.run_on_main(lambda: bpy.data.filepath, 5)
    except Exception:
        return ""


def _origin_ok(origin: str | None) -> bool:
    if not origin:
        return True
    return origin.split("://", 1)[-1].split(":", 1)[0].split("/", 1)[0] in {"localhost", "127.0.0.1", "[::1]"}


class _Handler(BaseHTTPRequestHandler):
    server_version = "PartyMode/" + SERVER_VERSION
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def _send(self, status: int, body: bytes = b"", ctype: str = "application/json", headers=None):
        self.send_response(status)
        if body:
            self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if body:
            self.wfile.write(body)

    def _chat(self, method):
        from . import chat_http
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if 0 < length <= _MAX_BODY else b""
        status, out, ctype = chat_http.handle(method, self.path, self.headers, body, _blend_file)
        self._send(status, out, ctype, headers={"Cache-Control": "no-store"})

    def do_POST(self):
        if self.path.startswith("/chat"):
            return self._chat("POST")
        if self.path.split("?")[0].rstrip("/") != "/mcp":
            return self._send(404)
        if not _origin_ok(self.headers.get("Origin")):
            return self._send(403, b'{"error":"origin not allowed"}')
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > _MAX_BODY:
            return self._send(413 if length > _MAX_BODY else 400)
        try:
            msg = json.loads(self.rfile.read(length))
        except ValueError:
            body = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}
            return self._send(400, json.dumps(body).encode())
        headers = {}
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        named = (query.get("client") or [None])[0]
        session = self.headers.get("Mcp-Session-Id")
        if isinstance(msg, dict) and msg.get("method") == "initialize":
            session = headers["Mcp-Session-Id"] = str(uuid.uuid4())
            intercom.remember_session(session, (msg.get("params") or {}).get("clientInfo"), named)
        client = intercom.identify(session, named, self.headers.get("User-Agent"))
        if isinstance(msg, list):
            replies = [rep for rep in (_respond(one, client) for one in msg) if rep is not None]
            reply = replies or None
        else:
            reply = _respond(msg, client)
        if reply is None:
            return self._send(202, headers=headers)
        self._send(200, json.dumps(reply, ensure_ascii=False).encode("utf-8"), headers=headers)

    def do_GET(self):
        if self.path.startswith("/chat"):
            return self._chat("GET")
        if self.path.split("?")[0].rstrip("/") == "/health":
            return self._send(200, json.dumps({"ok": True, "server": SERVER_NAME}).encode())
        self._send(405, headers={"Allow": "POST"})

    def do_DELETE(self):
        self._send(200)


class _Server(ThreadingHTTPServer):
    """One Blender per port. On Windows SO_REUSEADDR lets a second server bind a port that is
    already listening, and requests then go to either at random; ask for the port exclusively."""
    allow_reuse_address = sys.platform != "win32"

    def server_bind(self):
        if sys.platform == "win32" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def _answers(port: int) -> bool:
    """Whether something already accepts connections on this port."""
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.25):
            return True
    except OSError:
        return False


def start(port: int, tries: int = 1) -> int:
    """Listen on `port`, or the next free one of `tries` ports; returns the port in use."""
    global _httpd, _thread
    if _httpd is not None:
        return _httpd.server_address[1]
    last = None
    for p in range(port, port + max(1, tries)):
        try:
            if _answers(p):   # also catches servers that bound it shareably (older add-on versions)
                raise OSError("port {} is in use".format(p))
            _httpd = _Server(("127.0.0.1", p), _Handler)
            break
        except OSError as ex:
            last = ex
    else:
        set_status("port {} is in use".format(port) if tries <= 1 else
                   "ports {}-{} are in use".format(port, port + tries - 1))
        raise last
    _httpd.daemon_threads = True
    _thread = threading.Thread(target=_httpd.serve_forever, name="partymode-http", daemon=True)
    _thread.start()
    p = _httpd.server_address[1]
    print("PartyMode: MCP listening on http://127.0.0.1:{}/mcp".format(p))
    set_status("ready on port {}".format(p) if p == port else
               "ready on port {} ({} is used by another Blender)".format(p, port))
    return p


def port() -> int | None:
    """The port this Blender's server listens on, or None when it is stopped."""
    return _httpd.server_address[1] if _httpd is not None else None


def stop() -> None:
    global _httpd, _thread
    if _httpd is None:
        return
    set_status("")
    _httpd.shutdown()
    _httpd.server_close()
    _httpd = _thread = None


def is_running() -> bool:
    return _httpd is not None
