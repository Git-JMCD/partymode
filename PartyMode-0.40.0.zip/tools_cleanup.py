# SPDX-License-Identifier: GPL-3.0-or-later
"""
Scene cleanup: what makes a file heavy or hard to read, found (inspect_scene) and fixed in one
undo step (clean_scene). Unused data, duplicate materials and images (Wood.001 next to an
identical Wood), empty collections, material slots no face uses, mesh data named apart from its
object; reported only: default object names, hidden heavy objects. Applying scale is opt-in, as
it changes geometry.
"""

import re

import bpy

from .registry import ToolError, r, tool

_SUFFIX = re.compile(r"^(.*)\.\d{3}$")
_DEFAULT_NAMES = re.compile(r"^(Cube|Sphere|Icosphere|Plane|Cylinder|Cone|Torus|Suzanne|Circle|Grid|Empty|Text|"
                            r"BezierCurve|BezierCircle|NurbsCurve|NurbsPath|Mball|Lattice)(\.\d{3})?$")
# Data kinds whose unused blocks are counted (and purged): the kinds people make and forget.
_KINDS = ("meshes", "materials", "images", "textures", "node_groups", "actions", "curves", "lights",
          "cameras", "worlds", "particles", "grease_pencils")
HEAVY = 50_000   # faces: a hidden object this heavy is worth knowing about
FIXES = ("unused_data", "duplicate_materials", "duplicate_images", "empty_collections", "unused_slots",
         "data_names", "apply_scale")
SAFE = FIXES[:-1]  # all but apply_scale


def _val(v):
    """A socket value as something comparable: numbers rounded, others by their name or text."""
    if isinstance(v, float):
        return round(v, 4)
    if isinstance(v, (int, bool, str)) or v is None:
        return v
    try:
        return tuple(round(float(x), 4) for x in v)
    except (TypeError, ValueError):
        return getattr(v, "name", None) or str(v)


def _material_key(mat):
    """What a material looks like, so an exact copy can be found."""
    if not (mat.use_nodes and mat.node_tree):
        return ("flat", _val(mat.diffuse_color), round(mat.metallic, 4), round(mat.roughness, 4))
    nodes = []
    for n in mat.node_tree.nodes:
        ins = tuple((s.identifier, _val(s.default_value)) for s in n.inputs
                    if hasattr(s, "default_value") and not s.is_linked)
        img = n.image.name if getattr(n, "image", None) else None
        tree = n.node_tree.name if getattr(n, "node_tree", None) else None
        nodes.append((n.name, n.bl_idname, ins, img, tree))
    links = sorted((l.from_node.name, l.from_socket.identifier, l.to_node.name, l.to_socket.identifier)
                   for l in mat.node_tree.links)
    return ("nodes", tuple(sorted(nodes)), tuple(links), mat.blend_method if hasattr(mat, "blend_method") else "")


def _duplicates(coll, key):
    """[(copy, original)]: X.001 that matches an X it was copied from."""
    out = []
    for block in coll:
        m = _SUFFIX.match(block.name)
        if not m or block.library:
            continue
        base = coll.get(m.group(1))
        if base is None or base == block or base.library:
            continue
        try:
            if key(block) == key(base):
                out.append((block, base))
        except (AttributeError, TypeError, ValueError):
            continue
    return out


def _image_key(img):
    if img.packed_file is not None or not img.filepath:
        return ("packed", img.name)  # never the same as another
    return ("file", bpy.path.abspath(img.filepath, library=img.library).lower(), img.colorspace_settings.name)


def _unused():
    out = {}
    for kind in _KINDS:
        coll = getattr(bpy.data, kind, None)
        if coll is None:
            continue
        names = [b.name for b in coll if b.users == 0 and not b.use_fake_user and not b.library]
        if names:
            out[kind] = names
    return out


def _unused_slots(ob):
    """How many of a mesh object's material slots no face uses."""
    if ob.type != 'MESH' or not ob.material_slots or ob.data.library or ob.data.users != 1             or any(s.link == 'OBJECT' for s in ob.material_slots):
        return 0  # a shared mesh, or slots on the object: left alone
    used = set()
    if ob.data.polygons:
        idx = [0] * len(ob.data.polygons)
        ob.data.polygons.foreach_get("material_index", idx)
        used = set(idx)
    return sum(1 for i in range(len(ob.material_slots)) if i not in used)


def _empty_collections(scene):
    out = []

    def walk(c):
        for child in c.children:
            walk(child)
            if not child.objects and not child.children and not child.library:
                out.append(child)
    walk(scene.collection)
    return out


def survey(scene):
    """Everything inspect_scene reports, with the blocks themselves for clean_scene."""
    objs = [o for o in scene.objects if not o.library]
    found = {
        "unused_data": _unused(),
        "duplicate_materials": _duplicates(bpy.data.materials, _material_key),
        "duplicate_images": _duplicates(bpy.data.images, _image_key),
        "empty_collections": _empty_collections(scene),
        "unused_slots": [(o, n) for o in objs if (n := _unused_slots(o))],
        "data_names": [(o, o.data.name) for o in objs if o.type == 'MESH' and o.data.users == 1
                       and not o.data.library and o.data.name != o.name],
        "apply_scale": [(o, tuple(o.scale)) for o in objs if o.type == 'MESH' and o.data.users == 1
                        and any(abs(s - 1.0) > 1e-4 for s in o.scale)],
        "negative_scale": [o for o in objs if any(s < 0 for s in o.scale)],
        "default_names": [o for o in objs if _DEFAULT_NAMES.match(o.name)],
        "hidden_heavy": [(o, len(o.data.polygons)) for o in objs if o.type == 'MESH'
                         and not o.visible_get() and len(o.data.polygons) >= HEAVY],  # hidden, or its collection is
    }
    return found


def _public(found, limit=25):
    def names(items):
        return [i.name if hasattr(i, "name") else i for i in items][:limit]
    unused = found["unused_data"]
    return {
        "unused_data": {k: v[:limit] for k, v in unused.items()},
        "unused_total": sum(len(v) for v in unused.values()),
        "duplicate_materials": [[c.name, b.name] for c, b in found["duplicate_materials"]][:limit],
        "duplicate_images": [[c.name, b.name] for c, b in found["duplicate_images"]][:limit],
        "empty_collections": names(found["empty_collections"]),
        "unused_slots": [[o.name, n] for o, n in found["unused_slots"]][:limit],
        "data_names": [[o.name, d] for o, d in found["data_names"]][:limit],
        "unapplied_scale": [[o.name, [r(v, 3) for v in s]] for o, s in found["apply_scale"]][:limit],
        "negative_scale": names(found["negative_scale"]),
        "default_names": names(found["default_names"]),
        "hidden_heavy": [[o.name, n] for o, n in found["hidden_heavy"]][:limit],
    }


def _summary(p):
    bits = []
    for key, label in (("unused_total", "unused data blocks"), ("duplicate_materials", "duplicate materials"),
                       ("duplicate_images", "duplicate images"), ("empty_collections", "empty collections"),
                       ("unused_slots", "objects with unused material slots"),
                       ("data_names", "meshes named apart from their object"),
                       ("unapplied_scale", "objects with unapplied scale"), ("negative_scale", "negative scales"),
                       ("default_names", "default names"), ("hidden_heavy", "hidden heavy objects")):
        n = p[key] if isinstance(p[key], int) else len(p[key])
        if n:
            bits.append("{} {}".format(n, label))
    return ", ".join(bits) or "Nothing to clean up."


@tool("inspect_scene",
      "Find what makes the file heavy or hard to read (changes nothing): unused data blocks, duplicate "
      "materials and images (Wood.001 identical to Wood), empty collections, material slots no face uses, "
      "meshes named apart from their object, unapplied or negative scale, default names (Cube.003), and "
      "hidden heavy objects. Fix with clean_scene.")
def inspect_scene(args):
    p = _public(survey(bpy.context.scene))
    return {"data": dict(p, summary=_summary(p),
                         fixable_by_clean_scene=[k for k in SAFE if (p.get(k if k != "unused_data" else "unused_total"))],
                         note="Default names and hidden heavy objects are for you to decide: rename or delete "
                              "them with run_python if the user wants.")}


@tool("clean_scene",
      "Tidy the file in one undo step: purge unused data, merge duplicate materials and images into the "
      "originals they were copied from, remove empty collections and material slots no face uses, and "
      "name each mesh after its object. `fix` picks which (default: all of those); add apply_scale to "
      "also apply unapplied scale (changes geometry; single-user meshes only). Run inspect_scene first "
      "and say what will change.",
      {"fix": {"type": "array", "items": {"type": "string", "enum": list(FIXES)},
               "description": "What to fix; default all but apply_scale."}},
      mutating=True)
def clean_scene(args):
    fix = set(args.get("fix") or SAFE)
    unknown = fix - set(FIXES)
    if unknown:
        raise ToolError("Unknown fix: {} (choose from {}).".format(", ".join(sorted(unknown)), ", ".join(FIXES)))
    scene = bpy.context.scene
    found = survey(scene)
    done = {}
    if "duplicate_materials" in fix:
        merged = []
        for copy, base in found["duplicate_materials"]:
            merged.append([copy.name, base.name])
            copy.user_remap(base)
            bpy.data.materials.remove(copy)
        done["duplicate_materials"] = merged
    if "duplicate_images" in fix:
        merged = []
        for copy, base in found["duplicate_images"]:
            merged.append([copy.name, base.name])
            copy.user_remap(base)
            bpy.data.images.remove(copy)
        done["duplicate_images"] = merged
    if "unused_slots" in fix:
        cleaned = []
        for ob, n in found["unused_slots"]:
            used = set()
            if ob.data.polygons:
                idx = [0] * len(ob.data.polygons)
                ob.data.polygons.foreach_get("material_index", idx)
                used = set(idx)
            keep = [i for i in range(len(ob.material_slots)) if i in used]
            remap = {old: new for new, old in enumerate(keep)}
            mats = [(ob.material_slots[i].material, ob.material_slots[i].link) for i in keep]
            if ob.data.polygons:
                ob.data.polygons.foreach_set("material_index", [remap[i] for i in idx])
            ob.data.materials.clear()
            for mat, link in mats:
                ob.data.materials.append(mat)
            cleaned.append([ob.name, n])
        done["unused_slots"] = cleaned
    if "data_names" in fix:
        # Two passes, so a mesh can take a name another mesh in the list gives up (Spade.001 -> Spade).
        pairs = found["data_names"]
        for i, (ob, _old) in enumerate(pairs):
            ob.data.name = "_agent_rename_{}".format(i)
        renamed = []
        for ob, old in pairs:
            ob.data.name = ob.name
            renamed.append([old, ob.data.name])
        done["data_names"] = renamed
    if "apply_scale" in fix:
        applied = []
        for ob, s in found["apply_scale"]:
            with bpy.context.temp_override(selected_editable_objects=[ob], active_object=ob, object=ob):
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            applied.append([ob.name, [r(v, 3) for v in s]])
        done["apply_scale"] = applied
    if "empty_collections" in fix:
        gone = []
        for c in _empty_collections(scene):
            gone.append(c.name)
            bpy.data.collections.remove(c)
        done["empty_collections"] = gone
    if "unused_data" in fix:  # last: the merges above leave more unused data behind
        before = sum(len(v) for v in _unused().values())
        bpy.data.orphans_purge(do_local_ids=True, do_linked_ids=False, do_recursive=True)
        done["unused_data_purged"] = before
    left = _public(survey(scene))
    return {"data": {"done": done, "left": _summary(left),
                     "still_for_you": {k: left[k] for k in ("default_names", "hidden_heavy", "negative_scale",
                                                            "unapplied_scale") if left[k]}}}
