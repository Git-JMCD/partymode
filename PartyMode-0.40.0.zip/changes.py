# SPDX-License-Identifier: GPL-3.0-or-later
"""
Change reports: what an agent call actually did to the file.

Two sources are combined:
- A before/after snapshot of every object and of the names in the main ID
  collections (catches created / deleted / renamed / moved / re-meshed).
- IDs the depsgraph reports as updated while the call ran (catches edits to
  materials, node groups, worlds and other data the snapshot does not hash).
"""

import hashlib

import bpy

# ID collections whose membership is tracked (created / deleted).
_ID_COLLECTIONS = (
    "materials", "meshes", "node_groups", "worlds", "images", "collections",
    "cameras", "lights", "curves", "actions", "textures", "armatures", "texts",
)
SANDBOX_INDEX = ".agent_scrapbook"  # see sandbox.py: its edits are changes too

_updated_ids: set = set()
_tracking = 0


@bpy.app.handlers.persistent
def _on_depsgraph_update(scene, depsgraph):
    if not _tracking:
        return
    for update in depsgraph.updates:
        id_ = update.id
        try:
            original = id_.original
            _updated_ids.add((type(original).__name__, original.name))
        except ReferenceError:
            pass


def register():
    if _on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)


def unregister():
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)


def _mesh_digest(mesh) -> str:
    """Cheap fingerprint of a mesh's topology and vertex positions."""
    import numpy as np
    n = len(mesh.vertices)
    co = np.empty(n * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    h = hashlib.blake2b(digest_size=8)
    h.update(np.round(co, 5).tobytes())
    h.update(bytes(str((n, len(mesh.edges), len(mesh.polygons))), "ascii"))
    return h.hexdigest()


def _props_digest(ob):
    """Custom properties (e.g. agent_intent, user tags): their names and simple values."""
    keys = [k for k in ob.keys() if not k.startswith("_")]
    if not keys:
        return None
    out = []
    for k in sorted(keys):
        v = ob[k]
        out.append((k, v if isinstance(v, (int, float, str, bool)) else repr(type(v))))
    return tuple(out)


def _object_state(ob, mesh_digests: dict) -> dict:
    mw = ob.matrix_world
    state = {
        "type": ob.type,
        "parent": ob.parent.name if ob.parent else None,
        "matrix": tuple(round(v, 5) for row in mw for v in row),
        "data": ob.data.name if ob.data else None,
        "hide": (ob.hide_get(), ob.hide_viewport, ob.hide_render),
        "materials": tuple(s.material.name if s.material else None for s in ob.material_slots),
        "modifiers": tuple((m.name, m.type, m.show_viewport) for m in ob.modifiers),
        "collections": tuple(sorted(c.name for c in ob.users_collection)),
        "props": _props_digest(ob),
    }
    if ob.type == 'MESH' and ob.data is not None:
        key = ob.data.name
        if key not in mesh_digests:
            mesh_digests[key] = _mesh_digest(ob.data)
        state["mesh"] = mesh_digests[key]
    return state


def snapshot() -> dict:
    mesh_digests = {}
    objects = {}
    for ob in bpy.data.objects:
        try:
            objects[ob.name] = _object_state(ob, mesh_digests)
        except ReferenceError:
            pass
    ids = {attr: set(getattr(bpy.data, attr).keys()) for attr in _ID_COLLECTIONS}
    index = bpy.data.texts.get(SANDBOX_INDEX)
    scrap = hashlib.sha1(index.as_string().encode("utf-8")).hexdigest() if index is not None else None
    return {"objects": objects, "ids": ids, "sandbox": scrap}


_FIELD_LABELS = {
    "matrix": "transform", "data": "data", "hide": "visibility",
    "materials": "materials", "modifiers": "modifiers", "mesh": "geometry",
    "parent": "parent", "collections": "collections", "type": "type", "props": "custom properties",
}


def begin():
    global _tracking
    _tracking += 1
    _updated_ids.clear()
    return snapshot()


def end(before: dict) -> dict:
    """Diff against ``before`` and return a JSON-friendly change report."""
    global _tracking
    try:
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        after = snapshot()
    finally:
        _tracking = max(0, _tracking - 1)
    report = diff(before, after)

    # Data edited in place (material node tweaks etc.). Objects are covered by the
    # snapshot above, and the depsgraph also tags objects it merely re-evaluated.
    data_updated = sorted(
        "{}:{}".format(kind, name) for kind, name in _updated_ids
        if kind not in {"Object", "Scene", "ViewLayer", "Collection"}
    )
    _updated_ids.clear()
    if data_updated:
        report["updated_data"] = data_updated[:50]
        report["changed"] = True
    return report


def diff(before: dict, after: dict) -> dict:
    """Compare two snapshots: objects created / modified (which fields) / deleted, data created / deleted."""
    b_obj, a_obj = before["objects"], after["objects"]
    created = sorted(set(a_obj) - set(b_obj))
    deleted = sorted(set(b_obj) - set(a_obj))
    modified = {}
    for name in sorted(set(a_obj) & set(b_obj)):
        fields = [
            _FIELD_LABELS[k] for k in a_obj[name]
            if a_obj[name].get(k) != b_obj[name].get(k)
        ]
        if fields:
            modified[name] = fields

    data_created, data_deleted = {}, {}
    for attr in _ID_COLLECTIONS:
        added = sorted(after["ids"][attr] - before["ids"][attr])
        removed = sorted(before["ids"][attr] - after["ids"][attr])
        if added:
            data_created[attr] = added
        if removed:
            data_deleted[attr] = removed

    report = {
        "created_objects": created,
        "modified_objects": modified,
        "deleted_objects": deleted,
    }
    if before.get("sandbox") != after.get("sandbox"):
        report["sandbox"] = "changed"
    if data_created:
        report["created_data"] = data_created
    if data_deleted:
        report["deleted_data"] = data_deleted
    report["changed"] = bool(created or deleted or modified or data_created or data_deleted
                             or report.get("sandbox"))
    return report
