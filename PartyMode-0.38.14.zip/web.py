# SPDX-License-Identifier: GPL-3.0-or-later
"""
Pulling pictures from the web for the Sandbox, and searching openly licensed images (Openverse).
No bpy here: these run on the server thread, after the user has said yes (approvals.py).

Only https, only public addresses (no localhost or private networks, checked again on every
redirect), only images and SVG, and nothing bigger than MAX_BYTES.
"""

import ipaddress
import json
import socket
import urllib.parse
import urllib.request

MAX_BYTES = 25 * 1024 * 1024
TIMEOUT_S = 20
UA = "PartyMode (Blender add-on; +https://github.com/johnmcclurgdesign/jmcd-lab/tree/main/partymode)"
OPENVERSE = "https://api.openverse.org/v1/images/"
IMAGE_TYPES = ("image/png", "image/jpeg", "image/webp", "image/bmp", "image/tiff", "image/gif", "image/svg+xml")


class WebError(Exception):
    pass


def check_url(url):
    """Raise WebError unless url is https on a public host."""
    parts = urllib.parse.urlsplit(url or "")
    if parts.scheme != "https" or not parts.hostname:
        raise WebError("Only https addresses can be fetched: {!r}".format(url))
    try:
        infos = socket.getaddrinfo(parts.hostname, parts.port or 443, proto=socket.IPPROTO_TCP)
    except OSError as ex:
        raise WebError("Could not find {} ({})".format(parts.hostname, ex)) from None
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if not ip.is_global or ip.is_multicast:
            raise WebError("{} is not a public address, so it is not fetched.".format(parts.hostname))
    return url


class _CheckedRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_opener = urllib.request.build_opener(_CheckedRedirects)


def _get(url, accept="*/*", limit=MAX_BYTES):
    check_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
    try:
        with _opener.open(req, timeout=TIMEOUT_S) as resp:
            ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            size = resp.headers.get("Content-Length")
            if size and size.isdigit() and int(size) > limit:
                raise WebError("That file is {:.0f} MB; the limit is {:.0f} MB.".format(int(size) / 1e6, limit / 1e6))
            chunks, total = [], 0
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit:
                    raise WebError("That file is over {:.0f} MB, the limit.".format(limit / 1e6))
                chunks.append(chunk)
            return b"".join(chunks), ctype, resp.geturl()
    except WebError:
        raise
    except Exception as ex:  # noqa: BLE001 - network errors of every kind become one message
        raise WebError("Could not fetch {}: {}".format(url, ex)) from None


def fetch_image(url):
    """(bytes, kind, extension, final_url) for an image or SVG at url; kind is "image" or "svg"."""
    data, ctype, final = _get(url, accept="image/*,image/svg+xml;q=0.9,*/*;q=0.5")
    head = data[:600].lstrip().lower()
    if ctype == "image/svg+xml" or head.startswith(b"<svg") or (head.startswith(b"<?xml") and b"<svg" in head):
        return data, "svg", ".svg", final
    ext = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/bmp": ".bmp",
           "image/tiff": ".tif", "image/gif": ".gif"}.get(ctype)
    if ext is None:
        magic = {b"\x89PNG": ".png", b"\xff\xd8\xff": ".jpg", b"RIFF": ".webp", b"BM": ".bmp", b"GIF8": ".gif"}
        ext = next((e for sig, e in magic.items() if data.startswith(sig)), None)
    if ext is None:
        raise WebError("That address is not a picture ({}).".format(ctype or "unknown type"))
    return data, "image", ext, final


def search_images(query, license_type="commercial", count=8):
    """Openly licensed images from Openverse: [{id, title, creator, license, license_url, url,
    thumbnail, page, source, width, height}]. license_type: "commercial" (default: CC0, CC BY,
    CC BY-SA and public domain, fine to use in paid work with credit) or "all"."""
    params = {"q": query, "page_size": max(1, min(int(count), 20)), "mature": "false"}
    if license_type == "commercial":
        params["license_type"] = "commercial"
    data, _ctype, _final = _get(OPENVERSE + "?" + urllib.parse.urlencode(params), accept="application/json",
                                limit=4 * 1024 * 1024)
    try:
        results = json.loads(data.decode("utf-8")).get("results") or []
    except ValueError:
        raise WebError("Openverse sent something unexpected.") from None
    out = []
    for r in results:
        lic = (r.get("license") or "").upper()
        version = r.get("license_version") or ""
        out.append({"id": r.get("id"), "title": (r.get("title") or "")[:120], "creator": (r.get("creator") or "")[:80],
                    "license": ("CC0" if lic == "CC0" else ("Public domain" if lic == "PDM" else
                                "CC {} {}".format(lic, version).strip())) if lic else "",
                    "license_url": r.get("license_url") or "", "url": r.get("url") or "",
                    "thumbnail": r.get("thumbnail") or "", "page": r.get("foreign_landing_url") or "",
                    "source": r.get("source") or r.get("provider") or "",
                    "width": r.get("width"), "height": r.get("height")})
    return out


def thumbnail(url, limit=2 * 1024 * 1024):
    """A small preview image's (bytes, mime type), or None."""
    try:
        data, ctype, _final = _get(url, accept="image/jpeg,image/png,*/*;q=0.8", limit=limit)  # image/* alone: 406
    except WebError:
        return None
    if ctype not in IMAGE_TYPES or ctype == "image/svg+xml":
        ctype = "image/png" if data.startswith(b"\x89PNG") else ("image/jpeg" if data.startswith(b"\xff\xd8") else None)
    return (data, ctype) if ctype else None
