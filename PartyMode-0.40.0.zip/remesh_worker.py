# SPDX-License-Identifier: GPL-3.0-or-later
"""
Runs in a child Blender started by `tools_remesh` (blender -b --factory-startup --python this),
never inside the add-on. Loads one mesh from a .blend, runs QuadriFlow on it (after a voxel
remesh to close it, when QuadriFlow refuses it as it is), and writes the result to another
.blend. QuadriFlow can loop forever in C on some meshes, where no stop reaches it; here that only
costs this process, which the parent kills at its time limit or on a stop.

Arguments after "--": <in.blend> <out.blend> <options as JSON>.
The last stdout line starting with MARKER holds the report as JSON.
"""

import json
import sys
import time

import bmesh
import bpy
from mathutils import Matrix

MARKER = "AGENT_BRIDGE_REMESH "


def _quad_share(me) -> float:
    sides = [len(p.vertices) for p in me.polygons]
    return sum(1 for n in sides if n == 4) / len(sides) if sides else 0.0


def _shape(me) -> dict:
    """Edges shared by three or more faces, and separate parts: what QuadriFlow refuses."""
    bm = bmesh.new()
    bm.from_mesh(me)
    nonmanifold = sum(1 for e in bm.edges if len(e.link_faces) > 2)
    seen, parts = set(), 0
    for f in bm.faces:
        if f.index in seen:
            continue
        parts += 1
        stack = [f]
        seen.add(f.index)
        while stack:
            for e in stack.pop().edges:
                for g in e.link_faces:
                    if g.index not in seen:
                        seen.add(g.index)
                        stack.append(g)
    bm.free()
    return {"non_manifold_edges": nonmanifold, "parts": parts}


def _tidy(me):
    """What QuadriFlow refuses: edges under 0.1 mm (it checks in absolute units), degenerate
    faces, loose geometry and flipped normals."""
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=2e-4)
    bmesh.ops.dissolve_degenerate(bm, dist=2e-4, edges=bm.edges[:])
    loose = [e for e in bm.edges if not e.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='EDGES')
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(me)
    bm.free()


def _quadriflow(ob, target) -> bool:
    me = ob.data
    faces = len(me.polygons)
    _tidy(me)
    try:
        res = bpy.ops.object.quadriflow_remesh(mode='FACES', target_faces=target, use_mesh_symmetry=False,
                                               use_preserve_sharp=False, use_preserve_boundary=False,
                                               preserve_attributes=False, smooth_normals=False, seed=0)
    except RuntimeError:
        return False
    return 'FINISHED' in res and len(ob.data.polygons) != faces and _quad_share(ob.data) > 0.5


def main(report: dict) -> None:
    argv = sys.argv[sys.argv.index("--") + 1:]
    src, dst, opts = argv[0], argv[1], json.loads(argv[2])
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob)
    with bpy.data.libraries.load(src) as (_, data_to):
        data_to.meshes = [opts["mesh"]]
    me = data_to.meshes[0]
    ob = bpy.data.objects.new("remesh", me)
    bpy.context.scene.collection.objects.link(ob)
    bpy.context.view_layer.objects.active = ob
    ob.select_set(True)
    # QuadriFlow checks edge lengths in absolute units, so a small shape runs scaled up.
    k = float(opts["scale"])
    me.transform(Matrix.Scale(k, 4))
    target = int(opts["target_faces"])
    t0 = time.monotonic()
    used = None
    if not opts.get("voxel_first") and _quadriflow(ob, target):
        used = "quadriflow"
    else:
        report["refused"] = _shape(ob.data)
        print("AGENT_BRIDGE_STEP voxel", flush=True)
        ob.data.remesh_voxel_size = float(opts["voxel_size"]) * k
        bpy.ops.object.voxel_remesh()
        if _quadriflow(ob, target):
            used = "quadriflow (after a voxel remesh to close it)"
    report["remesh_s"] = round(time.monotonic() - t0, 2)
    if used is None:
        raise RuntimeError("QuadriFlow could not remesh this shape, even after a voxel remesh")
    out = ob.data
    out.transform(Matrix.Scale(1.0 / k, 4))
    out.name = opts["out_name"]
    report.update(used=used, faces=len(out.polygons))
    bpy.data.libraries.write(dst, {out})


if __name__ == "__main__":
    result = {}
    try:
        main(result)
        code = 0
    except Exception as ex:  # every failure goes back to the parent as text
        result["error"] = str(ex).strip() or type(ex).__name__
        code = 2
    sys.stdout.write("\n" + MARKER + json.dumps(result) + "\n")
    sys.stdout.flush()
    sys.exit(code)
