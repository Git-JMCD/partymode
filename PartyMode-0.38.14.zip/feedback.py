# SPDX-License-Identifier: GPL-3.0-or-later
"""
A feedback journal about the add-on itself: bugs, ideas, likes and dislikes that agents (and the
user) note while working, for whoever develops the add-on. It lives in Blender's config folder
(agent_bridge/feedback.json), not in the .blend: scene undo, reverting or closing a file never
touches it, and every agent and every file sees the same journal. Entries keep a stable id
(FB-001), their kind, status and history of updates.
"""

import json
import os
import threading
import time

import bpy

from .registry import ToolError, tool

KINDS = ("bug", "idea", "like", "dislike", "question", "note")
STATUSES = ("open", "confirmed", "fixed", "expected", "wontfix", "unclear")
_lock = threading.Lock()


def path():
    return os.path.join(bpy.utils.user_resource('CONFIG', path="agent_bridge", create=True), "feedback.json")


def _load():
    try:
        with open(path(), encoding="utf-8") as fh:
            return list(json.load(fh))
    except (OSError, ValueError, TypeError):
        return []


def _save(entries):
    tmp = path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(entries, fh, indent=1, ensure_ascii=False)
    os.replace(tmp, path())


def _version():
    from .tools_look import addon_build
    return addon_build()["version"]


@tool("feedback_add",
      "Note feedback about this add-on (agent-blender) for its developers: a bug, an idea, what you "
      "like or dislike, a question. Kept in a journal outside the scene (scene undo or closing the file "
      "never loses it), shared by every agent and file. Give `id` (FB-007) to update an entry: new "
      "details, evidence or a status are added to its history. Use it when the user asks you to keep "
      "feedback, or when a tool misbehaves.",
      {"title": {"type": "string", "minLength": 1, "maxLength": 160},
       "kind": {"type": "string", "enum": list(KINDS), "default": "note"},
       "details": {"type": "string", "maxLength": 6000, "description": "What happened, how to repeat it, "
                                                                       "what you expected."},
       "evidence": {"type": "string", "maxLength": 3000, "description": "Tool results, numbers, call ids."},
       "confidence": {"type": "string", "enum": ["confirmed", "likely", "suspected"]},
       "status": {"type": "string", "enum": list(STATUSES)},
       "id": {"type": "string", "description": "Update this entry instead of adding one."}},
      required=("title",))
def feedback_add(args):
    from . import intercom
    who = intercom.label_for(args.get("_client", "agent"))
    now = time.time()
    with _lock:
        entries = _load()
        if args.get("id"):
            e = next((x for x in entries if x["id"].lower() == args["id"].strip().lower()), None)
            if e is None:
                raise ToolError("No feedback entry {!r}; feedback_list shows them.".format(args["id"]))
            change = {k: args[k] for k in ("title", "kind", "details", "evidence", "confidence", "status") if args.get(k)}
            e.update({k: v for k, v in change.items() if k in ("title", "kind", "confidence", "status")})
            e["history"].append(dict(change, t=now, by=who))
            e["updated"] = now
        else:
            n = max((int(x["id"][3:]) for x in entries if x["id"][3:].isdigit()), default=0) + 1
            e = {"id": "FB-{:03d}".format(n), "t": now, "updated": now, "by": who, "title": args["title"],
                 "kind": args.get("kind", "note"), "status": args.get("status", "open"),
                 "confidence": args.get("confidence", ""), "addon": _version(),
                 "file": os.path.basename(bpy.data.filepath) or "(unsaved)",
                 "history": [{k: args[k] for k in ("details", "evidence") if args.get(k)} | {"t": now, "by": who}]}
            entries.append(e)
        _save(entries)
    return {"data": {"saved": e["id"], "entries": len(entries), "journal": path()}}


@tool("feedback_list",
      "The add-on feedback journal (see feedback_add): every entry with its kind, status and latest "
      "details, newest first. Filter by status or kind; full=true includes each entry's history.",
      {"status": {"type": "string", "enum": list(STATUSES)}, "kind": {"type": "string", "enum": list(KINDS)},
       "full": {"type": "boolean", "default": False}})
def feedback_list(args):
    with _lock:
        entries = _load()
    out = []
    for e in sorted(entries, key=lambda x: -x.get("updated", 0)):
        if args.get("status") and e["status"] != args["status"]:
            continue
        if args.get("kind") and e["kind"] != args["kind"]:
            continue
        last = next((h.get("details") for h in reversed(e["history"]) if h.get("details")), "")
        row = {k: e[k] for k in ("id", "title", "kind", "status", "confidence", "by", "addon", "file")}
        row["latest"] = last[:600]
        if args.get("full"):
            row["history"] = e["history"]
        out.append(row)
    return {"data": {"entries": out, "count": len(out), "journal": path()}}
