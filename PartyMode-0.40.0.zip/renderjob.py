# SPDX-License-Identifier: GPL-3.0-or-later
"""
Background renders: a full render of the scene in a second, hidden Blender, so this one stays
free to work in. The scene is saved as a copy, rendered there with the settings asked for, and
the picture lands in the Sandbox. Jobs sit with the generation jobs, so generation_status,
wait_for_job and cancel_generation work on them too.
"""

import os
import re
import subprocess
import tempfile
import threading
import time
import uuid

import bpy

from . import mainthread, sandbox
from .registry import ToolError, r, tool

_PROGRESS = re.compile(r"Sample (\d+)\s*/\s*(\d+)|Rendering (\d+)\s*/\s*(\d+) samples")
_ENGINES = {"eevee": "BLENDER_EEVEE_NEXT", "cycles": "CYCLES", "workbench": "BLENDER_WORKBENCH"}


def _engine_id(name):
    """Blender's id for an engine name (EEVEE's changed between versions)."""
    if name in (None, "", "current"):
        return None
    want = _ENGINES[name]
    items = {i.identifier for i in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items}
    if want not in items and name == "eevee":
        want = next((i for i in ("BLENDER_EEVEE", "BLENDER_EEVEE_NEXT") if i in items), want)
    return want


def _script(out_path, engine, samples, percent, camera, frame, width, height):
    """What the hidden Blender runs: the settings asked for, then one still render."""
    lines = ["import bpy", "sc = bpy.context.scene"]
    if engine:
        lines.append("sc.render.engine = {!r}".format(engine))
    if samples:
        lines += ["if sc.render.engine == 'CYCLES': sc.cycles.samples = {0}".format(int(samples)),
                  "elif hasattr(sc, 'eevee'): sc.eevee.taa_render_samples = {0}".format(int(samples))]
    if percent:
        lines.append("sc.render.resolution_percentage = {}".format(int(percent)))
    if width and height:
        lines += ["sc.render.resolution_x = {}".format(int(width)), "sc.render.resolution_y = {}".format(int(height))]
    if camera:
        lines.append("sc.camera = bpy.data.objects[{!r}]".format(camera))
    if frame is not None:
        lines.append("sc.frame_set({})".format(int(frame)))
    lines += ["sc.render.image_settings.file_format = 'PNG'",
              "sc.render.filepath = {!r}".format(out_path),
              "bpy.ops.render.render(write_still=True)",
              "print('AGENT_RENDER_DONE', flush=True)"]
    return "\n".join(lines)


def _jobs():
    from . import tools_generate as g
    return g


def start(engine=None, samples=None, percent=None, camera=None, frame=None, width=None, height=None, title=""):
    scene = bpy.context.scene
    cam = bpy.data.objects.get(camera) if camera else scene.camera
    if cam is None or cam.type != 'CAMERA':
        raise ToolError("No camera to render from: give `camera`, or set the scene's camera first.")
    g = _jobs()
    job_id = "render-" + uuid.uuid4().hex[:8]
    folder = os.path.join(tempfile.gettempdir(), "agent_render", job_id)
    os.makedirs(folder, exist_ok=True)
    blend = os.path.join(folder, "scene.blend")
    bpy.ops.wm.save_as_mainfile(filepath=blend, copy=True, relative_remap=True, compress=False)
    out = os.path.join(folder, "render.png")
    eng = _engine_id(engine)
    expr = _script(out, eng, samples, percent, cam.name if camera else None, frame, width, height)
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    # A background Blender (-b) starts no agent server of its own. Blender 5 prints render
    # progress ("Sample 12/64") only with the render log on at info level.
    proc = subprocess.Popen([bpy.app.binary_path, "-b", blend, "--log", "render", "--log-level", "info",
                             "--python-expr", expr], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                            creationflags=flags)
    eng_label = (engine or scene.render.engine.replace("BLENDER_", "").split("_")[0]).lower()
    label = title or "Render · {}{}".format(eng_label, " · {} samples".format(samples) if samples else "")
    job = {"job_id": job_id, "kind": "render", "state": "running", "started": time.time(), "folder": folder,
           "images": [], "meshes": [], "imported": [], "request": {"engine": eng_label, "samples": samples,
                                                                  "camera": cam.name, "frame": frame},
           "progress": "starting", "title": label, "proc": proc, "cancel": lambda: _kill(proc)}
    with g._lock:
        g._jobs[job_id] = job
    threading.Thread(target=_watch, args=(job, out), name="agent-render-" + job_id, daemon=True).start()
    return job


def _kill(proc):
    if proc.poll() is None:
        proc.kill()


def _watch(job, out):
    g = _jobs()
    tail = []
    for line in job["proc"].stdout:
        tail = (tail + [line.rstrip()])[-12:]
        m = _PROGRESS.search(line)
        if m:
            done, total = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
            g._update(job, progress="{}/{} samples".format(done, total), fraction=int(done) / max(1, int(total)))
    code = job["proc"].wait()
    if job.get("state") == "cancelled":
        g._changed.set()
        return
    if code == 0 and os.path.isfile(out):
        g._update(job, images=[out], progress="done")

        def pin():
            item = sandbox.add_image_file(out, job["title"], "render", kind="render")
            g._update(job, state="done", finished=time.time(), sandbox_item=item["id"])
            g._changed.set()
            _redraw()
        mainthread.submit(pin)
    else:
        g._update(job, state="failed", finished=time.time(), error="render failed: " + " | ".join(tail[-4:]))
        g._changed.set()


def _redraw():
    wm = bpy.context.window_manager
    for win in getattr(wm, "windows", ()):
        for area in win.screen.areas:
            area.tag_redraw()


def running():
    g = _jobs()
    with g._lock:
        return [j for j in g._jobs.values() if j.get("kind") == "render" and j["state"] not in g._FINISHED]


def cancel(job_id):
    g = _jobs()
    with g._lock:
        job = g._jobs.get(job_id)
    if job is None or job.get("kind") != "render":
        return False
    job["state"] = "cancelled"
    _kill(job["proc"])
    g._update(job, finished=time.time(), error="cancelled")
    g._changed.set()
    return True


@tool("render_scene",
      "A full render of the scene from its camera (the real look: lighting, materials, render "
      "settings), in a second, hidden Blender, so this one stays free. It lands in the Sandbox "
      "when done. Returns a job_id: wait_for_job waits for it, cancel_generation stops it. Leave "
      "settings out to use the scene's own; engine: eevee, cycles or workbench; samples; "
      "percent (resolution %); width and height (pixels); camera; frame.",
      {"engine": {"type": "string", "enum": ["current", "eevee", "cycles", "workbench"], "default": "current"},
       "samples": {"type": "integer", "minimum": 1, "maximum": 16384},
       "percent": {"type": "integer", "minimum": 1, "maximum": 400},
       "width": {"type": "integer", "minimum": 16, "maximum": 16384},
       "height": {"type": "integer", "minimum": 16, "maximum": 16384},
       "camera": {"type": "string"}, "frame": {"type": "integer"},
       "title": {"type": "string", "description": "The Sandbox card's title."}})
def render_scene(args):
    job = start(args.get("engine"), args.get("samples"), args.get("percent"), args.get("camera"), args.get("frame"),
                args.get("width"), args.get("height"), args.get("title", ""))
    return {"data": {"job_id": job["job_id"], "state": job["state"], "title": job["title"],
                     "next": "wait_for_job(job_id) waits for it; it lands in the Sandbox",
                     "elapsed_s": r(time.time() - job["started"], 1)}}
