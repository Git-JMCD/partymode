# SPDX-License-Identifier: GPL-3.0-or-later
"""
The Sandbox board: an endless canvas where each item stays where it was put.

Board units are pixels at 100% zoom and UI scale 1. x runs right and y runs down, as in Figma; an
item's "pos" is its card's top-left corner and "cw" its card width. Items without a place (added
before the board, or by a tool that gave none) get one next to the others.
"""

from . import sandbox

CARD_W = {"note": 200.0, "image": 180.0, "svg": 180.0, "render": 220.0}
MIN_CW, MAX_CW = 90.0, 900.0
ZMIN, ZMAX = 0.1, 4.0
GAP = 24.0
CAPTION_H = 40.0
NOTE_SIZE = 12.0
NOTE_LINE = 17.0
NOTE_LINES = 14


def card_w(it):
    return min(max(float(it.get("cw") or CARD_W.get(it["kind"], 180.0)), MIN_CW), MAX_CW)


def note_lines(it, cw=None):
    """The note's text broken into lines for a card cw wide (board units)."""
    from . import ui_space
    note = it.get("note", "")
    cw = cw or card_w(it)
    try:
        spans = ui_space._wrap_plain(note, cw - 20.0, NOTE_SIZE)
    except Exception:  # noqa: BLE001 - no fonts (a background run): about 6.6 units a character
        n = max(1, int((cw - 20.0) / 6.6))
        spans, start = [], 0
        while start < len(note):
            spans.append((start, min(len(note), start + n)))
            start += n
    lines = [note[a:b] for a, b in spans] or [""]
    if len(lines) > NOTE_LINES:
        lines = lines[:NOTE_LINES]
        lines[-1] = lines[-1].rstrip() + "…"
    return lines


def card_size(it):
    """(w, h) of an item's card in board units."""
    cw = card_w(it)
    if it["kind"] == "note":
        return cw, 34.0 + NOTE_LINE * len(note_lines(it, cw))
    ar = (it.get("h") or 3) / max(1, it.get("w") or 4)
    return cw, (cw - 8.0) * min(max(ar, 0.2), 3.0) + 4.0 + CAPTION_H


def rect(it, pos=None, size=None):
    """(x0, y0, x1, y1) of a placed card, y down."""
    x, y = pos or it["pos"]
    w, h = size or card_size(it)
    return x, y, x + w, y + h


def _overlaps(a, rects, gap=GAP):
    return any(a[0] < b[2] + gap and a[2] > b[0] - gap and a[1] < b[3] + gap and a[3] > b[1] - gap
               for b in rects)


def free_spot(w, h, near, rects, step=40.0):
    """Top-left of a w x h card as close to `near` (its centre) as there is room, searching
    outward on a grid (nearest first)."""
    cx, cy = near
    x0, y0 = cx - w / 2, cy - h / 2
    for r in range(0, 80):
        ring = [(i, j) for i in range(-r, r + 1) for j in range(-r, r + 1) if max(abs(i), abs(j)) == r]
        ring.sort(key=lambda p: (p[0] * p[0] + 2 * p[1] * p[1], p[0] < 0, p[1] < 0))
        for i, j in ring:
            x, y = x0 + i * step, y0 + j * step
            if not _overlaps((x, y, x + w, y + h), rects):
                return round(x), round(y)
    return round(x0), round(y0)


def bounds(its):
    rs = [rect(i) for i in its if i.get("pos")]
    if not rs:
        return None
    return min(r[0] for r in rs), min(r[1] for r in rs), max(r[2] for r in rs), max(r[3] for r in rs)


def plan_missing(its, near=None):
    """{id: [x, y]} for the items without a place, beside the others (in the order they came
    in), nearest `near` when given. Changes nothing."""
    todo = [i for i in its if not i.get("pos")]
    if not todo:
        return {}
    have = [i for i in its if i.get("pos")]
    placed = [rect(i) for i in have]
    out = {}
    if not placed and len(todo) > 1:
        # A fresh board from an old list: a few columns, newest first, like the old drawer.
        cols = 3 if len(todo) > 4 else 2
        col_h = [0.0] * cols
        for it in reversed(todo):
            w, h = card_size(it)
            c = col_h.index(min(col_h))
            out[it["id"]] = [round(c * (CARD_W["render"] + GAP)), round(col_h[c])]
            col_h[c] += h + GAP
        return out
    if near is None:
        b = bounds(have)
        near = (0.0, 0.0) if b is None else (b[2] + GAP + 120.0, b[1] + 100.0)  # right of the rest
    for it in todo:
        w, h = card_size(it)
        out[it["id"]] = list(free_spot(w, h, near, placed))
        placed.append(rect(it, out[it["id"]], (w, h)))
    return out


def place_missing(near=None):
    """Give every item without a place one (see plan_missing) and save. Returns the ids placed."""
    data = sandbox._load()
    plan = plan_missing(data["items"], near)
    if plan:
        for it in data["items"]:
            if it["id"] in plan:
                it["pos"] = plan[it["id"]]
        sandbox._save(data)
    return list(plan)


def move(item_id, x=None, y=None, width=None, to_front=True):
    """Move or resize one card (and bring it to the front: later items draw on top)."""
    data = sandbox._load()
    it = next((i for i in data["items"] if i["id"] == item_id), None)
    if it is None:
        return None
    if x is not None and y is not None:
        it["pos"] = [round(float(x), 1), round(float(y), 1)]
    if width is not None:
        it["cw"] = round(min(max(float(width), MIN_CW), MAX_CW), 1)
    if to_front:
        data["items"] = [i for i in data["items"] if i["id"] != item_id] + [it]
    sandbox._save(data)
    return it


# ---------------------------------------------------------------------------
# A view of the board: its centre in board units and the zoom. Screen y runs up.

def new_view(cx=0.0, cy=0.0, z=1.0):
    return {"cx": cx, "cy": cy, "z": z}


def to_screen(view, s, pane, x, y):
    k = view["z"] * s
    mx, my = (pane[0] + pane[2]) / 2, (pane[1] + pane[3]) / 2
    return mx + (x - view["cx"]) * k, my - (y - view["cy"]) * k


def to_board(view, s, pane, sx, sy):
    k = view["z"] * s
    mx, my = (pane[0] + pane[2]) / 2, (pane[1] + pane[3]) / 2
    return view["cx"] + (sx - mx) / k, view["cy"] - (sy - my) / k


def zoom_at(view, s, pane, sx, sy, factor):
    """Zoom by factor keeping the board point under (sx, sy) where it is."""
    bx, by = to_board(view, s, pane, sx, sy)
    view["z"] = min(max(view["z"] * factor, ZMIN), ZMAX)
    k = view["z"] * s
    mx, my = (pane[0] + pane[2]) / 2, (pane[1] + pane[3]) / 2
    view["cx"] = bx - (sx - mx) / k
    view["cy"] = by + (sy - my) / k


def fit(view, s, pane, its, top_pad=0.0, most=1.0):
    """Frame every card in the pane (no closer than `most`)."""
    b = bounds(its)
    if b is None:
        view.update(new_view())
        return
    pw = max(1.0, pane[2] - pane[0] - 48 * s)
    ph = max(1.0, pane[3] - pane[1] - 48 * s - top_pad)
    bw, bh = max(1.0, b[2] - b[0]), max(1.0, b[3] - b[1])
    view["z"] = min(max(min(pw / (bw * s), ph / (bh * s), most), ZMIN), ZMAX)
    k = view["z"] * s
    view["cx"] = (b[0] + b[2]) / 2
    view["cy"] = (b[1] + b[3]) / 2 - top_pad / 2 / k  # a little down, clear of the toolbar
