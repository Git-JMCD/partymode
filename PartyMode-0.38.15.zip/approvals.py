# SPDX-License-Identifier: GPL-3.0-or-later
"""
Asking the user before an agent reaches outside Blender: a web search, reading a page, pulling a
picture into the Sandbox. The request shows in the chat (Allow, Allow for this chat, Deny) and
the agent's tool call waits on the server thread for the answer, so Blender keeps running.

On by default; the add-on preferences can switch it off ("Ask before the agent uses the web").
"""

import threading
import time
import uuid

WAIT_S = 300  # an unanswered request is turned down after this long

_lock = threading.Lock()
_pending = []        # requests waiting for an answer, oldest first
_allowed = set()     # scopes (a chat, or a terminal agent's session) allowed the web for the rest of it


ASK = {"on": True}  # the preference, kept here by its update (read off the main thread)
HEADLESS = {"on": False}  # set by serve_blocking: no chat to answer in, so asking can't wait


def asking():
    """Whether requests are asked at all."""
    return ASK["on"]


def who(client):
    """'Claude' for the chat's own agents, the client's name for others."""
    if client and client.startswith("chat-"):
        from . import runners
        key = client[len("chat-"):]
        return runners.RUNNERS[key].label if key in runners.RUNNERS else key
    return client or "An agent"


def _scope(client):
    """What "Allow for this chat" covers: the chat's conversation, or another agent's session."""
    if client and client.startswith("chat-"):
        from . import chat
        live = chat.live()
        return "chat:" + (live["local_id"] if live else "")
    return "client:" + (client or "")


def ask(kind, text, detail="", client="agent", wait=WAIT_S):
    """Ask the user; returns (allowed, reason). Blocks the calling (server) thread, never the main
    one: call it from a tool's `prepare` or from a tool that runs off the main thread."""
    if threading.current_thread() is threading.main_thread():
        raise RuntimeError("approvals.ask must not run on Blender's main thread")
    if not asking():
        return True, "allowed (asking is off)"
    if HEADLESS["on"]:
        return False, ("Not allowed: Blender is running headless, so there is no chat to ask in. "
                       "To let agents use the web here, turn off \"Ask before the agent uses the web\" "
                       "in the PartyMode preferences.")
    scope = _scope(client)
    with _lock:
        if scope in _allowed:
            return True, "allowed for this chat"
    req = {"id": uuid.uuid4().hex[:8], "kind": kind, "text": text, "detail": detail, "who": who(client),
           "client": client, "scope": scope, "t": time.time(), "event": threading.Event(), "answer": None}
    with _lock:
        _pending.append(req)
    _changed()
    from . import chat
    _set_activity(chat, "waiting for your OK")
    try:
        answered = req["event"].wait(wait)
    finally:
        with _lock:
            if req in _pending:
                _pending.remove(req)
        _set_activity(chat, "working")
        _changed()
    if not answered:
        return False, "The user did not answer in time, so it was not done."
    if req["answer"] in ("allow", "chat"):
        return True, "allowed"
    return False, "The user said no. Do not try it again this turn; say what you would have done instead."


def pending():
    with _lock:
        return [dict(r, event=None) for r in _pending]


def answer(req_id, choice):
    """The user's answer: "allow", "chat" (allow for the rest of this chat) or "deny"."""
    with _lock:
        req = next((r for r in _pending if r["id"] == req_id), None)
        if req is None:
            return False
        req["answer"] = choice
        if choice == "chat":
            _allowed.add(req["scope"])
        req["event"].set()
    _changed()
    return True


def forget(scope_prefix=""):
    """Drop "allowed for this chat" (all of it, or one chat's)."""
    with _lock:
        for item in [a for a in _allowed if a.startswith(scope_prefix)]:
            _allowed.discard(item)


def deny_all():
    """Turn down everything waiting (Stop, quitting)."""
    with _lock:
        for r in _pending:
            r["answer"] = "deny"
            r["event"].set()


def _set_activity(chat, text):
    try:
        with chat.S.lock:
            if chat.S.live:
                chat.S.live["activity"] = text
    except AttributeError:
        pass


def _changed():
    from . import chat
    chat.S.revision += 1  # the chat redraws on its next tick
