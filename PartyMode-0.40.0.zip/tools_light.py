# SPDX-License-Identifier: GPL-3.0-or-later
"""
Lighting presets in one call: studio (key, fill and rim area lights sized to the subject), golden
hour, noon, overcast and night (a sky and a sun lamp). The light's direction is given the way a
photographer says it, around the subject from the camera (0 = from behind the camera, 90 = from
its right, 180 = backlight), so the shadows fall where asked. Everything lives in an "Agent
Lighting" collection and world, replaced on the next call; the user's own lights are kept (or
hidden, when asked) and nothing else is touched. One undo step.
"""

import math

import bpy
from mathutils import Vector

from .registry import ToolError, r, tool, vec, world_bounds

COLL = "Agent Lighting"
_RENDERABLE = {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META', 'CURVES', 'POINTCLOUD', 'VOLUME'}

# elevation of the key or sun (deg), its colour temperature (K) and strength, how soft (sun angle, deg).
PRESETS = {
    "studio": {"elevation": 35, "kelvin": 5200, "say": "key, fill and rim lights on a dark grey backdrop"},
    "golden_hour": {"elevation": 9, "kelvin": 2600, "sun": 4.5, "angle": 1.5, "sky": 0.05, "sky_seen": 0.8,
                    "aerosol": 2.0, "say": "a low warm sun and a glowing sky: long soft-edged shadows"},
    "noon": {"elevation": 62, "kelvin": 5600, "sun": 3.6, "angle": 0.6, "sky": 0.07, "sky_seen": 0.9, "aerosol": 1.0,
             "say": "a high white sun and a blue sky: short crisp shadows"},
    "overcast": {"elevation": 55, "kelvin": 6500, "sun": 1.4, "angle": 100, "flat": (0.62, 0.66, 0.72),
                 "sky": 0.8, "say": "an even grey sky: soft shading, almost no shadows"},
    "night": {"elevation": 35, "kelvin": 9000, "sun": 0.35, "angle": 0.6, "flat": (0.010, 0.016, 0.035),
              "sky": 1.0, "say": "cool moonlight under a dark blue sky"},
}


def _kelvin_rgb(k):
    """Linear RGB of a colour temperature (an approximation of the black-body curve), max 1."""
    t = k / 100.0
    red = 255 if t <= 66 else 329.698727446 * ((t - 60) ** -0.1332047592)
    green = (99.4708025861 * math.log(t) - 161.1195681661) if t <= 66 else 288.1221695283 * ((t - 60) ** -0.0755148492)
    blue = 255 if t >= 66 else (0 if t <= 19 else 138.5177312231 * math.log(t - 10) - 305.0447927307)
    srgb = [min(max(c, 0.0), 255.0) / 255.0 for c in (red, green, blue)]
    lin = [c ** 2.2 for c in srgb]
    top = max(lin) or 1.0
    return tuple(c / top for c in lin)


def _subject(scene, names):
    if names:
        obs = []
        for n in names:
            ob = bpy.data.objects.get(n)
            if ob is None:
                raise ToolError("No object named {!r}.".format(n))
            obs.append(ob)
            obs.extend(c for c in ob.children_recursive if c.type in _RENDERABLE)
    else:
        obs = [ob for ob in scene.objects if ob.type in _RENDERABLE and ob.visible_get() and not ob.hide_render]
    dg = bpy.context.evaluated_depsgraph_get()
    lo = hi = None
    for ob in obs:
        b = world_bounds(ob, dg)
        if b is None:
            continue
        lo = b[0].copy() if lo is None else Vector(map(min, lo, b[0]))
        hi = b[1].copy() if hi is None else Vector(map(max, hi, b[1]))
    if lo is None:
        return Vector((0, 0, 0)), 1.0, Vector((0, 0, 0))
    centre = (lo + hi) / 2
    return centre, max((hi - lo).length / 2, 0.05), Vector((centre.x, centre.y, lo.z))


def _camera_heading(scene, centre):
    """Compass direction (radians, 0 = +Y, 90 deg = +X) from the subject towards the camera, on the ground."""
    cam = scene.camera
    if cam is not None:
        d = cam.matrix_world.translation - centre
        if Vector((d.x, d.y)).length > 1e-6:
            return math.atan2(d.x, d.y), cam.name
    return math.atan2(0.0, -1.0), None  # no camera: as seen from the front (-Y)


def _direction(heading, elevation):
    """Unit vector from the subject towards the light."""
    return Vector((math.sin(heading) * math.cos(elevation), math.cos(heading) * math.cos(elevation),
                   math.sin(elevation)))


def _clear(scene):
    """This scene's own lighting collection, emptied (each scene gets its own, so lighting one leaves
    the others as they are)."""
    coll = next((c for c in scene.collection.children if c.get("agent_lighting")), None)
    if coll is None:
        coll = bpy.data.collections.new(COLL)
        coll["agent_lighting"] = True
        scene.collection.children.link(coll)
    for ob in list(coll.objects):
        data = ob.data
        bpy.data.objects.remove(ob)
        if data is not None and data.users == 0:
            bpy.data.lights.remove(data)
    return coll


def _lamp(coll, name, kind, colour, energy, towards, origin, **extra):
    data = bpy.data.lights.new(name, kind)
    data.color = colour
    data.energy = energy
    for k, v in extra.items():
        setattr(data, k, v)
    ob = bpy.data.objects.new(name, data)
    coll.objects.link(ob)
    ob.location = origin
    # A lamp shines down its -Z: point +Z back at where the light comes from.
    ob.rotation_euler = towards.to_track_quat('Z', 'Y').to_euler()
    return ob


def _world(scene, coll, p, heading, elevation, strength):
    world = scene.world if scene.world is not None and scene.world.get("agent_lighting") else None
    if world is None:
        world = bpy.data.worlds.new(coll.name)
        world["agent_lighting"] = True
    world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputWorld")
    bg = nt.nodes.new("ShaderNodeBackground")
    out.location, bg.location = (200, 0), (0, 0)
    if "flat" in p:
        bg.inputs["Color"].default_value = (*p["flat"], 1.0)
    elif "sky" in p and "sun" in p:
        sky = nt.nodes.new("ShaderNodeTexSky")
        sky.location = (-250, 0)
        sky.sky_type = 'MULTIPLE_SCATTERING'
        sky.sun_disc = False  # the sun lamp gives the sunlight and its shadows
        sky.sun_elevation = elevation
        sky.sun_rotation = heading  # 0 puts the sky's sun towards +Y, 90 deg towards +X: the same compass
        sky.aerosol_density = p.get("aerosol", 1.0)
        nt.links.new(sky.outputs["Color"], bg.inputs["Color"])
        # The scattering sky is bright: the light it casts is set apart from how bright it looks behind
        # the subject, or it would wash out the sun's colour.
        seen = nt.nodes.new("ShaderNodeBackground")
        seen.inputs["Strength"].default_value = p.get("sky_seen", p["sky"]) * strength
        nt.links.new(sky.outputs["Color"], seen.inputs["Color"])
        path = nt.nodes.new("ShaderNodeLightPath")
        mix = nt.nodes.new("ShaderNodeMixShader")
        seen.location, path.location, mix.location = (0, -160), (0, 260), (180, 0)
        out.location = (380, 0)
        nt.links.new(path.outputs["Is Camera Ray"], mix.inputs["Fac"])
        nt.links.new(bg.outputs["Background"], mix.inputs[1])
        nt.links.new(seen.outputs["Background"], mix.inputs[2])
        bg.inputs["Strength"].default_value = p["sky"] * strength
        nt.links.new(mix.outputs["Shader"], out.inputs["Surface"])
        scene.world = world
        return world
    else:  # studio
        bg.inputs["Color"].default_value = (0.05, 0.05, 0.055, 1.0)
    bg.inputs["Strength"].default_value = p.get("sky", 1.0) * strength
    nt.links.new(bg.outputs["Background"], out.inputs["Surface"])
    scene.world = world
    return world


def _shadow_words(light_from):
    """Where shadows fall, as seen from the camera."""
    a = (light_from + 180) % 360  # shadows point away from the light
    names = ["towards the camera", "towards the camera, to the right", "to the right", "away, to the right",
             "away from the camera", "away, to the left", "to the left", "towards the camera, to the left"]
    return names[int(((a + 22.5) % 360) // 45)]


@tool("light_scene",
      "Light the scene from a preset, in one undo step: studio (key, fill and rim area lights sized "
      "to the subject, dark backdrop), golden_hour, noon, overcast, night (a sky and a sun lamp). "
      "light_from_deg says where the key light or sun comes from, around the subject seen from the "
      "camera: 0 from behind the camera (flat front light), 45 front-right (the classic), 90 the "
      "right side, 180 behind the subject (backlight, rim), negative for the left. elevation_deg "
      "overrides the preset's height (low = long shadows). Lights go in an 'Agent Lighting' "
      "collection with their own world; calling again replaces them. The user's lights stay on "
      "unless other_lights='hide'. Look with render_view look=lit.",
      {"preset": {"type": "string", "enum": sorted(PRESETS)},
       "objects": {"type": "array", "items": {"type": "string"}, "maxItems": 64,
                   "description": "The subject to light (default: everything visible)."},
       "light_from_deg": {"type": "number", "minimum": -360, "maximum": 360, "default": 45},
       "elevation_deg": {"type": "number", "minimum": -10, "maximum": 90},
       "strength": {"type": "number", "minimum": 0.01, "maximum": 20, "default": 1.0},
       "other_lights": {"type": "string", "enum": ["keep", "hide"], "default": "keep"}},
      required=("preset",), mutating=True)
def light_scene(args):
    scene = bpy.context.scene
    name = args["preset"]
    if name not in PRESETS:
        raise ToolError("Unknown preset {!r}: choose from {}.".format(name, ", ".join(sorted(PRESETS))))
    p = PRESETS[name]
    strength = float(args.get("strength", 1.0))
    light_from = float(args.get("light_from_deg", 45)) % 360
    elevation = math.radians(float(args.get("elevation_deg", p["elevation"])))
    centre, radius, ground = _subject(scene, args.get("objects"))
    cam_heading, cam_name = _camera_heading(scene, centre)
    # Seen from above, the camera's right is a quarter turn clockwise from it, which is -90 on this compass.
    heading = cam_heading - math.radians(light_from)
    towards = _direction(heading, elevation)
    colour = _kelvin_rgb(p["kelvin"])
    coll = _clear(scene)
    made = []
    if name == "studio":
        dist = radius * 3.0
        power = 16.0 * dist * dist * strength
        size = radius * 1.6
        rigs = (("Key", heading, elevation, 1.0, size),
                ("Fill", heading + math.radians(100), math.radians(15), 0.3, size * 1.6),
                ("Rim", heading + math.radians(180), math.radians(40), 0.6, size * 0.6))
        for label, hd, el, share, sz in rigs:
            d = _direction(hd, el)
            ob = _lamp(coll, "Agent " + label, 'AREA', colour, power * share, d, centre + d * dist,
                       shape='DISK', size=sz)
            made.append({"name": ob.name, "kind": "area", "watts": r(power * share, 1)})
    else:
        ob = _lamp(coll, "Agent Sun", 'SUN', colour, p["sun"] * strength, towards, ground + towards * radius * 4,
                   angle=math.radians(p["angle"]))
        made.append({"name": ob.name, "kind": "sun", "strength": r(p["sun"] * strength, 3), "softness_deg": p["angle"]})
    world = _world(scene, coll, p, heading, elevation, strength)

    others = [ob for ob in scene.objects if ob.type == 'LIGHT' and ob.name not in coll.objects]
    hidden = []
    if args.get("other_lights", "keep") == "hide":
        for ob in others:
            if not ob.hide_render or ob.visible_get():
                ob.hide_render = True
                ob.hide_viewport = True
                hidden.append(ob.name)
    data = {"preset": name, "looks_like": p["say"], "lights": made, "world": world.name,
            "light_from_deg": r(light_from, 1), "elevation_deg": r(math.degrees(elevation), 1),
            "compass_heading_deg": r(math.degrees(heading) % 360, 1),
            "light_direction": vec(-towards, 3),
            "shadows_fall": _shadow_words(light_from) + (" (seen from {})".format(cam_name) if cam_name
                                                         else " (seen from the front: the scene has no camera)"),
            "subject": {"centre": vec(centre, 3), "radius_m": r(radius, 3)},
            "note": "Lighting shows in render_view look=lit; the camera view is render_view view=camera."}
    if hidden:
        data["hidden_lights"] = hidden
    elif others:
        data["your_lights_still_on"] = [ob.name for ob in others if not ob.hide_render][:12]
    return {"data": data}
