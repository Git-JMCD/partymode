# SPDX-License-Identifier: GPL-3.0-or-later
"""
How much of each agent's plan limits is used: the 5-hour and weekly windows.

Claude reports them with every reply (a rate_limit_event in its stream: runners.Claude.parse
hands it here), so they are as fresh as the last Claude turn PartyMode ran; refresh_claude()
sends one tiny message to ask again. Codex writes them into its own session logs
(~/.codex/sessions), including sessions run in its own app or CLI, so they are read from the
newest log. OpenCode's models have no plan windows (local ones have no limit; hosted ones bill
per request). Nothing here touches bpy (read from draws and worker threads).
"""

import json
import os
import subprocess
import threading
import time

WARN = 0.8    # a window this full shows amber; the lead is told to go easy on that helper
FULL = 0.95   # and red

_lock = threading.Lock()
_S = {"claude": None, "codex": None, "codex_checked": 0.0, "refreshing": False, "file": None}


def configure(root):
    """Keep Claude's last report in `root` (the chat's folder), so it survives a restart."""
    path = os.path.join(root, "usage.json")
    with _lock:
        _S["file"] = path
        if _S["claude"] is None:
            try:
                with open(path, encoding="utf-8") as f:
                    _S["claude"] = json.load(f).get("claude")
            except (OSError, ValueError):
                pass


def _window_name(minutes):
    return {300: "5h", 10080: "week"}.get(int(minutes or 0), "{}h".format(round((minutes or 0) / 60)))


def record(key, info):
    """Claude's rate_limit_info, from a reply."""
    windows = []
    for name, w in (("5h", (info.get("unifiedWindows") or {}).get("five_hour")),
                    ("week", (info.get("unifiedWindows") or {}).get("seven_day"))):
        if isinstance(w, dict) and w.get("utilization") is not None:
            windows.append({"name": name, "used": float(w["utilization"]), "resets": w.get("resetsAt"),
                            "status": w.get("status", "")})
    if not windows:
        return
    got = {"windows": windows, "status": info.get("status", ""), "t": time.time()}
    with _lock:
        _S[key] = got
        path = _S["file"]
    if path:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"claude": got}, f)
        except OSError:
            pass


def _codex_dir():
    return os.path.join(os.environ.get("CODEX_HOME") or os.path.join(os.path.expanduser("~"), ".codex"), "sessions")


def _newest_logs(root, n=2):
    """The newest day folders' session logs, newest first (sessions/YYYY/MM/DD/rollout-*.jsonl)."""
    days = []
    try:
        for y in sorted(os.listdir(root), reverse=True)[:2]:
            for mth in sorted(os.listdir(os.path.join(root, y)), reverse=True)[:2]:
                for d in sorted(os.listdir(os.path.join(root, y, mth)), reverse=True)[:n]:
                    days.append(os.path.join(root, y, mth, d))
    except OSError:
        pass
    files = []
    for d in days[:n]:
        try:
            files += [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".jsonl")]
        except OSError:
            pass
    return sorted(files, key=lambda p: os.path.getmtime(p), reverse=True)


def _codex_read():
    for path in _newest_logs(_codex_dir())[:6]:
        try:
            size = os.path.getsize(path)
            with open(path, "rb") as f:
                f.seek(max(0, size - 512 * 1024))
                tail = f.read().decode("utf-8", "replace")
        except OSError:
            continue
        for line in reversed(tail.splitlines()):
            if '"rate_limits"' not in line:
                continue
            try:
                rl = (json.loads(line).get("payload") or {}).get("rate_limits") or {}
            except ValueError:
                continue
            windows = []
            for part in ("primary", "secondary"):
                w = rl.get(part)
                if isinstance(w, dict) and w.get("used_percent") is not None:
                    windows.append({"name": _window_name(w.get("window_minutes")), "used": float(w["used_percent"]) / 100,
                                    "resets": w.get("resets_at"), "status": ""})
            if windows:
                return {"windows": windows, "status": "", "t": os.path.getmtime(path)}
    return None


def get(key):
    """{"windows": [{"name", "used" 0..1, "resets" (unix time)}], "t": when it was seen} or None."""
    if key == "codex":
        now = time.time()
        with _lock:
            fresh = now - _S["codex_checked"] < 15
            if not fresh:
                _S["codex_checked"] = now
        if not fresh:  # the logs: a cheap read, at most every 15 s
            got = _codex_read()
            with _lock:
                _S["codex"] = got
    with _lock:
        got = _S.get(key) if key in ("claude", "codex") else None
        return json.loads(json.dumps(got)) if got else None


def refreshing():
    return _S["refreshing"]


def refresh_claude(exe, env=None, cwd=None, done=None):
    """Ask Claude for its usage now: one tiny message on its smallest model, with no tools, no
    MCP servers and no saved session (a few tokens of the plan). Runs in the background."""
    with _lock:
        if _S["refreshing"] or not exe:
            return False
        _S["refreshing"] = True

    def work():
        try:
            flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            cmd = [exe, "-p", "--output-format", "stream-json", "--verbose", "--model", "haiku", "--tools", "",
                   "--strict-mcp-config", "--no-session-persistence"]
            out = subprocess.run(cmd, input=b"Reply with OK.", capture_output=True, timeout=90, env=env, cwd=cwd,
                                 creationflags=flags)
            for line in out.stdout.decode("utf-8", "replace").splitlines():
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                if isinstance(msg, dict) and msg.get("type") == "rate_limit_event":
                    record("claude", msg.get("rate_limit_info") or {})
        except (OSError, subprocess.SubprocessError):
            pass
        finally:
            _S["refreshing"] = False
            if done:
                done()
    threading.Thread(target=work, name="agent-usage-refresh", daemon=True).start()
    return True


def level(used):
    return "full" if used >= FULL else "warn" if used >= WARN else "ok"


def summary(key):
    """For the team lead: "Codex has used 19% of its 5-hour limit and 3% of its week", or ""."""
    got = get(key)
    if not got:
        return ""
    parts = ["{}% of its {}".format(round(w["used"] * 100), "5-hour limit" if w["name"] == "5h" else
                                    "week" if w["name"] == "week" else w["name"] + " limit")
             for w in got["windows"]]
    text = "used " + " and ".join(parts)
    if any(w["used"] >= WARN for w in got["windows"]):
        text += " (close to its limit: give it only small tasks)"
    return text
