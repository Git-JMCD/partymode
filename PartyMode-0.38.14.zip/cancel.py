# SPDX-License-Identifier: GPL-3.0-or-later
"""
Stopping agent work that has run too long or that the user wants stopped.

Agent scripts run on Blender's main thread, which freezes the UI, so the stop
has to come from another thread: the `stop` MCP tool, the Escape key (polled
from a watcher thread while Blender is the foreground window), or a time limit.
A stop raises `AgentStopped` inside the running script and also sets Blender's
break flag (agent builds) so renders and bakes end too.

A stop can only land between Python bytecodes. While the script is inside one of
Blender's own C operators (bpy.ops...), nothing reaches it until the operator
returns, and some never return (QuadriFlow on a bad mesh). `busy_report` tells the
agent when that has happened. Work that may hang runs in a child Blender instead
(see `tools_remesh`), which a stop or time limit kills outright.
"""

import ctypes
import os
import sys
import threading
import time

import bpy

from . import mainthread


class AgentStopped(BaseException):
    """Raised inside agent code to stop it. BaseException so `except Exception` cannot swallow it."""


_lock = threading.Lock()
_main_id = threading.main_thread().ident
_busy = None          # dict(label, started, deadline, timeout_s, stop_sent) while agent code runs, else None.
_children = {}        # id -> `child` for child processes doing agent work.
_last_stop = None     # Reason of the most recent stop, read by the code that was stopped.
_watcher = None
_watching = False


def _raise_in_main(exc_type) -> None:
    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(_main_id), ctypes.py_object(exc_type))


def _clear_pending() -> None:
    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(_main_id), None)


class running:
    """Context manager around agent code on the main thread: `with cancel.running(label, 60): exec(...)`."""

    def __init__(self, label: str, timeout_s: float | None):
        self.label, self.timeout_s = label, timeout_s

    def __enter__(self):
        global _busy, _last_stop
        with _lock:
            now = time.monotonic()
            _last_stop = None
            _busy = {"label": self.label, "started": now, "timeout_s": self.timeout_s,
                     "deadline": now + self.timeout_s if self.timeout_s else None, "stop_sent": None}
        return self

    def __exit__(self, *exc):
        global _busy
        with _lock:
            _busy = None
            _clear_pending()  # A stop that arrived as the code finished must not hit anything else.
        return False


class child:
    """Context manager around a child process doing agent work, so `stop` can kill it:
    `with cancel.child(label, proc): proc.communicate(timeout=...)`."""

    def __init__(self, label: str, proc):
        self.label, self.proc = label, proc
        self.killed = None  # the stop's reason once `stop` killed it

    def __enter__(self):
        with _lock:
            _children[id(self)] = self
        return self

    def __exit__(self, *exc):
        with _lock:
            _children.pop(id(self), None)
        return False


def _kill_children(reason: str) -> list:
    with _lock:
        kids = list(_children.values())
    for kid in kids:
        kid.killed = reason
        try:
            kid.proc.kill()
        except OSError:
            pass
    return [kid.label for kid in kids]


def stop(reason: str, children: bool = True) -> dict:
    """Stop the agent code running now, if any (and its child processes unless `children` is
    False). Safe from any thread."""
    global _last_stop
    agent = getattr(bpy.app, "agent", None)
    killed = _kill_children(reason) if children else []
    with _lock:
        if _busy is None:
            if killed:
                return {"stopped": True, "label": killed[0], "reason": reason}
            return {"stopped": False, "note": "Nothing of the agent's is running."}
        _last_stop = reason
        _raise_in_main(AgentStopped)
        if _busy["stop_sent"] is None:
            _busy["stop_sent"] = time.monotonic()
        label = _busy["label"]
    if agent is not None:
        try:
            agent.request_break()  # Renders, bakes and simulations check this flag.
        except Exception:
            pass
    return {"stopped": True, "label": label, "reason": reason}


def last_reason() -> str | None:
    return _last_stop


def busy() -> dict | None:
    with _lock:
        if _busy is None:
            return None
        return {"label": _busy["label"], "running_s": round(time.monotonic() - _busy["started"], 1),
                "timeout_s": _busy["timeout_s"],
                "stop_sent_s_ago": None if _busy["stop_sent"] is None
                else round(time.monotonic() - _busy["stop_sent"], 1)}


# A stop reaches Python code within milliseconds. Still busy this long after one was sent means
# the main thread is inside a C operator that may never return.
STUCK_AFTER_STOP_S = 15.0
# Main-thread work that isn't an agent script (render_view, add_asset...) has no time limit of
# its own; past this it is reported as stuck too.
STUCK_OTHER_S = 300.0


def busy_report() -> dict | None:
    """What Blender's main thread is doing, for replies that waited on it (call_status, a
    timed-out call). Says `stuck` with advice when the work is past any chance of stopping."""
    main = mainthread.busy()
    if main is None:
        return None
    script = busy()
    rep = {}
    if main["running_s"] is not None:
        rep["busy_s"] = main["running_s"]
    if script:
        rep.update(running=script["label"], timeout_s=script["timeout_s"])
        if script["stop_sent_s_ago"] is not None:
            rep["stop_sent_s_ago"] = script["stop_sent_s_ago"]
    if main["running_s"] is None:
        # Our job hasn't started: Blender is busy with something else (the user's own operation,
        # a modal dialog, a long load).
        rep["waiting_s"] = main["oldest_waiting_s"]
        if main["oldest_waiting_s"] > STUCK_OTHER_S:
            rep["stuck"] = True
            rep["advice"] = ("Blender has not picked up agent work for {:.0f}s: it is busy with something "
                             "that isn't the agent's (an operation started by hand, a dialog, a long file "
                             "load). Stop polling and tell the user.").format(main["oldest_waiting_s"])
        return rep
    stuck = (script is not None and script["stop_sent_s_ago"] is not None
             and script["stop_sent_s_ago"] > STUCK_AFTER_STOP_S) or \
            (script is None and main["running_s"] > STUCK_OTHER_S)
    if stuck:
        limit = " (its limit was {:.0f}s)".format(script["timeout_s"]) if script and script["timeout_s"] else ""
        rep["stuck"] = True
        rep["advice"] = (
            "Blender's main thread has been busy for {:.0f}s{} and did not respond to the stop. "
            "It is inside one of Blender's own operations (C code), which neither a time limit, stop "
            "nor Escape can interrupt, and it may never finish. Stop polling and sending calls. Tell "
            "the user Blender is frozen by that operation: they can wait, or force-quit Blender and "
            "lose changes since the last save (checkpoints are on disk: list_checkpoints after a "
            "restart).").format(main["running_s"], limit)
    return rep


# ---------------------------------------------------------------------------
# Watcher thread: Escape key and time limits.

def _escape_pressed_in_blender() -> bool:
    if sys.platform != "win32":
        return False
    user32 = ctypes.windll.user32
    if not (user32.GetAsyncKeyState(0x1B) & 0x8000):  # VK_ESCAPE held.
        return False
    hwnd = user32.GetForegroundWindow()
    pid = ctypes.c_ulong()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value == os.getpid()


def _watch():
    while _watching:
        time.sleep(0.05)
        with _lock:
            job = dict(_busy) if _busy else None
        if job is None:
            # A child doing agent work off the main thread (a remesh): Escape ends that too.
            with _lock:
                kids = bool(_children)
            if kids and _escape_pressed_in_blender():
                _kill_children("you pressed Escape")
            continue
        if job["deadline"] is not None and time.monotonic() > job["deadline"]:
            stop("time limit reached", children=False)
        elif job["stop_sent"] is not None:
            # Keep sending until the script ends: a stop that lands while a C operator runs can hit
            # a handler Blender calls from inside it (depsgraph_update_post), which swallows it.
            stop(_last_stop or "stop requested", children=False)
        elif time.monotonic() - job["started"] > 0.3 and _escape_pressed_in_blender():
            stop("you pressed Escape", children=False)


def start_watcher() -> None:
    global _watcher, _watching
    if _watcher is not None:
        return
    _watching = True
    _watcher = threading.Thread(target=_watch, name="agent-bridge-stop-watcher", daemon=True)
    _watcher.start()


def stop_watcher() -> None:
    global _watcher, _watching
    _watching = False
    _watcher = None
